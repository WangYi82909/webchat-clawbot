# -*- coding: utf-8 -*-
import ast
import unittest
from pathlib import Path

import utils


ROOT = Path(__file__).resolve().parent


class UnifiedContextContractTests(unittest.TestCase):
    def test_chat_context_is_fixed_at_60_turns(self):
        source = (ROOT / "chat.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        values = {
            node.targets[0].id: ast.literal_eval(node.value)
            for node in tree.body
            if isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id == "UNIFIED_CONTEXT_TURNS"
        }
        self.assertEqual(values.get("UNIFIED_CONTEXT_TURNS"), 60)
        self.assertNotIn('inst_config.get("context_turns")', source)
        self.assertIn("history_for_llm = _convo_history[-_ctx_entries:]", source)

    def test_decision_does_not_select_context_turns(self):
        source = (ROOT / "decision.py").read_text(encoding="utf-8")
        self.assertNotIn("SELECT user_id, model, context_turns", source)
        self.assertIn("chat.UNIFIED_CONTEXT_TURNS", source)
        self.assertIn("utils.get_context(pool, db_id, uid=uid)", source)

    def test_broadcast_context_filters_internal_entries_and_keeps_60(self):
        source = (ROOT / "main.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        fn = next(
            node for node in tree.body
            if isinstance(node, ast.FunctionDef) and node.name == "_bc_context_messages"
        )
        module = ast.Module(body=[fn], type_ignores=[])
        namespace = {"chat": type("Chat", (), {"UNIFIED_CONTEXT_TURNS": 60})}
        exec(compile(module, str(ROOT / "main.py"), "exec"), namespace)

        history = [{"role": "system", "content": "hidden"}]
        history.extend(
            {"role": "user" if i % 2 == 0 else "assistant", "content": f"m{i}"}
            for i in range(245)
        )
        history.append({"role": "user", "content": "synthetic", "llm_only": True})

        messages = namespace["_bc_context_messages"](history)
        self.assertEqual(len(messages), 120)
        self.assertEqual(messages[0]["content"], "m125")
        self.assertEqual(messages[-1]["content"], "m244")
        self.assertNotIn("hidden", {item["content"] for item in messages})
        self.assertNotIn("synthetic", {item["content"] for item in messages})

    def test_broadcast_loads_the_target_contact_context(self):
        source = (ROOT / "main.py").read_text(encoding="utf-8")
        self.assertIn("utils.get_context(pool, db_id, uid=uid)", source)
        self.assertIn("messages.extend(context_messages)", source)

    def test_wechat_and_qq_use_one_canonical_context_key(self):
        self.assertEqual(
            utils.unified_conversation_uid(12),
            utils.unified_conversation_uid(12),
        )
        self.assertNotIn("qq", utils.unified_conversation_uid(12).lower())
        source = (ROOT / "utils.py").read_text(encoding="utf-8")
        self.assertIn("canonical_uid = unified_conversation_uid(db_id)", source)
        self.assertIn("conversation_uid = unified_conversation_uid(db_id)", source)

    def test_old_channel_histories_merge_without_duplicate_copies(self):
        shared = {"role": "user", "content": "你好", "ts": 1}
        wechat = [
            shared.copy(),
            {"role": "assistant", "content": "在呢", "ts": 2},
        ]
        qq = [
            shared.copy(),
            {"role": "user", "content": "换到QQ了", "ts": 3},
        ]
        merged = utils._merge_context_histories([(wechat, 10), (qq, 20)])
        self.assertEqual([item["content"] for item in merged], [
            "你好", "在呢", "换到QQ了",
        ])


if __name__ == "__main__":
    unittest.main()
