#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量把代码文件中的 gemini-2.5-flash(含手误写法 gemini-2.5-falsh)
替换为 gemini-3.1-flash-lite,并输出改了哪些文件、哪几行。

用法:
    python3 replace_gemini_model.py              # 处理当前目录(直接写入)
    python3 replace_gemini_model.py /path/dir    # 指定目录
    python3 replace_gemini_model.py --dry-run    # 只预览,不写入(建议先跑一遍)
    python3 replace_gemini_model.py --backup     # 写入前为每个文件生成 .bak 备份
"""
import argparse
import re
from pathlib import Path

NEW = "gemini-3.1-flash-lite"

# (?![\w-]) 防止误伤更长的模型名,
# 例如 gemini-2.5-flash-lite 不会被改成 gemini-3.1-flash-lite-lite
PATTERN = re.compile(r"gemini-2\.5-(?:flash|falsh)(?![\w-])")

# 要处理的文件后缀,可按需增删
EXTS = {
    ".html", ".htm", ".php", ".js", ".mjs", ".ts", ".jsx", ".tsx", ".vue",
    ".py", ".json", ".yaml", ".yml", ".css", ".md", ".sql", ".sh",
    ".ini", ".conf", ".txt",
}
EXTRA_FILES = {".env"}  # 无后缀但也要处理的文件名

# 跳过这些目录
SKIP_DIRS = {
    ".git", ".svn", ".hg", "node_modules", "__pycache__",
    "venv", ".venv", "env", "dist", "build", ".idea", ".vscode", "vendor",
}

ENCODINGS = ("utf-8", "gbk", "latin-1")


def read_text(path: Path):
    """读文件并探测编码;二进制文件返回 (None, None)。"""
    data = path.read_bytes()
    if b"\x00" in data:
        return None, None
    for enc in ENCODINGS:
        try:
            return data.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return None, None


def main():
    ap = argparse.ArgumentParser(description="批量替换 gemini 模型名")
    ap.add_argument("root", nargs="?", default=".", help="要处理的目录,默认当前目录")
    ap.add_argument("--dry-run", action="store_true", help="只预览,不写入")
    ap.add_argument("--backup", action="store_true", help="写入前生成 .bak 备份")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    self_path = Path(__file__).resolve()
    changed_files = 0
    changed_lines = 0

    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if path.suffix.lower() not in EXTS and path.name not in EXTRA_FILES:
            continue
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        if path.resolve() == self_path:  # 跳过脚本自身
            continue

        text, enc = read_text(path)
        if text is None or not PATTERN.search(text):
            continue

        lines = text.splitlines(keepends=True)
        hits = []
        for i, line in enumerate(lines, 1):
            new_line, n = PATTERN.subn(NEW, line)
            if n:
                hits.append((i, line, new_line))
                lines[i - 1] = new_line

        try:
            rel = path.relative_to(root)
        except ValueError:
            rel = path
        tag = "[预览] " if args.dry_run else ""
        print(f"\n{tag}{rel}  ({len(hits)} 处)")
        for no, old, new in hits:
            print(f"  行 {no}: {old.rstrip()}")
            print(f"     -> {new.rstrip()}")

        if not args.dry_run:
            if args.backup:
                path.with_name(path.name + ".bak").write_bytes(path.read_bytes())
            # newline="" 保留原有行尾(\n 或 \r\n),不做平台转换
            with path.open("w", encoding=enc, newline="") as f:
                f.write("".join(lines))

        changed_files += 1
        changed_lines += len(hits)

    mode = "(预览模式,未写入)" if args.dry_run else ""
    print(f"\n====== 完成{mode}:共 {changed_files} 个文件、{changed_lines} 行被替换 ======")
    if changed_files == 0:
        print("没有找到包含 gemini-2.5-flash / gemini-2.5-falsh 的文件。")


if __name__ == "__main__":
    main()