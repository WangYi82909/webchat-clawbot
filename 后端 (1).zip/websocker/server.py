"""server.py — 语音通话 WebSocket 服务器 (嵌入版).

入口: `await server.run(pool)`, 由 data/main.py 在 main() 里以 asyncio.create_task
拉起. 共享主进程 aiomysql pool.

业务链:
    浏览器 PCM -> 上行 WS -> ASR (qwen3-asr-flash-realtime)
                                |
                                +--> partial: 推给浏览器实时显示
                                |
                                +--> final: 推给浏览器 + 触发 chat
                                                            |
                                                            v
                                                chat.generate_reply (走用户的
                                                model/persona/计费/记忆)
                                                            |
                                                            v
                                                TTS (cosyvoice-v3.5-plus + 用
                                                户音色 ID) -> mp3 base64 -> WS
                                                            |
                                                            v
                                                浏览器 <audio autoplay>

v2 (2026-05-15) 新增:
  · 余额预检 (MIN_BALANCE_TO_CONNECT, 不够拒绝接通)
  · 计费: ASR 0.008 元/秒 + TTS 0.0006 元/字
  · 间隔模式 (interval): LLM 思考 + TTS 生成期间不喂 ASR, 防止打断
  · 持续模式 (continuous): 现有行为, 任何时候说话都能识别 + 打断
  · 前端通过 {type:'set_mode', mode:'continuous|interval'} 切换, 默认 continuous

v3 (2026-05-16) 计费修复:
  · 删除 ASR 按秒计费 (浏览器持续上送 PCM, 静音也累计, 导致"进入即扣费")
  · TTS 单价 0.0006 → 0.001 元/字 (即 10 元/万字)
  · 用户没说话 = AI 不回复 = 不扣钱
"""
import asyncio
import base64
import json
import logging
import time
import uuid
from typing import Any
from urllib.parse import parse_qs, urlparse

import websockets
from websockets.asyncio.server import ServerConnection, serve

from . import config
from . import asr as asr_mod
from . import tts as tts_mod
from . import chat_bridge
from .auth import authenticate, AuthError


log = logging.getLogger('voice_ws')


# ─── 计费常量 ──────────────────────────────────────────────────────────────
# 接通前最低余额 (元). 不够直接拒绝, 避免接通后讲两句就断 (走 chat.generate_reply 还是要扣的)
MIN_BALANCE_TO_CONNECT = 0.5

# 2026-06-02 删除"语音生成费":
#   旧设计: 平台代用户调 DashScope, 按 TTS 回复字符数收 0.001 元/字 (TTS_RATE_YUAN_PER_CHAR).
#   新版改: 用户填自己的 DashScope API key + voice_id, 语音合成走用户自己账号,
#           平台不再代付 → 也不再收"生成费"。整段语音通话的计费完全交给
#           chat.generate_reply 内部按原来对话计费规则进行 (Token / 角色 / 余额),
#           websocker 这一侧只做接通余额预检 + chat 调用 + 用户 key 直传 TTS。
#   保留 ASR 按秒计费已删除的历史说明 (旧版"进入即扣"问题), 不再恢复。


# ─── 全局并发计数 ──────────────────────────────────────────────────────────
_session_count = 0
_session_lock = asyncio.Lock()


async def _try_acquire_slot() -> bool:
    global _session_count
    async with _session_lock:
        if _session_count >= config.MAX_CONNECTIONS:
            return False
        _session_count += 1
        return True


async def _release_slot() -> None:
    global _session_count
    async with _session_lock:
        _session_count = max(0, _session_count - 1)


# ─── 余额操作 ──────────────────────────────────────────────────────────────
async def _read_balance(pool, uid: int) -> float:
    """读用户当前余额 (元)."""
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute("SELECT balance FROM users WHERE id=%s LIMIT 1", (uid,))
            row = await cur.fetchone()
            if not row:
                return 0.0
            try:
                return float(row['balance'] or 0)
            except (TypeError, ValueError):
                return 0.0


async def _charge_balance_yuan(pool, uid: int, yuan: float) -> tuple[float, float, float]:
    """扣余额. 余额不够时扣到 0 截止 (不让余额变负).

    Returns:
        (before, after, charged)
        · before:  扣费前余额
        · after:   扣费后余额
        · charged: 实际扣减金额 (扣到 0 时可能 < yuan)
    """
    if yuan <= 0:
        return 0.0, 0.0, 0.0

    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT balance FROM users WHERE id=%s LIMIT 1",
                (uid,),
            )
            row = await cur.fetchone()
            if not row:
                return 0.0, 0.0, 0.0
            try:
                before = float(row['balance'] or 0)
            except (TypeError, ValueError):
                before = 0.0
            charged = min(yuan, before)
            after = max(0.0, round(before - charged, 4))
            if charged > 0:
                await cur.execute(
                    "UPDATE users SET balance=%s WHERE id=%s",
                    (after, uid),
                )
                await conn.commit()
            return before, after, charged


# ─── 单条连接的会话 ────────────────────────────────────────────────────────
class Session:
    def __init__(self, ws: ServerConnection, user: dict, pool) -> None:
        self.ws         = ws
        self.user       = user
        self.uid        = int(user['id'])
        self.username   = str(user.get('username') or '')
        self.voice_id   = str(user.get('_voice_id') or '')
        # 2026-06-02 用户自带 DashScope key (auth.authenticate 解密后挂到 user)
        self.dashscope_key = str(user.get('_dashscope_key') or '')
        self.pool       = pool
        self.session_id = 'sess_' + uuid.uuid4().hex[:12]
        self.last_active = time.monotonic()
        self._send_lock = asyncio.Lock()         # 多协程并发 send 时保证整帧
        self._asr: asr_mod.RealtimeASRSession | None = None
        # 同一时刻只跑一个 chat+tts 任务, 避免一句话还没回复完用户又触发了
        self._pipeline_task: asyncio.Task | None = None

        # v2 新增: 模式 + 计费状态
        # mode: 'continuous' (默认, 现有行为) / 'interval' (思考时不听)
        self.mode = 'continuous'
        # pipeline 是否正在跑 (chat 调用 → TTS 推送完成期间)
        # interval 模式下, _on_binary 检查到 busy=True 就丢弃 PCM 不喂 ASR
        self.pipeline_busy = False
        # 余额耗尽标志: 任一次扣费后余额=0 → 断开连接
        self.balance_exhausted = False

    # ── 统一发 JSON (容错) ────────────────────────────────────────
    async def send(self, payload: dict[str, Any]) -> None:
        try:
            async with self._send_lock:
                await self.ws.send(json.dumps(payload, ensure_ascii=False))
        except websockets.exceptions.ConnectionClosed:
            pass

    async def log_to_client(self, level: str, message: str) -> None:
        """实时日志直接推到前端, 用户在页面"事件日志"里能看到."""
        await self.send({'type': 'log', 'level': level, 'message': message})

    # 2026-06-02 已删除 _settle_tts():
    #   语音生成现在走用户自己的 DashScope key, 平台不再收"语音生成费"。
    #   整通语音对话的费用由 chat.generate_reply 内部按对话计费规则结算 ——
    #   若那边判定余额耗尽, generate_reply 会返回 is_error, _run_pipeline 会
    #   据此设置 self.balance_exhausted 并主动断开 (见 _close_if_exhausted)。

    async def _close_if_exhausted(self) -> bool:
        """余额耗尽时主动断开. 返回 True 表示已断开."""
        if not self.balance_exhausted:
            return False
        try:
            await self.send({
                'type': 'error',
                'message': '余额已用完, 通话结束。请到控制台充值后再来。',
            })
            await self.ws.close(1000, 'balance exhausted')
        except Exception:
            pass
        return True

    # ── 主循环 ──────────────────────────────────────────────────
    async def run(self) -> None:
        # ── 余额预检: 不够直接拒绝 ──
        try:
            bal = await _read_balance(self.pool, self.uid)
        except Exception:
            log.exception('[%s] read balance failed', self.session_id)
            bal = 0.0
        if bal < MIN_BALANCE_TO_CONNECT:
            await self.send({
                'type': 'auth_failed',
                'message': (
                    f'余额不足 (当前 ¥{bal:.2f}, 至少需要 ¥{MIN_BALANCE_TO_CONNECT:.2f})。'
                    '请到控制台充值后再来通话。'
                ),
            })
            try:
                await self.ws.close(1008, 'low balance')
            except Exception:
                pass
            log.info('[%s] reject: low balance uid=%d balance=%.4f',
                     self.session_id, self.uid, bal)
            return

        # ASR 真正连通后才能告诉前端 ready。旧逻辑在 ASR 启动前先发 ready，
        # ASR 初始化一旦失败，页面会先显示“通话中”再立刻断开。
        try:
            await self._start_asr()
        except Exception as e:
            log.exception('[%s] start ASR failed', self.session_id)
            await self.send({
                'type': 'fatal_error',
                'stage': 'asr',
                'message': '语音识别服务暂时不可用，正在重试',
                'retryable': True,
            })
            await self.ws.close(1011, 'asr start failed')
            return

        await self.send({
            'type': 'ready',
            'session_id': self.session_id,
            'server_name': config.SERVER_NAME,
            'user': {
                'id':       self.uid,
                'username': self.username,
            },
            'voice_id': self.voice_id,
        })
        await self.log_to_client('ok', f'会话建立, 音色 ID = {self.voice_id}')
        log.info('[%s] session ready, uid=%d username=%s voice=%s balance=%.4f',
                 self.session_id, self.uid, self.username, self.voice_id, bal)

        watchdog = asyncio.create_task(self._idle_watchdog())
        try:
            async for msg in self.ws:
                self.last_active = time.monotonic()
                if isinstance(msg, (bytes, bytearray)):
                    await self._on_binary(bytes(msg))
                else:
                    await self._on_text(msg)
        finally:
            watchdog.cancel()
            if self._asr is not None:
                try:
                    await self._asr.close()
                except Exception:
                    pass
            if self._pipeline_task and not self._pipeline_task.done():
                self._pipeline_task.cancel()
            chat_bridge.drop_user(self.uid)
            log.info('[%s] session end', self.session_id)

    # ── ASR 相关 ────────────────────────────────────────────────
    async def _start_asr(self) -> None:
        self._asr = asr_mod.RealtimeASRSession(
            on_partial=self._on_asr_partial,
            on_final=self._on_asr_final,
            on_event=self._on_asr_event,
            api_key=self.dashscope_key,
            tag=self.session_id,
        )
        await self._asr.start()
        await self.log_to_client('info', 'ASR 已就绪, 可以开始说话')

    async def _on_asr_event(self, evt: str) -> None:
        # speech_started / speech_stopped
        # interval 模式 + pipeline 正在跑: 忽略残留音频产生的语音事件,
        # 否则用户无意的一声"嗯"会让前端从"思考中"跳回"正在说话"
        if self.mode == 'interval' and self.pipeline_busy:
            log.debug('[%s] ignore ASR event "%s" (interval + busy)', self.session_id, evt)
            return
        await self.send({'type': evt})

    async def _on_asr_partial(self, text: str) -> None:
        if self.mode == 'interval' and self.pipeline_busy:
            return
        await self.send({'type': 'partial', 'text': text})

    async def _on_asr_final(self, text: str) -> None:
        # interval 模式 + pipeline 正在跑: 丢弃这条 final.
        # 虽然 _on_binary 已经停喂 PCM, 但 ASR 内部可能还在消化之前缓冲的
        # 音频, 产出的 final 只是残留噪声 / 用户无意的短语, 不应打断当前回复.
        if self.mode == 'interval' and self.pipeline_busy:
            log.info('[%s] drop ASR final while pipeline busy (interval): "%s"',
                     self.session_id, text[:40])
            return

        await self.send({'type': 'final', 'text': text})
        await self.log_to_client('info', f'识别完成: {text[:60]}')

        if await self._close_if_exhausted():
            return

        # 若上一轮 chat+tts 还没完成, 取消之 (用户已经说了新的一句, 老回复废了)
        if self._pipeline_task and not self._pipeline_task.done():
            self._pipeline_task.cancel()
        self._pipeline_task = asyncio.create_task(self._run_pipeline(text))

    # ── chat + tts pipeline ────────────────────────────────────
    async def _run_pipeline(self, user_text: str) -> None:
        self.pipeline_busy = True   # interval 模式: 此期间 _on_binary 会丢 PCM
        try:
            await self.send({'type': 'thinking'})
            await self.log_to_client('info', f'调用 chat 引擎处理: {user_text[:30]}...')

            reply, err = await chat_bridge.respond(self.pool, self.uid, user_text)
            if err:
                await self.log_to_client('err', err)
                await self.send({'type': 'error', 'message': err})
                return

            await self.send({'type': 'reply', 'text': reply})
            await self.log_to_client('ok', f'AI 回复: {reply[:60]}')

            # TTS
            await self.send({'type': 'synthesizing'})
            await self.log_to_client('info', '正在合成语音...')
            try:
                audio = await tts_mod.synthesize(reply, self.voice_id, self.dashscope_key)
            except Exception as e:
                log.exception('[%s] TTS failed', self.session_id)
                await self.log_to_client('err', f'语音合成失败: {e}')
                await self.send({'type': 'tts_error', 'message': str(e)})
                return

            await self.send({
                'type': 'tts_audio',
                'text': reply,
                'audio': base64.b64encode(audio).decode('ascii'),
            })
            await self.log_to_client('ok', f'已推送 {len(audio)} 字节音频')

            # 2026-06-02: 语音生成走用户自己的 DashScope key, 平台不收"生成费",
            # 这里不再扣费; balance_exhausted 由 chat.generate_reply 那条路径触发
            # (它已在 _run_pipeline 上游对 is_error 做了断开处理)。
            await self._close_if_exhausted()

        except asyncio.CancelledError:
            log.info('[%s] pipeline cancelled (用户开始了新一句)', self.session_id)
            raise
        except Exception as e:
            log.exception('[%s] pipeline crashed', self.session_id)
            await self.log_to_client('err', f'内部错误: {e}')
        finally:
            self.pipeline_busy = False

    # ── 上行二进制 = PCM 音频帧 ────────────────────────────────
    async def _on_binary(self, data: bytes) -> None:
        # interval 模式 + pipeline 正在跑 → 丢弃 PCM, 不喂 ASR, 不计字节
        # 这样实现"思考时不听", 避免被打断
        if self.mode == 'interval' and self.pipeline_busy:
            return
        if self._asr is not None:
            await self._asr.feed_audio(data)

    # ── 上行文本 = 控制指令 ────────────────────────────────────
    async def _on_text(self, raw: str) -> None:
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            await self.send({'type': 'error', 'message': '非法 JSON'})
            return

        t = msg.get('type', '')
        if t == 'ping':
            await self.send({'type': 'pong', 'ts': int(time.time())})
        elif t == 'stop':
            log.info('[%s] client stop', self.session_id)
            await self.ws.close(1000, 'client stop')
        elif t == 'set_mode':
            # v2: 切换聆听模式 (continuous / interval)
            new_mode = str(msg.get('mode', '')).strip().lower()
            if new_mode not in ('continuous', 'interval'):
                await self.send({'type': 'error', 'message': '非法 mode: ' + new_mode})
                return
            self.mode = new_mode
            await self.send({'type': 'mode_set', 'mode': new_mode})
            await self.log_to_client('info', f'模式已切换: {new_mode}')
            log.info('[%s] mode set to: %s', self.session_id, new_mode)
        else:
            log.debug('[%s] ignore unknown msg type=%s', self.session_id, t)

    # ── 空闲超时 ────────────────────────────────────────────────
    async def _idle_watchdog(self) -> None:
        try:
            while True:
                await asyncio.sleep(15)
                if time.monotonic() - self.last_active > config.IDLE_TIMEOUT_SEC:
                    log.info('[%s] idle timeout', self.session_id)
                    await self.log_to_client('warn', '空闲超时, 即将断开')
                    try:
                        await self.ws.close(1001, 'idle timeout')
                    except Exception:
                        pass
                    return
        except asyncio.CancelledError:
            pass


# ─── 连接握手 ──────────────────────────────────────────────────────────────
def _extract_token(ws: ServerConnection) -> str:
    raw = getattr(ws, 'request', None)
    path = raw.path if raw is not None else ''
    qs = parse_qs(urlparse(path).query)
    vals = qs.get('token') or []
    return vals[0] if vals else ''


def _make_handler(pool):
    """构造 handler 闭包, 把 pool 透进去."""
    async def handler(ws: ServerConnection) -> None:
        peer = getattr(ws, 'remote_address', None)

        if not await _try_acquire_slot():
            log.warning('reject: too many connections, peer=%s', peer)
            try:
                await ws.send(json.dumps({'type': 'error', 'message': '服务器忙, 请稍后再试'}))
                await ws.close(1013, 'too many connections')
            finally:
                return

        try:
            token = _extract_token(ws)
            if not token:
                await ws.send(json.dumps({'type': 'auth_failed', 'message': '缺少 token'}))
                await ws.close(1008, 'no token')
                return

            try:
                user = await authenticate(pool, token)
            except AuthError as e:
                log.info('auth failed: %s, peer=%s', e, peer)
                try:
                    await ws.send(json.dumps({'type': 'auth_failed', 'message': str(e)}))
                finally:
                    await ws.close(1008, 'auth failed')
                return

            await Session(ws, user, pool).run()

        except websockets.exceptions.ConnectionClosed:
            pass
        except Exception:
            log.exception('handler crashed, peer=%s', peer)
        finally:
            await _release_slot()

    return handler


# ─── 嵌入式入口: 被 main.py 调用 ──────────────────────────────────────────
async def run(pool) -> None:
    """启动 WS 服务并阻塞在 serve() 上. main.py 用 asyncio.create_task 拉起它."""
    config.assert_ready()
    log.info('voice_ws starting on %s:%d, cap=%d, asr=%s, tts=%s',
             config.WS_HOST, config.WS_PORT, config.MAX_CONNECTIONS,
             config.ASR_MODEL, config.TTS_MODEL)

    async with serve(
        _make_handler(pool),
        host=config.WS_HOST,
        port=config.WS_PORT,
        ssl=None,                       # SSL 由 nginx 终结
        ping_interval=25,
        ping_timeout=20,
        max_size=2 ** 20,
    ):
        log.info('voice_ws listening on %s:%d (server_name=%s)',
                 config.WS_HOST, config.WS_PORT, config.SERVER_NAME)
        # 阻塞直到外层 task 被 cancel
        await asyncio.Future()
