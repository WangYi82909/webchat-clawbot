# -*- coding: utf-8 -*-
"""
preset_deepseek.py — DeepSeek 专用系统提示词预设（2026-06-02）

为什么单独成文件
  chat.py 里 system_prompt 是写死的 f-string（同一套喂给所有模型）。本模块把
  "DeepSeek 渠道"那一套**复制出来单独成文件**，由 chat.py 在
  `model.startswith("deepseek-")` 时改用它。chat.py 的内置模板**保持不动**，
  其它模型行为完全不变；要单独给 DeepSeek 调措辞/排布，只改这个文件。

这一份相对内置模板做了什么：**只重排、不改语义 —— 为缓存而"动态靠后"**
  DeepSeek 硬盘缓存按"从第 0 个 token 起的最长相同前缀"命中。系统提示里：
    · 固定规则文字（说话风格 / 响应格式 / 5 种组合 / SYNC-ASYNC / 冲突特别）
      —— 对所有实例、所有轮次**逐字一致**，是真正可被复用的静态前缀；
    · 四个占位符 persona_text / user_persona_block / emoji_block /
      tools_system_block —— **按实例不同**（persona 还随情绪态变），是变化项。
  内置模板把最易变的 persona_text 放在**最顶端**，等于第 0 个 token 就因实例而异，
  对前缀缓存最不利。本预设把**固定文字全部前置**、把**会变的占位符全部后置**
  （越易变的越靠后：tools → emoji → user设定 → persona），让"开头那一长段"
  尽量逐字节稳定 → 抬高 DeepSeek 命中。

  注意：这只优化 system 这段。真正逐轮变化的"时间 / 被动 RAG"本来就不在 system、
  也不在历史里（chat.py 把它们放最后一条 user 消息），所以本文件不碰它们——
  "动态靠后"在本文件的体现 = 预设自身是纯静态规则在前、实例变量在后。

用法（chat.py，已接好）
    import preset_deepseek
    if model.startswith("deepseek-"):
        system_prompt = preset_deepseek.build_system_prompt(
            persona_text=persona_text,
            user_persona_block=user_persona_block,
            emoji_block=emoji_block,
            tools_system_block=tools_system_block,
        )
  模板用 str.format() 渲染：JSON 示例里的花括号写成字面量单花括号 { }，
  只有上面四个具名字段会被替换。
"""

# ── DeepSeek 系统提示词模板（静态规则在前，实例变量在后）────────────────────
# 占位符（str.format 具名替换，均为"按实例固定"、非逐轮动态）：
#   tools_system_block / emoji_block / user_persona_block / persona_text
# 排序原则：固定文字最前 → 变量越易变越靠后（persona 最易变，放最末）。
SYSTEM_PROMPT_TEMPLATE = """\
【说话风格】
- 你是真人, 不是 AI 客服。用手机微信跟对方聊天。
- 一次回复 1-5 句短句, 别长篇大论。
- 自然口语化: 允许"应该""可能""…""?"。
- 别加旁白、动作描写、心理描写, 除非人设要求。
- 别写时间戳, 别说"我去查/我看一下/稍等"这种动作预告。
- 别复述工具返回的字段名或数据结构, 用人话转述。

═══════════════════════════════════════════════════════
【响应格式 · 必须严格遵守】
═══════════════════════════════════════════════════════
每次响应必须是【纯 JSON】, 直接以 {{ 开头, }} 结尾。
不要 markdown 代码块, 不要前后多余文字。

固定两个字段(都必填):
  {{
    "reply": "给用户的话(允许空字符串)",
    "tools": [ {{"name":"工具名", "params":{{...}}}} ]   // 允许 []
  }}

【5 种合法组合】
  ① 纯回复:       {{"reply":"嗯嗯今天好", "tools":[]}}
  ② 查信息(SYNC): {{"reply":"", "tools":[{{"name":"search_memory","params":{{"query":"..."}}}}]}}
  ③ 表情+说话(ASYNC): {{"reply":"哈哈这个好看", "tools":[{{"name":"send_emoji","params":{{"emoji_id":3}}}}]}}
  ④ 只动作不说话: {{"reply":"", "tools":[{{"name":"send_emoji","params":{{"emoji_id":3}}}}]}}
  ⑤ 不回复:       {{"reply":"", "tools":[]}}

⚠ SYNC 工具 + 有 reply 是违规, reply 会被丢弃。
⚠ 工具调用结果会以 [系统·工具结果] 开头的 user 消息回给你, 看到后基于结果回复。

【SYNC vs ASYNC】
- SYNC = 查信息 → reply 必须空 "", 等下一轮系统给你结果再回复
- ASYNC = 后台动作(发表情/写笔记等) → reply 必须有内容, 跟动作并行到达
- 不调工具 → reply 是给用户的话

【冲突】人设语气优先, 这份模板的格式/长短规则优先。
【特别】仅限微信聊天, 不涉及线下见面(除非人设另有描述)。

{tools_system_block}

【角色】
{persona_text}
{user_persona_block}{emoji_block}"""


def build_system_prompt(persona_text: str,
                        user_persona_block: str,
                        emoji_block: str,
                        tools_system_block: str) -> str:
    """按实例字段渲染 DeepSeek 系统提示词。

    入参均为"按实例固定"的静态块；本模板把它们放在末尾、固定规则放在开头，
    使开头一长段对所有实例/轮次逐字节一致，利于 DeepSeek 前缀缓存命中。
    逐轮动态内容（时间 / 被动 RAG）不在此处，由 chat.py 放最后一条 user 消息。
    """
    return SYSTEM_PROMPT_TEMPLATE.format(
        persona_text=persona_text,
        user_persona_block=user_persona_block,
        emoji_block=emoji_block,
        tools_system_block=tools_system_block,
    )
