#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
voice_clone.py — DashScope CosyVoice 克隆 + 合成示例 (v9.3 · 2026-05-11)

PHP api_voice.php 通过 shell_exec 调用:
    python3 voice_clone.py --audio-url <url> --sample-text <text> \
                            --prefix <prefix> --api-key <key> --model cosyvoice-v3.5-plus

输出: stdout 最后一行 JSON
    成功: {"ok": true, "voice_id": "xxx", "sample_mp3_b64": "..."}
    失败: {"ok": false, "error": "原因"}

依赖: pip install dashscope
"""

import sys
import json
import argparse
import base64
import time
import traceback


def emit(obj):
    # 加唯一前缀,PHP 用此前缀定位 JSON 行,避免被 dashscope SDK 的 log 干扰
    sys.stdout.write("__VC_JSON__" + json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--audio-url",   required=True)
    ap.add_argument("--sample-text", required=True)
    ap.add_argument("--prefix",      required=True)
    ap.add_argument("--api-key",     required=True)
    ap.add_argument("--model",       default="cosyvoice-v3.5-plus")
    args = ap.parse_args()

    try:
        import dashscope
        from dashscope.audio.tts_v2 import VoiceEnrollmentService, SpeechSynthesizer
    except ImportError:
        emit({"ok": False, "error": "缺少 dashscope SDK,请: pip install dashscope"})
        return

    dashscope.api_key = args.api_key
    dashscope.base_websocket_api_url = "wss://dashscope.aliyuncs.com/api-ws/v1/inference"
    dashscope.base_http_api_url      = "https://dashscope.aliyuncs.com/api/v1"

    # ── Step 1: 创建音色 ─────────────────────────────────────────────
    try:
        service = VoiceEnrollmentService()
        voice_id = service.create_voice(
            target_model=args.model,
            prefix=args.prefix,
            url=args.audio_url,
        )
    except Exception as e:
        emit({"ok": False, "error": f"创建音色失败: {type(e).__name__}: {e}"})
        return

    if not voice_id:
        emit({"ok": False, "error": "create_voice 未返回 voice_id"})
        return

    # ── Step 2: 轮询状态 ─────────────────────────────────────────────
    deadline = time.time() + 180
    status   = None
    while time.time() < deadline:
        try:
            info   = service.query_voice(voice_id=voice_id)
            status = info.get("status") if isinstance(info, dict) else str(info)
            if status == "OK":
                break
            if status == "UNDEPLOYED":
                emit({"ok": False, "error": "音色处理失败 (UNDEPLOYED): 音频质量不佳或时长不符"})
                return
        except Exception:
            pass
        time.sleep(3)

    if status != "OK":
        emit({"ok": False, "error": f"音色处理超时 (last status={status})"})
        return

    # ── Step 3: 合成示例音频 ─────────────────────────────────────────
    try:
        synthesizer = SpeechSynthesizer(model=args.model, voice=voice_id)
        audio_data  = synthesizer.call(args.sample_text)
        if not audio_data:
            emit({"ok": False, "error": "合成返回空数据"})
            return
    except Exception as e:
        emit({"ok": False, "error": f"合成失败: {type(e).__name__}: {e}"})
        return

    # ── 输出 ────────────────────────────────────────────────────────
    emit({
        "ok":             True,
        "voice_id":       voice_id,
        "sample_mp3_b64": base64.b64encode(audio_data).decode("ascii"),
    })


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        emit({"ok": False, "error": f"脚本异常: {type(e).__name__}: {e}\n{traceback.format_exc()[:400]}"})
