# =============================================================================
# utils.py — 公共工具函数库（全功能架构版）
# =============================================================================
import base64
import random
import time
import json
import os
import re
import importlib.util
import asyncio
import collections
import contextvars
import httpx
from datetime import datetime, timezone, timedelta
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5

PRIV_KEY = None
PUB_KEY  = None

# ─────────────────────────────────────────────────────────────────────────────
# v12.14 (2026-05-15) 修复"日志串用户"
# ─────────────────────────────────────────────────────────────────────────────
# 问题:500 个 message_worker 并发跑同一个 bot 实例,处理多个微信好友的消息;
#       add_temp_log 只按 db_id 隔离 buffer,文本里不带 uid → 同 instance 下
#       多个好友的日志全混在一起,前端看上去"A 用户的话出现在 B 用户日志里"。
# 修复:用 contextvars (asyncio 友好,task 间天然隔离) 让每个 worker 在 task
#       入口 set 当前 uid;add_temp_log 自动从 contextvar 读 uid 拼前缀。
#       原所有 add_temp_log 调用零改动。
# ─────────────────────────────────────────────────────────────────────────────
current_uid_var: contextvars.ContextVar = contextvars.ContextVar('current_uid', default=None)
current_kind_var: contextvars.ContextVar = contextvars.ContextVar('current_kind', default=None)  # 'main' / 'manual_push' / 'proactive' / 'voice' ...

# 北京时区(固定 UTC+8)。datetime.now(_BEIJING_TZ) 取的是绝对时刻再渲染到 +8,
# 不依赖服务器/容器系统时区, 也不存在"双重 +8"。
_BEIJING_TZ = timezone(timedelta(hours=8))
_WEEKDAYS_CN = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']


def get_beijing_time(ts: float | None = None, with_weekday: bool = True) -> str:
    """
    返回北京时间字符串。显式 UTC+8, 不依赖服务器/容器系统时区。

      ts=None       → 当前时刻; 否则把给定的 UTC epoch 秒转成北京时间。
      with_weekday  → True(默认)带中文星期, 与历史调用方格式完全一致;
                      False 只给 'YYYY-MM-DD HH:MM:SS'(消息时间戳前缀用)。

    v?? (2026-06-16) 彻底终结"白天说梦话"的时区反复横跳:
      之前在「显式 +8」和「datetime.now() 信任系统时区」之间来回改——容器实际
      跑在 UTC 时, datetime.now() 比北京慢 8h, 白天被模型当成半夜, 于是装困、说
      晚安。当初担心的"双重 +8"只会发生在旧式 datetime.now()+timedelta(8) 写法上;
      datetime.now(<+8 tzinfo>) 取绝对时刻再渲染, 无论服务器在 UTC / Asia/Shanghai
      / 任何时区结果都对, 不会重复加。
    """
    dt = (datetime.now(_BEIJING_TZ) if ts is None
          else datetime.fromtimestamp(int(ts), _BEIJING_TZ))
    if with_weekday:
        return dt.strftime(f"%Y-%m-%d {_WEEKDAYS_CN[dt.weekday()]} %H:%M:%S")
    return dt.strftime("%Y-%m-%d %H:%M:%S")


async def init_rsa_keys(pool):
    # 挂载 RSA 密钥
    global PRIV_KEY, PUB_KEY
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT config_key, config_value FROM system_config "
                "WHERE config_key IN ('rsa_private', 'rsa_public')"
            )
            rows = await cur.fetchall()
            keys = {row['config_key']: row['config_value'] for row in rows}
            if 'rsa_private' in keys and 'rsa_public' in keys:
                PRIV_KEY = RSA.import_key(keys['rsa_private'])
                PUB_KEY  = RSA.import_key(keys['rsa_public'])
            else:
                print("[系统致命错误] 未能在数据库中找到 RSA 密钥，请确保前端已生成配置。")
                exit(1)

def decrypt_data(encrypted_b64: str) -> str:
    # 私钥解密
    if not encrypted_b64:
        return ""
    try:
        cipher = PKCS1_v1_5.new(PRIV_KEY)
        decrypted = cipher.decrypt(base64.b64decode(encrypted_b64), None)
        return decrypted.decode('utf-8')
    except Exception:
        return ""

def encrypt_data(plain_text: str) -> str:
    # 公钥加密
    if not plain_text:
        return ""
    try:
        cipher = PKCS1_v1_5.new(PUB_KEY)
        encrypted = cipher.encrypt(plain_text.encode('utf-8'))
        return base64.b64encode(encrypted).decode('utf-8')
    except Exception:
        return ""

def generate_client_id() -> str:
    # 生成 client_id
    return f"openclaw-weixin-{int(time.time() * 1000)}-{random.randint(1000, 9999)}"

def generate_x_wechat_uin() -> str:
    # 生成 x-wechat-uin
    return base64.b64encode(str(random.randint(0, 2**32 - 1)).encode('utf-8')).decode('ascii')

## ─────────────────────────────────────────────────────────────────────────
##  v9.8 (2026-05-11):add_temp_log 改异步火忘 + 批量合并
##
##  问题: 老实现每次调用 = SELECT + UPDATE 两次同步 SQL,await 阻塞调用者。
##        chat.py 一次回复 80+ 次 add_temp_log,累计 200~500ms 纯粹是
##        "写日志"占着主线,挤压"拿到回复 → 推送给用户"的时间。
##
##  新版: add_temp_log 不再 await 真正的 DB 写入,而是把日志塞进内存 buffer。
##        后台单例 _flusher_task 每 0.3s 批量 flush 一次:
##        每个实例只做一次 SELECT + UPDATE,N 条日志合并为一次 IO。
##        调用方代价 = list.append() ≈ 微秒级。
##
##  关键不变量:
##  - 调用方仍然 `await utils.add_temp_log(...)`(签名兼容),但 await 立即返回
##  - 顺序保证: 同一实例 buffer 内 append 顺序 == 落库顺序
##  - 进程退出前能否冲走最后一批:本服务是常驻进程,正常运转下不掉日志;
##    crash 场景下丢最后 ≤0.3s 的日志,可以接受
## ─────────────────────────────────────────────────────────────────────────

import collections  # noqa: F401
_log_buffers: dict = {}  # db_id → deque[str]
_log_pool_ref = None                              # 启动时由首次调用注入
_log_flusher_task = None
_log_flush_lock = asyncio.Lock()

# v12.2 (2026-05-12) 监控指标 — 用 stdout 打,运维直接 grep 即可
_log_flush_count       = 0       # 成功 flush 次数
_log_flush_error_count = 0       # flush 失败次数
_log_last_print_at     = 0.0     # 最近一次报告时刻(防刷屏)


async def _flush_logs_loop():
    """后台协程:每 0.3s 批量 flush 所有实例的 log buffer。

    v12.2 (2026-05-12) 加固:不再静默吞异常,所有失败都打 stdout 留痕,
    避免"日志不显示却完全没线索"的死局。
    """
    global _log_flush_count, _log_flush_error_count, _log_last_print_at
    print("[log_flusher] 启动", flush=True)
    try:
        while True:
            try:
                await asyncio.sleep(0.3)
                if not _log_buffers or _log_pool_ref is None:
                    continue
                # 快照并清空 buffer(下一拨日志可以继续 append)
                async with _log_flush_lock:
                    snapshot = {db_id: list(buf) for db_id, buf in _log_buffers.items() if buf}
                    for buf in _log_buffers.values():
                        buf.clear()
                if not snapshot:
                    continue
                # 每个实例一次 SELECT + UPDATE 合并写入
                for db_id, new_lines in snapshot.items():
                    try:
                        async with _log_pool_ref.acquire() as conn:
                            async with conn.cursor() as cur:
                                await cur.execute("SELECT temp_log FROM instances WHERE id=%s", (db_id,))
                                row  = await cur.fetchone()
                                logs = row['temp_log'].split('\n') if row and row['temp_log'] else []
                                logs.extend(new_lines)
                                # v12.16 (2026-05-19) 行数上限从 500 提至 1500
                                #   背景:语音通话每分钟产生 ~70 行日志(听语音/STT/扣费/chat),
                                #         5 分钟通话就把老 chat 日志全部冲掉,部分用户控制台
                                #         看不到对话日志,只看到语音流水。
                                #   1500 行 × 平均 200 字 ≈ 300KB,占 MEDIUMTEXT(16MB) 的 1.8%,
                                #   足够装连续语音通话 30+ 分钟仍保留 chat 历史。
                                if len(logs) > 1500:
                                    logs = logs[-1500:]
                                joined = '\n'.join(logs)
                                # v12.9 (2026-05-12) 取消总字节截断:
                                #   之前为防 TEXT 64KB 溢出,会从最旧的日志开始砍 1/4。
                                #   但用户排查 AI 重复输出时需要完整思维链,截断让日志失去价值。
                                #   正解:必须跑 migration_v12_3_temp_log.sql 把列升到 MEDIUMTEXT
                                #   (16MB)。若没跑这条迁移,这里会让 UPDATE 失败,在下面
                                #   except 里把错误打 stdout 提醒"请跑 migration_v12_3"。
                                await cur.execute(
                                    "UPDATE instances SET temp_log=%s WHERE id=%s",
                                    (joined, db_id)
                                )
                            await conn.commit()
                        _log_flush_count += 1
                    except Exception as e:
                        # 关键修复:不再静默,把错误打 stdout 以便排查
                        _log_flush_error_count += 1
                        # 节流:同样的错可能每 0.3s 触发一次,5s 内只报告 1 次
                        now_ts = time.time()
                        if (now_ts - _log_last_print_at) >= 5.0:
                            err_msg = str(e)
                            # v12.9 1406 = TEXT 列溢出 → 明确提示跑迁移
                            if "1406" in err_msg or "Data too long" in err_msg:
                                print(
                                    f"[log_flusher] db_id={db_id} ★ 列溢出 ★ "
                                    f"请立即执行 migration/migration_v12_3_temp_log.sql "
                                    f"(ALTER temp_log TEXT→MEDIUMTEXT),"
                                    f"不跑这条迁移日志将持续丢失!原始错误: {err_msg[:120]}",
                                    flush=True,
                                )
                            else:
                                print(
                                    f"[log_flusher] db_id={db_id} 写库失败: "
                                    f"{type(e).__name__}: {err_msg[:200]}",
                                    flush=True,
                                )
                            _log_last_print_at = now_ts
            except asyncio.CancelledError:
                # 不吞 CancelledError,让上层正常退出
                raise
            except Exception as e:
                # 任何外层异常也不静默
                import traceback as _tb
                print(
                    f"[log_flusher] 外层循环异常: {type(e).__name__}: {e}",
                    flush=True,
                )
                _tb.print_exc()
                await asyncio.sleep(1.0)   # 防止死循环刷屏
    except asyncio.CancelledError:
        print("[log_flusher] 收到 cancel 信号,退出", flush=True)
        raise
    finally:
        # 不应该走到这里 — 走到这就是 loop 退出了,要让 add_temp_log 下次能重启
        print("[log_flusher] 任务结束(将由下次 add_temp_log 自动重启)", flush=True)


async def add_temp_log(pool, db_id, log_str):
    """
    异步火忘日志:把日志塞进内存 buffer 立即返回,后台批量 flush。
    调用方代价: 微秒级 (list.append),不再阻塞主流程。

    v12.13 (2026-05-12) 恢复 append 写库行为:
      用户反馈 SQL 已经升到 MEDIUMTEXT(16MB),足以容纳完整流水日志,
      不需要覆盖式只存一轮。所有日志按时间顺序追加,前端能看到完整运转流水。
      最近 500 行 + 16MB 列容量足够装几小时甚至几天的实例日志。
      思维链全文也走这里,不截断。
    """
    global _log_pool_ref, _log_flusher_task
    if _log_pool_ref is None and pool is not None:
        _log_pool_ref = pool
    if _log_flusher_task is None or _log_flusher_task.done():
        try:
            _log_flusher_task = asyncio.create_task(_flush_logs_loop())
        except RuntimeError as e:
            print(
                f"[log_flusher] 无法启动后台任务(不在 event loop): {e}",
                flush=True,
            )
    time_str = time.strftime("%H:%M:%S")

    # v12.14: 自动从 contextvar 拼上 uid 前缀, 解决多好友日志混杂问题
    _uid_tag = ''
    try:
        _uid = current_uid_var.get()
        if _uid:
            _kind = current_kind_var.get()
            _uid_tag = f"[uid={_uid}{('·' + _kind) if _kind else ''}] "
    except LookupError:
        pass

    new_log = f"[{time_str}] {_uid_tag}{log_str}"
    if db_id not in _log_buffers:
        _log_buffers[db_id] = collections.deque(maxlen=600)
    _log_buffers[db_id].append(new_log)
    # 旁路:同时打到 stdout,排查时不用进 DB 看
    print(f"[temp_log] [{time_str}] db_id={db_id} {log_str}", flush=True)


async def set_temp_log_overwrite(pool, db_id: int, content: str) -> bool:
    """
    v12.13 (2026-05-12) 重新定位:不再覆盖整列,改为 **append 一个带标记的思维链块**。
    
    名字保留(向后兼容 chat.py 调用方),行为改为追加。content 已经是 chat.py
    拼好的"时间 + 轮次 + 模型 + 思维链 + 回复"完整块。这里加 ═ 包裹标记,
    方便前端"复制最新思维链"按钮用正则抠出最新一段。

    优势:
      - 完整流水日志 + 最新一轮思维链 二者兼得
      - 前端可"复制最新思维链"(用正则抓最后一块)
      - 不丢历史:多轮回复时旧的思维链块也保留,可滚动回看
    """
    if not content:
        return True
    # 直接走 add_temp_log 路径,内容前后加分隔标记
    marked = (
        f"\n{'═' * 40}\n"
        f"┃ 最新一轮思维链 ┃\n"
        f"{'═' * 40}\n"
        f"{content}\n"
        f"{'═' * 40}\n"
    )
    await add_temp_log(pool, db_id, marked)
    return True

_UNIFIED_CONTEXT_PREFIX = "__cloudlove_cross_platform__:"


def unified_conversation_uid(db_id: int) -> str:
    """同一实例的微信、QQ、网页等渠道共用一个上下文身份。"""
    return f"{_UNIFIED_CONTEXT_PREFIX}{int(db_id)}"


def _history_source_timestamp(value) -> float:
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    if hasattr(value, "timestamp"):
        try:
            return float(value.timestamp())
        except Exception:
            return 0.0
    try:
        return float(value)
    except Exception:
        return 0.0


def _merge_context_histories(sources: list[tuple[list, float]]) -> list:
    """合并旧渠道历史，保留同一来源内重复发言并去掉跨表重复副本。"""
    merged = []
    seen_occurrences = set()
    for source_index, (history, source_ts) in enumerate(sources):
        occurrences = collections.Counter()
        for position, message in enumerate(history or []):
            if not isinstance(message, dict):
                continue
            message_id = str(message.get("message_id") or "").strip()
            if message_id:
                base_key = "id:" + message_id
            else:
                base_key = json.dumps(
                    {
                        "role": message.get("role"),
                        "content": message.get("content"),
                        "ts": message.get("ts"),
                    },
                    ensure_ascii=False,
                    sort_keys=True,
                    default=str,
                    separators=(",", ":"),
                )
            occurrences[base_key] += 1
            occurrence_key = (base_key, occurrences[base_key])
            if occurrence_key in seen_occurrences:
                continue
            seen_occurrences.add(occurrence_key)
            msg_ts = _history_source_timestamp(message.get("ts"))
            merged.append((
                msg_ts if msg_ts > 0 else source_ts,
                source_index,
                position,
                message,
            ))
    merged.sort(key=lambda item: (item[0], item[1], item[2]))
    return [item[3] for item in merged]


async def get_context(pool, db_id, uid=None) -> list:
    """读取微信与 QQ 共用的实例上下文。

    首次升级读取时会把 conversation_contexts 中旧微信 UID、旧 QQ openid
    以及 instances.context 合并进一个跨平台键；后续所有渠道都只读写该键。
    表尚未迁移时仍回退 instances.context。
    """
    if uid is not None:
        canonical_uid = unified_conversation_uid(db_id)
        try:
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT context FROM conversation_contexts "
                        "WHERE instance_id=%s AND conversation_uid=%s LIMIT 1",
                        (db_id, canonical_uid),
                    )
                    row = await cur.fetchone()
                    if row is not None:
                        return json.loads(row['context']) if row.get('context') else []

                    # 仅在跨平台键第一次出现时执行一次兼容合并。旧渠道行保留作
                    # 回滚依据，但新消息不会再写入那些隔离键。
                    await cur.execute(
                        "SELECT conversation_uid, context, updated_at "
                        "FROM conversation_contexts WHERE instance_id=%s "
                        "AND conversation_uid<>%s ORDER BY updated_at ASC",
                        (db_id, canonical_uid),
                    )
                    old_rows = list(await cur.fetchall() or [])
                    await cur.execute(
                        "SELECT context, last_heartbeat FROM instances WHERE id=%s",
                        (db_id,),
                    )
                    legacy_row = await cur.fetchone()

                    sources = []
                    for old_row in old_rows:
                        try:
                            old_history = (
                                json.loads(old_row.get('context') or '[]')
                                if old_row.get('context') else []
                            )
                        except Exception:
                            old_history = []
                        if isinstance(old_history, list) and old_history:
                            sources.append((
                                old_history,
                                _history_source_timestamp(old_row.get('updated_at')),
                            ))
                    if legacy_row and legacy_row.get('context'):
                        try:
                            legacy_history = json.loads(legacy_row.get('context') or '[]')
                        except Exception:
                            legacy_history = []
                        if isinstance(legacy_history, list) and legacy_history:
                            sources.append((
                                legacy_history,
                                _history_source_timestamp(legacy_row.get('last_heartbeat')),
                            ))

                    merged_history = _merge_context_histories(sources)
                    merged_json = json.dumps(merged_history, ensure_ascii=False)
                    await cur.execute(
                        "INSERT INTO conversation_contexts "
                        "(instance_id, conversation_uid, context) VALUES (%s,%s,%s) "
                        "ON DUPLICATE KEY UPDATE context=VALUES(context), "
                        "updated_at=CURRENT_TIMESTAMP(6)",
                        (db_id, canonical_uid, merged_json),
                    )
                await conn.commit()
            if old_rows or (legacy_row and legacy_row.get('context')):
                await add_temp_log(
                    pool,
                    db_id,
                    f"[跨平台上下文] 已合并微信/QQ旧记录，共 {len(merged_history)} 条",
                )
            return merged_history
        except Exception as exc:
            # 表尚未迁移时兼容旧部署；其它异常也保留旧字段兜底并输出根因。
            print(
                f"[unified_context] db_id={db_id} 合并/读取失败: "
                f"{type(exc).__name__}: {exc}",
                flush=True,
            )
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute("SELECT context FROM instances WHERE id=%s", (db_id,))
                row = await cur.fetchone()
                return json.loads(row['context']) if row and row['context'] else []
    except Exception:
        return []


# v12.10 (2026-05-12) 每实例 save_context 互斥锁,避免丢失更新。
# 场景:同一实例 chat.py 处理一条 30 秒,manual_push_worker 同期也在 save_context,
# 后写的覆盖前面的 in-flight 内容。锁保证 read-modify-write 串行。
#
# 但锁本身解决不了"我用 30 秒前的 in-memory history,直接覆盖 DB"的问题。
# 真正解法是 save_context 内部:先 re-fetch DB 最新版本,合并 caller 想加的条目,再写。
# append_to_context(...) 就是这个语义。
_save_locks = {}     # (db_id, uid) -> asyncio.Lock


def _get_save_lock(db_id: int, uid=None) -> asyncio.Lock:
    key = (
        int(db_id),
        "" if uid is None else unified_conversation_uid(db_id),
    )
    lock = _save_locks.get(key)
    if lock is None:
        lock = asyncio.Lock()
        _save_locks[key] = lock
    return lock


async def save_context(pool, db_id, history: list, uid=None):
    """
    全量覆盖式保存(legacy)。chat.py 内部目前仍用,但加了 per-db_id 锁串行,
    避免 manual_push / chat 并发同时写时丢失更新。
    """
    history_str = json.dumps(history, ensure_ascii=False)
    async with _get_save_lock(db_id, uid):
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                if uid is not None:
                    conversation_uid = unified_conversation_uid(db_id)
                    try:
                        await cur.execute(
                            "INSERT INTO conversation_contexts "
                            "(instance_id, conversation_uid, context) VALUES (%s,%s,%s) "
                            "ON DUPLICATE KEY UPDATE context=VALUES(context), "
                            "updated_at=CURRENT_TIMESTAMP(6)",
                            (db_id, conversation_uid, history_str),
                        )
                        await cur.execute(
                            "UPDATE instances SET last_heartbeat=%s WHERE id=%s",
                            (int(time.time()), db_id),
                        )
                    except Exception:
                        # 迁移前兼容：仍写旧字段，但不再进行 400 条破坏性截断。
                        await cur.execute(
                            "UPDATE instances SET context=%s, last_heartbeat=%s WHERE id=%s",
                            (history_str, int(time.time()), db_id),
                        )
                else:
                    await cur.execute(
                        "UPDATE instances SET context=%s, last_heartbeat=%s WHERE id=%s",
                        (history_str, int(time.time()), db_id)
                    )
            await conn.commit()


async def append_to_context(pool, db_id: int, new_entries: list, uid=None) -> bool:
    """
    v12.10 (2026-05-12) 安全 append:从 DB 读最新 history → 追加 new_entries → 写回。

    场景:manual_push / proactive_scanner / tool callback 等需要在 chat.py 之外
          也往 history 加内容的地方,用这个函数代替"get + append + save"模式,
          避免被并发的 chat.py save_context 覆盖。

    在 _save_locks[db_id] 内整体执行,保证原子性。
    """
    if not new_entries:
        return True
    # 确保首次 append 前已经把旧微信/QQ 分离上下文迁到跨平台键。
    if uid is not None:
        await get_context(pool, db_id, uid=uid)
    async with _get_save_lock(db_id, uid):
        try:
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    if uid is not None:
                        conversation_uid = unified_conversation_uid(db_id)
                        try:
                            await cur.execute(
                                "SELECT context FROM conversation_contexts "
                                "WHERE instance_id=%s AND conversation_uid=%s",
                                (db_id, conversation_uid),
                            )
                            row = await cur.fetchone()
                        except Exception:
                            await cur.execute("SELECT context FROM instances WHERE id=%s", (db_id,))
                            row = await cur.fetchone()
                    else:
                        await cur.execute("SELECT context FROM instances WHERE id=%s", (db_id,))
                        row = await cur.fetchone()
                    history = json.loads(row['context']) if row and row['context'] else []
                    history.extend(new_entries)
                    history_json = json.dumps(history, ensure_ascii=False)
                    if uid is not None:
                        try:
                            await cur.execute(
                                "INSERT INTO conversation_contexts "
                                "(instance_id, conversation_uid, context) VALUES (%s,%s,%s) "
                                "ON DUPLICATE KEY UPDATE context=VALUES(context), "
                                "updated_at=CURRENT_TIMESTAMP(6)",
                                (db_id, conversation_uid, history_json),
                            )
                            await cur.execute(
                                "UPDATE instances SET last_heartbeat=%s WHERE id=%s",
                                (int(time.time()), db_id),
                            )
                        except Exception:
                            await cur.execute(
                                "UPDATE instances SET context=%s, last_heartbeat=%s WHERE id=%s",
                                (history_json, int(time.time()), db_id),
                            )
                    else:
                        await cur.execute(
                            "UPDATE instances SET context=%s, last_heartbeat=%s WHERE id=%s",
                            (history_json, int(time.time()), db_id),
                        )
                await conn.commit()
            return True
        except Exception as e:
            print(
                f"[append_to_context] db_id={db_id} 失败: {type(e).__name__}: {e}",
                flush=True,
            )
            return False


def split_text(text: str, rules_str: str, ignore_punc: bool) -> list:
    # 按规则切分文本
    if not text:
        return []
    
    text = re.sub(r'[\r\n]+', '。', text)
    text = re.sub(r'。+', '。', text).strip()

    if not rules_str:
        rules_str = '\n'

    puncts_set = set()
    for part in rules_str.split(','):
        part = part.strip()
        if part in ('\n', '\\n'):
            puncts_set.add('\n')
        elif part:
            for char in part:
                puncts_set.add(char)

    chunks  = []
    current = ""

    for i, char in enumerate(text):
        if len(chunks) == 9:
            current += text[i:]
            if current.strip():
                chunks.append(current.strip())
            break

        current += char
        if char in puncts_set or (char == '。' and ('\n' in puncts_set or '\\n' in puncts_set)):
            if ignore_punc:
                current = current[:-1]
            if current.strip():
                chunks.append(current.strip())
            current = ""
        elif len(current) >= 300:
            chunks.append(current.strip())
            current = ""
    else:
        if current.strip():
            chunks.append(current.strip())

    return [c for c in chunks if c]

async def _fetch_send_config(pool, db_id):
    # 读取发送规则配置
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT split_rule, ignore_punctuation, wx_token, persona_id FROM instances WHERE id=%s",
                (db_id,)
            )
            row = await cur.fetchone()

    if not row or not row['wx_token']:
        return None, '\n', False

    wx_token_plain = decrypt_data(row['wx_token'])
    split_rule     = (row.get('split_rule') or '\\n').replace('\\n', '\n')
    ignore_punc    = int(row.get('ignore_punctuation') or 0) == 1
    return wx_token_plain, split_rule, ignore_punc

SKILLS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "skills")

def _load_skill_module(skill_path: str):
    # 动态载入模块
    spec   = importlib.util.spec_from_file_location("skill_module", skill_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _infer_params_from_usage(usage_str: str) -> dict:
    """
    从 USAGE 字符串(JSON 示例,如 '{"city": "城市名称"}')推断 OpenAI 兼容的
    JSON Schema。无法解析时退回空 schema(等同于无参数工具)。

    限制:
      - 所有字段一律推为 string 类型,description 用 USAGE 里的对应值。
      - 数字/布尔类型的参数请在 skill 文件里直接声明 PARAMETERS 字段(标准
        JSON Schema),否则 LLM 调用时可能传成字符串导致工具内部需要再做
        转换。

    返回结构示例:
      {
        "type": "object",
        "properties": {"city": {"type": "string", "description": "城市名称"}},
        "required": ["city"]
      }
    """
    try:
        sample = json.loads(usage_str or "{}")
        if not isinstance(sample, dict) or not sample:
            return {"type": "object", "properties": {}}
        properties = {}
        for k, v in sample.items():
            properties[str(k)] = {
                "type": "string",
                "description": str(v) if v else f"参数 {k}",
            }
        return {
            "type": "object",
            "properties": properties,
            "required": list(properties.keys()),
        }
    except Exception:
        return {"type": "object", "properties": {}}


async def load_skill_specs_for_openai(
    pool, db_id: int = None, *, tool_channel: str = "wechat",
):
    """
    扫描 skills 目录,生成可直接传给 OpenAI 协议 `tools` 字段的工具规格列表。
    所有加载成功的工具均使用同一个同步协议。工具能否在某个客户端使用，
    由 CHANNELS 元数据单独控制，不能再借执行模式表达渠道范围。

    返回值:
        specs: list[dict]
               [{"type":"function","function":{name,description,parameters}}]

    工具元数据约定(每个 skill 文件顶部):
        NAME, DESCRIPTION   必填
        MODE                必填且只能为 "SYNC"
        CHANNELS            可选,如 ("wechat",)；缺省为 ("*",)
        ENABLED             可选,显式 False 时不加载且不能执行
        PARAMETERS          可选,直接写 JSON Schema(优先生效)
        USAGE               兜底,JSON 示例字符串,用于推断 PARAMETERS

    黑名单:
        若传入 db_id,会查 instance_tool_blacklist 表过滤掉用户在「工具市场」
        中禁用的工具,被禁用工具不会出现在 specs。
        查表失败 → 静默 fallback 全开,不阻塞主流程。
    """
    if not os.path.isdir(SKILLS_DIR):
        return []

    # ── 黑名单查询 ────────────────────────────────────────────────────────
    blacklist = set()
    if db_id:
        try:
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT tool_name FROM instance_tool_blacklist "
                        "WHERE instance_db_id=%s",
                        (db_id,),
                    )
                    rows = await cur.fetchall()
                    for r in rows:
                        if isinstance(r, dict):
                            blacklist.add(r.get("tool_name"))
                        else:
                            blacklist.add(r[0])
        except Exception as e:
            print(
                f"[load_skill_specs_for_openai] 黑名单查询失败,fallback 全开: {e}",
                flush=True,
            )

    specs = []
    skipped = []
    failed  = []
    for filename in sorted(os.listdir(SKILLS_DIR)):
        if not filename.endswith('.py') or filename.startswith('_'):
            continue
        skill_path = os.path.join(SKILLS_DIR, filename)
        try:
            module = _load_skill_module(skill_path)
            name = getattr(module, 'NAME', filename.replace('.py', ''))

            if getattr(module, 'ENABLED', True) is False:
                skipped.append(name)
                continue

            if name in blacklist:
                skipped.append(name)
                continue

            channels = getattr(module, 'CHANNELS', ("*",))
            if isinstance(channels, str):
                channels = (channels,)
            channels = {
                str(item).strip().lower() for item in (channels or ("*",))
                if str(item).strip()
            }
            requested_channel = str(tool_channel or "wechat").strip().lower()
            if "*" not in channels and requested_channel not in channels:
                skipped.append(name)
                continue

            desc = getattr(module, 'DESCRIPTION', '无描述')
            mode = (getattr(module, 'MODE', 'SYNC') or 'SYNC').upper()
            if mode != "SYNC":
                failed.append(f"{filename}(MODE 必须为 SYNC，实际为 {mode})")
                continue

            # 优先用 PARAMETERS(标准 JSON Schema),否则从 USAGE 推断
            usage_raw = getattr(module, 'USAGE', '{}')
            params_schema = getattr(module, 'PARAMETERS', None)
            if not isinstance(params_schema, dict) or "type" not in params_schema:
                params_schema = _infer_params_from_usage(usage_raw)

            usage_str = usage_raw if isinstance(usage_raw, str) else json.dumps(usage_raw, ensure_ascii=False)
            full_description = (
                "[同步工具] 调用本工具时本轮 reply 必须为空；系统会等待执行结果，"
                "下一轮必须基于结果继续思考并生成最终回复。\n\n"
                f"{desc}\n\n"
                f"调用示例: {usage_str}"
            )

            specs.append({
                "type": "function",
                "function": {
                    "name": name,
                    "description": full_description,
                    "parameters": params_schema,
                },
            })
        except Exception as e:
            failed.append(f"{filename}({e!s:.60})")

    if skipped:
        print(f"[load_skill_specs_for_openai] 已跳过禁用工具: {skipped}", flush=True)
    if failed:
        print(f"[load_skill_specs_for_openai] 加载失败: {failed}", flush=True)

    return specs


def build_tools_system_block(specs: list, *, allow_silent: bool = False) -> str:
    """
    把 OpenAI tools 规格列表渲染成 system prompt 里的纯文本块。

    v?? (2026-05-27) 工具调用协议大改:
        不再通过 OpenAI 原生 tools / tool_calls 字段下发,改为把工具说明直接
        塞进 system prompt, 让模型按硬编码的 JSON 响应格式自己调用。

    输入:
        specs    : load_skill_specs_for_openai 返回的 list[dict] (OpenAI tools 格式)
    输出: 单段文本, 直接拼到 system_prompt 末尾。
    格式:
        【可用工具清单】
        你可以在响应的 tools 字段里调用以下工具...

        ──[ send_emoji ]──
          说明: ...
          参数: {...}
          示例: {"name":"send_emoji","params":{...}}

    无工具(specs 空)时返回 "" — 调用方判断空串就不拼。
    """
    if not specs:
        return ""

    lines = [
        "【可用工具清单】",
        "你可以在响应的 tools 字段(数组)里调用以下工具。每个调用是一个对象, ",
        "格式: {\"name\":\"工具名\", \"params\":{...参数...}}。允许空数组 [] 表示不调用。",
        "",
    ]

    for spec in specs:
        fn = spec.get("function") or {}
        name = fn.get("name", "")
        if not name:
            continue
        desc = fn.get("description", "无描述").strip()
        params = fn.get("parameters") or {}

        # 参数 schema 简化展示:列出顶级 properties + required
        props = params.get("properties") or {}
        required = set(params.get("required") or [])
        param_lines = []
        for k, v in props.items():
            t = (v.get("type") or "any")
            d = (v.get("description") or "").strip()
            mark = "*必填*" if k in required else "可选"
            if d:
                param_lines.append(f"    - {k} ({t}, {mark}): {d}")
            else:
                param_lines.append(f"    - {k} ({t}, {mark})")

        # 示例:用 properties 第一个键造个最小示例
        if props:
            example_params = {next(iter(props)): "..."}
        else:
            example_params = {}
        example = json.dumps(
            {"name": name, "params": example_params},
            ensure_ascii=False,
        )

        lines.append(f"──[ {name} ]──")
        lines.append(f"  说明: {desc}")
        if param_lines:
            lines.append("  参数:")
            lines.extend(param_lines)
        else:
            lines.append("  参数: (无)")
        lines.append(f"  调用示例: {example}")
        lines.append("")

    lines.append("【工具调用规则】")
    lines.extend([
        "- 调用任何工具的轮次: reply 字段必须为 \"\" 空串。",
        "  这只是用户不可见的中间轮。系统会等待全部工具按顺序执行完毕，",
        "  把结果交给你；下一轮必须基于结果继续思考并生成有文字的最终回复。",
        "- 工具调用只能使用 tools 数组中的 {\"name\":\"工具名\",\"params\":{...}}。",
        "  内部工具结果不是用户发言，也不是另一种工具调用语法。",
        "- 禁止在调用工具的同一轮输出 reply；否则整轮作废且工具不会执行。",
    ])
    if allow_silent:
        lines.extend([
            "- 不调任何工具时通常应输出非空 reply；仅在主动消息模式明确决定不打扰时，",
            "  才允许 reply=\"\" 且 tools=[]，此时系统不会向用户发送消息。",
        ])
    else:
        lines.extend([
            "- 不调任何工具的轮次: tools 字段为 [], reply 必须是非空的最终回复。",
            "- 禁止 tools=[] 且 reply=\"\"；最终响应不允许空回复。",
        ])
    lines.append("")
    return "\n".join(lines)


async def run_skill(
    skill_name: str, params: dict, pool, db_id, uid, bot_instance,
    *, tool_channel: str = "wechat",
) -> dict:
    """
    调度执行具体工具。

    二次防御（2026-05-05 增加）：
        即使 AI 凭"对话记忆"绕过了 get_tool_list 看到的清单，
        直接发起调用被禁工具，这里也会查 instance_tool_blacklist 拦截。

        没有这层防御，禁用功能会形同虚设——因为 load_skill_specs_for_openai 仅做
        源头展示过滤，run_skill 此前直接扫文件系统执行不查任何权限。
    """
    if not os.path.isdir(SKILLS_DIR):
        return {"success": False, "message": "skills 目录不存在"}

    # ── 二次防御：查实例黑名单 ────────────────────────────────────────────
    if db_id:
        try:
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT 1 FROM instance_tool_blacklist "
                        "WHERE instance_db_id=%s AND tool_name=%s LIMIT 1",
                        (db_id, skill_name),
                    )
                    if await cur.fetchone():
                        print(
                            f"[run_skill][二次防御] 实例 db_id={db_id} 试图调用已禁用工具 {skill_name}，已拦截",
                            flush=True,
                        )
                        return {
                            "success": False,
                            "message": f"工具 {skill_name} 已被该实例禁用，请使用其他工具或直接回复用户。",
                        }
        except Exception as e:
            # 黑名单查询失败不阻塞主流程，仅打印
            print(f"[run_skill] 黑名单查询异常（继续执行）: {e}", flush=True)

    for filename in os.listdir(SKILLS_DIR):
        if not filename.endswith('.py') or filename.startswith('_'):
            continue
        skill_path = os.path.join(SKILLS_DIR, filename)
        try:
            module = _load_skill_module(skill_path)
            name   = getattr(module, 'NAME', filename.replace('.py', ''))
            if name == skill_name:
                if getattr(module, 'ENABLED', True) is False:
                    return {
                        "success": False,
                        "message": f"工具 {skill_name} 当前已停用。",
                    }
                actual_mode = str(getattr(module, 'MODE', 'SYNC') or 'SYNC').upper()
                if actual_mode != "SYNC":
                    return {
                        "success": False,
                        "message": f"工具 {skill_name} 未使用统一同步协议，已拒绝执行。",
                    }
                channels = getattr(module, 'CHANNELS', ("*",))
                if isinstance(channels, str):
                    channels = (channels,)
                allowed_channels = {
                    str(item).strip().lower() for item in (channels or ("*",))
                    if str(item).strip()
                }
                requested_channel = str(tool_channel or "wechat").strip().lower()
                bound_channel = getattr(bot_instance, "tool_channel", None)
                if bound_channel:
                    bound_channel = str(bound_channel).strip().lower()
                    if bound_channel != requested_channel:
                        message = (
                            f"工具调用通道不一致（实例={bound_channel}，"
                            f"请求={requested_channel}），已阻止执行。"
                        )
                        print(f"[run_skill][通道隔离] {message}", flush=True)
                        return {"success": False, "message": message}
                if "*" not in allowed_channels and requested_channel not in allowed_channels:
                    return {
                        "success": False,
                        "message": f"工具 {skill_name} 不支持当前消息渠道。",
                    }
                result = await module.run(params, pool, db_id, uid, bot_instance)
                if isinstance(result, dict):
                    success = bool(result.get("success", True))
                    message = str(result.get("message") or "").strip()
                    if not message:
                        result = dict(result)
                        result["message"] = "执行成功。" if success else "执行失败。"
                    return result
                return {"success": True, "message": str(result or "执行成功。")}
        except Exception as e:
            return {"success": False, "message": f"工具 {skill_name} 执行异常: {str(e)[:100]}"}

    return {"success": False, "message": f"未找到工具: {skill_name}"}


async def cancel_proactive_message(pool, db_id, uid):
    # 取消主动推送
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "UPDATE proactive_schedules SET status=2 "
                "WHERE db_id=%s AND uid=%s AND status=0",
                (db_id, uid)
            )
        await conn.commit()

async def get_due_proactive_messages(pool) -> list:
    # 获取到期推送任务
    now = int(time.time())
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT id, db_id, uid, context_token, content FROM proactive_schedules "
                "WHERE status=0 AND send_at <= %s LIMIT 50",
                (now,)
            )
            rows = await cur.fetchall()
            if rows:
                ids = [r['id'] for r in rows]
                fmt = ','.join(['%s'] * len(ids))
                await cur.execute(
                    f"UPDATE proactive_schedules SET status=1 WHERE id IN ({fmt})",
                    ids
                )
        await conn.commit()
    return rows if rows else []
