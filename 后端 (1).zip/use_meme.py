# =============================================================================
# skills/use_meme.py — 玩梗库智能检索工具 (v9.1 · 2026-05-10)
# =============================================================================
#
# 工作流:
#   1. 向量化传入关键词(与 meme_vector_embed.py 入库时相同的 embedding 配置)
#   2. 余弦相似度初筛 → 候选 top15
#   3. Rerank 精排 → 最终返回 top3(附评分)
#   4. 以 JSON-like 结构返回给 AI,让 AI 自然地融入对话
#
# AI 使用场景:
#   当对话中出现适合玩梗的时机(用户分享、吐槽、感叹等),调用本工具
#   传入关键词/氛围描述,拿到最合适的梗,自然地在 reply 中用出来。
#
# 注意:
#   - meme_library 表需先跑 meme_vector_embed.py 入库
#   - embedding / rerank 配置从 system_config 读(embedding_endpoint 等)
# =============================================================================

NAME        = "use_meme"
DESCRIPTION = (
    "当对话中出现适合玩梗的时机时(如用户感叹、吐槽、分享趣事、情绪起伏),"
    "调用本工具检索最匹配的网络梗,拿到梗的名称与使用场景后,自然融入 reply 中使用。"
    "不要生硬套用,要结合人设和当前语境灵活发挥。"
)
USAGE = '{"keyword": "描述当前对话氛围或情绪的关键词,如\'感动''崩溃''搞笑''敷衍\'"}'
MODE  = "SYNC"


async def run(params: dict, pool, db_id, uid, bot_instance) -> dict:
    import json
    import math
    import httpx

    keyword = params.get("keyword", "").strip()
    if not keyword:
        return {"success": False, "message": "未提供关键词,无法检索玩梗库。"}

    # ── 从 system_config 读 embedding / rerank 配置 ──────────────────────────
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT config_key, config_value FROM system_config "
                "WHERE config_key IN ('embedding_endpoint','embedding_api_key','embedding_model')"
            )
            cfg = {r["config_key"]: r["config_value"] for r in await cur.fetchall()}

    EMB_URL      = cfg.get("embedding_endpoint", "https://yunwu.ai/v1/embeddings")
    EMB_KEY      = cfg.get("embedding_api_key",  "")
    EMB_MODEL    = cfg.get("embedding_model",    "text-embedding-3-large")
    RERANK_URL   = EMB_URL.replace("/embeddings", "/rerank")
    RERANK_MODEL = "qwen3-rerank"

    if not EMB_KEY:
        return {"success": False, "message": "系统未配置 embedding_api_key，无法检索玩梗库。"}

    def cosine_sim(v1: list, v2: list) -> float:
        dot   = sum(a * b for a, b in zip(v1, v2))
        n1    = math.sqrt(sum(a * a for a in v1))
        n2    = math.sqrt(sum(b * b for b in v2))
        return dot / (n1 * n2) if n1 and n2 else 0.0

    try:
        async with httpx.AsyncClient(timeout=20.0) as client:

            # ── Step 1: 向量化关键词 ──────────────────────────────────────────
            emb_res = await client.post(
                EMB_URL,
                json={"model": EMB_MODEL, "input": keyword},
                headers={"Authorization": f"Bearer {EMB_KEY}"},
            )
            emb_res.raise_for_status()
            q_vec = emb_res.json()["data"][0]["embedding"]

            # ── Step 2: 从 meme_library 拉所有已向量化的条目 ─────────────────
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT meme_name, usage_scenario, embedding "
                        "FROM meme_library "
                        "WHERE embedding IS NOT NULL AND embedded_at IS NOT NULL"
                    )
                    rows = await cur.fetchall()

            if not rows:
                return {
                    "success": False,
                    "message": "玩梗库暂无数据，请先运行 meme_vector_embed.py 入库。"
                }

            # ── Step 3: 余弦相似度初筛 → top15 候选 ──────────────────────────
            candidates = []
            for r in rows:
                try:
                    emb = (
                        json.loads(r["embedding"])
                        if isinstance(r["embedding"], str)
                        else r["embedding"]
                    )
                    score = cosine_sim(q_vec, emb)
                    candidates.append({
                        "meme_name":      r["meme_name"],
                        "usage_scenario": r["usage_scenario"],
                        "cosine_score":   score,
                    })
                except Exception:
                    continue

            if not candidates:
                return {"success": False, "message": "向量检索失败,请检查数据入库是否正常。"}

            candidates.sort(key=lambda x: x["cosine_score"], reverse=True)
            top15 = candidates[:15]

            # ── Step 4: Rerank 精排 → top3 ───────────────────────────────────
            # rerank 的 documents 格式:"梗名称: X\n使用场景: Y"(与入库格式一致)
            docs = [
                f"梗名称: {c['meme_name']}\n使用场景: {c['usage_scenario']}"
                for c in top15
            ]

            try:
                rerank_res = await client.post(
                    RERANK_URL,
                    json={
                        "model":    RERANK_MODEL,
                        "query":    keyword,
                        "documents": docs,
                        "top_n":    3,
                    },
                    headers={"Authorization": f"Bearer {EMB_KEY}"},
                )
                rerank_res.raise_for_status()
                rerank_data = rerank_res.json()

                ranked = sorted(
                    rerank_data.get("results", []),
                    key=lambda x: x.get("relevance_score", 0),
                    reverse=True,
                )

                final = []
                for r in ranked[:3]:
                    idx   = r["index"]
                    score = round(r.get("relevance_score", 0), 4)
                    if score < 0.05:   # 相关性极低的直接丢弃
                        continue
                    final.append({
                        "rank":           len(final) + 1,
                        "meme_name":      top15[idx]["meme_name"],
                        "usage_scenario": top15[idx]["usage_scenario"],
                        "relevance":      score,
                    })

            except Exception as rerank_err:
                # rerank 接口失败 → 降级:直接用余弦 top3
                final = [
                    {
                        "rank":           i + 1,
                        "meme_name":      c["meme_name"],
                        "usage_scenario": c["usage_scenario"],
                        "relevance":      round(c["cosine_score"], 4),
                    }
                    for i, c in enumerate(top15[:3])
                ]

            if not final:
                return {
                    "success": True,
                    "message": f"未检索到与「{keyword}」相关度足够高的梗，建议换个关键词或直接自然对话。",
                }

            # ── Step 5: 组装返回给 AI 的结构化文本 ───────────────────────────
            meme_lines = []
            for item in final:
                meme_lines.append(
                    f"第{item['rank']}名 【{item['meme_name']}】(相关度 {item['relevance']})\n"
                    f"  使用场景: {item['usage_scenario']}"
                )
            meme_text = "\n\n".join(meme_lines)

            return {
                "success": True,
                "message": (
                    f"针对关键词「{keyword}」，检索到以下 {len(final)} 个最匹配的梗：\n\n"
                    f"{meme_text}\n\n"
                    "请结合当前对话语境和你的人设，选择最合适的梗自然地融入 reply 中，"
                    "不要生硬照搬场景描述，要灵活发挥。"
                ),
                "memes": final,   # 结构化数据,方便后续扩展
            }

    except Exception as e:
        return {"success": False, "message": f"玩梗检索异常: {str(e)[:200]}"}
