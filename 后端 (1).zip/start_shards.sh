#!/usr/bin/env bash
# ============================================================================
# Cloud Love 引擎 · 多进程分片启动脚本
# ----------------------------------------------------------------------------
# 低配置服务器默认只启动 2 个 main.py 进程。每个进程通过环境变量
# 拿到自己的分片编号:
#     SHARD_TOTAL = 2       进程总数
#     SHARD_INDEX = 0..1    本进程编号
# 实例按 id %% 2 自动归属;新增或导入实例下一轮扫库会被对应进程接管,
# 无需重启。QQ 连接仍由 0 号主分片统一管理。
# 0 号进程为主进程,额外负责 webchat / 语音 WS / 监控快照。
#
# 用法:
#     source myenv/bin/activate
#     ./start_shards.sh start     启动 2 个进程
#     ./start_shards.sh stop      停止全部进程
#     ./start_shards.sh status    查看进程状态
#     ./start_shards.sh restart   重启
# ============================================================================

SHARD_TOTAL=2
WORKDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -x "${WORKDIR}/.venv/bin/python" ]; then
    PYTHON="${WORKDIR}/.venv/bin/python"
else
    PYTHON="python3"
fi
LOGDIR="${WORKDIR}/logs"
PIDDIR="${WORKDIR}/pids"

# QQBot 现在由 0 号 main.py 分片从数据库动态管理，不再由脚本单独拉起
# 一个硬编码账号；这样控制台保存配置后即可自动建立/撤销对应连接。
# 启动脚本固定开启 QQ 管理器，不继承 shell/systemd 中可能残留的
# QQBOT_ENABLED=0。没有已保存账号时不会建立外部连接；用户保存配置后，
# 0 号 main.py 会在下一轮数据库扫描中自动建立 Gateway 连接。
QQBOT_ENABLED=1
export QQBOT_ENABLED
QQBOT_PIDFILE="${PIDDIR}/qqbot.pid"
QQBOT_LOGFILE="${LOGDIR}/qqbot.log"

mkdir -p "$LOGDIR" "$PIDDIR"

start_qqbot() {
    # 兼容旧版本遗留的 qqbot.pid，但不再启动第二个独立 Gateway。
    if [ -f "$QQBOT_PIDFILE" ] && kill -0 "$(cat "$QQBOT_PIDFILE")" 2>/dev/null; then
        echo "QQBot: 检测到旧版独立进程 (PID $(cat "$QQBOT_PIDFILE")),请先执行 stop 清理"
    else
        echo "QQBot: 由 0 号 main.py 分片的数据库管理器负责，无独立进程"
    fi
}

# 从 13 分片等旧配置降配时，单纯把 SHARD_TOTAL 改成 2 不会自动结束
# shard_2 以后的旧进程。启动前按 PID 文件清理超出当前范围的分片，保证
# 实际运行数量确实只有 SHARD_TOTAL 个。
stop_extra_shards() {
    local pidfile base index pid
    shopt -s nullglob
    for pidfile in "${PIDDIR}"/shard_*.pid; do
        base="$(basename "$pidfile" .pid)"
        index="${base#shard_}"
        if [[ "$index" =~ ^[0-9]+$ ]] && [ "$index" -ge "$SHARD_TOTAL" ]; then
            pid="$(cat "$pidfile" 2>/dev/null || true)"
            if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
                kill "$pid"
                echo "  旧分片 ${index}: 已发送停止信号 (PID ${pid})"
            fi
            rm -f -- "$pidfile"
        fi
    done
    shopt -u nullglob
}

stop_qqbot() {
    if [ -f "$QQBOT_PIDFILE" ]; then
        local pid
        pid="$(cat "$QQBOT_PIDFILE")"
        if kill -0 "$pid" 2>/dev/null; then
            kill "$pid"
            echo "QQBot: 已发送停止信号 (PID ${pid})"
        fi
        rm -f "$QQBOT_PIDFILE"
    fi
}

start() {
    echo "启动 ${SHARD_TOTAL} 个引擎分片进程..."
    echo "QQBot: 默认开启（由 0 号 main.py 分片管理）"
    stop_extra_shards
    for i in $(seq 0 $((SHARD_TOTAL - 1))); do
        local pidfile="${PIDDIR}/shard_${i}.pid"
        if [ -f "$pidfile" ] && kill -0 "$(cat "$pidfile")" 2>/dev/null; then
            echo "  分片 ${i}: 已在运行 (PID $(cat "$pidfile")),跳过"
            continue
        fi
        SHARD_INDEX=$i SHARD_TOTAL=$SHARD_TOTAL QQBOT_ENABLED=$QQBOT_ENABLED \
            nohup "$PYTHON" "${WORKDIR}/main.py" \
            > "${LOGDIR}/shard_${i}.log" 2>&1 &
        echo $! > "$pidfile"
        echo "  分片 ${i}: 已启动 (PID $!)$([ "$i" = "0" ] && echo '  [主进程]')"
        sleep 0.3
    done
    start_qqbot
    echo "全部分片已启动。日志: ${LOGDIR}/shard_*.log"
}

stop() {
    echo "停止全部引擎分片进程..."
    local pidfile base index pid
    shopt -s nullglob
    for pidfile in "${PIDDIR}"/shard_*.pid; do
        base="$(basename "$pidfile" .pid)"
        index="${base#shard_}"
        pid="$(cat "$pidfile" 2>/dev/null || true)"
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            kill "$pid"
            echo "  分片 ${index}: 已发送停止信号 (PID ${pid})"
        fi
        rm -f -- "$pidfile"
    done
    shopt -u nullglob
    stop_qqbot
    echo "全部分片已停止。"
}

status() {
    echo "引擎分片状态 (共 ${SHARD_TOTAL} 个):"
    local running=0
    for i in $(seq 0 $((SHARD_TOTAL - 1))); do
        local pidfile="${PIDDIR}/shard_${i}.pid"
        if [ -f "$pidfile" ] && kill -0 "$(cat "$pidfile")" 2>/dev/null; then
            echo "  分片 ${i}: 运行中 (PID $(cat "$pidfile"))$([ "$i" = "0" ] && echo '  [主进程]')"
            running=$((running + 1))
        else
            echo "  分片 ${i}: 未运行"
        fi
    done
    echo "运行中: ${running}/${SHARD_TOTAL}"
    if [ -f "$QQBOT_PIDFILE" ] && kill -0 "$(cat "$QQBOT_PIDFILE")" 2>/dev/null; then
        echo "QQBot: 发现旧版独立进程 (PID $(cat "$QQBOT_PIDFILE"))"
    else
        echo "QQBot: 已随主分片开启（QQBOT_ENABLED=${QQBOT_ENABLED}，连接由数据库配置决定）"
    fi
}

case "${1:-}" in
    start)   start ;;
    stop)    stop ;;
    restart) stop; sleep 2; start ;;
    status)  status ;;
    *)
        echo "用法: $0 {start|stop|restart|status}"
        exit 1
        ;;
esac
