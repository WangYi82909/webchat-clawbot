"""
announce_broadcast.py — 紧急公告一次性广播脚本（不常驻）

设计前提：
  - 平时不调用，由 admin 触发后启动一次，跑完 exit。
  - 不进入 main.py 的常驻循环，避免影响主流程稳定性。

调用方式：
  1. 命令行直接传文本（紧急排查/手动广播）：
        python3 announce_broadcast.py --text "公告内容..."
  2. 由 admin 触发 → admin 已写好任务到 system_config[announce_broadcast_job]：
        python3 announce_broadcast.py --from-db --job-id <job_id>

广播规则：
  - 目标：所有 status='启动' 且 wx_token 非空 的实例
  - 每实例下：从 proactive_schedules 取所有历史交互过的 (uid, 最新 context_token)
  - 全局节流：3 条/秒（避免触发微信 CDN 反垃圾）
  - 单条失败不中断，错误归集后写进度

进度存储：
  system_config[announce_broadcast_progress]
    JSON: {job_id, status, total, done, ok, fail, text(预览), started_at,
           finished_at?, errors[最近 50 条], updated_at}
  admin 每秒拉一次画进度条。
"""
import asyncio
import argparse
import aiomysql
import httpx
import time
import json
import sys
import os
import traceback

# 复用 main.py 同目录下的 utils（加解密、生成 client_id / x_wechat_uin、init_rsa_keys）
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import utils

# ── DB 配置：优先从同目录 main.py 动态读取，保持与主程序一致 ───────────────
# announce_broadcast.py 与 main.py 同目录，直接取 main.py 的 DB_CONFIG，
# 避免硬编码不同 host 导致脚本连不上 DB 而悄悄崩溃（进度永不更新→"疑似僵死"）。
_this_dir = os.path.dirname(os.path.abspath(__file__))
try:
    import importlib.util as _ilu
    _spec = _ilu.spec_from_file_location("_main_cfg", os.path.join(_this_dir, "main.py"))
    _m    = _ilu.module_from_spec(_spec)
    _spec.loader.exec_module(_m)                 # 只解析模块顶层，不 run asyncio.run
    DB_CONFIG = dict(_m.DB_CONFIG)               # 深拷贝，避免污染 main 模块命名空间
    print(f"[广播] DB_CONFIG 从 main.py 读取: host={DB_CONFIG.get('host')} db={DB_CONFIG.get('db')}", flush=True)
except Exception as _e:
    # fallback：万一 main.py 无法 import（语法改了、依赖缺失），用硬编码兜底
    print(f"[广播] 警告: 无法从 main.py 读 DB_CONFIG ({_e})，使用 fallback", flush=True)
    DB_CONFIG = {
        'host':        '127.0.0.1',
        'port':        3306,
        'user':        'webchat',
        'password':    '',
        'db':          'webchat',
        'autocommit':  True,
    }
BASE_URL = "https://ilinkai.weixin.qq.com/ilink/bot"

# ── 节流参数（用户要求："每秒发三个"）────────────────────────────────────
RATE_PER_SEC = 3
GAP_SEC      = 1.0 / RATE_PER_SEC      # 每条至少间隔 0.333s
HTTP_TIMEOUT = 10.0


# =====================================================================
# 进度上报
# =====================================================================
async def _write_progress(pool, snapshot: dict):
    """把当前进度 UPSERT 到 system_config[announce_broadcast_progress]。"""
    snapshot['updated_at'] = time.time()
    payload = json.dumps(snapshot, ensure_ascii=False, separators=(',', ':'))
    # 安全截断（TEXT 字段保险），错误列表过长时优先丢老条目
    while len(payload.encode('utf-8')) > 55 * 1024 and snapshot.get('errors'):
        snapshot['errors'] = snapshot['errors'][-max(10, len(snapshot['errors']) // 2):]
        payload = json.dumps(snapshot, ensure_ascii=False, separators=(',', ':'))
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "INSERT INTO system_config (config_key, config_value, remark) "
                    "VALUES ('announce_broadcast_progress', %s, '紧急广播进度·脚本写入·勿手改') "
                    "ON DUPLICATE KEY UPDATE config_value=VALUES(config_value)",
                    (payload,)
                )
            await conn.commit()
    except Exception as e:
        print(f"[广播] 写进度失败: {e}", flush=True)


# =====================================================================
# 取广播目标
# =====================================================================
async def _load_targets(pool) -> list:
    """
    返回要发送的扁平计划：
        [{db_id, uid, ctx, wx_plain}, ...]
    去重键：(db_id, uid)
    """
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            # 1) 在线实例
            await cur.execute(
                "SELECT id, wx_token FROM instances "
                "WHERE status='启动' AND wx_token IS NOT NULL AND wx_token != ''"
            )
            instances = await cur.fetchall() or []

            plan = []
            seen = set()
            for ins in instances:
                # 解密 wx_token，失败的实例直接跳过（标记到 errors）
                try:
                    wx_plain = utils.decrypt_data(ins['wx_token'])
                except Exception as e:
                    print(f"[广播] 实例 {ins['id']} wx_token 解密失败: {e}", flush=True)
                    continue
                if not wx_plain:
                    continue

                # 2) 该实例下所有 uid 的最新 context_token
                #    从 proactive_schedules 取（全表唯一记录用户接触历史的地方）
                await cur.execute(
                    "SELECT p.uid, p.context_token "
                    "FROM proactive_schedules p "
                    "INNER JOIN ("
                    "  SELECT uid, MAX(id) AS max_id "
                    "  FROM proactive_schedules "
                    "  WHERE db_id=%s "
                    "  GROUP BY uid"
                    ") m ON p.uid=m.uid AND p.id=m.max_id "
                    "WHERE p.db_id=%s",
                    (ins['id'], ins['id'])
                )
                rows = await cur.fetchall() or []

                for r in rows:
                    uid = r['uid']
                    if not uid:
                        continue
                    key = (ins['id'], uid)
                    if key in seen:
                        continue
                    seen.add(key)
                    plan.append({
                        'db_id':    ins['id'],
                        'uid':      uid,
                        'ctx':      r['context_token'] or '',
                        'wx_plain': wx_plain,
                    })
    return plan


# =====================================================================
# 单条发送（无重试 / 无切分；失败计数即可）
# =====================================================================
async def _send_one(client, db_id: int, uid: str, ctx: str,
                    text: str, wx_plain: str) -> tuple[bool, str | None]:
    headers = {
        "Authorization":           f"Bearer {wx_plain}",
        "AuthorizationType":       "ilink_bot_token",
        "iLink-App-ClientVersion": "1",
        "X-WECHAT-UIN":            utils.generate_x_wechat_uin(),
        "Content-Type":            "application/json",
    }
    payload = {
        "msg": {
            "from_user_id":  "",
            "to_user_id":    uid,
            "client_id":     utils.generate_client_id(),
            "message_type":  2,
            "message_state": 2,
            "item_list":     [{"type": 1, "text_item": {"text": text}}],
            "context_token": ctx or "",
        }
    }
    try:
        res = await client.post(
            f"{BASE_URL}/sendmessage",
            json=payload, headers=headers, timeout=HTTP_TIMEOUT,
        )
        if res.status_code == 200:
            return True, None
        return False, f"HTTP {res.status_code}: {res.text[:80]}"
    except httpx.TimeoutException:
        return False, "timeout"
    except Exception as e:
        return False, f"{type(e).__name__}: {str(e)[:80]}"


# =====================================================================
# 主逻辑
# =====================================================================
async def broadcast(text: str, job_id: str):
    pool = await aiomysql.create_pool(
        minsize=1, maxsize=4,
        cursorclass=aiomysql.DictCursor,
        **DB_CONFIG,
    )

    snapshot = {
        'job_id':     job_id,
        'status':     'loading',
        'text':       text[:200],
        'total':      0,
        'done':       0,
        'ok':         0,
        'fail':       0,
        'errors':     [],
        'started_at': time.time(),
    }

    try:
        await _write_progress(pool, snapshot)
        await utils.init_rsa_keys(pool)   # decrypt_data 依赖

        plan = await _load_targets(pool)
        snapshot['total']  = len(plan)
        snapshot['status'] = 'running'
        await _write_progress(pool, snapshot)

        if not plan:
            snapshot['status']      = 'done'
            snapshot['finished_at'] = time.time()
            await _write_progress(pool, snapshot)
            print("[广播] 没有可发送的目标，退出。", flush=True)
            return

        print(f"[广播] 任务 {job_id} 开始 | 目标 {len(plan)} 条 | 限速 {RATE_PER_SEC}/s", flush=True)

        # 共享一个 httpx client，避免每条新建 TCP
        # limits 控制并发连接：广播脚本每条 send 都同步在前一条 await 后再发，
        # 实际并发 1，给到 10 是冗余足够的。
        async with httpx.AsyncClient(
            limits=httpx.Limits(
                max_connections=10,
                max_keepalive_connections=5,
                keepalive_expiry=30.0,
            ),
        ) as client:
            for i, t in enumerate(plan):
                tick_start = time.monotonic()

                ok, err = await _send_one(
                    client, t['db_id'], t['uid'], t['ctx'], text, t['wx_plain']
                )
                if ok:
                    snapshot['ok'] += 1
                else:
                    snapshot['fail'] += 1
                    if len(snapshot['errors']) < 200:
                        snapshot['errors'].append({
                            'db_id': t['db_id'],
                            'uid':   str(t['uid'])[:24],
                            'err':   err,
                        })
                snapshot['done'] = i + 1

                # 每 5 条 / 末尾 上报一次（高频写库无意义）
                if (i + 1) % 5 == 0 or (i + 1) == len(plan):
                    await _write_progress(pool, snapshot)
                    print(f"[广播] 进度 {snapshot['done']}/{snapshot['total']} "
                          f"成功={snapshot['ok']} 失败={snapshot['fail']}", flush=True)

                # 节流：保证整体节奏 ≈ RATE_PER_SEC/秒
                spent = time.monotonic() - tick_start
                if spent < GAP_SEC:
                    await asyncio.sleep(GAP_SEC - spent)

        snapshot['status']      = 'done'
        snapshot['finished_at'] = time.time()
        await _write_progress(pool, snapshot)

        print(f"[广播] 完成 总数={snapshot['total']} "
              f"成功={snapshot['ok']} 失败={snapshot['fail']}", flush=True)

    except Exception as e:
        snapshot['status']      = 'error'
        snapshot['error']       = f"{type(e).__name__}: {e}"
        snapshot['finished_at'] = time.time()
        try:
            await _write_progress(pool, snapshot)
        except Exception:
            pass
        print(f"[广播] 异常退出: {e}", flush=True)
        traceback.print_exc()
        raise
    finally:
        pool.close()
        await pool.wait_closed()


# =====================================================================
# CLI 入口
# =====================================================================
async def _resolve_text(args) -> tuple[str, str]:
    """根据参数确定 (text, job_id)。--from-db 时从 system_config 取。"""
    if args.text:
        return args.text, args.job_id or f"cli-{int(time.time())}"

    if args.from_db:
        pool = await aiomysql.create_pool(
            minsize=1, maxsize=2,
            cursorclass=aiomysql.DictCursor,
            **DB_CONFIG,
        )
        try:
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT config_value FROM system_config "
                        "WHERE config_key='' LIMIT 1"
                    )
                    row = await cur.fetchone()
        finally:
            pool.close()
            await pool.wait_closed()

        if not row or not row.get('config_value'):
            raise SystemExit("[ERR] system_config[announce_broadcast_job] 不存在或为空")

        try:
            payload = json.loads(row['config_value'])
        except Exception as e:
            raise SystemExit(f"[ERR] payload JSON 解析失败: {e}")

        text   = (payload.get('text') or '').strip()
        job_id = args.job_id or payload.get('job_id') or f"db-{int(time.time())}"

        # 校验 job_id 与 DB 中一致（admin 防重放）
        if args.job_id and payload.get('job_id') and payload.get('job_id') != args.job_id:
            raise SystemExit(
                f"[ERR] CLI job_id={args.job_id} 与 DB 中 {payload.get('job_id')} 不一致"
            )
        return text, job_id

    raise SystemExit("[ERR] 必须提供 --text 或 --from-db")


async def _async_main():
    ap = argparse.ArgumentParser(description="紧急公告一次性广播脚本")
    ap.add_argument('--text',    help='直接传入广播文本')
    ap.add_argument('--from-db', action='store_true',
                    help='从 system_config[announce_broadcast_job] 读取任务')
    ap.add_argument('--job-id',  help='可选 job_id（默认从 DB 取或 cli-时间戳）')
    args = ap.parse_args()

    text, job_id = await _resolve_text(args)
    if not (text or '').strip():
        raise SystemExit("[ERR] 公告文本为空，拒绝广播")

    await broadcast(text, job_id)


if __name__ == "__main__":
    try:
        asyncio.run(_async_main())
    except KeyboardInterrupt:
        print("\n[广播] 用户中断", flush=True)
        sys.exit(130)
