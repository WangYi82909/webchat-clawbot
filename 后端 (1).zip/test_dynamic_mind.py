import json
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

import dynamic_mind as dm


UTC = timezone.utc


class DynamicMindPureTests(unittest.TestCase):
    def test_legacy_emotion_tool_is_inert_and_hidden(self):
        root = Path(__file__).resolve().parent
        chat_source = (root / "chat.py").read_text(encoding="utf-8")
        console_path = root / "console.php"
        if not console_path.exists():
            console_path = root.parent / "console.php"
        console_source = console_path.read_text(encoding="utf-8")

        self.assertEqual(chat_source.count('"update_emotion_state"'), 1)
        self.assertNotIn("current_emotion_state", chat_source)
        self.assertNotIn("【你现在的心情与节奏】", chat_source)
        self.assertNotIn("【心情】", chat_source)
        # 统一工具协议后已删除 mode_map 的第三次重复过滤；加载清单与模型
        # 返回解析仍各有一道拦截，skill 自身也保持 ENABLED=False。
        self.assertGreaterEqual(
            chat_source.count("in _DISABLED_LEGACY_MIND_TOOLS"),
            2,
        )
        emotion_source = (root / "skills" / "update_emotion_state.py").read_text(
            encoding="utf-8"
        )
        self.assertIn("ENABLED = False", emotion_source)
        self.assertLess(
            chat_source.index("tool_specs = ["),
            chat_source.index("tools_system_block ="),
        )
        self.assertNotIn("agentEmotion", console_source)
        self.assertNotIn("persona_emotion", console_source)
        self.assertNotIn("renderEmotionState", console_source)

    def test_new_state_isolated_and_complete(self):
        now = datetime(2026, 8, 3, 2, 0, tzinfo=UTC)
        left = dm.new_state(11, 101, now)
        right = dm.new_state(12, 101, now)
        left["drives"]["share"] = 0.77
        self.assertEqual(right["drives"]["share"], 0.15)
        self.assertEqual(set(left["drives"]), set(dm.DRIVE_KEYS))
        self.assertNotEqual(left["db_id"], right["db_id"])

    def test_state_does_not_duplicate_contact_credentials(self):
        state = dm.new_state(11, 101, datetime(2026, 8, 3, 2, 0, tzinfo=UTC))
        self.assertNotIn("uid", state)
        self.assertNotIn("last_uid", state)
        self.assertNotIn("context_token", state)
        self.assertNotIn("last_context_token", state)

    def test_settle_uses_elapsed_time_and_enters_sleep(self):
        start = datetime(2026, 8, 3, 2, 0, tzinfo=UTC)  # 10:00 Shanghai
        state = dm.new_state(11, 101, start)
        dm.settle_state(state, start + timedelta(hours=2))
        self.assertEqual(state["consciousness"], "sleeping")
        self.assertGreater(state["drives"]["share"], 0.15)
        self.assertIsNotNone(state["sleep_started_at"])

    def test_dawn_freezes_normal_drives(self):
        start = datetime(2026, 8, 2, 18, 0, tzinfo=UTC)  # 02:00 Shanghai
        state = dm.new_state(11, 101, start)
        before = state["drives"]["possess"]
        dm.settle_state(state, start + timedelta(hours=1))
        self.assertEqual(state["drives"]["possess"], before)

    def test_mind_event_is_strictly_whitelisted_and_clamped(self):
        raw = json.dumps({
            "reply": "好",
            "tools": [],
            "mind_event": {
                "interaction_type": "sharing",
                "tone": "warm",
                "warmth": 9,
                "tension": -2,
                "drive_deltas": {"possess": 99},
                "flash_thought": {
                    "key": "share",
                    "text": " 她愿意和我分享今天发生的事 ",
                    "intensity": 4,
                },
            },
        }, ensure_ascii=False)
        event = dm.extract_mind_event(raw)
        self.assertEqual(event["interaction_type"], "sharing")
        self.assertEqual(event["warmth"], 1.0)
        self.assertEqual(event["tension"], 0.0)
        self.assertEqual(event["flash_thought"]["intensity"], 1.0)
        self.assertNotIn("drive_deltas", event)

    def test_invalid_event_values_fall_back_safely(self):
        event = dm.extract_mind_event(
            '{"reply":"x","tools":[],"mind_event":'
            '{"interaction_type":"hack","tone":"evil","dream":null}}'
        )
        self.assertIsNone(event["interaction_type"])
        self.assertEqual(event["tone"], "neutral")

    def test_context_does_not_expose_storage_or_credentials(self):
        now = datetime(2026, 8, 3, 2, 0, tzinfo=UTC)
        state = dm.new_state(11, 101, now)
        rendered = dm.render_context(state, now)
        self.assertIn("心潮动态状态", rendered)
        self.assertIn("当前驱动力", rendered)
        self.assertIn("表达自由=", rendered)
        self.assertNotIn("state_json", rendered)
        self.assertNotIn("SERVICE_TOKEN", rendered)

    def test_semantic_interaction_changes_only_server_mapped_drives(self):
        now = datetime(2026, 8, 3, 2, 0, tzinfo=UTC)
        state = dm.new_state(11, 101, now)
        state["drives"]["share"] = 0.8
        before_other = state["drives"]["anger"]
        dm._apply_model_event(
            state,
            {"interaction_type": "sharing", "tone": "warm"},
            now,
            False,
        )
        self.assertLess(state["drives"]["share"], 0.8)
        self.assertEqual(state["drives"]["anger"], before_other)

    def test_proactive_output_cannot_claim_user_interaction(self):
        now = datetime(2026, 8, 3, 2, 0, tzinfo=UTC)
        state = dm.new_state(11, 101, now)
        state["drives"]["share"] = 0.8
        dm._apply_model_event(
            state,
            {"interaction_type": "sharing", "tone": "warm"},
            now,
            True,
        )
        self.assertEqual(state["drives"]["share"], 0.8)

    def test_two_unanswered_proactive_messages_stop_scheduling(self):
        now = datetime(2026, 8, 3, 2, 0, tzinfo=UTC)
        state = dm.new_state(11, 101, now)
        state["proactive_count_since_user"] = dm.PROACTIVE_MAX_UNANSWERED
        dm._schedule_next(state, now)
        self.assertIsNone(state["next_proactive_at"])

    def test_thought_decay_depends_on_clock_not_chat_call_count(self):
        now = datetime(2026, 8, 3, 2, 0, tzinfo=UTC)
        state = dm.new_state(11, 101, now)
        state["thought_pool"]["flash"] = [
            {"key": "share", "text": "想起刚才的分享", "intensity": 0.7, "age": 0}
        ]
        dm.settle_state(state, now + timedelta(minutes=14))
        self.assertEqual(state["thought_pool"]["flash"][0]["intensity"], 0.7)
        dm.settle_state(state, now + timedelta(minutes=15))
        self.assertAlmostEqual(state["thought_pool"]["flash"][0]["intensity"], 0.574)


class DynamicMindAsyncTests(unittest.IsolatedAsyncioTestCase):
    async def test_suspend_proactive_waits_for_next_user_presence(self):
        now = datetime(2026, 8, 13, 2, 0, tzinfo=UTC)

        async def fake_mutate(pool, db_id, persona_id, mutator, current):
            state = dm.new_state(db_id, persona_id, current)
            state["pending_proactive"] = True
            state["pending_proactive_at"] = current.isoformat()
            state["pending_proactive_reason"] = "daytime-emergence:drive:share"
            state["next_proactive_at"] = (current + timedelta(minutes=11)).isoformat()
            next_state, result = mutator(state)
            next_state["revision"] += 1
            return next_state, result

        with patch.object(dm, "_mutate", side_effect=fake_mutate):
            result = await dm.suspend_proactive_until_user(object(), 11, now=now)

        self.assertTrue(result["suspended"])
        self.assertIsNone(result["next_proactive_at"])


if __name__ == "__main__":
    unittest.main()
