"""
================================================================================
data/tool_leak_cleaner.py · 工具调用残骸统一清洗库 (v1 · 2026-05-23)
================================================================================

【职责】
LLM 在 OpenAI function calling 协议下,本来应该把工具调用放在 message.tool_calls
字段里走专门通道,但实际生产中各种模型(尤其是小参数模型 gemini-flash-lite、
deepseek-v4-flash 等)会把工具调用写到 message.content 正文里,形态万变 ──
XML 标签、中文方括号、JSON 字典、YAML 风格、Markdown 代码块、半截残骸 ...
不一而足。

本模块是这些异常输出的**统一防御层**:把 chat.py 里历史累积的 D1-D5 +
_sanitize_outgoing_text 内部 6 个 step 全部收敛进来,以单个 `clean()` 入口
对外暴露,保证 chat.py 端只做一次调用。

【设计原则】
1. **形态分类法,不打补丁**:每种已知形态写一条独立清洗规则,新形态加规则
   不改老规则,规则之间天然无依赖。
2. **关键字白名单驱动**:只有出现工具调用关键字时才剥除符号块。普通的
   `<标签>`/`【提示】`/`[备注]` 等中文常见用法**完全不动**,防误伤。
3. **绝不执行工具**:泄漏到正文的调用没有可靠的工具轮与正文配对状态，
   只能清除，不能从清洗器旁路执行副作用。
4. **空兜底**:全部清洗后如果 cleaned 为空,**自动调用裸自然语言提取器**
   ── 抓所有未嵌入可疑符号块的中文段,按序拼接返回,保证用户至少能收到
   一些自然语言,而不是完全静默。
5. **协议无关**:本模块不知道 OpenAI / Anthropic 协议,只处理"模型把
   工具调用写到了正文里"这一类异常。协议层的 tool_calls 字段处理由
   llm_protocol_*.py 负责,与本模块互不干扰。

【对外接口】
    async def clean(
        text: str,
        diag_logger: Optional[Callable[[str], Awaitable[None]]] = None,
    ) -> str

参数:
    text                  ── 原始正文(LLM 出 content 后已经过思维链剥离)
    diag_logger           ── 可选异步日志回调,签名 (msg: str) -> Awaitable[None]。
                             命中各种规则时调一下,用于在 admin 控制台留痕。

返回:
    清洗后的字符串。可能为空字符串(整段都是残骸,且裸提取也没拿到自然语言)。

【调用方】
chat.py 在 generate_reply 末尾(计费提交之前)调用一次本入口,把多步清洗
收敛为单点。

================================================================================
"""
from __future__ import annotations
import json
import re
from typing import Any, Awaitable, Callable, Optional


# ──────────────────────────────────────────────────────────────────────────────
# § 0. 工具调用关键字白名单
# ──────────────────────────────────────────────────────────────────────────────
# 出现这些关键字才认为是工具调用残骸,触发剥除。否则一律不动,防误伤。
#
# 设计:全部小写匹配,正则/字符串匹配时都先 .lower() 一遍,避免大小写遗漏。
# 中文关键字单列,因为 .lower() 对中文无效但也无害。
#
# 新增工具调用形态时,只需要在这里加关键字,无需改其它逻辑。

_TOOL_KEYWORDS_EN = (
    # OpenAI function calling 标准
    "tool_calls", "tool_call", "toolcalls", "toolcall",
    "function_call", "function_calls", "functioncall",
    # ReAct 风格
    "action_input", "action",
    # 通用参数字段
    "arguments", "params", "parameters",
    # Anthropic 风格
    "tool_use", "tool_uses", "tooluse",
    # 各种 invoke 派生
    "invoke", "invocation", "invoke_tool",
    # antml 风格(Claude 内部)
    "antml:invoke", "antml:parameter",
    # 通用工具描述字段
    "parameter",
)

_TOOL_KEYWORDS_CN = (
    "工具调用", "调用工具", "调用函数", "执行工具",
    "操作记录", "历史工具调用", "过去的工具调用记录", "过去的操作记录",
)

_ALL_KEYWORDS = _TOOL_KEYWORDS_EN + _TOOL_KEYWORDS_CN

# 高置信度关键字 ── 只要文本里出现这些字面量(任何上下文),就认定有工具调用残骸,
# 触发兜底层。用于 D5 残留扫描那种"半截 / 残缺 / 无符号包裹"的怪样本。
_HIGH_CONFIDENCE_MARKERS = (
    # 带引号的(JSON 字段)
    '"tool_calls"', "'tool_calls'", '"tool_call"',
    '"action_input"', '"function":', '"function" :',
    '"arguments":', '"arguments" :',
    '"tool_use"', '"invoke"',
    # 不带引号的(YAML 风 / 裸残骸 ── v1 新增,修线上 `tool_calls: []` 漏案)
    'tool_calls:', 'tool_call:', 'toolcalls:', 'toolcall:',
    'function_call:', 'tool_use:',
    'action_input:',
    # 大括号开头变体
    '{tool_calls', '{"tool_calls', '{tool_call', '{function_call',
)

# 系统会在历史 assistant 消息中显示这种只读执行注记，但模型绝不能把它
# 仿写进本轮 reply。发送前无条件移除完整块；不依赖其它工具关键字判定。
_SYSTEM_TOOL_EXECUTION_NOTE_RE = re.compile(
    r"【\s*工具执行\s*[：:].*?】",
    re.DOTALL,
)


# 强工具关键字(出现就是工具调用,不需要看其它字段)。
# 用于"整段 JSON dict 判定"那一步 ── 含强关键字时即便同时有 content/reply
# 也算工具调用(修复复合 JSON {"content":"...","tool_calls":[...]} 漏案)。
_STRONG_TOOL_KEYS = {"tool_calls", "tool_call", "action_input", "function",
                     "action", "tool_use", "invoke"}
_WEAK_TOOL_KEYS = {"name", "arguments", "params", "parameters", "tool"}


# ──────────────────────────────────────────────────────────────────────────────
# § 1. 思维链泄漏剥离(独立小工具,chat.py 在轮内调用)
# ──────────────────────────────────────────────────────────────────────────────
# 部分模型(Claude / DeepSeek 思考模式)会把 <thinking>...</thinking> 漏到
# content 字段。chat.py 在每轮 LLM 响应解析时立即剥一次。

_THINKING_FULL_RE = re.compile(
    r"<think(?:ing)?\b[^>]*>.*?</think(?:ing)?\s*>",
    re.DOTALL | re.IGNORECASE,
)
_THINKING_OPEN_TAIL_RE = re.compile(
    r"<think(?:ing)?\b[^>]*>.*\Z",
    re.DOTALL | re.IGNORECASE,
)


def strip_thinking_tags(text: str) -> str:
    """剥离 LLM 漏出到 content 的 <thinking>/<think> 标签(含未闭合的尾部残骸)。"""
    if not text or not isinstance(text, str):
        return text or ""
    cleaned = _THINKING_FULL_RE.sub("", text)
    cleaned = _THINKING_OPEN_TAIL_RE.sub("", cleaned)
    return cleaned.strip()


# ──────────────────────────────────────────────────────────────────────────────
# § 2. 形态识别正则集合
# ──────────────────────────────────────────────────────────────────────────────

# § 2.1 XML 标签形态(所有英文工具关键字 + 中文工具关键字)
# 例:<tool_calls>...</tool_calls> / <调用工具>...</调用工具>
#
# 标签名匹配规则:从 _ALL_KEYWORDS 拼成正则 alternation,大小写不敏感。
# 中文关键字也走同一套正则(中文不区分大小写,但 re.IGNORECASE 不影响中文)。
# 标签后允许跟任何非 `>` 字符(兼容 <tool_calls type="x"> 这种带属性的写法)。
_TAG_NAME_PATTERN = "|".join(re.escape(k) for k in _ALL_KEYWORDS)

# 成对标签(标签内容跨行)
_XML_PAIR_RE = re.compile(
    rf"<\s*(?:{_TAG_NAME_PATTERN})\b[^>]*>.*?<\s*/\s*(?:{_TAG_NAME_PATTERN})\s*[^>]*>",
    re.DOTALL | re.IGNORECASE,
)
# 只剩开头标签的残片:<tool_calls...> 一直到文末
_XML_OPEN_TAIL_RE = re.compile(
    rf"<\s*(?:{_TAG_NAME_PATTERN})\b[^>]*>.*\Z",
    re.DOTALL | re.IGNORECASE,
)
# 只剩闭合标签的残片:文首一直到 </tool_calls>
_XML_CLOSE_HEAD_RE = re.compile(
    rf"\A.*?<\s*/\s*(?:{_TAG_NAME_PATTERN})\s*[^>]*>",
    re.DOTALL | re.IGNORECASE,
)
# 孤立单标签(自闭合 <x/> 或 <x>)
_XML_LONE_RE = re.compile(
    rf"<\s*/?\s*(?:{_TAG_NAME_PATTERN})\b[^>]*/?\s*>",
    re.IGNORECASE,
)


# § 2.2 中文/全角括号包裹工具关键字的形态
# 覆盖:【...】「...」『...』〈...〉《...》 ── 这些是中文文本里"括号"的常见
# 形态。英文 (...) 不动(人设动作描写依赖)。
# 触发条件:括号内必须含至少一个工具调用关键字,才认为是工具调用残骸。
_CN_BRACKET_PAIRS = [
    ("【", "】"),
    ("「", "」"),
    ("『", "』"),
    ("〈", "〉"),
    ("《", "》"),
    ("[", "]"),   # 英文方括号也算 ── 但下面会单独判定是否含关键字
]

def _strip_cn_bracket_tool_blocks(text: str) -> str:
    """
    剥中文/全角括号包裹的工具调用文本块。仅当括号内含工具关键字时才剥。

    示例命中:
      "【调用工具】" → 剥
      "【工具调用：send_emoji(...)】" → 剥
      "「执行工具 send_emoji」" → 剥
    示例不命中(普通中文用法):
      "【重要】" → 保留(无关键字)
      "「他说『你好』」" → 保留
      "(嘟囔)" → 保留(英文括号不动)
    """
    for left, right in _CN_BRACKET_PAIRS:
        # 非贪婪匹配 left ... right 中间不含 left/right(避免嵌套):
        # 用 [^{left}{right}]*? 这种字符类。
        # 注意 `[` 和 `]` 在字符类里要转义。
        pattern = re.compile(
            re.escape(left) + r"[^" + re.escape(left) + re.escape(right) + r"]{0,200}" + re.escape(right),
            re.DOTALL,
        )

        def _replacer(m):
            block = m.group(0)
            # 块内含任何工具关键字 → 剥(返回空字符串)
            block_lower = block.lower()
            for kw in _ALL_KEYWORDS:
                if kw.lower() in block_lower:
                    return ""
            return block

        text = pattern.sub(_replacer, text)
    return text


# § 2.3 Markdown 代码块包裹的工具调用
# 例:```json\n{"action":"send_emoji"}\n``` / ```tool_calls\n[...]\n```
#
# 整段被 ```...``` 包,且 fence 标签或内部含工具关键字 → 整段砍掉(含 fence)。
# 普通代码块(```python ...```)不动。
_FENCE_RE = re.compile(
    r"```([^\n]*)\n(.*?)\n?```",
    re.DOTALL,
)

def _strip_tool_fence_blocks(text: str) -> str:
    """剥 Markdown 代码块包裹的工具调用。普通代码块保留。"""
    def _replacer(m):
        lang = m.group(1).strip().lower()
        body = m.group(2)
        # fence lang 标签本身含关键字(如 ```tool_calls)
        if any(kw.lower() in lang for kw in _ALL_KEYWORDS):
            return ""
        # body 含高置信度关键字
        body_lower = body.lower()
        for kw in _ALL_KEYWORDS:
            if kw.lower() in body_lower:
                return ""
        # 兼容旧版:body 看起来像工具调用 JSON dict(强关键字)
        body_stripped = body.strip()
        if body_stripped.startswith("{") and body_stripped.endswith("}"):
            try:
                obj = json.loads(body_stripped)
                if isinstance(obj, dict):
                    keys = {str(k).lower() for k in obj.keys()}
                    if keys & _STRONG_TOOL_KEYS:
                        return ""
                    if (keys & _WEAK_TOOL_KEYS) and not (
                        keys & {"reply", "content", "text", "message"}
                    ):
                        return ""
            except Exception:
                pass
        return m.group(0)

    return _FENCE_RE.sub(_replacer, text)


# § 2.4 YAML 风裸键值残骸(无引号、无大括号包裹)
# 例:`tool_calls: [...]` `action: send_emoji` `arguments: {...}`
# 这是 v1 修线上 `tool_calls: []` 漏案专门加的形态。
#
# 关键:从关键字开始,贪婪吞到行末或者吞到下一个空行(双换行)为止。
# 如果关键字后面带 `:` + 值(JSON/方括号/纯文本),整段剥。
#
# 注意:**只在行首(或仅前面有空白)**才剥,避免误伤"句子中间提到 tool_calls"。
_YAML_KEYS_PATTERN = "|".join(
    re.escape(k) for k in (
        "tool_calls", "tool_call", "toolcalls", "toolcall",
        "function_call", "function_calls", "tool_use",
        "action_input", "action",
        "arguments", "params", "parameters",
        "invoke", "invocation",
    )
)

# 形如 `<空白>tool_calls: ANYTHING_UP_TO_BLANK_LINE_OR_EOF`
_YAML_BARE_RE = re.compile(
    rf"(?:^|\n)[ \t]*(?:{_YAML_KEYS_PATTERN})[ \t]*:[ \t]*(?:\[[^\]]*\]|\{{[^}}]*\}}|[^\n]*)(?:\n(?:[ \t]+[^\n]*|\][ \t]*|\}}[ \t]*))*",
    re.IGNORECASE,
)

def _strip_yaml_bare_residues(text: str) -> str:
    """剥行首形如 `tool_calls: [...]` 的 YAML 风残骸(无引号无大括号)。"""
    return _YAML_BARE_RE.sub("\n", text)


# § 2.5 整段是 JSON dict / 嵌入的 JSON dict
# JSON 字典工具调用 ── 用栈匹配 + json.loads 校验。
# 这一段是历史 _strip_inline_tool_call_json + _sanitize step 2 的合并版,
# 同时修了 v1 漏的"外层 tool_calls: [...] 包内层 dict"案例 ── 见下方注释。

_UNCLOSED_JSON_TRIGGERS = (
    '"tool_calls"', '"action"', '"action_input"',
    '"arguments"', '"function"', '"name":', '"tool_use"',
)


def _looks_like_tool_call_dict(obj: Any) -> bool:
    """dict 是否是工具调用 JSON(而非真实回复)。"""
    if not isinstance(obj, dict):
        return False
    keys = {str(k).lower() for k in obj.keys()}
    if keys & _STRONG_TOOL_KEYS:
        return True
    if (keys & _WEAK_TOOL_KEYS) and not (keys & {"reply", "content", "text", "message"}):
        return True
    return False


def _strip_inline_json_blocks(text: str, on_tool_extracted=None) -> str:
    """
    剔除文本里嵌入的工具调用 JSON dict 块。

    on_tool_extracted: Optional[Callable[[dict], None]]
        每剥掉一个合法工具调用 dict 时回调,把 dict 喂出去用于补救执行。
    """
    if "{" not in text:
        return text
    out = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch == "{":
            depth = 0
            j = i
            in_str = False
            esc = False
            while j < n:
                c = text[j]
                if esc:
                    esc = False
                elif c == "\\":
                    esc = True
                elif c == '"':
                    in_str = not in_str
                elif not in_str:
                    if c == "{":
                        depth += 1
                    elif c == "}":
                        depth -= 1
                        if depth == 0:
                            break
                j += 1
            if depth == 0 and j < n:
                candidate = text[i:j + 1]
                try:
                    obj = json.loads(candidate)
                    if isinstance(obj, dict) and _looks_like_tool_call_dict(obj):
                        if on_tool_extracted is not None:
                            on_tool_extracted(obj)
                        i = j + 1
                        continue
                except Exception:
                    # 残缺但含高置信度关键字 → 同样剥
                    if any(t in candidate for t in _UNCLOSED_JSON_TRIGGERS):
                        i = j + 1
                        continue
            else:
                # 未闭合:从此处到文末若含高置信度关键字 → 截断丢弃
                preview = text[i:i + 200]
                if any(t in preview for t in _UNCLOSED_JSON_TRIGGERS):
                    return "".join(out).rstrip()
            out.append(ch)
            i += 1
        else:
            out.append(ch)
            i += 1
    return "".join(out)


# § 2.6 方括号时间戳清洗(独立于工具调用,但属于"上下文格式残骸")
# 例:[北京时间 2026-05-23 14:30]
_BRACKET_TIMESTAMP_RE = re.compile(
    r"\[(?:北京时间|当前时间|现在时间|时间)[^\]]*\]",
)

def _strip_bracket_timestamp(text: str) -> str:
    """剥方括号时间戳前缀(只删 [...]，不动 (...))。"""
    return _BRACKET_TIMESTAMP_RE.sub("", text)


# § 2.7 方括号"伪工具调用"文本(纯文字仿写,不是 JSON)
# 例:[工具调用：update_emotion_state(state="...")] / [调用 send_emoji]
# 注:此函数只剥**英文方括号**包含工具关键字的形态,中文括号已在 § 2.2 处理。
_BRACKET_TOOL_TEXT_RE = re.compile(
    r"\[\s*(?:" + "|".join(re.escape(k) for k in _TOOL_KEYWORDS_CN) +
    r")\s*[:：]?[^\]]{0,200}\]",
    re.IGNORECASE,
)

def _strip_bracket_tool_text(text: str) -> str:
    """剥英文方括号包工具调用关键字的形态(中文括号已在 § 2.2 处理)。"""
    return _BRACKET_TOOL_TEXT_RE.sub("", text)


# ──────────────────────────────────────────────────────────────────────────────
# § 3. 兜底:裸自然语言提取器
# ──────────────────────────────────────────────────────────────────────────────
# 当所有清洗规则跑完后 cleaned 为空 / 极短时,从原文里"找没有镶嵌在任何可疑
# 符号块内的自然语言"。
#
# 严格策略:
#   1. 先把原文按"可疑符号块"切碎 ── 任何 < > 【】「」『』 {} [] ``` 包裹的内容
#      都被去掉,剩下的认为是"可信中文区"。
#   2. 在可信区里抓 [中文 + 中文标点] 的连续片段(>=5 字),按序拼接返回。
#   3. 若提取后字数 < 5,返回空串(说明原文整段就是残骸,没有自然语言)。

_SUSPICIOUS_BLOCKS_RE = re.compile(
    # 所有可疑括号/标签/代码块,一次性砍掉
    r"<[^>]*>"               # XML 标签
    r"|【[^】]*】|「[^」]*」|『[^』]*』|〈[^〉]*〉|《[^》]*》"  # 中文括号
    r"|\[[^\]]*\]"           # 英文方括号
    r"|\{[^}]*\}"            # 大括号 ── 注意:用户消息里很少出现 {},清掉相对安全
    r"|```[^`]*```",         # markdown fence
    re.DOTALL,
)

_NATURAL_CN_RE = re.compile(
    r"[\u4e00-\u9fa5][\u4e00-\u9fa5,。!?、:;\u201c\u201d\u2018\u2019  —…]{4,}"
)

# 自然语言区**仍要扫一遍残留协议关键字**,凡是匹配的关键字一律 replace 掉。
_RESIDUE_KEYWORDS = (
    "tool_calls", "tool_call", "toolcalls", "toolcall",
    "function_call", "action_input", "action",
    "arguments", "params", "tool_use", "invoke",
    "antml:invoke", "antml:parameter", "parameter",
    "工具调用", "调用工具", "操作记录", "历史工具调用",
)

def extract_bare_natural_language(text: str) -> str:
    """
    兜底:从原文中提取所有未嵌入可疑符号块的中文自然语言段。

    用法:当主清洗管线清洗后为空时调用本函数,从**原文**(不是 cleaned 后的)
    取自然语言段拼接返回,保证用户至少看到一些回复。

    返回:
      - 拼接出的字符串(可能为空)
      - 长度 < 5 时返回空串
    """
    if not text:
        return ""
    # 把所有可疑符号块挖掉,只剩"可信中文区"
    safe_zone = _SUSPICIOUS_BLOCKS_RE.sub("\n", text)
    # 抓中文自然语言连续段
    chunks = _NATURAL_CN_RE.findall(safe_zone)
    joined = "".join(chunks)
    # 残留关键字再扫一遍(理论上正则已经隔绝)
    for kw in _RESIDUE_KEYWORDS:
        joined = joined.replace(kw, "")
    joined = joined.strip(' ,;:\u201c\u201d\u2018\u2019\n\t')
    if len(joined) < 5:
        return ""
    return joined


# ──────────────────────────────────────────────────────────────────────────────
# § 4. 高置信度关键字残留检测(D5)
# ──────────────────────────────────────────────────────────────────────────────
# 上面所有形态规则跑完之后,文本里要是还含 _HIGH_CONFIDENCE_MARKERS 任一字面,
# 说明清洗器漏了一种新形态 ── 触发兜底层(裸提取)。
#
# 跟 § 3 不同:本函数只判定,不提取;提取的工作交给 § 3。

def has_residual_leak(text: str) -> bool:
    """文本里是否还有高置信度工具调用残骸字面量。"""
    if not text:
        return False
    text_lower = text.lower()
    return any(m.lower() in text_lower for m in _HIGH_CONFIDENCE_MARKERS)


# ──────────────────────────────────────────────────────────────────────────────
# § 5. 主入口:clean() 和 clean_json_response()
# ──────────────────────────────────────────────────────────────────────────────

# 某些上游模型会用 <special>...</special> 标记特殊文本。
# 这不是业务协议，用户只应收到标签内容，因此只删除开始/结束标签，
# 不删除中间文字。兼容大小写、属性和单边残缺标签。
_SPECIAL_TAG_RE = re.compile(r"</?\s*special\b[^>]*>", re.IGNORECASE)


def strip_special_tags(text: str) -> str:
    """只移除 ``special`` 标签本身，完整保留其包裹的文本。"""
    if not isinstance(text, str) or not text:
        return text if isinstance(text, str) else ""
    return _SPECIAL_TAG_RE.sub("", text)

async def clean_json_response(
    raw_content: str,
    diag_logger: Optional[Callable[[str], Awaitable[None]]] = None,
    reasoning_fallback: Optional[str] = None,
) -> dict:
    """
    v?? (2026-05-27) JSON 响应解析 + 多级兜底

    优先级(严格按顺序, 找到就返回):
        1. 正文 JSON 直接解析合法 → 抽 reply
        2. 正文剥 markdown ```json``` 围栏后再 parse → 抽 reply
        3. 正文里找第一个 {...} 块再 parse → 抽 reply
        4. 全部失败 → 返回 _invalid_json 标记，由 chat.py 触发协议重试

    入参:
        raw_content        : message.content 原始字符串
        diag_logger        : 异步日志回调
        reasoning_fallback : 正文完全为空时，允许从思维链恢复完整 JSON 信封；
                             仅可恢复 reply/mind_event，tools 会被强制清空，保证
                             思维链里的预演工具永远没有执行权。

    返回:
        {"reply": str, "tools": list}；失败时额外含 _invalid_json=True
        保证返回 dict 含两个字段, 永远不抛异常。
    """
    async def _log(msg: str):
        if diag_logger is not None:
            try:
                await diag_logger(msg)
            except Exception:
                pass

    if not raw_content or not isinstance(raw_content, str):
        raw_content = ""

    text = strip_thinking_tags(raw_content).strip() if raw_content else ""

    # ── 阶段 1-3: 正文 JSON 解析(三段式) ─────────────────────────────────
    if text:
        # 阶段 1: 直接 parse
        parsed = _try_json_parse(text)
        if parsed is not None:
            await _log("[json清洗] 正文直接 JSON 解析成功")
            return _normalize_parsed(parsed, _log_sync=None)

        # 阶段 2: 剥 markdown 围栏后 parse
        stripped = _strip_markdown_fences(text)
        if stripped != text:
            parsed = _try_json_parse(stripped)
            if parsed is not None:
                await _log(f"[json清洗] 正文剥 markdown 围栏后解析成功")
                return _normalize_parsed(parsed, _log_sync=None)
        else:
            stripped = text

        # 阶段 3: 找最后一个完整的“回复信封”JSON。模型可能先输出状态
        # JSON、甚至先写一版再修订；不能把第一个分析对象误当最终回复。
        json_block = _find_response_json_object(stripped)
        if json_block:
            parsed = _try_json_parse(json_block)
            if parsed is not None:
                await _log(f"[json清洗] 正文内嵌 JSON 块抽取成功")
                return _normalize_parsed(parsed, _log_sync=None)

    # ── 阶段 4: 空正文时只从思维链恢复可见回复，不恢复任何工具 ─────────
    # 某些 Gemini 中转会把完整 JSON 放进 thought Part，而正式正文 token=0。
    # 为避免所有用户进入空回复重试，只允许在“正文完全为空”时恢复最后一个
    # 完整响应信封；无论其中写了什么，tools 都清空，绝不执行思维预演动作。
    if not text and isinstance(reasoning_fallback, str) and reasoning_fallback.strip():
        reasoning_text = reasoning_fallback.strip()
        candidates = [reasoning_text, _strip_markdown_fences(reasoning_text)]
        block = _find_response_json_object(candidates[-1])
        if block:
            candidates.append(block)
        for candidate in reversed(candidates):
            parsed = _try_json_parse(candidate)
            if parsed is None:
                continue
            normalized = _normalize_parsed(parsed, _log_sync=None)
            reply = (normalized.get("reply") or "").strip()
            if reply:
                await _log("[json清洗] 正文为空，从思维摘要恢复回复内容（未恢复工具）")
                normalized["tools"] = []
                normalized["_recovered_from_reasoning"] = True
                return normalized

    # ── 阶段 5: 全部失败 → 明确标记非法 JSON，由 chat.py 重试 ──────────
    # 结构化输出解析绝不能把协议残片或系统指令裸提取成用户回复。最终发送前的
    # 工具泄漏清洗仍可使用 extract_bare_natural_language；这里只负责判定响应信封。
    await _log("[json清洗] 无法获取回复内容：正式正文中没有合法 JSON")
    return {"reply": "", "tools": [], "_invalid_json": True}


def _try_json_parse(text: str):
    """尝试 json.loads, 失败返回 None。"""
    try:
        obj = json.loads(text)
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None


# markdown 代码围栏正则: ```json ... ``` 或 ``` ... ```
_MD_FENCE_RE = re.compile(r"^\s*```(?:json|JSON)?\s*\n?(.*?)\n?```\s*$", re.DOTALL)

def _strip_markdown_fences(text: str) -> str:
    """剥 ```json``` 或 ``` 围栏, 没匹配返回原文。"""
    m = _MD_FENCE_RE.match(text)
    if m:
        return m.group(1).strip()
    return text


def _find_first_json_object(text: str) -> str:
    """
    在 text 里找第一个平衡的 {...} 块, 返回其字符串。
    用于处理"前后有解释文字 + 中间是 JSON"的脏响应。
    没找到返回 ""。
    """
    if not text or "{" not in text:
        return ""
    start = text.find("{")
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(text)):
        ch = text[i]
        if esc:
            esc = False
            continue
        if ch == "\\":
            esc = True
            continue
        if ch == '"':
            in_str = not in_str
            continue
        if in_str:
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start:i+1]
    return ""


def _find_json_objects(text: str) -> list[str]:
    """按出现顺序返回文本中所有顶层、平衡的 JSON 对象字符串。"""
    if not text or "{" not in text:
        return []

    objects: list[str] = []
    start = None
    depth = 0
    in_str = False
    esc = False
    for index, ch in enumerate(text):
        if esc:
            esc = False
            continue
        if ch == "\\" and in_str:
            esc = True
            continue
        if ch == '"':
            in_str = not in_str
            continue
        if in_str:
            continue
        if ch == "{":
            if depth == 0:
                start = index
            depth += 1
        elif ch == "}" and depth > 0:
            depth -= 1
            if depth == 0 and start is not None:
                objects.append(text[start:index + 1])
                start = None
    return objects


def _find_response_json_object(text: str) -> str:
    """返回最后一个完整回复信封，忽略 ``{"state": ...}`` 等分析对象。"""
    selected = ""
    for block in _find_json_objects(text):
        parsed = _try_json_parse(block)
        if not isinstance(parsed, dict):
            continue
        if any(key in parsed for key in ("reply", "content", "text", "message", "tools")):
            selected = block
    return selected


def _normalize_parsed(parsed: dict, _log_sync=None) -> dict:
    """
    把解析出的 dict 归一化成 {"reply": str, "tools": list}。
    容错:
      - reply 字段缺失 → 尝试 content/text/message 字段兜底
      - tools 字段缺失 → []
      - tools 不是 list → []
      - 兼容 {"name","params"}、{"function_call":{"name","args"}}
        和 {"function":{"name","arguments"}} 形态
    """
    if not isinstance(parsed, dict):
        return {"reply": "", "tools": []}

    # reply 字段: 优先 reply, 兼容 content / text / message
    reply = ""
    for k in ("reply", "content", "text", "message"):
        v = parsed.get(k)
        if isinstance(v, str):
            reply = v.strip()
            if reply:
                break

    # tools 字段
    tools_raw = parsed.get("tools", [])
    if not isinstance(tools_raw, list):
        tools_raw = []

    tools = []
    for tc in tools_raw:
        if not isinstance(tc, dict):
            continue
        call = tc
        for wrapper_key in ("function_call", "function"):
            wrapped = tc.get(wrapper_key)
            if isinstance(wrapped, dict):
                call = wrapped
                break
        name = call.get("name") or tc.get("name")
        if not name or not isinstance(name, str):
            continue
        params = call.get("params")
        if not isinstance(params, dict):
            params = call.get("args")
        if not isinstance(params, dict):
            # 兼容 arguments 字段(OpenAI 旧协议形态)
            args = call.get("arguments")
            if isinstance(args, dict):
                params = args
            elif isinstance(args, str):
                try:
                    params = json.loads(args)
                except Exception:
                    params = {}
            else:
                params = {}
        tools.append({"name": name, "params": params})

    return {"reply": reply, "tools": tools}


async def clean(
    text: str,
    diag_logger: Optional[Callable[[str], Awaitable[None]]] = None,
) -> str:
    """
    工具调用残骸统一清洗入口。详见模块顶部 docstring。

    执行顺序:
      1. 整段是 JSON dict 优先处理 ── 含工具关键字时提 content/reply/text/message,
         否则清空(防整段就是 {"action":"..."} 的怪样本)。
      2. XML 标签形态(成对/单边/孤立)按白名单关键字剥。
      3. 中文括号 + 英文方括号 + Markdown fence + YAML 裸残骸 + 嵌入 JSON dict
         五类同步剥。这里只清洗，任何工具都不得执行。
      4. 方括号时间戳 / 方括号伪工具调用文本一起清。
      5. 残留扫描(has_residual_leak):上述规则跑完还有 _HIGH_CONFIDENCE_MARKERS
         字面 → 走兜底层 (extract_bare_natural_language)。
      6. 终态守卫:cleaned 为空 / < 5 字 → 用裸提取兜底。如果原文里有自然语言段,
         至少能拿到一些;真没有就空串。
    """
    if not text or not isinstance(text, str):
        return ""

    # 防御性预处理:即使 chat.py 已在轮内调过 strip_thinking_tags,这里再跑一次
    # (幂等),避免某些场景漏剥。special 只脱标签，不脱内容。
    text = strip_thinking_tags(text)
    text_before_special = text
    text = strip_special_tags(text)
    special_tag_removed = text != text_before_special

    original = text
    s = text.strip()
    # 记一份"原文里所有高置信度残骸字面量",用于稍后判定 "lost_all_markers"
    original_high_conf_hit = has_residual_leak(s)

    async def _log(msg: str):
        if diag_logger is not None:
            try:
                await diag_logger(msg)
            except Exception:
                pass

    if special_tag_removed:
        await _log("[tool_leak_cleaner] 已移除 special 标签并保留标签内文本")

    # ── 阶段 0:系统只读工具历史注记绝不允许进入用户正文 ───────────────
    stripped_system_note = _SYSTEM_TOOL_EXECUTION_NOTE_RE.sub("", s).strip()
    if stripped_system_note != s:
        await _log("[tool_leak_cleaner] 已移除模型仿写的工具执行历史注记")
        s = stripped_system_note
        if not s:
            return ""

    # ── 阶段 A:整段是 JSON dict ────────────────────────────────────────
    if s.startswith("{") and s.endswith("}"):
        try:
            obj = json.loads(s)
            if isinstance(obj, dict):
                if _looks_like_tool_call_dict(obj):
                    # 提 content/reply/text/message
                    for fld in ("content", "reply", "text", "message"):
                        v = obj.get(fld)
                        if isinstance(v, str) and v.strip():
                            await _log(
                                f"[tool_leak_cleaner] 整段是工具调用 JSON,"
                                f"已提取 '{fld}' 字段({len(v.strip())}字)"
                            )
                            return _strip_bracket_timestamp(v.strip())
                    await _log(
                        f"[tool_leak_cleaner] 整段是工具调用 JSON 且无可提取字段,清空。"
                        f"keys={list(obj.keys())[:5]}"
                    )
                    return ""
                # 非工具调用的 dict(普通结构化输出)── 不动,继续走下面规则
        except Exception:
            pass

    # ── 阶段 B:容错补闭合符(以 { 开头但 } 不闭合)────────────────────
    if s.startswith("{") and not s.endswith("}"):
        diff_brace = s.count("{") - s.count("}")
        diff_square = s.count("[") - s.count("]")
        if diff_brace > 0 or diff_square > 0:
            patched = s + ("]" * max(0, diff_square)) + ("}" * max(0, diff_brace))
            try:
                obj = json.loads(patched)
                if isinstance(obj, dict):
                    if "reply" in obj and isinstance(obj["reply"], str):
                        await _log("[tool_leak_cleaner] 截断 JSON 补闭合后含 reply,已提取")
                        return _strip_bracket_timestamp(obj["reply"].strip())
                    if _looks_like_tool_call_dict(obj):
                        await _log("[tool_leak_cleaner] 截断 JSON 补闭合后是工具调用,清空")
                        return ""
            except Exception:
                pass

    # ── 阶段 C:形态规则并行剥除 ──────────────────────────────────────────
    # 顺序:先 XML(跨行最长),再 fence(独立块),再 YAML 裸,再嵌入 JSON,
    # 最后中文/英文括号 + 时间戳 + 方括号伪调用。
    # 每一步都是幂等的(再跑一次结果不变),所以顺序不敏感,但按"大块到小块"
    # 顺序跑日志更清晰。
    s = _XML_PAIR_RE.sub("", s)
    s = _XML_OPEN_TAIL_RE.sub("", s)
    s = _XML_CLOSE_HEAD_RE.sub("", s)
    s = _XML_LONE_RE.sub("", s)

    s = _strip_tool_fence_blocks(s)

    s = _strip_yaml_bare_residues(s)

    # 嵌入 JSON dict 只剥除。清洗层没有一轮完整状态，不能执行任何副作用。
    s = _strip_inline_json_blocks(s)

    s = _strip_cn_bracket_tool_blocks(s)
    s = _strip_bracket_tool_text(s)
    s = _strip_bracket_timestamp(s)

    s = s.strip()

    # ── 阶段 D:残留扫描(D5)─────────────────────────────────────────────
    # 跑到这里如果还有高置信度残骸字面量,说明形态规则漏了一种 → 走兜底
    if has_residual_leak(s):
        await _log(
            f"[tool_leak_cleaner] 形态规则跑完仍有残留关键字,走裸提取兜底。"
            f"残留预览: {s[:80]!r}"
        )
        bare = extract_bare_natural_language(original)
        if bare:
            return bare
        return ""

    # ── 阶段 E:50% 红线 + 防误伤(保留旧版兜底逻辑)─────────────────────
    # 清洗前后字数对比:
    #   ① 清洗后非空 且 ≥ 原文 50% → 信任清洗(常规路径)
    #   ② 清洗后非空 且 < 50% 但 原文含强关键字 / 清洗后已无 → 信任清洗(v21 硬否决)
    #   ③ 清洗后空 且 原文整段就是 JSON / 原文含强关键字 → 信任清洗(整段是残骸)
    #   ④ 清洗后空 且 原文非工具调用形态 → 异常,走裸提取兜底(防误伤导致静默)
    orig_len = len(original.strip())
    new_len = len(s)

    if s:
        if new_len >= orig_len * 0.5:
            return s
        # 缩水严重(<50%):若原文里有高置信度残骸,信任清洗
        if original_high_conf_hit:
            await _log(
                f"[tool_leak_cleaner] 清洗后缩水({orig_len}→{new_len}),"
                f"但原文含强关键字,信任清洗结果。"
            )
            return s
        # 否则视为误伤,降级用裸提取
        await _log(
            f"[tool_leak_cleaner] 清洗后缩水({orig_len}→{new_len}) 且原文无强关键字,"
            f"判定为误伤。降级用裸提取从原文取自然语言。"
        )
        bare = extract_bare_natural_language(original)
        # 如果裸提取更长更接近原文,用裸提取;否则用清洗结果(至少是干净的)
        if bare and len(bare) > new_len:
            return bare
        return s

    # s 为空:走兜底
    if original_high_conf_hit:
        # 原文就是整段残骸,清空合理
        await _log("[tool_leak_cleaner] 原文整段是工具调用残骸,清空合理")
        # 但仍试一下裸提取 ── 万一原文里也夹着自然语言段
        bare = extract_bare_natural_language(original)
        if bare:
            await _log(f"[tool_leak_cleaner] 裸提取补回 {len(bare)} 字自然语言")
            return bare
        return ""
    # 原文不含强关键字但清洗后空了 → 一定是误伤,强制裸提取
    bare = extract_bare_natural_language(original)
    if bare:
        await _log(
            f"[tool_leak_cleaner] 清洗误伤导致空串,裸提取兜底成功({len(bare)}字)"
        )
        return bare
    # 实在没有 → 空
    return ""

