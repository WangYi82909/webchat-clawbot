import base64
import json
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

import httpx

import weixin_media
from skills import send_emoji


def _response(status=200, *, json_data=None, headers=None, text=None):
    request = httpx.Request("POST", "https://example.test")
    if json_data is not None:
        return httpx.Response(
            status, request=request, json=json_data, headers=headers,
        )
    return httpx.Response(
        status, request=request, text=text or "", headers=headers,
    )


class FakeClient:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    async def post(self, url, **kwargs):
        self.calls.append((url, kwargs))
        return self.responses.pop(0)


class _Cursor:
    def __init__(self, rows):
        self.rows = rows
        self.query = ""

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return False

    async def execute(self, query, params):
        self.query = query

    async def fetchone(self):
        if "emojis_json" in self.query and "wx_token" in self.query:
            return {
                "emojis_json": self.rows["emojis_json"],
                "wx_token": self.rows["wx_token"],
            }
        if "emojis_json" in self.query:
            return {"emojis_json": self.rows["emojis_json"]}
        return {"wx_token": self.rows["wx_token"]}


class _Connection:
    def __init__(self, rows):
        self.rows = rows

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return False

    def cursor(self):
        return _Cursor(self.rows)


class _Acquire:
    def __init__(self, rows):
        self.rows = rows

    async def __aenter__(self):
        return _Connection(self.rows)

    async def __aexit__(self, *_):
        return False


class _Pool:
    def __init__(self, rows):
        self.rows = rows

    def acquire(self):
        return _Acquire(self.rows)


class OfficialWeixinMediaDeliveryTests(unittest.IsolatedAsyncioTestCase):
    async def test_upload_param_is_encoded_like_encode_uri_component(self):
        client = FakeClient([
            _response(json_data={"upload_param": "opaque/value+=&"}),
            _response(headers={"x-encrypted-param": "download-param"}),
            _response(json_data={"ret": 0}),
        ])
        image = b"\x89PNG\r\n\x1a\n" + b"payload" * 20
        await weixin_media.upload_and_send_image(
            client, "token", "wx-user", image, context_token="ctx-1",
        )

        self.assertEqual(len(client.calls), 3)
        cdn_url = client.calls[1][0]
        self.assertIn(
            "encrypted_query_param=opaque%2Fvalue%2B%3D%26",
            cdn_url,
        )
        self.assertNotIn("opaque/value", cdn_url)

        upload = client.calls[0][1]["json"]
        self.assertEqual(upload["base_info"]["channel_version"], "2.4.6")
        self.assertEqual(upload["base_info"]["bot_agent"], "OpenClaw")
        self.assertEqual(upload["media_type"], 1)
        self.assertTrue(upload["no_need_thumb"])

        message = client.calls[2][1]["json"]["msg"]
        self.assertEqual(message["context_token"], "ctx-1")
        image_item = message["item_list"][0]["image_item"]
        decoded_key = base64.b64decode(image_item["media"]["aes_key"])
        self.assertRegex(decoded_key.decode("ascii"), r"^[0-9a-f]{32}$")
        self.assertGreater(image_item["mid_size"], len(image))

    def test_generate_image_keeps_shared_media_implementation(self):
        root = Path(__file__).parent
        generated = (root / "skills" / "generate_image.py").read_text(encoding="utf-8")
        self.assertIn("weixin_media.upload_and_send_image", generated)
        self.assertNotIn("/ilink/bot/getuploadurl", generated.lower())

    def test_emoji_uses_parameters_from_supplied_past_version(self):
        root = Path(__file__).parent
        emoji = (root / "skills" / "send_emoji.py").read_text(encoding="utf-8")
        self.assertIn('APP_VERSION = "2.4.2"', emoji)
        self.assertIn('CLIENT_VERSION = "132098"', emoji)
        self.assertIn('BOT_AGENT = "PyWeixinBot/1.0"', emoji)
        self.assertIn('"context_token": ""', emoji)
        self.assertIn("legacy_param = urllib.parse.quote(upload_param)", emoji)
        self.assertIn("follow_redirects=True", emoji)
        self.assertIn("await _send_emoji_image_legacy", emoji)
        self.assertNotIn("asyncio.create_task", emoji)

    async def test_send_emoji_waits_for_legacy_delivery(self):
        image = b"GIF89a" + b"payload" * 20
        stored = [{
            "id": 7,
            "base64_data": "data:image/gif;base64," + base64.b64encode(image).decode(),
        }]
        pool = _Pool({
            "emojis_json": json.dumps(stored),
            "wx_token": "encrypted-token",
        })
        with (
            patch("skills.send_emoji.utils.decrypt_data", return_value="token"),
            patch("skills.send_emoji.utils.add_temp_log", new=AsyncMock()),
            patch(
                "skills.send_emoji._select_emoji_via_qe",
                new=AsyncMock(return_value="7"),
            ) as select,
            patch(
                "skills.send_emoji._send_emoji_image_legacy",
                new=AsyncMock(return_value={
                    "client_id": "cid-1",
                    "ret": 0,
                    "upload_route": "full_url",
                    "raw_size": len(image),
                }),
            ) as send,
        ):
            result = await send_emoji.run(
                {
                    "_conversation_context": [
                        {"role": "user", "content": "今天好开心"},
                        {"role": "assistant", "content": "我也是"},
                    ],
                    "_context_token": "ctx-live",
                },
                pool,
                12,
                "wx-user",
                object(),
            )
        self.assertTrue(result["success"])
        self.assertEqual(select.await_count, 1)
        select_args = select.await_args.args
        self.assertEqual(select_args[1][-1]["content"], "我也是")
        self.assertEqual(select_args[2], [{"emoji_id": "7", "tag": ""}])
        self.assertEqual(send.await_count, 1)
        args, kwargs = send.await_args
        self.assertEqual(args[1:4], ("token", "wx-user", image))
        self.assertEqual(kwargs, {})

    async def test_qe_selector_requires_json_and_temperature_point_one(self):
        client = FakeClient([_response(json_data={
            "choices": [{"message": {"content": '{"emoji_id":"7"}'}}],
        })])
        selected = await send_emoji._select_emoji_via_qe(
            client,
            [{"role": "user", "content": "太好了"}],
            [
                {"emoji_id": "7", "tag": "开心"},
                {"emoji_id": "8", "tag": "无语"},
            ],
        )

        self.assertEqual(selected, "7")
        payload = client.calls[0][1]["json"]
        self.assertEqual(payload["model"], send_emoji.QE_MODEL)
        self.assertEqual(payload["temperature"], 0.1)
        self.assertEqual(payload["thinking"], {"type": "disabled"})
        self.assertEqual(payload["response_format"], {"type": "json_object"})
        self.assertFalse(payload["stream"])
        request_data = json.loads(payload["messages"][1]["content"])
        self.assertEqual(request_data["conversation"][-1]["content"], "太好了")
        self.assertEqual(len(request_data["emojis"]), 2)
        self.assertNotIn("base64_data", payload["messages"][1]["content"])

    async def test_qe_selector_rejects_non_json_or_unknown_id(self):
        invalid_json = FakeClient([_response(json_data={
            "choices": [{"message": {"content": "emoji 7"}}],
        })])
        with self.assertRaisesRegex(RuntimeError, "合法 JSON"):
            await send_emoji._select_emoji_via_qe(
                invalid_json,
                [{"role": "user", "content": "x"}],
                [{"emoji_id": "7", "tag": "开心"}],
            )

        unknown = FakeClient([_response(json_data={
            "choices": [{"message": {"content": '{"emoji_id":"999"}'}}],
        })])
        with self.assertRaisesRegex(RuntimeError, "不存在"):
            await send_emoji._select_emoji_via_qe(
                unknown,
                [{"role": "user", "content": "x"}],
                [{"emoji_id": "7", "tag": "开心"}],
            )

    async def test_legacy_emoji_wire_format_matches_supplied_archive(self):
        client = FakeClient([
            _response(json_data={"upload_param": "opaque/value+"}),
            _response(headers={"x-encrypted-param": "download-param"}),
            _response(json_data={"ret": 0}),
        ])
        image = b"GIF89a" + b"payload" * 20
        with patch("skills.send_emoji.utils.generate_client_id", return_value="cid-1"):
            result = await send_emoji._send_emoji_image_legacy(
                client, "token", "wx-user", image,
            )

        self.assertEqual(result["client_id"], "cid-1")
        self.assertEqual(len(client.calls), 3)
        upload = client.calls[0][1]["json"]
        self.assertEqual(upload["media_type"], 1)
        self.assertTrue(upload["no_need_thumb"])
        self.assertEqual(upload["base_info"], {
            "channel_version": "2.4.2",
            "bot_agent": "PyWeixinBot/1.0",
        })
        self.assertIn("encrypted_query_param=opaque/value%2B", client.calls[1][0])
        self.assertNotIn("opaque%2Fvalue", client.calls[1][0])

        headers = client.calls[0][1]["headers"]
        self.assertEqual(headers["iLink-App-ClientVersion"], "132098")
        message = client.calls[2][1]["json"]["msg"]
        self.assertEqual(message["context_token"], "")
        self.assertEqual(message["client_id"], "cid-1")
        image_item = message["item_list"][0]["image_item"]
        decoded_key = base64.b64decode(image_item["media"]["aes_key"])
        self.assertRegex(decoded_key.decode("ascii"), r"^[0-9a-f]{32}$")

    async def test_emoji_prefers_server_full_url_for_existing_success_users(self):
        client = FakeClient([
            _response(json_data={
                "upload_full_url": "https://cdn.example.test/upload/full",
                "upload_param": "opaque/value+",
            }),
            _response(headers={"x-encrypted-param": "download-param"}),
            _response(json_data={"ret": 0}),
        ])

        result = await send_emoji._send_emoji_image_legacy(
            client, "token", "wx-user", b"GIF89a-payload",
        )

        self.assertEqual(result["upload_route"], "full_url")
        self.assertEqual(client.calls[1][0], "https://cdn.example.test/upload/full")
        self.assertEqual(len(client.calls), 3)

    async def test_emoji_falls_back_from_rejected_full_url_to_legacy_param(self):
        client = FakeClient([
            _response(json_data={
                "upload_full_url": "https://cdn.example.test/upload/full",
                "upload_param": "opaque/value+",
            }),
            _response(status=403, headers={"x-error-message": "bad signature"}),
            _response(headers={"x-encrypted-param": "download-param"}),
            _response(json_data={"ret": 0}),
        ])

        result = await send_emoji._send_emoji_image_legacy(
            client, "token", "wx-user", b"GIF89a-payload",
        )

        self.assertEqual(result["upload_route"], "upload_param_legacy")
        self.assertEqual(client.calls[1][0], "https://cdn.example.test/upload/full")
        self.assertIn("encrypted_query_param=opaque/value%2B", client.calls[2][0])

    async def test_emoji_falls_back_to_strict_encoding_for_affected_users(self):
        client = FakeClient([
            _response(json_data={"upload_param": "opaque/value+"}),
            _response(status=403, headers={"x-error-message": "bad query"}),
            _response(headers={"x-encrypted-param": "download-param"}),
            _response(json_data={"ret": 0}),
        ])

        result = await send_emoji._send_emoji_image_legacy(
            client, "token", "wx-user", b"GIF89a-payload",
        )

        self.assertEqual(result["upload_route"], "upload_param_strict")
        self.assertIn("encrypted_query_param=opaque/value%2B", client.calls[1][0])
        self.assertIn("encrypted_query_param=opaque%2Fvalue%2B", client.calls[2][0])

    async def test_emoji_retries_transient_cdn_5xx_on_same_route(self):
        full_url = "https://cdn.example.test/upload/full"
        client = FakeClient([
            _response(json_data={"upload_full_url": full_url}),
            _response(status=503, text="busy"),
            _response(headers={"x-encrypted-param": "download-param"}),
            _response(json_data={"ret": 0}),
        ])

        result = await send_emoji._send_emoji_image_legacy(
            client, "token", "wx-user", b"GIF89a-payload",
        )

        self.assertEqual(result["upload_route"], "full_url")
        self.assertEqual(client.calls[1][0], full_url)
        self.assertEqual(client.calls[2][0], full_url)

    async def test_emoji_all_routes_failure_reports_branch_without_signed_url(self):
        client = FakeClient([
            _response(json_data={
                "upload_full_url": "https://secret.example/upload/signed-token",
                "upload_param": "opaque/value+",
            }),
            _response(status=403, headers={"x-error-message": "full rejected"}),
            _response(status=403, headers={"x-error-message": "legacy rejected"}),
            _response(status=403, headers={"x-error-message": "strict rejected"}),
        ])

        with self.assertRaises(RuntimeError) as caught:
            await send_emoji._send_emoji_image_legacy(
                client, "token", "wx-user", b"GIF89a-payload",
            )

        detail = str(caught.exception)
        self.assertIn(
            "路径状态=full_url:HTTP403,upload_param_legacy:HTTP403,"
            "upload_param_strict:HTTP403",
            detail,
        )
        self.assertIn("full_url=HTTP 403", detail)
        self.assertIn("upload_param_legacy=HTTP 403", detail)
        self.assertIn("upload_param_strict=HTTP 403", detail)
        self.assertNotIn("signed-token", detail)

    async def test_legacy_emoji_rejects_http_200_business_error(self):
        client = FakeClient([
            _response(json_data={"ret": -1, "errmsg": "denied"}),
        ])
        image = b"GIF89a" + b"payload" * 20
        with self.assertRaisesRegex(RuntimeError, "denied"):
            await send_emoji._send_emoji_image_legacy(
                client, "token", "wx-user", image,
            )


if __name__ == "__main__":
    unittest.main()
