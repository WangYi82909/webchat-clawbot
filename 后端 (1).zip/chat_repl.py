#!/usr/bin/env python3
"""
chat_repl.py · 独立 OpenAI 协议命令行调试工具
==============================================

用途:
    排查"思维链 rsn 是否真的下发/返回/被提取"。
    不走 chat.py 的复杂流程, 直接命令行交互。

特点:
    - 调用 llm_protocol_openai.build_payload / extract_reasoning, 跟主程序一致
    - 每一轮把【原始请求体】和【原始响应体】完整打印到终端 + 写日志文件
    - 命令行明确显示: rsn 字段是否被提取、提取到几个字、思维链原文
    - 上下文只放内存(进程退出即丢), 不连数据库
    - 不用预设 / 不用工具 / 不用清洗器, 纯对话裸跑

用法:
    python chat_repl.py
    然后按提示输入: endpoint / api_key / model, 之后直接打字对话。

    特殊指令:
        :reset    清空上下文重新开始
        :hist     打印当前上下文
        :quit     退出

日志:
    chat_repl.log   每一轮的请求/响应原文 (追加写入)
"""

import asyncio
import json
import os
import sys
import datetime

try:
    import httpx
except ImportError:
    print("缺少 httpx, 请先安装:  pip install httpx", file=sys.stderr)
    sys.exit(1)

# 把当前目录加进 path, 才能 import llm_protocol_openai
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    import llm_protocol_openai as proto
except ImportError as e:
    print(f"无法 import llm_protocol_openai: {e}", file=sys.stderr)
    print("请把本脚本放在 llm_protocol_openai.py 同目录下运行。", file=sys.stderr)
    sys.exit(1)


# ─── 输出格式 ─────────────────────────────────────────────────────────
SEP_THICK = "═" * 70
SEP_THIN  = "─" * 70

def banner(title: str, char: str = "═"):
    print()
    print(char * 70)
    print(f"  {title}")
    print(char * 70)


# ─── 日志写入 ─────────────────────────────────────────────────────────
LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chat_repl.log")

def log_write(section: str, content: str):
    """追加写入日志文件, 带时间戳分隔。"""
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(f"\n[{ts}] {section}\n{SEP_THIN}\n{content}\n")


# ─── 主对话循环 ───────────────────────────────────────────────────────
async def chat_loop(endpoint: str, api_key: str, model: str):
    banner("准备完毕,开始对话")
    print(f"  模型:    {model}")
    print(f"  endpoint: {endpoint}")
    print(f"  api_key:  {api_key[:8]}...{api_key[-4:] if len(api_key) > 12 else ''}")
    print(f"  日志:    {LOG_PATH}")
    print()
    print("  指令: :reset 清空上下文 | :hist 看历史 | :quit 退出")
    print()

    # 上下文(只在内存,退出即丢)
    history: list[dict] = []
    turn = 0

    # 全局 httpx 客户端(长连接复用)
    async with httpx.AsyncClient(timeout=180.0) as client:
        while True:
            try:
                user_input = input("\033[36m你 > \033[0m").strip()
            except (EOFError, KeyboardInterrupt):
                print("\n再见。")
                return

            if not user_input:
                continue

            if user_input == ":quit":
                print("再见。")
                return
            if user_input == ":reset":
                history.clear()
                turn = 0
                print("[已清空上下文]")
                continue
            if user_input == ":hist":
                print(f"\n当前上下文 ({len(history)} 条):")
                for i, m in enumerate(history):
                    role = m["role"]
                    content = m["content"][:80].replace("\n", " ")
                    print(f"  {i}. [{role}] {content}{'...' if len(m['content']) > 80 else ''}")
                print()
                continue

            # 加入用户消息
            history.append({"role": "user", "content": user_input})
            turn += 1

            # ── 构造请求 ────────────────────────────────────────────
            # 用 proto.build_payload, 跟主程序完全一致的下发方式。
            # 注: build_payload 会自动加 reasoning_effort="low" 引导思考。
            #     不传 tools, 纯对话。
            payload = proto.build_payload(
                model=model,
                messages=history,
                temperature=1.0,
                presence_penalty=0.1,
                frequency_penalty=0.1,
                tools=None,
                enable_thinking=True,
                supports_thinking=True,   # 强制开, 不靠白名单
                tool_choice=None,
            )
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type":  "application/json",
            }

            # ── 终端打印请求 ────────────────────────────────────────
            req_dump = json.dumps(payload, ensure_ascii=False, indent=2)
            banner(f"第 {turn} 轮 · 原始请求", "═")
            print(req_dump)
            log_write(f"第 {turn} 轮 · 原始请求", req_dump)

            # ── 发请求 ──────────────────────────────────────────────
            try:
                resp = await client.post(endpoint, json=payload, headers=headers)
            except Exception as e:
                banner(f"第 {turn} 轮 · 请求失败", "✗")
                print(f"  异常: {type(e).__name__}: {e}")
                history.pop()
                turn -= 1
                continue

            if resp.status_code != 200:
                banner(f"第 {turn} 轮 · HTTP {resp.status_code}", "✗")
                print(resp.text[:2000])
                log_write(f"第 {turn} 轮 · HTTP {resp.status_code}", resp.text)
                history.pop()
                turn -= 1
                continue

            try:
                resp_json = resp.json()
            except Exception as e:
                banner(f"第 {turn} 轮 · JSON 解析失败", "✗")
                print(f"  {e}")
                print(resp.text[:2000])
                history.pop()
                turn -= 1
                continue

            # ── 终端打印响应 ────────────────────────────────────────
            resp_dump = json.dumps(resp_json, ensure_ascii=False, indent=2)
            banner(f"第 {turn} 轮 · 原始响应", "═")
            print(resp_dump)
            log_write(f"第 {turn} 轮 · 原始响应", resp_dump)

            # ── 提取关键信息 ────────────────────────────────────────
            # 1. message.keys()  —— 一眼看出上游返了哪些字段
            try:
                message = resp_json["choices"][0]["message"]
                msg_keys = list(message.keys())
            except Exception as e:
                banner(f"第 {turn} 轮 · 响应结构异常", "✗")
                print(f"  {e}")
                history.pop()
                turn -= 1
                continue

            # 2. content (正文)
            content = (message.get("content") or "").strip()

            # 3. reasoning (思维链) —— 用 proto.extract_reasoning, 跟主程序一致
            reasoning = proto.extract_reasoning(resp_json)

            # 4. usage 里的 reasoning_tokens (rsn 计费字段)
            usage = resp_json.get("usage") or {}
            rsn_tokens = (
                ((usage.get("completion_tokens_details") or {}).get("reasoning_tokens"))
                or usage.get("reasoning_tokens")
                or 0
            )
            in_tokens  = usage.get("prompt_tokens") or 0
            out_tokens = usage.get("completion_tokens") or 0

            # ── 终端高亮显示分析结果 ────────────────────────────────
            banner(f"第 {turn} 轮 · 分析", "━")
            print(f"  message.keys()         = {msg_keys}")
            print(f"  usage.in / out / rsn   = {in_tokens} / {out_tokens} / {rsn_tokens}")
            print()

            if reasoning is not None and reasoning.strip():
                print(f"  \033[32m✓ 思维链已提取\033[0m  ({len(reasoning)} 字)")
                print(f"  \033[90m思维链字段名: 来自 message.keys 中以下之一 → "
                      f"{[k for k in msg_keys if 'reason' in k.lower() or 'think' in k.lower() or 'thought' in k.lower()]}\033[0m")
                print()
                print(f"  \033[33m【思维链原文】\033[0m")
                # 限长打印, 防止刷屏; 日志里写全
                preview = reasoning if len(reasoning) <= 1500 else reasoning[:1500] + f"\n... [省略 {len(reasoning)-1500} 字, 完整看日志]"
                for line in preview.split("\n"):
                    print(f"    {line}")
                log_write(f"第 {turn} 轮 · 思维链(完整)", reasoning)
            else:
                print(f"  \033[31m✗ 思维链未提取\033[0m")
                print(f"  \033[90m原因分析:\033[0m")
                print(f"  - extract_reasoning 检查的字段: reasoning_content / reasoning / thinking / thought")
                print(f"  - 实际 message.keys: {msg_keys}")
                if rsn_tokens > 0:
                    print(f"  \033[31m  ★ usage.reasoning_tokens={rsn_tokens} > 0 说明上游有计费,\033[0m")
                    print(f"  \033[31m    但思维链字段没出现在 message 里 → 上游隐藏了内容,\033[0m")
                    print(f"  \033[31m    或者用了我们没覆盖的字段名(请翻日志找)。\033[0m")
                else:
                    print(f"  \033[90m  - usage.reasoning_tokens=0 → 上游根本没思考(模型设定或抑制)。\033[0m")

            # ── 显示正文 ───────────────────────────────────────────
            banner(f"第 {turn} 轮 · 正文回复", "━")
            if content:
                for line in content.split("\n"):
                    print(f"  {line}")
            else:
                print(f"  \033[31m(空响应)\033[0m")
            print()

            # 写回历史
            if content:
                history.append({"role": "assistant", "content": content})


# ─── 入口 ─────────────────────────────────────────────────────────────
def main():
    print("═" * 70)
    print("  chat_repl.py · OpenAI 协议命令行调试工具")
    print("═" * 70)
    print()

    # 用环境变量或交互输入, 都行
    endpoint = os.environ.get("LLM_ENDPOINT") or input(
        "endpoint (例: https://yunwu.ai/v1/chat/completions): "
    ).strip()
    if not endpoint:
        print("endpoint 不能空", file=sys.stderr); sys.exit(1)

    api_key = os.environ.get("LLM_API_KEY") or input("api_key: ").strip()
    if not api_key:
        print("api_key 不能空", file=sys.stderr); sys.exit(1)

    model = os.environ.get("LLM_MODEL") or input(
        "model (例: gemini-3.1-pro / gemini-3.1-flash-lite / o3-mini): "
    ).strip()
    if not model:
        print("model 不能空", file=sys.stderr); sys.exit(1)

    # 清空日志(每次启动覆盖, 不污染历史)
    with open(LOG_PATH, "w", encoding="utf-8") as f:
        f.write(f"# chat_repl 日志 · 启动时间 {datetime.datetime.now()}\n")
        f.write(f"# endpoint={endpoint}\n# model={model}\n")

    try:
        asyncio.run(chat_loop(endpoint, api_key, model))
    except KeyboardInterrupt:
        print("\n再见。")


if __name__ == "__main__":
    main()