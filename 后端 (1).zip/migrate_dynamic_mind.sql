-- Per-db_id dynamic mind state.
-- Safe to run more than once on MySQL 5.7+/8.0 and compatible MariaDB.

CREATE TABLE IF NOT EXISTS dynamic_mind_states (
    db_id BIGINT NOT NULL PRIMARY KEY,
    persona_id BIGINT NULL,
    schema_version INT NOT NULL DEFAULT 1,
    revision BIGINT NOT NULL DEFAULT 0,
    state_json LONGTEXT NOT NULL,
    next_proactive_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
        ON UPDATE CURRENT_TIMESTAMP(6),
    KEY idx_dynamic_mind_next_proactive (next_proactive_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

