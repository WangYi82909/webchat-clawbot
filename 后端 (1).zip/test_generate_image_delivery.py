import base64
import importlib.util
import unittest
from pathlib import Path

import httpx


def _load_skill():
    path = Path(__file__).parent / "skills" / "generate_image.py"
    spec = importlib.util.spec_from_file_location("test_generate_image_skill", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class _Client:
    def __init__(self, get_response=None):
        self.get_response = get_response
        self.get_calls = []

    async def get(self, url, **kwargs):
        self.get_calls.append((url, kwargs))
        return self.get_response


class GenerateImageResponseTests(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        cls.skill = _load_skill()
        cls.png = b"\x89PNG\r\n\x1a\n" + b"pixels" * 20

    @staticmethod
    def _response(payload, status=200):
        request = httpx.Request("POST", "https://image-api.test/v1/images/generations")
        return httpx.Response(status, request=request, json=payload)

    async def test_accepts_standard_b64_json(self):
        response = self._response({
            "data": [{"b64_json": base64.b64encode(self.png).decode()}]
        })
        result = await self.skill._extract_generated_image(_Client(), response)
        self.assertEqual(result, self.png)

    async def test_accepts_data_url_in_url_field(self):
        data_url = "data:image/png;base64," + base64.b64encode(self.png).decode()
        response = self._response({"data": [{"url": data_url}]})
        client = _Client()
        result = await self.skill._extract_generated_image(client, response)
        self.assertEqual(result, self.png)
        self.assertEqual(client.get_calls, [])

    async def test_accepts_download_url_and_validates_image(self):
        response = self._response({"data": [{"url": "https://cdn.test/image.png"}]})
        request = httpx.Request("GET", "https://cdn.test/image.png")
        download = httpx.Response(200, request=request, content=self.png)
        result = await self.skill._extract_generated_image(_Client(download), response)
        self.assertEqual(result, self.png)

    async def test_rejects_json_that_has_no_image(self):
        response = self._response({"data": [{}]})
        with self.assertRaisesRegex(RuntimeError, "既未返回"):
            await self.skill._extract_generated_image(_Client(), response)


if __name__ == "__main__":
    unittest.main()
