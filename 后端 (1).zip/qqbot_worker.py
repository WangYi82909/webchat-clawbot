#!/usr/bin/env python3
"""CloudLove QQ C2C WebSocket 通道。

传输层负责官方 QQ Bot 的稳定链路：

* 通过 bots.qq.com 换取短期 access_token；
* 通过官方 Gateway WebSocket 接收 C2C_MESSAGE_CREATE；
* 使用带 msg_id 的被动回复接口按顺序回一条或多条文本、图片；
* 保存 session_id/seq，支持断线后 RESUME；
* 不监听任何公网 HTTP 端口；数据库管理器会把 C2C 文本交给现有 chat.py。

独立运行时 ``build_reply`` 仅返回原文；由 main.py 启动的
``QQBotManager`` 使用 ``chat.generate_reply``，复用现有模型、人格、计费和
上下文链路。QQ 暂不加入主动消息和群聊；图片由同步工具在当前被动
消息上下文中上传并发送，完成后再由模型生成承接文字。
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import os
import secrets
import signal
import time
from pathlib import Path
from typing import Any, Awaitable, Callable
from urllib.parse import quote

import httpx
import websockets


# ---------------------------------------------------------------------------
# 独立运行测试时可填写这两个值。嵌入 main.py 的数据库管理器不会使用这两个
# 常量，而是从 qq_bot_accounts 表读取每个用户自己的 app_id/client_secret。
# 不要把短期 access_token 粘进代码，access_token 会过期，worker 会自动换取。
# ---------------------------------------------------------------------------
APP_ID = "REPLACE_WITH_QQBOT_APP_ID"
CLIENT_SECRET = ""

# 只接收 C2C，群消息先不启用，避免第一阶段把群聊权限、@规则和业务路由混进来。
ENABLE_GROUP_MESSAGES = False
MAX_REPLY_CHARS = 2000

WORKDIR = Path(__file__).resolve().parent
STATE_DIR = WORKDIR / "state" / "qqbot"

TOKEN_BASE_URL = "https://bots.qq.com"
API_BASE_URL = "https://api.sgroup.qq.com"
USER_AGENT = "cloudlove-qqbot/1.0"

# Gateway intents: DIRECT_MESSAGE | GROUP_AND_C2C.
INTENTS = (1 << 12) | (1 << 25)

OP_DISPATCH = 0
OP_HEARTBEAT = 1
OP_IDENTIFY = 2
OP_RESUME = 6
OP_RECONNECT = 7
OP_INVALID_SESSION = 9
OP_HELLO = 10
OP_HEARTBEAT_ACK = 11

LOG = logging.getLogger("cloudlove.qqbot")


class TokenRejected(RuntimeError):
    """Access token was rejected; the next request must fetch a new one."""


# 处理器可以返回整段文本，也可以返回已经按渠道规则切好的多段文本。
# QQ 传输层负责按数组顺序逐条发送，避免把分段逻辑散落在各个模型协议里。
MessageReply = str | list[str] | tuple[str, ...] | None
MessageHandler = Callable[["QQBotWorker", str, str, str], Awaitable[MessageReply]]


class QQBotWorker:
    def __init__(
        self,
        *,
        app_id: str | None = None,
        client_secret: str | None = None,
        on_c2c_message: MessageHandler | None = None,
        account_label: str = "standalone",
    ) -> None:
        self.app_id = (app_id if app_id is not None else APP_ID).strip()
        self.client_secret = (
            client_secret if client_secret is not None else CLIENT_SECRET
        ).strip()
        self.on_c2c_message = on_c2c_message
        self.account_label = account_label
        safe_label = "".join(
            ch if ch.isalnum() or ch in "-_" else "_" for ch in account_label
        )[:80] or "standalone"
        self.session_file = STATE_DIR / f"session_{safe_label}.json"
        self.ready = False
        self.last_error = ""
        self.stop_event = asyncio.Event()
        self.http: httpx.AsyncClient | None = None
        self.access_token: str | None = None
        self.token_expires_at = 0.0
        self.session_id: str | None = None
        self.last_seq: int | None = None
        self.heartbeat_task: asyncio.Task[None] | None = None
        self.seen_message_ids: set[str] = set()

    # ----------------------------- lifecycle --------------------------------

    async def run(self) -> None:
        if not self._is_enabled():
            LOG.info("QQBot 未启用（设置 QQBOT_ENABLED=1 后再启动）")
            return
        if not self._credentials_ready():
            LOG.error(
                "QQBot 未启动：请先填写 APP_ID 和 CLIENT_SECRET；"
                "当前不会监听公网端口。"
            )
            return

        STATE_DIR.mkdir(parents=True, exist_ok=True)
        self._load_session()
        self.http = httpx.AsyncClient(timeout=httpx.Timeout(30.0, connect=15.0))
        backoff = 2.0
        try:
            while not self.stop_event.is_set():
                try:
                    await self._connect_once()
                    backoff = 2.0
                    # 正常 close 也要留出退避时间，避免服务端主动断开时形成
                    # “连接-断开-立即重连”的忙循环。
                    await self._sleep(2.0)
                except asyncio.CancelledError:
                    raise
                except TokenRejected as exc:
                    self.access_token = None
                    self.token_expires_at = 0.0
                    self.ready = False
                    self.last_error = str(exc)[:500]
                    LOG.error("QQBot 令牌被拒绝，将刷新令牌后重连：%s", exc)
                    await self._sleep(5.0)
                except websockets.exceptions.ConnectionClosed as exc:
                    # “no close frame received or sent” 是 websockets 对网关
                    # 异常断开的标准异常，不代表 QQ 进程已停止。保留
                    # session_id/seq 走 RESUME，并按退避时间自动重连。
                    self.ready = False
                    self.last_error = str(exc)[:500]
                    LOG.warning(
                        "QQ Gateway WebSocket 断开(code=%s reason=%s)，将在 %.1f 秒后重连",
                        getattr(exc, "code", "?"),
                        getattr(exc, "reason", "") or "无关闭原因",
                        backoff,
                    )
                    await self._sleep(backoff)
                    backoff = min(backoff * 2.0, 60.0)
                except Exception as exc:  # noqa: BLE001 - 连接守护进程必须继续运行
                    self.ready = False
                    self.last_error = str(exc)[:500]
                    LOG.error("QQBot 连接异常，将在 %.1f 秒后重连：%s", backoff, exc)
                    await self._sleep(backoff)
                    backoff = min(backoff * 2.0, 60.0)
        finally:
            await self._cancel_heartbeat()
            if self.http is not None:
                await self.http.aclose()
                self.http = None
            LOG.info("QQBot 已停止")

    def request_stop(self) -> None:
        self.stop_event.set()

    @staticmethod
    def _is_enabled() -> bool:
        return os.getenv("QQBOT_ENABLED", "1").strip().lower() in {"1", "true", "yes", "on"}

    def _credentials_ready(self) -> bool:
        return bool(
            self.app_id
            and self.client_secret
            and not self.app_id.startswith("REPLACE_WITH_")
            and not self.client_secret.startswith("REPLACE_WITH_")
        )

    async def _sleep(self, seconds: float) -> None:
        try:
            await asyncio.wait_for(self.stop_event.wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass

    # ------------------------------ token -----------------------------------

    async def _get_access_token(self, force: bool = False) -> str:
        if not force and self.access_token and time.monotonic() < self.token_expires_at - 300:
            return self.access_token
        if self.http is None:
            raise RuntimeError("HTTP client 未初始化")

        response = await self.http.post(
            f"{TOKEN_BASE_URL}/app/getAppAccessToken",
            headers={"Content-Type": "application/json", "User-Agent": USER_AGENT},
            json={"appId": self.app_id, "clientSecret": self.client_secret},
        )
        if response.status_code >= 400:
            body = response.text[:500]
            raise RuntimeError(f"获取 access_token 失败 HTTP {response.status_code}: {body}")
        try:
            data = response.json()
        except ValueError as exc:
            raise RuntimeError("获取 access_token 返回了非法 JSON") from exc
        token = str(data.get("access_token") or "").strip()
        if not token:
            raise RuntimeError(f"获取 access_token 响应缺少 access_token: {data}")
        try:
            expires_in = max(float(data.get("expires_in", 7200)), 60.0)
        except (TypeError, ValueError):
            expires_in = 7200.0
        self.access_token = token
        self.token_expires_at = time.monotonic() + expires_in
        LOG.info("QQBot access_token 获取成功，预计 %.0f 秒后刷新", expires_in)
        return token

    async def _get_gateway_url(self, token: str) -> str:
        if self.http is None:
            raise RuntimeError("HTTP client 未初始化")
        response = await self.http.get(
            f"{API_BASE_URL}/gateway",
            headers={"Authorization": f"QQBot {token}", "User-Agent": USER_AGENT},
        )
        if response.status_code == 401:
            raise TokenRejected("获取 Gateway 返回 HTTP 401")
        if response.status_code >= 400:
            raise RuntimeError(
                f"获取 Gateway 失败 HTTP {response.status_code}: {response.text[:500]}"
            )
        try:
            url = str(response.json().get("url") or "").strip()
        except ValueError as exc:
            raise RuntimeError("Gateway 响应不是合法 JSON") from exc
        if not url.startswith(("ws://", "wss://")):
            raise RuntimeError(f"Gateway 返回了无效 WebSocket 地址: {url!r}")
        return url

    # --------------------------- gateway session -----------------------------

    async def _connect_once(self) -> None:
        token = await self._get_access_token()
        gateway_url = await self._get_gateway_url(token)
        LOG.info("连接 QQ Gateway: %s", gateway_url)

        # websockets 旧版参数名为 extra_headers，16.x 改为 additional_headers。
        try:
            ws_context = websockets.connect(
                gateway_url,
                additional_headers={"User-Agent": USER_AGENT},
                max_size=4 * 1024 * 1024,
                open_timeout=20,
                ping_interval=None,
            )
        except TypeError:
            ws_context = websockets.connect(
                gateway_url,
                extra_headers={"User-Agent": USER_AGENT},
                max_size=4 * 1024 * 1024,
                open_timeout=20,
                ping_interval=None,
            )

        async with ws_context as ws:
            LOG.info("QQ Gateway WebSocket 已连接")
            await self._cancel_heartbeat()
            async for raw in ws:
                try:
                    payload = json.loads(raw)
                except (TypeError, ValueError) as exc:
                    LOG.warning("忽略非法 Gateway JSON: %s", exc)
                    continue
                if not isinstance(payload, dict):
                    continue

                if payload.get("s") is not None:
                    try:
                        self.last_seq = int(payload["s"])
                    except (TypeError, ValueError):
                        LOG.warning("Gateway seq 非数字，已忽略: %r", payload.get("s"))
                    self._save_session()

                op = payload.get("op")
                if op == OP_HELLO:
                    data = payload.get("d") or {}
                    interval = float(data.get("heartbeat_interval", 45000)) / 1000.0
                    self.heartbeat_task = asyncio.create_task(self._heartbeat(ws, interval))
                    await self._identify_or_resume(ws, token)
                elif op == OP_DISPATCH:
                    await self._handle_event(payload.get("t"), payload.get("d"))
                elif op == OP_RECONNECT:
                    LOG.warning("Gateway 要求重连")
                    await ws.close()
                    break
                elif op == OP_INVALID_SESSION:
                    can_resume = bool(payload.get("d"))
                    LOG.warning("Gateway INVALID_SESSION can_resume=%s", can_resume)
                    if not can_resume:
                        self.session_id = None
                        self.last_seq = None
                        self._clear_session()
                    self.ready = False
                    await ws.close()
                    break
                elif op == OP_HEARTBEAT_ACK:
                    LOG.debug("Gateway heartbeat ACK")

            await self._cancel_heartbeat()
            self.ready = False
            LOG.warning("QQ Gateway WebSocket 已断开")

    async def _identify_or_resume(self, ws: Any, token: str) -> None:
        if self.session_id and self.last_seq is not None:
            payload = {
                "op": OP_RESUME,
                "d": {
                    "token": f"QQBot {token}",
                    "session_id": self.session_id,
                    "seq": self.last_seq,
                },
            }
            LOG.info("尝试 RESUME session_id=%s seq=%s", self.session_id, self.last_seq)
        else:
            payload = {
                "op": OP_IDENTIFY,
                "d": {"token": f"QQBot {token}", "intents": INTENTS, "shard": [0, 1]},
            }
            LOG.info("发送 IDENTIFY（仅 C2C/群聊 intent，当前只处理 C2C）")
        await ws.send(json.dumps(payload, ensure_ascii=False))

    async def _heartbeat(self, ws: Any, interval: float) -> None:
        # 只由这一条 task 发送心跳，避免和 recv 循环竞争 WebSocket 写入。
        try:
            while True:
                await asyncio.sleep(max(interval, 5.0))
                await ws.send(json.dumps({"op": OP_HEARTBEAT, "d": self.last_seq}))
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            LOG.warning("Gateway heartbeat 已停止：%s", exc)

    async def _cancel_heartbeat(self) -> None:
        task = self.heartbeat_task
        self.heartbeat_task = None
        if task is None:
            return
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

    # ------------------------------ messages ---------------------------------

    async def _handle_event(self, event_type: Any, data: Any) -> None:
        if not isinstance(data, dict):
            return
        if event_type == "READY":
            self.session_id = str(data.get("session_id") or "") or None
            self.ready = True
            self.last_error = ""
            self._save_session()
            LOG.info("QQ Gateway READY，session_id=%s", self.session_id)
            return
        if event_type == "RESUMED":
            self.ready = True
            self.last_error = ""
            LOG.info("QQ Gateway RESUMED")
            return
        if event_type == "C2C_MESSAGE_CREATE":
            await self._handle_c2c_message(data)
            return
        if event_type in {"GROUP_AT_MESSAGE_CREATE", "GROUP_MESSAGE_CREATE"}:
            if ENABLE_GROUP_MESSAGES:
                LOG.info("暂未实现群聊回复，忽略 event=%s", event_type)
            else:
                LOG.debug("群消息未启用，忽略 event=%s", event_type)

    async def _handle_c2c_message(self, data: dict[str, Any]) -> None:
        message_id = str(data.get("id") or "").strip()
        author = data.get("author") or {}
        openid = str(author.get("user_openid") or "").strip()
        content = str(data.get("content") or "").strip()
        if not message_id or not openid:
            LOG.warning("C2C 消息缺少 id 或 user_openid，忽略")
            return
        if message_id in self.seen_message_ids:
            LOG.debug("重复 C2C 消息已忽略: %s", message_id)
            return
        self.seen_message_ids.add(message_id)
        if len(self.seen_message_ids) > 2048:
            self.seen_message_ids = set(list(self.seen_message_ids)[-1024:])

        LOG.info(
            "收到 C2C 消息 account=%s openid=%s msg_id=%s chars=%d",
            self.account_label,
            openid,
            message_id,
            len(content),
        )
        if self.on_c2c_message is not None:
            reply = await self.on_c2c_message(self, openid, message_id, content)
        else:
            reply = await self.build_reply(content, openid)
        if isinstance(reply, (list, tuple)):
            replies = [str(part).strip() for part in reply if str(part).strip()]
        else:
            replies = [str(reply).strip()] if reply else []
        if not replies:
            LOG.warning("回复函数返回空文本，未发送 C2C 回复")
            return
        for index, part in enumerate(replies, start=1):
            if index > 1:
                # QQ 的被动回复接口允许沿用入站 msg_id 连续发送；短暂停顿
                # 避免多段消息在移动端被合并或触发频控。
                await asyncio.sleep(0.45)
            await self._send_c2c_text(openid, message_id, part)

    async def build_reply(self, content: str, _openid: str) -> str:
        """独立运行时返回原文；生产管理器会交给 chat.generate_reply。"""
        if not content:
            return "我收到了一条空消息。"
        # 独立运行模式不改写消息；正式模式由 chat.generate_reply 提供内容。
        return content[:MAX_REPLY_CHARS]

    async def _send_c2c_text(self, openid: str, inbound_message_id: str, content: str) -> None:
        if self.http is None:
            raise RuntimeError("HTTP client 未初始化")
        url = f"{API_BASE_URL}/v2/users/{quote(openid, safe='')}/messages"
        body = {
            "content": content,
            "msg_type": 0,
            "msg_seq": self._next_msg_seq(),
            # 带入站 msg_id 才是被动回复，避免第一阶段误用主动消息额度。
            "msg_id": inbound_message_id,
        }
        # 文本回复也必须走统一 JSON 发送器：它在 401 时刷新本 QQ 账号的
        # access_token 后重试一次。旧实现直接 POST，短 token 过期时会丢掉
        # 这一条消息，并可能让用户误以为是微信凭据串线。
        await self._post_qq_json(url, body, label="QQ C2C 回复")
        LOG.info(
            "C2C 回复发送成功 account=%s openid=%s msg_id=%s",
            self.account_label,
            openid,
            inbound_message_id,
        )

    async def _post_qq_json(
        self,
        url: str,
        body: dict[str, Any],
        *,
        label: str,
    ) -> dict[str, Any]:
        """向 QQ OpenAPI 发送 JSON；401 时只刷新一次短期令牌。"""
        if self.http is None:
            raise RuntimeError("HTTP client 未初始化")
        for attempt in range(2):
            token = await self._get_access_token(force=attempt > 0)
            response = await self.http.post(
                url,
                headers={
                    "Authorization": f"QQBot {token}",
                    "Content-Type": "application/json",
                    "User-Agent": USER_AGENT,
                },
                json=body,
            )
            if response.status_code == 401 and attempt == 0:
                self.access_token = None
                self.token_expires_at = 0.0
                continue
            if response.status_code == 401:
                raise TokenRejected(f"{label}返回 HTTP 401")
            if response.status_code >= 400:
                raise RuntimeError(
                    f"{label}失败 HTTP {response.status_code}: {response.text[:500]}"
                )
            if not response.content:
                return {}
            try:
                data = response.json()
            except ValueError as exc:
                raise RuntimeError(f"{label}返回了非法 JSON") from exc
            if not isinstance(data, dict):
                raise RuntimeError(f"{label}返回的 JSON 不是对象")
            return data
        raise TokenRejected(f"{label}令牌刷新后仍被拒绝")

    async def send_c2c_image(
        self,
        openid: str,
        inbound_message_id: str,
        image_bytes: bytes,
    ) -> dict[str, Any]:
        """按官方「上传 + msg_type=7 发送」协议发送 C2C 图片。"""
        if not isinstance(image_bytes, (bytes, bytearray)) or not image_bytes:
            raise ValueError("QQ 图片数据为空")
        image_bytes = bytes(image_bytes)
        # 官方 SDK 的 IMAGE 上限为 30 MB；在 Base64 编码前拦截，避免大请求。
        if len(image_bytes) > 30 * 1024 * 1024:
            raise ValueError("QQ 图片超过 30MB 上限")
        openid = str(openid or "").strip()
        inbound_message_id = str(inbound_message_id or "").strip()
        if not openid or not inbound_message_id:
            raise ValueError("QQ 图片发送缺少 openid 或入站 msg_id")

        target = quote(openid, safe="")
        upload = await self._post_qq_json(
            f"{API_BASE_URL}/v2/users/{target}/files",
            {
                "file_type": 1,
                "srv_send_msg": False,
                "file_data": base64.b64encode(image_bytes).decode("ascii"),
            },
            label="QQ 图片上传",
        )
        file_info = str(upload.get("file_info") or "").strip()
        if not file_info:
            raise RuntimeError("QQ 图片上传响应缺少 file_info")

        sent = await self._post_qq_json(
            f"{API_BASE_URL}/v2/users/{target}/messages",
            {
                "msg_type": 7,
                "media": {"file_info": file_info},
                "msg_seq": self._next_msg_seq(),
                "msg_id": inbound_message_id,
            },
            label="QQ 图片发送",
        )
        LOG.info(
            "C2C 图片发送成功 openid=%s msg_id=%s bytes=%d",
            openid,
            inbound_message_id,
            len(image_bytes),
        )
        return {
            "file_uuid": upload.get("file_uuid"),
            "file_info": file_info,
            "ttl": upload.get("ttl"),
            "message_id": sent.get("id"),
            "raw_size": len(image_bytes),
        }

    @staticmethod
    def _next_msg_seq() -> int:
        value = ((int(time.time() * 1000) % 100_000_000) ^ secrets.randbits(16)) % 65536
        return value or 1

    # -------------------------- session persistence --------------------------

    def _load_session(self) -> None:
        try:
            data = json.loads(self.session_file.read_text(encoding="utf-8"))
            self.session_id = str(data.get("session_id") or "") or None
            seq = data.get("last_seq")
            self.last_seq = int(seq) if seq is not None else None
            if self.session_id:
                LOG.info("恢复本地 session_id=%s seq=%s", self.session_id, self.last_seq)
        except FileNotFoundError:
            return
        except (OSError, ValueError, TypeError) as exc:
            LOG.warning("读取 QQBot session 失败，将重新 IDENTIFY：%s", exc)
            self._clear_session()

    def _save_session(self) -> None:
        if not self.session_id:
            return
        try:
            STATE_DIR.mkdir(parents=True, exist_ok=True)
            self.session_file.write_text(
                json.dumps(
                    {"session_id": self.session_id, "last_seq": self.last_seq},
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
        except OSError as exc:
            LOG.warning("保存 QQBot session 失败：%s", exc)

    def _clear_session(self) -> None:
        try:
            self.session_file.unlink(missing_ok=True)
        except OSError as exc:
            LOG.warning("清理 QQBot session 失败：%s", exc)


class QQBotInstanceAdapter:
    """给 chat.generate_reply 的最小实例适配器。

    除 chat.py 使用的 db_id 外，还保存本次 C2C 的 worker/openid/msg_id。
    媒体工具只调用 send_image，不需要知道 QQ 凭据或 OpenAPI 报文。
    """

    def __init__(
        self,
        db_id: int,
        pool: Any,
        worker: QQBotWorker,
        openid: str,
        inbound_message_id: str,
        account_id: int,
    ) -> None:
        self.db_id = int(db_id)
        self.pool = pool
        self.client = worker.http
        self.is_running = True
        self.tool_channel = "qq"
        self.channel = "qq"
        self.qq_worker = worker
        self.qq_openid = str(openid)
        self.qq_inbound_message_id = str(inbound_message_id)
        self.qq_account_id = int(account_id)

    async def send_image(self, image_bytes: bytes) -> dict[str, Any]:
        return await self.qq_worker.send_c2c_image(
            self.qq_openid,
            self.qq_inbound_message_id,
            image_bytes,
        )


class QQBotManager:
    """从 qq_bot_accounts 表动态维护多个 QQ 机器人连接。

    管理器运行在 main.py 的 0 号分片中，每个账号只会建立一个 Gateway
    WebSocket。QQ 只接收用户消息，不加入心潮主动调度。
    """

    def __init__(self, pool: Any, *, poll_seconds: float = 5.0) -> None:
        self.pool = pool
        self.poll_seconds = max(2.0, float(poll_seconds))
        self.stop_event = asyncio.Event()
        self.connections: dict[int, dict[str, Any]] = {}
        self.table_missing = False

    async def run(self) -> None:
        if os.getenv("QQBOT_ENABLED", "1").strip().lower() in {"0", "false", "no", "off"}:
            LOG.info("QQBot 数据库管理器已停用（QQBOT_ENABLED=1 才启用）")
            return
        LOG.info("QQBot 数据库管理器已启动（仅主分片，C2C 被动消息）")
        try:
            while not self.stop_event.is_set():
                try:
                    await self._sync_accounts()
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # noqa: BLE001
                    if self._is_missing_table_error(exc):
                        if not self.table_missing:
                            LOG.warning("QQBot 配置表不存在，请先执行 qq_bot_schema.sql")
                        self.table_missing = True
                    else:
                        LOG.error("QQBot 管理器同步异常：%s", exc)
                try:
                    await asyncio.wait_for(self.stop_event.wait(), timeout=self.poll_seconds)
                except asyncio.TimeoutError:
                    pass
        finally:
            await self.stop()

    async def stop(self) -> None:
        self.stop_event.set()
        entries = list(self.connections.items())
        self.connections.clear()
        for _account_id, info in entries:
            worker = info.get("worker")
            task = info.get("task")
            if worker is not None:
                worker.request_stop()
            if task is not None and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
                except Exception:
                    pass
        LOG.info("QQBot 数据库管理器已停止")

    async def _sync_accounts(self) -> None:
        rows = await self._load_accounts()
        active_ids = {int(row["id"]) for row in rows}

        for account_id, info in list(self.connections.items()):
            task = info.get("task")
            if account_id not in active_ids or task is None or task.done():
                await self._remove_connection(account_id)

        for row in rows:
            account_id = int(row["id"])
            if account_id in self.connections:
                info = self.connections[account_id]
                worker = info.get("worker")
                row_fingerprint = self._credential_fingerprint(
                    str(row.get("app_id") or ""),
                    str(row.get("client_secret") or ""),
                )
                # 控制台重新保存 AppID/AppSecret 后，旧 Gateway 不能继续复用；
                # 先安全停止旧连接，再用新凭据建立一条连接。
                if info.get("credential_fingerprint") != row_fingerprint:
                    LOG.info("QQBot account=%s 凭据已更新，重建连接", account_id)
                    await self._remove_connection(account_id)
                    await self._start_connection(row)
                    continue
                if getattr(worker, "ready", False):
                    state, error_message = "online", ""
                elif getattr(worker, "last_error", ""):
                    state, error_message = "error", str(worker.last_error)
                else:
                    # 凭据已保存即视为已启用；Gateway 的握手在后台完成，
                    # 不把“等待连接”暴露给控制台用户。
                    state, error_message = "online", ""
                await self._update_account_state(account_id, state, error_message)
                continue
            await self._start_connection(row)

    async def _load_accounts(self) -> list[dict[str, Any]]:
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT id, user_id, app_id, client_secret "
                    "FROM qq_bot_accounts WHERE enabled=1 ORDER BY id ASC"
                )
                return list(await cur.fetchall() or [])

    async def _start_connection(self, row: dict[str, Any]) -> None:
        account_id = int(row["id"])
        app_id = str(row.get("app_id") or "").strip()
        secret = str(row.get("client_secret") or "").strip()
        if not app_id or not secret:
            await self._update_account_state(account_id, "error", "AppID 或密钥为空")
            return

        async def on_c2c_message(
            worker: QQBotWorker, openid: str, message_id: str, content: str
        ) -> str | None:
            return await self._handle_c2c_message(
                int(row["user_id"]), account_id, worker, openid, message_id, content
            )

        worker = QQBotWorker(
            app_id=app_id,
            client_secret=secret,
            on_c2c_message=on_c2c_message,
            account_label=f"account:{account_id}/user:{int(row['user_id'])}",
        )
        worker.qq_account_id = account_id  # 供调试和未来媒体路由使用
        worker.qq_owner_user_id = int(row["user_id"])
        task = asyncio.create_task(worker.run(), name=f"qqbot-{account_id}")
        self.connections[account_id] = {
            "worker": worker,
            "task": task,
            "credential_fingerprint": self._credential_fingerprint(app_id, secret),
        }
        # 保存凭据后直接标记为已连接；实际 Gateway 握手和异常会在后台更新
        # 为 online/error，但前端不再显示中间等待态。
        await self._update_account_state(account_id, "online")
        LOG.info("QQBot account=%s 已加入连接管理", account_id)

    async def _remove_connection(self, account_id: int) -> None:
        info = self.connections.pop(account_id, None)
        if not info:
            return
        worker = info.get("worker")
        task = info.get("task")
        if worker is not None:
            worker.request_stop()
        if task is not None and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception as exc:
                LOG.warning("停止 QQBot account=%s 异常：%s", account_id, exc)
        await self._update_account_state(account_id, "disabled")
        LOG.info("QQBot account=%s 已移出连接管理", account_id)

    async def _update_account_state(
        self, account_id: int, state: str, error_message: str = ""
    ) -> None:
        # 老库未执行迁移时不影响主消息流；迁移后控制台可直接显示状态。
        try:
            async with self.pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "UPDATE qq_bot_accounts SET connection_state=%s, "
                        "last_error=%s, last_seen_at=%s WHERE id=%s",
                        (state, error_message[:500], int(time.time()), account_id),
                    )
                await conn.commit()
        except Exception as exc:  # noqa: BLE001
            if not self._is_missing_table_error(exc):
                LOG.debug("写入 QQBot 状态失败 account=%s: %s", account_id, exc)

    async def _handle_c2c_message(
        self,
        owner_user_id: int,
        account_id: int,
        worker: QQBotWorker,
        openid: str,
        message_id: str,
        content: str,
    ) -> MessageReply:
        """把 QQ 入站消息交给原有 chat.py，返回按实例规则切好的文本段。"""
        # 延迟导入，独立 worker 模式不会因 chat.py 的全部依赖而无法启动。
        import chat
        import utils

        instance_row = await self._find_instance(owner_user_id)
        if not instance_row:
            return "控制台还没有可用的智能体，请先创建并启动一个实例。"
        if str(instance_row.get("status") or "") != "启动":
            return "当前智能体已停止，请在控制台启动后再发送消息。"

        db_id = int(instance_row["id"])
        # 传输日志与媒体发送仍使用 QQ openid；utils.get/save_context 会把该
        # UID 与微信 UID 归一化到同一个实例级跨平台上下文键。
        uid = f"qq:{account_id}:{openid}"
        try:
            utils.current_uid_var.set(uid)
            utils.current_kind_var.set("qq")
        except Exception:
            pass
        adapter = QQBotInstanceAdapter(
            db_id,
            self.pool,
            worker,
            openid,
            message_id,
            account_id,
        )
        try:
            reply_json, is_error = await asyncio.wait_for(
                chat.generate_reply(
                    self.pool,
                    adapter,
                    uid,
                    content,
                    context_token="",
                    is_proactive=False,
                    tool_channel="qq",
                ),
                timeout=900.0,
            )
        except asyncio.TimeoutError:
            LOG.error("QQBot account=%s db_id=%s 对话处理超时", account_id, db_id)
            return "这条消息处理时间过长，请稍后再试。"
        except Exception as exc:  # noqa: BLE001
            LOG.exception("QQBot account=%s db_id=%s 对话处理失败", account_id, db_id)
            return f"暂时无法获取回复内容：{type(exc).__name__}"

        reply = str((reply_json or {}).get("reply") or "").strip()
        if not reply:
            return "暂时无法获取回复内容。" if is_error else "我暂时没有组织好回复，请再说一次。"

        # chat.generate_reply 会把本轮实际使用的分段配置作为隐藏字段带回。
        # 这里使用同一份配置切分 QQ 输出，确保 QQ 与微信的展示规则一致，
        # 而不是让 QQ 端重新猜测模型或实例的设置。
        split_rule = (reply_json or {}).get("_live_split_rule")
        if split_rule is None:
            split_rule = instance_row.get("split_rule")
            if split_rule is None:
                split_rule = ""
        split_rule = str(split_rule).replace("\\\\n", "\\n")
        raw_ignore = (reply_json or {}).get("_live_ignore_punctuation")
        if raw_ignore is None:
            raw_ignore = instance_row.get("ignore_punctuation", 0)
        ignore_punctuation = (
            raw_ignore is True
            or str(raw_ignore or "0").strip().lower() in {"1", "true", "yes", "on"}
        )
        if not split_rule.strip() or split_rule == "\x00":
            # 控制台留空表示不分段；utils.split_text 的历史默认值是换行，
            # 因而这里必须先拦截空规则，不能直接把空串交给它。
            chunks = [reply]
        else:
            try:
                chunks = utils.split_text(reply, split_rule, ignore_punctuation)
            except Exception as exc:  # noqa: BLE001
                LOG.warning(
                    "QQ 分段失败，回退整段发送 account=%s db_id=%s: %s",
                    account_id,
                    db_id,
                    exc,
                )
                chunks = [reply]
        return chunks or [reply]

    async def _find_instance(self, owner_user_id: int) -> dict[str, Any] | None:
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT id, status, split_rule, ignore_punctuation FROM instances "
                    "WHERE user_id=%s AND (deploy_type IS NULL OR deploy_type!='voice') "
                    "ORDER BY (status='启动') DESC, id ASC LIMIT 1",
                    (owner_user_id,),
                )
                return await cur.fetchone()

    @staticmethod
    def _credential_fingerprint(app_id: str, client_secret: str) -> str:
        return hashlib.sha256(
            f"{app_id.strip()}\x00{client_secret.strip()}".encode("utf-8")
        ).hexdigest()[:24]

    @staticmethod
    def _is_missing_table_error(exc: Exception) -> bool:
        msg = str(exc).lower()
        return "qq_bot_accounts" in msg and (
            "doesn't exist" in msg or "unknown table" in msg or "1146" in msg
        )


async def main() -> None:
    logging.basicConfig(
        level=os.getenv("QQBOT_LOG_LEVEL", "INFO").upper(),
        format="[%(asctime)s] [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )
    worker = QQBotWorker()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, worker.request_stop)
        except (NotImplementedError, RuntimeError):
            # Windows 或受限运行器不一定支持 asyncio signal handler。
            pass
    await worker.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
