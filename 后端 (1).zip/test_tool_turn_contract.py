import unittest
import re
from pathlib import Path

import chat
import llm_protocol_anthropic as anthropic_protocol
import llm_protocol_gemini as gemini_protocol
import llm_protocol_openai as openai_protocol
import tool_turn_contract as contract
import utils


ROOT = Path(__file__).parent


class ToolTurnContractTests(unittest.TestCase):
    def test_only_text_or_tool_only_are_valid(self):
        cases = [
            (True, [], contract.TEXT_ONLY, True),
            (False, [{"name": "get_weather"}], contract.TOOL_ONLY, True),
            (False, [], contract.EMPTY, False),
            (True, [{"name": "get_weather"}], contract.TOOL_WITH_TEXT, False),
        ]
        for has_text, calls, expected_state, expected_valid in cases:
            with self.subTest(has_text=has_text, calls=calls):
                state = contract.classify(has_text, calls)
                self.assertEqual(state, expected_state)
                self.assertEqual(contract.is_valid(state), expected_valid)


class ToolMetadataTests(unittest.IsolatedAsyncioTestCase):
    async def test_all_skills_use_sync_mode_and_channel_metadata(self):
        skill_files = sorted((ROOT / "skills").glob("*.py"))
        self.assertEqual(len(skill_files), 8)
        for path in skill_files:
            source = path.read_text(encoding="utf-8")
            with self.subTest(skill=path.name):
                self.assertRegex(
                    source, re.compile(r'^MODE\s*=\s*["\']SYNC["\']', re.MULTILINE),
                    path.name,
                )
                self.assertRegex(
                    source, re.compile(r'^CHANNELS\s*=', re.MULTILINE), path.name,
                )

    async def test_channel_filter_keeps_wechat_tools_out_of_other_clients(self):
        wechat_specs = await utils.load_skill_specs_for_openai(
            None, tool_channel="wechat",
        )
        web_specs = await utils.load_skill_specs_for_openai(
            None, tool_channel="web",
        )
        qq_specs = await utils.load_skill_specs_for_openai(
            None, tool_channel="qq",
        )
        wechat_names = {
            (spec.get("function") or {}).get("name") for spec in wechat_specs
        }
        web_names = {
            (spec.get("function") or {}).get("name") for spec in web_specs
        }
        qq_names = {
            (spec.get("function") or {}).get("name") for spec in qq_specs
        }
        self.assertTrue({"generate_image", "send_emoji", "write_couple_note"} <= wechat_names)
        self.assertTrue({"generate_image", "send_emoji", "write_couple_note"} <= qq_names)
        self.assertTrue({"generate_image", "send_emoji", "write_couple_note"}.isdisjoint(web_names))
        self.assertNotIn("schedule_message", wechat_names)
        self.assertNotIn("update_emotion_state", wechat_names)
        self.assertNotIn("get_emoji_list", wechat_names)
        self.assertIn("get_weather", web_names)

        send_emoji = next(
            spec for spec in wechat_specs
            if (spec.get("function") or {}).get("name") == "send_emoji"
        )
        schema = (send_emoji.get("function") or {}).get("parameters") or {}
        self.assertEqual(schema.get("properties"), {})
        self.assertEqual(schema.get("required", []), [])

    async def test_execution_guard_checks_channel_not_execution_mode(self):
        result = await utils.run_skill(
            "generate_image", {}, None, 0, "uid", None,
            tool_channel="web",
        )
        self.assertFalse(result["success"])
        self.assertIn("不支持当前消息渠道", result["message"])


class ToolPromptTests(unittest.TestCase):
    def test_prompt_exposes_one_canonical_synchronous_contract(self):
        specs = [{
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "查询天气",
                "parameters": {"type": "object", "properties": {}},
            },
        }]
        block = utils.build_tools_system_block(specs)
        self.assertIn('reply 字段必须为 "" 空串', block)
        self.assertIn('{"name":"工具名","params":{...}}', block)
        self.assertIn("下一轮必须基于结果", block)

    def test_proactive_prompt_keeps_explicit_silent_choice(self):
        specs = [{
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "查询天气",
                "parameters": {"type": "object", "properties": {}},
            },
        }]
        block = utils.build_tools_system_block(specs, allow_silent=True)
        self.assertIn("仅在主动消息模式明确决定不打扰时", block)


class ProtocolParityTests(unittest.TestCase):
    def test_all_protocols_keep_business_tools_in_plain_messages(self):
        messages = [
            {"role": "system", "content": "只按 JSON 工具协议响应"},
            {"role": "user", "content": "查天气"},
            {
                "role": "assistant",
                "content": '{"reply":"","tools":[{"name":"get_weather","params":{"city":"北京"}}]}',
            },
            {
                "role": "user",
                "content": '<internal_tool_results>{"tool_results":[{"name":"get_weather","success":true,"result":"晴"}]}</internal_tool_results>',
            },
        ]
        gemini_payload = gemini_protocol.build_payload(
            "gemini-3.5-flash", messages, tools=None,
        )
        openai_payload = openai_protocol.build_payload(
            "gpt-test", messages, tools=None,
        )
        anthropic_payload = anthropic_protocol.build_payload(
            "claude-test", messages, tools=None,
        )
        for payload in (gemini_payload, openai_payload, anthropic_payload):
            rendered = str(payload)
            self.assertNotIn("functionCall", rendered)
            self.assertNotIn("functionResponse", rendered)


class ToolFlowStaticAuditTests(unittest.TestCase):
    @staticmethod
    def source(relative_path):
        return (ROOT / relative_path).read_text(encoding="utf-8")

    def test_runtime_has_no_background_tool_protocol(self):
        runtime_paths = [
            "chat.py", "main.py", "utils.py", "tool_turn_contract.py",
            *[str(path.relative_to(ROOT)) for path in (ROOT / "skills").glob("*.py")],
        ]
        forbidden = (
            "allow_async_tools", "expected_mode", "_schedule_async_tools",
            "_run_async_tool", "pending_async_tools", "deferred_async_tools",
        )
        for relative_path in runtime_paths:
            source = self.source(relative_path)
            for marker in forbidden:
                with self.subTest(path=relative_path, marker=marker):
                    self.assertNotIn(marker, source)

    def test_chat_waits_and_returns_results_before_next_model_round(self):
        source = self.source("chat.py")
        run_at = source.index("res = await utils.run_skill(")
        result_at = source.index("<internal_tool_results>", run_at)
        continue_at = source.index("continue", result_at)
        self.assertLess(run_at, result_at)
        self.assertLess(result_at, continue_at)
        self.assertIn("executed_tool_results.get(call_key)", source)
        self.assertIn("[工具][重复调用已跳过]", source)

    def test_main_only_sends_final_text_and_uses_long_wechat_timeout(self):
        source = self.source("main.py")
        self.assertIn("timeout=900.0", source)
        self.assertNotIn('reply_json.get("tools"', source)
        self.assertNotIn("update_tool_execution_context", source)

    def test_clients_select_channels_explicitly(self):
        expected = {
            "main.py": 'tool_channel="wechat"',
            "webchat_server.py": 'tool_channel="web"',
            "chat_bridge.py": 'tool_channel="voice"',
            "websocker/chat_bridge.py": 'tool_channel="voice"',
        }
        for path, marker in expected.items():
            with self.subTest(path=path):
                self.assertIn(marker, self.source(path))

    def test_media_failures_return_to_model_without_direct_failure_text(self):
        source = self.source("skills/generate_image.py")
        self.assertNotIn("_notify_failure", source)
        self.assertIn("图片生成或发送失败", source)


class HiddenToolExecutionMessageTests(unittest.TestCase):
    def test_recent_tool_context_contains_only_last_twenty_real_messages(self):
        history = [
            {"role": "system", "content": "hidden"},
            *[
                {"role": "user" if i % 2 == 0 else "assistant", "content": f"m{i}"}
                for i in range(25)
            ],
            {"role": "user", "content": "synthetic", "llm_only": True},
        ]
        context = chat._recent_context_for_tool(history, limit=20)
        self.assertEqual(len(context), 20)
        self.assertEqual(context[0]["content"], "m5")
        self.assertEqual(context[-1]["content"], "m24")
        self.assertNotIn("hidden", {item["content"] for item in context})
        self.assertNotIn("synthetic", {item["content"] for item in context})

    def test_completed_execution_is_hidden_from_stored_content(self):
        execution = chat._new_tool_execution(
            "get_weather", {"city": "北京"},
            status="completed", success=True, result="8℃",
        )
        stored = chat._make_msg(
            "assistant", "今晚有点冷。",
            message_id="message-1", tool_executions=[execution],
        )
        self.assertEqual(stored["content"], "今晚有点冷。")
        rendered = chat._flatten_for_llm(stored)
        self.assertIn("工具执行：你在发送这条消息时调用 get_weather", rendered["content"])
        self.assertEqual(stored["content"], "今晚有点冷。")


if __name__ == "__main__":
    unittest.main()
