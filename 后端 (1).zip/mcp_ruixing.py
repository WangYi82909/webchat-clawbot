#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
瑞幸咖啡 MCP × AI 自动下单 Agent（单文件 · 连续对话 · 配置持久化 · Token 统计）
================================================================================
新增：
- 配置持久化：首次运行向你询问网关地址/Key/模型，写入 luckin_config.json，
  以后直接读文件，不用再改硬编码。
- Token 消耗统计：累计本次会话所有 LLM 调用的 prompt/completion/total tokens，
  每轮打印增量，且可随时在对话里输入  /usage（或 /tokens）查看总量。

依赖：
  pip install "mcp>=1.10" requests

跑法：
  export LUCKIN_MCP_TOKEN="你的瑞幸Token"     # 推荐用环境变量；不放 env 时首次会问你
  python luckin_agent.py
  # 对话中可用命令：
  #   /usage 或 /tokens   查看累计 token 消耗
  #   /config             查看当前配置（Key 脱敏）
  #   /help               帮助
  #   exit / quit / 退出   结束

⚠️ 本版本允许模型【自行真实下单扣款】。Token 曾外泄过先去 open.luckincoffee.com 重置。
"""

import asyncio
import json
import os
import sys
import datetime

import requests

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client


# ════════════════════════════════════════════════════════════════════════════
#  常量（瑞幸 MCP 官方地址，写死）
# ════════════════════════════════════════════════════════════════════════════
LUCKIN_MCP_URL = "https://gwmcp.lkcoffee.com/order/user/mcp"
CONFIG_PATH    = os.path.join(os.path.dirname(os.path.abspath(__file__)), "luckin_config.json")
MAX_STEPS_PER_USER_MSG = 20


# ════════════════════════════════════════════════════════════════════════════
#  打印辅助
# ════════════════════════════════════════════════════════════════════════════
def _ts() -> str:
    return datetime.datetime.now().strftime("%H:%M:%S")

def line(ch="─", n=78):
    print(ch * n)

def jdump(obj) -> str:
    try:
        return json.dumps(obj, ensure_ascii=False, indent=2, default=str)
    except Exception:
        return str(obj)

def banner(title):
    line("═")
    print(f"  {title}")
    line("═")

def mask(s: str, keep=4) -> str:
    s = s or ""
    return s if len(s) <= keep * 2 else s[:keep] + "…" + s[-keep:]


# ════════════════════════════════════════════════════════════════════════════
#  配置：首次运行询问并写入 luckin_config.json；之后读文件
#  优先级：环境变量 > 配置文件
# ════════════════════════════════════════════════════════════════════════════
def load_or_init_config() -> dict:
    cfg = {}
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            print(f"✓ 已读取配置：{CONFIG_PATH}")
        except Exception as e:
            print(f"! 配置文件损坏（{e}），将重新引导填写。")
            cfg = {}

    if not cfg.get("openai_base_url") or not cfg.get("openai_api_key"):
        print("\n首次配置（仅本次需要，之后会记住）。回车可留空用默认值。")
        base = input("  OpenAI 兼容网关地址（填到 /v1 这层，不会自动补全）: ").strip()
        key  = input("  API Key: ").strip()
        model = input("  模型名 [默认 gemini-3.5-flash]: ").strip() or "gemini-3.5-flash"
        # 瑞幸 Token：优先环境变量；env 没有才问，并征求是否写盘
        save_lk = ""
        if not os.environ.get("LUCKIN_MCP_TOKEN", "").strip():
            print("  （未检测到环境变量 LUCKIN_MCP_TOKEN）")
            lk = input("  瑞幸 Token（可留空，留空则每次用环境变量）: ").strip()
            if lk:
                yn = input("  ⚠️ 该 Token 可真实下单，是否明文存入 luckin_config.json？(y/N): ").strip().lower()
                if yn == "y":
                    save_lk = lk
                else:
                    print("  好的，不写盘。请用：export LUCKIN_MCP_TOKEN=\"你的Token\"")
        cfg = {
            "openai_base_url": base,
            "openai_api_key": key,
            "model": model,
        }
        if save_lk:
            cfg["luckin_token"] = save_lk
        try:
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
            os.chmod(CONFIG_PATH, 0o600)  # 尽量限制权限
            print(f"✓ 配置已保存到 {CONFIG_PATH}（含敏感信息，请勿提交到 git）\n")
        except Exception as e:
            print(f"! 配置保存失败：{e}（本次仍可继续运行）\n")

    # 环境变量覆盖
    cfg["model"] = cfg.get("model") or "gemini-3.5-flash"
    return cfg


# ════════════════════════════════════════════════════════════════════════════
#  Token 用量累计器
# ════════════════════════════════════════════════════════════════════════════
class Usage:
    def __init__(self):
        self.prompt = 0
        self.completion = 0
        self.total = 0
        self.calls = 0

    def add(self, usage: dict):
        if not usage:
            return (0, 0, 0)
        p = int(usage.get("prompt_tokens", 0) or 0)
        c = int(usage.get("completion_tokens", 0) or 0)
        t = int(usage.get("total_tokens", 0) or (p + c))
        self.prompt += p
        self.completion += c
        self.total += t
        self.calls += 1
        return (p, c, t)

    def summary(self) -> str:
        return (f"累计 token 消耗（共 {self.calls} 次模型调用）：\n"
                f"  prompt(输入)     = {self.prompt}\n"
                f"  completion(输出) = {self.completion}\n"
                f"  total(合计)      = {self.total}")


# ════════════════════════════════════════════════════════════════════════════
#  MCP 工具 schema → OpenAI tools 格式
# ════════════════════════════════════════════════════════════════════════════
def mcp_tools_to_openai(mcp_tools) -> list:
    out = []
    for t in mcp_tools:
        schema = getattr(t, "inputSchema", None) or {"type": "object", "properties": {}}
        if schema.get("type") != "object":
            schema = {"type": "object", "properties": {}}
        out.append({
            "type": "function",
            "function": {
                "name": t.name,
                "description": (t.description or t.name).strip(),
                "parameters": schema,
            },
        })
    return out


# ════════════════════════════════════════════════════════════════════════════
#  调 OpenAI 兼容端点，打印原始请求/响应，并累计 token
# ════════════════════════════════════════════════════════════════════════════
def call_llm(cfg: dict, messages: list, tools: list, usage: Usage) -> dict:
    url = f"{cfg['openai_base_url']}/chat/completions"
    payload = {
        "model": cfg["model"],
        "messages": messages,
        "tools": tools,
        "tool_choice": "auto",
        "temperature": 0.3,
        "stream": False,
    }
    headers = {
        "Authorization": f"Bearer {cfg['openai_api_key']}",
        "Content-Type": "application/json",
    }

    banner(f"[{_ts()}] → 发给模型的原始请求 (POST {url})")
    print(jdump(payload))

    resp = requests.post(url, headers=headers, json=payload, timeout=120)

    banner(f"[{_ts()}] ← 模型返回的原始响应 (HTTP {resp.status_code})")
    try:
        data = resp.json()
        print(jdump(data))
    except Exception:
        print(resp.text)
        resp.raise_for_status()
        raise

    if resp.status_code >= 400:
        raise RuntimeError(f"LLM 接口报错 {resp.status_code}: {data}")

    # 累计 + 打印本次增量
    p, c, t = usage.add(data.get("usage") or {})
    banner(f"[{_ts()}] 📊 本次 token：输入 {p} / 输出 {c} / 合计 {t}　|　累计合计 {usage.total}")

    return data


# ════════════════════════════════════════════════════════════════════════════
#  系统提示词
# ════════════════════════════════════════════════════════════════════════════
SYSTEM_PROMPT = """你是一个帮用户在「瑞幸咖啡」下单的中文 AI 助手，通过工具(function calling)操作用户真实的瑞幸账号。

【可用工具与正确顺序】
1. queryShopList(deptName?, longitude?, latitude?)   —— 查门店，拿到门店 deptId。
2. searchProductForMcp(deptId, query)                —— 在该门店按关键词搜商品，拿到 productId / skuCode。
3. queryProductDetailInfo(deptId, productId)          —— 看商品详情/规格（需要时）。
4. switchProduct(deptId, productId, skuCode)          —— 切换冰热/糖度等规格（需要时）。
5. previewOrder(deptId, productList)                  —— 预览订单，确认价格与明细。下单前必须调用。
6. createOrder(deptId, productList)                   —— 真实创建订单（会扣款）。在 previewOrder 之后调用。
7. queryOrderDetailInfo(orderId) / cancelOrder(orderId) —— 下单后查询 / 取消。

【关于位置/门店——很重要】
- 这些工具没有“收货地址”字段；下单靠门店 deptId（门店出餐/自提）。
- 不知道用户在哪、要去哪家门店时，**先用中文向用户提问**（你大概在什么位置？想去哪家门店？），
  用户回答后再用 queryShopList 按地点名(deptName)查门店；必要时也可让用户提供经纬度。
- 缺 deptId 时不要凭空臆造门店或商品 id。

【自主下单】
- 你被授权自行完成下单：previewOrder 把价格/商品/门店用中文念给用户之后，可直接调用 createOrder，无需逐字确认。
- 但用户需求不明确（哪款/几杯/冰热糖度/哪家店）时，必须先问清楚再继续。

【输出格式：每一步先思考】
- 调用任何工具前，先用中文写“思考过程/思维链”：当前在哪一步、为什么调它、参数来源，写在 assistant 正文(content)，再发起工具调用。
- 需要用户补充信息时，直接用中文提问，且这一轮不要调用工具（等用户回答）。
- 订单完成或取消后，用中文总结（门店、商品、价格、订单号/状态）。

【其它】
- productList 等参数字段结构严格依据工具 parameters(JSON Schema) 填，不要臆造字段。
- 全程简体中文。
"""


# ════════════════════════════════════════════════════════════════════════════
#  让模型连续行动，直到需要用户输入或达上限
# ════════════════════════════════════════════════════════════════════════════
async def drive_until_user_needed(cfg, session, messages, tools, usage) -> None:
    for step in range(1, MAX_STEPS_PER_USER_MSG + 1):
        banner(f"第 {step} 步（本轮用户发言后）")
        data = call_llm(cfg, messages, tools, usage)
        msg = data["choices"][0]["message"]

        if msg.get("content"):
            banner(f"[{_ts()}] 🧠 模型思考 / 回复")
            print(msg["content"])
        if msg.get("reasoning_content"):
            banner(f"[{_ts()}] 🧠 模型思考 (reasoning_content)")
            print(msg["reasoning_content"])

        tool_calls = msg.get("tool_calls") or []

        if not tool_calls:
            messages.append({"role": "assistant", "content": msg.get("content") or ""})
            print()
            banner(f"[{_ts()}] 💬 AI（请在下方回复，或 /usage 看消耗，exit 结束）")
            print(msg.get("content") or "(空)")
            return

        messages.append({
            "role": "assistant",
            "content": msg.get("content") or "",
            "tool_calls": tool_calls,
        })

        for tc in tool_calls:
            fn = tc["function"]["name"]
            raw_args = tc["function"].get("arguments") or "{}"
            try:
                args = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
            except Exception:
                args = {}

            banner(f"[{_ts()}] 🔧 调用工具：{fn}")
            print("参数：", jdump(args))

            try:
                result = await session.call_tool(fn, args)
                parts = []
                for c in getattr(result, "content", []) or []:
                    parts.append(getattr(c, "text", None) or getattr(c, "data", None) or str(c))
                tool_text = "\n".join(str(p) for p in parts) if parts \
                    else jdump(getattr(result, "structuredContent", {}))
                if getattr(result, "isError", False):
                    tool_text = "工具返回错误：" + tool_text
            except Exception as e:
                tool_text = f"调用工具 {fn} 异常：{e}"

            banner(f"[{_ts()}] 🧾 工具 {fn} 返回（回灌给模型）")
            print(tool_text[:2000] + (" …(截断)" if len(tool_text) > 2000 else ""))

            messages.append({
                "role": "tool",
                "tool_call_id": tc["id"],
                "name": fn,
                "content": tool_text,
            })

    print(f"\n（已达本轮自动步数上限 {MAX_STEPS_PER_USER_MSG}，交还给你。）")


# ════════════════════════════════════════════════════════════════════════════
#  交互式命令处理；返回 True 表示已处理（不发给模型）
# ════════════════════════════════════════════════════════════════════════════
def handle_command(text: str, cfg: dict, usage: Usage) -> bool:
    cmd = text.strip().lower()
    if cmd in ("/usage", "/tokens", "/token"):
        banner(f"[{_ts()}] 📊 Token 用量")
        print(usage.summary())
        return True
    if cmd == "/config":
        banner("当前配置")
        print(f"  网关地址: {cfg.get('openai_base_url')}")
        print(f"  API Key : {mask(cfg.get('openai_api_key',''))}")
        print(f"  模型    : {cfg.get('model')}")
        print(f"  配置文件: {CONFIG_PATH}")
        return True
    if cmd == "/help":
        banner("命令帮助")
        print("  /usage 或 /tokens  查看累计 token 消耗")
        print("  /config            查看当前配置（Key 脱敏）")
        print("  /help              本帮助")
        print("  exit / quit / 退出  结束对话")
        return True
    return False


# ════════════════════════════════════════════════════════════════════════════
#  主循环：连续对话
# ════════════════════════════════════════════════════════════════════════════
async def chat_loop(cfg: dict, first_goal):
    # 瑞幸 Token：环境变量优先，其次配置文件
    lk_token = os.environ.get("LUCKIN_MCP_TOKEN", "").strip() or cfg.get("luckin_token", "").strip()
    if not lk_token:
        sys.exit('未提供瑞幸 Token。请  export LUCKIN_MCP_TOKEN="你的Token"  后重试。')
    if not cfg.get("openai_base_url") or not cfg.get("openai_api_key"):
        sys.exit("配置缺失：请删除 luckin_config.json 后重新运行以重新填写。")

    usage = Usage()

    banner(f"[{_ts()}] 连接瑞幸 MCP：{LUCKIN_MCP_URL}")
    async with streamablehttp_client(
        LUCKIN_MCP_URL, headers={"Authorization": f"Bearer {lk_token}"}
    ) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            mcp_tools = (await session.list_tools()).tools
            tools = mcp_tools_to_openai(mcp_tools)
            print(f"✓ MCP 已连接，加载 {len(tools)} 个工具：",
                  ", ".join(t["function"]["name"] for t in tools))
            print("✓ 进入连续对话。输入 /help 看命令；exit 结束。\n")

            messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            pending = (first_goal or "").strip()

            while True:
                if pending:
                    user_text = pending
                    pending = ""
                    print(f"你：{user_text}")
                else:
                    try:
                        user_text = input("你：").strip()
                    except (EOFError, KeyboardInterrupt):
                        print("\n" + usage.summary())
                        print("再见。")
                        return

                if user_text.lower() in ("exit", "quit", "退出", "q"):
                    print("\n" + usage.summary())
                    print("再见。")
                    return
                if not user_text:
                    continue
                # 交互式命令（不发给模型）
                if user_text.startswith("/"):
                    if handle_command(user_text, cfg, usage):
                        continue

                messages.append({"role": "user", "content": user_text})
                await drive_until_user_needed(cfg, session, messages, tools, usage)


if __name__ == "__main__":
    cfg = load_or_init_config()
    goal = " ".join(sys.argv[1:]).strip() or None
    asyncio.run(chat_loop(cfg, goal))