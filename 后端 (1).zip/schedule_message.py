NAME        = "schedule_message"
DESCRIPTION = "在指定的毫秒延迟后发送补充消息，用于模拟延时思考或主动追问"
USAGE       = '{"delay_ms": 300000, "content": "要发送的回复内容"}'
MODE        = "ASYNC"  # 关键：告诉系统这是一个异步流工具，允许AI一边和用户说话，一边挂起延迟任务
# 旧 proactive_schedules 扫描器已被 dynamic_mind 替代；继续暴露会出现“写入
# 成功但永不发送”。在按新心智调度重写前必须 fail-closed 停用。
ENABLED     = False

async def run(params: dict, pool, db_id, uid, bot_instance) -> dict:
    import time
    import utils
    
    delay_ms = params.get("delay_ms")
    content = params.get("content", "").strip()

    print(f"[主动计划工具] [异步] 实例 {db_id} 请求设定延时: {delay_ms} ms, 内容: {content}")

    if not delay_ms or not content:
        return {"success": False, "message": ""}

    try:
        delay_ms = int(delay_ms)
    except ValueError:
        return {"success": False, "message": ""}

    send_at_seconds = int(time.time()) + int(delay_ms / 1000)

    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "INSERT INTO proactive_schedules (db_id, uid, context_token, send_at, content, status) "
                    "VALUES (%s, %s, %s, %s, %s, 0)",
                    (db_id, uid, "", send_at_seconds, content)
                )
            await conn.commit()
        
        print(f"[主动计划工具] [成功] 写入数据库，将在 {int(delay_ms / 1000)} 秒后触发。")
        return {"success": True, "message": ""}
    except Exception as e:
        print(f"[主动计划工具] [异常] 写入发生异常: {e}")
        return {"success": False, "message": ""}
