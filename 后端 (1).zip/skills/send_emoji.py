"""根据最近对话自动选择并同步发送表情包。

主模型只需要决定“现在适合发表情”并无参数调用本工具。
本工具会把最近 20 条 user/assistant 对话和当前实例的表情
ID/标签发给硬编码 QE 模型，强制它返回 JSON 选择结果，再使用
当前聊天渠道的媒体协议发送（微信保留既有报文，QQ 使用官方两步上传协议）。
"""
import base64
import hashlib
import json
import os
import urllib.parse

import httpx
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

import utils


NAME = "send_emoji"
DESCRIPTION = (
    "在当前微信或 QQ 对话中发送一个贴合当前语境的表情包。"
    "不需要查询列表、不需要提供 ID 或标签，无参数调用即可；"
    "工具会根据最近 20 条对话和实例表情配置自动选择并等待发送完成。"
)
PARAMETERS = {
    "type": "object",
    "properties": {},
    "additionalProperties": False,
}
USAGE = '{}'
MODE = "SYNC"
CHANNELS = ("wechat", "qq")

# 与 chat.py 的 Query Expansion 使用同一组硬编码配置。
# 这是系统内部轻量决策请求，不读用户当前聊天模型端点。
QE_ENDPOINT = "https://api.deepseek.com/chat/completions"
QE_API_KEY = ""
QE_MODEL = "deepseek-v4-flash"
QE_TEMPERATURE = 0.1
QE_TIMEOUT_SECONDS = 15.0

API_BASE_URL = "https://ilinkai.weixin.qq.com"
CDN_BASE_URL = "https://novac2c.cdn.weixin.qq.com/c2c"
APP_VERSION = "2.4.2"
CLIENT_VERSION = "132098"
APP_ID = "bot"
BOT_AGENT = "PyWeixinBot/1.0"


def _normalize_context(value) -> list[dict]:
    """只保留最近 20 条真实 user/assistant 文本。"""
    if not isinstance(value, list):
        return []
    normalized = []
    for item in value:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "").strip().lower()
        content = item.get("content")
        if role not in {"user", "assistant"} or not isinstance(content, str):
            continue
        content = content.strip()
        if content:
            normalized.append({"role": role, "content": content})
    return normalized[-20:]


def _emoji_choices(emojis: list) -> list[dict]:
    """只把 ID 和标签交给 QE，绝不传输 Base64 图片数据。"""
    choices = []
    for item in emojis:
        if not isinstance(item, dict):
            continue
        emoji_id = item.get("id")
        if emoji_id in (None, ""):
            emoji_id = item.get("emoji_id")
        if emoji_id in (None, ""):
            continue
        choices.append({
            "emoji_id": str(emoji_id),
            "tag": str(item.get("tag") or "").strip(),
        })
    return choices


async def _select_emoji_via_qe(
    client: httpx.AsyncClient,
    context: list[dict],
    choices: list[dict],
) -> str:
    """Ask the hard-coded QE model for exactly one configured emoji ID."""
    if not choices:
        raise RuntimeError("当前没有可用表情包配置")
    if not context:
        raise RuntimeError("未获取到最近对话上下文")

    allowed_ids = {str(item["emoji_id"]) for item in choices}
    request_data = {
        "conversation": context[-20:],
        "emojis": choices,
        "required_output": {"emoji_id": "必须是 emojis 中的一个真实 ID"},
    }
    payload = {
        "model": QE_MODEL,
        "messages": [
            {
                "role": "system",
                "content": (
                    "你是表情包选择器。根据对话语境和表情标签，"
                    "选择最贴合当前氛围的一个表情。必须只返回一个 JSON 对象，"
                    "格式固定为 {\"emoji_id\":\"真实ID\"}；禁止返回解释、Markdown、"
                    "不存在的 ID 或其他字段。"
                ),
            },
            {
                "role": "user",
                "content": json.dumps(request_data, ensure_ascii=False),
            },
        ],
        "temperature": QE_TEMPERATURE,
        "max_tokens": 80,
        "stream": False,
        # 与 chat.py 现有 QE 链路一致：DeepSeek V4 用该字段关闭思考，
        # 避免短 JSON 结果被 reasoning 耗尽输出 token。
        "thinking": {"type": "disabled"},
        "response_format": {"type": "json_object"},
    }
    response = await client.post(
        QE_ENDPOINT,
        json=payload,
        headers={
            "Authorization": f"Bearer {QE_API_KEY}",
            "Content-Type": "application/json",
        },
        timeout=QE_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    try:
        response_data = response.json()
        content = response_data["choices"][0]["message"]["content"]
        selected = json.loads(content)
    except Exception as exc:
        raise RuntimeError("QE 模型未返回合法 JSON 选择结果") from exc
    if not isinstance(selected, dict) or set(selected.keys()) != {"emoji_id"}:
        raise RuntimeError("QE 模型返回的 JSON 字段不合法")
    selected_id = str(selected.get("emoji_id") or "").strip()
    if selected_id not in allowed_ids:
        raise RuntimeError("QE 模型选择了不存在的表情包 ID")
    return selected_id


def _legacy_headers(token: str | None = None) -> dict:
    headers = {
        "Content-Type": "application/json",
        "AuthorizationType": "ilink_bot_token",
        "X-WECHAT-UIN": utils.generate_x_wechat_uin(),
        "iLink-App-Id": APP_ID,
        "iLink-App-ClientVersion": CLIENT_VERSION,
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _legacy_base_info() -> dict:
    return {"channel_version": APP_VERSION, "bot_agent": BOT_AGENT}


def _check_json_business_result(
    response: httpx.Response, label: str, *, require_json: bool = False,
) -> dict:
    """旧版只检查 HTTP；这里额外识别 HTTP 200 内的明确业务错误。"""
    try:
        data = response.json()
    except Exception as exc:
        # 历史接口允许成功响应没有 JSON；保持旧版兼容，不凭空判失败。
        if require_json:
            raise RuntimeError(f"{label} 返回了非法 JSON") from exc
        return {}
    if not isinstance(data, dict):
        return {}
    ret = data.get("ret")
    if ret not in (None, 0, "0"):
        detail = data.get("errmsg") or data.get("message") or "未知错误"
        raise RuntimeError(f"{label} 失败：ret={ret} {detail}")
    return data


def _cdn_upload_candidates(upload_data: dict, filekey: str) -> list[tuple[str, str]]:
    """按兼容优先级生成上传地址；成功用户仍首先走原来的地址。"""
    candidates: list[tuple[str, str]] = []
    full_url = str(upload_data.get("upload_full_url") or "").strip()
    upload_param = upload_data.get("upload_param")
    if full_url:
        candidates.append(("full_url", full_url))
    if isinstance(upload_param, str) and upload_param:
        # 第一候选保持用户提供的历史版本行为（quote 默认保留 '/'）。
        legacy_param = urllib.parse.quote(upload_param)
        legacy_url = (
            f"{CDN_BASE_URL}/upload?encrypted_query_param={legacy_param}"
            f"&filekey={filekey}"
        )
        candidates.append(("upload_param_legacy", legacy_url))

        # 某些账号返回的 opaque upload_param 含 '/'。只有历史地址明确失败后
        # 才尝试完全编码，不改变原本可用账号的发送路径。
        strict_param = urllib.parse.quote(upload_param, safe="")
        strict_url = (
            f"{CDN_BASE_URL}/upload?encrypted_query_param={strict_param}"
            f"&filekey={urllib.parse.quote(filekey, safe='')}"
        )
        if strict_url != legacy_url:
            candidates.append(("upload_param_strict", strict_url))

    # 服务端偶尔会同时返回 full_url 和 upload_param。按标签+URL 去重，既优先
    # 使用 full_url，也能在该地址明确失败时救回只影响部分账号的请求。
    result: list[tuple[str, str]] = []
    seen: set[str] = set()
    for label, url in candidates:
        if url and url not in seen:
            result.append((label, url))
            seen.add(url)
    return result


def _cdn_failure_detail(response: httpx.Response) -> str:
    detail = str(response.headers.get("x-error-message") or "").strip()
    if not detail:
        try:
            detail = (response.text or "").strip()
        except Exception:
            detail = ""
    # CDN 可能在正文里回显签名 URL；只保留短错误原因并去掉换行。
    return " ".join(detail.split())[:100] or "无错误详情"


async def _send_emoji_image_legacy(
    client: httpx.AsyncClient,
    token: str,
    uid: str,
    plaintext: bytes,
) -> dict:
    """逐字段复刻历史版本的图片上传与发送报文。"""
    raw_size = len(plaintext)
    raw_md5 = hashlib.md5(plaintext).hexdigest()
    filekey = os.urandom(16).hex()
    aeskey = os.urandom(16)
    ciphertext = AES.new(aeskey, AES.MODE_ECB).encrypt(pad(plaintext, 16))
    cipher_size = len(ciphertext)
    headers = _legacy_headers(token)

    upload_req = {
        "filekey": filekey,
        "media_type": 1,
        "to_user_id": uid,
        "rawsize": raw_size,
        "rawfilemd5": raw_md5,
        "filesize": cipher_size,
        "no_need_thumb": True,
        "aeskey": aeskey.hex(),
        "base_info": _legacy_base_info(),
    }
    upload_response = await client.post(
        f"{API_BASE_URL}/ilink/bot/getuploadurl",
        json=upload_req,
        headers=headers,
    )
    upload_response.raise_for_status()
    upload_data = _check_json_business_result(
        upload_response, "getUploadUrl", require_json=True,
    )
    candidates = _cdn_upload_candidates(upload_data, filekey)
    if not candidates:
        raise RuntimeError("getUploadUrl 未返回 upload_full_url 或 upload_param")

    download_param = ""
    upload_route = ""
    failures: list[str] = []
    route_statuses: list[str] = []
    for route, upload_url in candidates:
        route_failure = ""
        # 同一路由仅对网络异常、5xx 和响应头缺失重试；4xx 表示签名/参数明确
        # 无效，立即换下一种 URL 形态，避免无意义地连续打三次。
        for attempt in range(1, 4):
            try:
                cdn_response = await client.post(
                    upload_url,
                    content=ciphertext,
                    headers={"Content-Type": "application/octet-stream"},
                )
            except (httpx.TimeoutException, httpx.NetworkError) as exc:
                route_failure = f"网络异常({type(exc).__name__})"
                if attempt < 3:
                    continue
                break
            except Exception as exc:
                detail = str(exc).strip() or type(exc).__name__
                route_failure = f"请求异常({detail[:60]})"
                if attempt < 3:
                    continue
                break

            if 400 <= cdn_response.status_code < 500:
                route_failure = (
                    f"HTTP {cdn_response.status_code}"
                    f"({_cdn_failure_detail(cdn_response)})"
                )
                break
            if cdn_response.status_code != 200:
                route_failure = (
                    f"HTTP {cdn_response.status_code}"
                    f"({_cdn_failure_detail(cdn_response)})"
                )
                if attempt < 3:
                    continue
                break
            candidate_param = str(
                cdn_response.headers.get("x-encrypted-param") or ""
            ).strip()
            if not candidate_param:
                route_failure = "HTTP 200但缺少x-encrypted-param"
                if attempt < 3:
                    continue
                break
            download_param = candidate_param
            upload_route = route
            break

        if download_param:
            break
        route_failure = route_failure or "未知错误"
        failures.append(f"{route}={route_failure}")
        # 状态摘要放在错误最前方，即使上层日志截断，也能看见所有候选路径。
        short_status = route_failure.split("(", 1)[0].replace(" ", "")
        route_statuses.append(f"{route}:{short_status[:28]}")

    if not download_param:
        joined = "; ".join(failures) or "没有可用上传地址"
        status_summary = ",".join(route_statuses) or "none"
        raise RuntimeError(
            f"CDN 上传失败（图片{raw_size}字节；路径状态={status_summary}）："
            f"{joined[:300]}"
        )

    final_aes_key = base64.b64encode(
        aeskey.hex().encode("utf-8")
    ).decode("ascii")
    client_id = utils.generate_client_id()
    message_payload = {
        "msg": {
            "from_user_id": "",
            "to_user_id": uid,
            "client_id": client_id,
            "message_type": 2,
            "message_state": 2,
            "context_token": "",
            "item_list": [{
                "type": 2,
                "image_item": {
                    "media": {
                        "encrypt_query_param": download_param,
                        "aes_key": final_aes_key,
                        "encrypt_type": 1,
                    },
                    "mid_size": cipher_size,
                },
            }],
        },
        "base_info": _legacy_base_info(),
    }
    send_response = await client.post(
        f"{API_BASE_URL}/ilink/bot/sendmessage",
        json=message_payload,
        headers=headers,
    )
    send_response.raise_for_status()
    send_data = _check_json_business_result(send_response, "sendMessage")
    return {
        "client_id": client_id,
        "ret": send_data.get("ret"),
        "upload_route": upload_route,
        "raw_size": raw_size,
        "cipher_size": cipher_size,
    }

async def run(params: dict, pool, db_id, uid, bot_instance) -> dict:
    params = params if isinstance(params, dict) else {}
    is_qq = str(getattr(bot_instance, "tool_channel", "wechat")).lower() == "qq"
    context = _normalize_context(params.get("_conversation_context"))
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT emojis_json, wx_token FROM instances WHERE id=%s", (db_id,)
            )
            row = await cur.fetchone()
    if not row:
        return {"success": False, "message": "实例不存在，无法发送表情包。"}
    raw = (row or {}).get("emojis_json") or ""
    try:
        decoded = json.loads(raw) if isinstance(raw, str) else raw
    except Exception:
        return {"success": False, "message": "表情包配置解析异常。"}
    emojis = decoded if isinstance(decoded, list) else []
    choices = _emoji_choices(emojis)
    if not choices:
        return {"success": False, "message": "当前没有可用的表情包配置。"}
    if not context:
        return {"success": False, "message": "无法获取最近 20 条对话，本次未发送表情包。"}

    token = ""
    if is_qq:
        if not callable(getattr(bot_instance, "send_image", None)):
            return {"success": False, "message": "当前 QQ 会话缺少图片发送上下文。"}
    else:
        token = utils.decrypt_data((row or {}).get("wx_token") or "")
        if not token:
            return {"success": False, "message": "无法获取微信 Token。"}

    # 选择和实际发送同在这个同步工具轮内完成。主模型在
    # 工具返回前不会生成最终文字，因此不会出现“先说已发、后发送失败”。
    try:
        async with httpx.AsyncClient(
            timeout=60.0,
            follow_redirects=True,
        ) as client:
            selected_id = await _select_emoji_via_qe(
                client,
                context,
                choices,
            )
            target = next(
                (
                    item for item in emojis
                    if isinstance(item, dict)
                    and str(item.get("id") or item.get("emoji_id") or "")
                    == selected_id
                ),
                None,
            )
            if not target:
                raise RuntimeError("选中的表情包在配置中不存在")
            base64_data = target.get("base64_data") or ""
            if not base64_data:
                raise RuntimeError("选中的表情包图片数据为空")
            try:
                encoded = str(base64_data).split(",", 1)[-1]
                image_bytes = base64.b64decode(encoded, validate=True)
            except Exception as exc:
                raise RuntimeError("选中的表情包 Base64 图片数据已损坏") from exc
            if is_qq:
                result = await bot_instance.send_image(image_bytes)
            else:
                result = await _send_emoji_image_legacy(
                    client,
                    token,
                    uid,
                    image_bytes,
                )
    except Exception as exc:
        detail = str(exc).strip() or type(exc).__name__
        await utils.add_temp_log(
            pool,
            db_id,
            f"[表情包·自动选择] 失败: {detail[:180]}",
        )
        return {"success": False, "message": f"表情选择或发送失败：{detail[:160]}"}

    selected_tag = str((target or {}).get("tag") or "").strip()
    if is_qq:
        delivery_detail = (
            f"QQ已发送，大小={result.get('raw_size', len(image_bytes))}字节，"
            f"message_id={result.get('message_id') or '未返回'}"
        )
    else:
        delivery_detail = (
            f"微信已受理，通道={result['upload_route']}，"
            f"大小={result['raw_size']}字节，client_id={result['client_id']}"
        )
    await utils.add_temp_log(
        pool,
        db_id,
        f"[表情包·自动选择] QE 选择 ID={selected_id} "
        f"标签={selected_tag or '未填写'}；{delivery_detail}",
    )
    return {
        "success": True,
        "message": (
            "已根据最近对话和表情标签自动选择并发送表情包。"
            + (f"选中标签：{selected_tag}。" if selected_tag else "")
        ),
    }
