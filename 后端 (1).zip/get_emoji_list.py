"""
get_emoji_list.py — 读取实例可用表情包列表

修改说明（2026-05-06）：
    数据存储已从独立表 `instance_emojis` 迁移到 instances.emojis_json
    JSON 字段（PHP 端早已迁移，本工具长期未同步导致 AI 永远拿到空列表，
    或在新库直接报 "Table 'webchat2.instance_emojis' doesn't exist"）。
    本次改为：JSON_EXTRACT instances.emojis_json，与 PHP api_instance.php
    的 get_emojis / add_emoji / delete_emoji 三个 case 保持同源。

    JSON 数组每项结构：{id, tag, base64_data}
"""
import json
import utils

NAME        = "get_emoji_list"
DESCRIPTION = (
    "查询当前实例可用的表情包 ID 和含义。系统提示词不会提供表情包清单；"
    "想发表情时必须先调用本 SYNC 工具，拿到结果后再在下一轮调用 send_emoji。"
    "当前没有表情包时直接回复文字，不要调用 send_emoji。"
)
USAGE       = '{}'
MODE        = "SYNC"


async def run(params: dict, pool, db_id, uid, bot_instance) -> dict:
    # 从 instances.emojis_json 读取（与 PHP api_instance.php 同源）
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT emojis_json FROM instances WHERE id=%s",
                (db_id,)
            )
            row = await cur.fetchone()

    raw = (row or {}).get('emojis_json') or ''
    emojis = []
    if raw:
        try:
            decoded = json.loads(raw) if isinstance(raw, str) else raw
            if isinstance(decoded, list):
                emojis = decoded
        except Exception as e:
            print(f"[表情包工具] 实例 {db_id} emojis_json 解析失败: {e}")
            return {
                "success": False,
                "message": "表情包配置解析异常，请联系管理员"
            }

    if not emojis:
        print(f"[表情包工具] 实例 {db_id} 请求列表，但当前无可用表情包。")
        return {
            "success": True,
            "message": "当前没有可用的表情包配置。请直接回复文本，不要再尝试发送表情包。"
        }

    # 仅暴露 id 和 tag 给 AI（base64 数据不喂给 LLM 节省 token）
    emoji_list_str = "\n".join([
        f"ID: {e.get('id')}, 标签: {e.get('tag', '')}"
        for e in emojis
        if e.get('id') is not None
    ])

    print(f"[表情包工具] 实例 {db_id} 成功获取列表（{len(emojis)} 张）")

    return {
        "success": True,
        "message": (
            f"当前可用的表情包列表如下：\n{emoji_list_str}\n"
            "请挑选合适的ID，调用 send_emoji 工具发送，并在 reply 中写下你想说的话。"
        )
    }
