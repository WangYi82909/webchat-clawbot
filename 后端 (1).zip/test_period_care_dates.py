import datetime
import unittest

import period_care


class PeriodCareDateTests(unittest.TestCase):
    def test_nullish_database_dates_are_ignored(self):
        for value in (None, "", "None", "null", "0000-00-00", "not-a-date"):
            with self.subTest(value=value):
                self.assertIsNone(period_care._parse_date(value))

    def test_valid_date_shapes_still_work(self):
        expected = datetime.date(2026, 8, 12)
        self.assertEqual(period_care._parse_date("2026-08-12 20:58:47"), expected)
        self.assertEqual(period_care._parse_date(expected), expected)
        self.assertEqual(
            period_care._parse_date(datetime.datetime(2026, 8, 12, 20, 58, 47)),
            expected,
        )


if __name__ == "__main__":
    unittest.main()
