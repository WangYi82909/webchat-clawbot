# =============================================================================
# persona.py — 人格热读与缓存
# =============================================================================
# 职责：
#   - get_persona_prompt()：给定 db_id,返回 (system_prompt, emotion_state) 元组
#     · system_prompt:走 instances.persona 缓存(热路径快)
#     · emotion_state:每条消息都新鲜读 user_personas,不缓存
#       (AI 通过 update_emotion_state 工具改完情绪,下条消息立即生效)
#   - refresh_persona_cache()：强制刷新 system_prompt 缓存(切人格时由 PHP 调)
#
# v13 (2026-05-13) 新增 emotion_state 字段:
#   · 老库无该字段 → 静默降级为空串,不影响主流程
#   · chat.py 通过 {emotion_state} 占位符注入到给 LLM 的 prompt
# =============================================================================

import aiomysql


async def get_persona_prompt(pool, db_id: int) -> tuple[str, str]:
    """
    返回 (system_prompt, emotion_state) 元组。

    流程：
      1. 读 instances 行,拿到 persona_id 和 persona(缓存)
      2. 未绑定人格 → 返回 ("", "")
      3. 读 user_personas 一次,同时拿 system_prompt 与 emotion_state
         (老库无 emotion_state 列时降级,只取 system_prompt)
      4. 若 instances.persona 缓存存在,system_prompt 直接用缓存值;
         否则用步骤 3 的 system_prompt,并回写缓存
    """
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT id, persona_id, persona FROM instances WHERE id=%s",
                (db_id,)
            )
            inst = await cur.fetchone()

    if not inst or not inst['persona_id']:
        return "", ""

    pid = inst['persona_id']

    # 同时拿 system_prompt 与 emotion_state。单行 PK 查询 < 1ms,代价可忽略;
    # 换来 emotion_state 完全实时(AI 工具刚改完立即被读到)。
    row = None
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT system_prompt, emotion_state FROM user_personas WHERE id=%s",
                    (pid,)
                )
                row = await cur.fetchone()
    except Exception as e:
        # 老库无 emotion_state 列 → 降级只取 system_prompt,emotion_state 视为空
        msg = str(e)
        if "emotion_state" in msg and "Unknown column" in msg:
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT system_prompt FROM user_personas WHERE id=%s",
                        (pid,)
                    )
                    row = await cur.fetchone()
                    if row:
                        row['emotion_state'] = ''
        else:
            raise

    if not row:
        return "", ""

    emotion_state = row.get('emotion_state') or ''

    # ── system_prompt:优先用 instances.persona 缓存(热路径) ──
    if inst['persona']:
        return inst['persona'], emotion_state

    # 缓存为空 → 用刚查到的 system_prompt 回写
    system_prompt = row.get('system_prompt') or ''
    if not system_prompt:
        return "", emotion_state

    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "UPDATE instances SET persona=%s WHERE id=%s",
                (system_prompt, db_id)
            )
        await conn.commit()

    return system_prompt, emotion_state


async def refresh_persona_cache(pool, db_id: int) -> None:
    """
    强制刷新实例的 system_prompt 缓存(emotion_state 无缓存,本函数不涉及)。
    在以下场景调用：
      - 实例启动时（run_loop 开始）
      - 用户通过微信发送 /persona 切换命令后（skill 调用）
    正常消息流程不需要调用此函数，get_persona_prompt 会自动处理。
    """
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT persona_id FROM instances WHERE id=%s", (db_id,)
            )
            inst = await cur.fetchone()

    if not inst or not inst['persona_id']:
        # 清空缓存
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "UPDATE instances SET persona=NULL WHERE id=%s", (db_id,)
                )
            await conn.commit()
        return

    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT system_prompt FROM user_personas WHERE id=%s",
                (inst['persona_id'],)
            )
            row = await cur.fetchone()

    prompt = row['system_prompt'] if row else ''
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "UPDATE instances SET persona=%s WHERE id=%s",
                (prompt or None, db_id)
            )
        await conn.commit()
