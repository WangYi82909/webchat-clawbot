import unittest

import chat
import llm_protocol_openai as openai_protocol


class VisionModelDetectionTests(unittest.TestCase):
    def test_prefixed_gemini_id_is_supported_by_openai_protocol(self):
        model = "[ais]gemini-3.5-flash"
        self.assertTrue(chat._is_gemini_named_native_vision_model(model, "openai"))
        self.assertTrue(chat._model_supports_vision_by_prefix(model, "openai"))
        self.assertTrue(openai_protocol.is_explicit_native_vision_model(model))

        image_url = "data:image/jpeg;base64,cGhvdG8="
        payload = openai_protocol.build_payload(model, [{
            "role": "user",
            "content": [
                {"type": "text", "text": "请看图"},
                {"type": "image_url", "image_url": {"url": image_url}},
            ],
        }])
        self.assertEqual(
            payload["messages"][0]["content"][1]["image_url"]["url"],
            image_url,
        )

    def test_prefixed_gemini_id_is_supported_by_gemini_protocol(self):
        self.assertTrue(chat._is_gemini_named_native_vision_model(
            "[route]vendor/GEMINI-3.1-pro", "gemini"
        ))

    def test_gemini_substring_does_not_override_other_protocols(self):
        self.assertFalse(chat._is_gemini_named_native_vision_model(
            "[route]gemini-3.1-pro", "anthropic"
        ))

    def test_non_gemini_model_is_not_enabled_by_the_new_rule(self):
        self.assertFalse(chat._is_gemini_named_native_vision_model(
            "[route]text-only-model", "openai"
        ))


if __name__ == "__main__":
    unittest.main()
