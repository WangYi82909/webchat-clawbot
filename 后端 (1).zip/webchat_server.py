"""
webchat_server.py — 网页端对话服务（随 main.py 启动）

定位
  让网页（demo.php 听歌页右下角输入框）能和 AI 对话。
  复用引擎里**同一套 chat.generate_reply**，计费、上下文、人格等路由
  完全不变；不新增实例，直接用用户**已有实例的现成配置**。

  main.py 集成（仅两处，详见随附说明）：
    from webchat_server import run as webchat_run
    asyncio.create_task(webchat_run(pool))

工作方式
  - 本文件用 asyncio 起一个**仅监听 127.0.0.1** 的极简 HTTP 服务（默认
    端口 8765），不依赖 aiohttp 等第三方库（stdlib 即可）。
  - 它是**内部服务**：不直接对公网开放。公网入口是 PHP 的
    api_webchat.php —— 它用 PHP session 鉴权、查出该用户的实例 id，
    再把 {db_id, message} 转发到本服务。鉴权与计费都留在原有链路。
  - 收到请求后用一个最小 bot_instance 桩（只需 .db_id）调
    chat.generate_reply，把回复 JSON 返回。

请求 / 响应（POST / ，application/json）
  请求：{ "db_id": 123, "message": "你好", "uid": "webchat" }
  响应：{ "ok": true,  "reply": "……" }
        { "ok": false, "error": "……" }
"""
import asyncio
import json
import traceback

import chat   # 复用引擎现成的对话主入口

# 仅监听本机，避免公网直连；端口可按需改（需与 api_webchat.php 一致）
WEBCHAT_HOST = '0.0.0.0'
WEBCHAT_PORT = 8765

# 网页对话统一用这个合成 uid（区别于微信联系人 uid）
WEBCHAT_UID  = 'webchat'

_POOL = None   # 由 run() 注入的全局连接池

# 歌词注入节流(2026-06-02)
#   每 WEBCHAT_LYRIC_INTERVAL 轮才把"正在听的歌 + 歌词"作为独立 user 消息注入
#   一次(第 1、11、21… 轮)，而不是每轮都塞 —— 避免输入爆炸、也不污染实例
#   共享历史(歌曲信息只本轮临时注入、不入 history、也不进 system 前缀)。
#   计数按 db_id 存在进程内存里：进程重启即重置；换歌立即重新注入并把计数归零。
WEBCHAT_LYRIC_INTERVAL = 10

# db_id -> {'song': 最近注入的歌名, 'lyric': 对应歌词, 'turn': 累计对话轮数}
#   命中判定用"歌名 + 歌词"两者：前端只传歌名+歌词、没有稳定歌曲 id，
#   只比歌名会把"同名不同曲"(翻唱/重名)误判为同一首而漏掉重注。
#   一次播放期间歌词是固定的(demo.php 载入时一次性写入)，故不会误触发。
# 注：asyncio 单线程，下面对该 dict 的读改写之间不 await，天然无需加锁。
_LYRIC_INJECT_STATE = {}


# ---------------------------------------------------------------------
# 最小 bot_instance 桩 —— generate_reply 实际只用到 .db_id，
# 其它配置它都自己从 DB 现查（见 chat.py: SELECT * FROM instances）。
# ---------------------------------------------------------------------
class _WebBotInstance:
    def __init__(self, db_id, pool):
        self.db_id = db_id
        self.pool  = pool
        self.tool_channel = "web"
        self.channel = "web"


# ---------------------------------------------------------------------
# 核心：处理一条网页消息
#   song / lyric：用户当前正在听的歌名 + 完整歌词。作为独立 user 消息按轮数
#   间隔注入(默认每 10 轮一次，换歌立即重注)，让 AI 知道在听什么、可就歌聊，
#   又不必每轮重复传整段歌词。
# ---------------------------------------------------------------------
async def _handle_chat(db_id, message, uid, song=None, lyric=None):
    if not db_id:
        return {'ok': False, 'error': '缺少 db_id'}
    if not message or not str(message).strip():
        return {'ok': False, 'error': '消息为空'}

    # 用户消息保持原样，不再把歌曲信息拼进去(否则每轮重复、还会被持久化进
    # 实例共享历史)。歌曲信息改为以 system 背景块按轮数间隔注入(见下)。
    user_text = str(message)
    song = (song or '').strip()
    lyric = (lyric or '').strip()

    # ── 歌曲背景注入节流 ──────────────────────────────────────────────
    #   第 1、11、21… 轮(以及换歌那一轮)才注入一次；其余轮不带歌曲信息。
    #   注入内容走 generate_reply 的 extra_user_block(独立 user 消息，放在历史
    #   之后、本轮消息之前)，仅本轮生效、不入 history、也不污染 system 前缀缓存。
    #   计数按 db_id 存内存：换歌立即重置为第 1 轮并注入。
    extra_user_block = None
    if song:
        try:
            _key = int(db_id)
        except (TypeError, ValueError):
            _key = db_id
        # 缓存命中：同一 db_id 且歌名+歌词都没变 → 命中(继续累加轮数)；
        # 歌名或歌词任一变化(含同名不同曲)→ 未命中，计数归零并本轮立即重注。
        _st = _LYRIC_INJECT_STATE.get(_key)
        if _st is None or _st.get('song') != song or _st.get('lyric') != lyric:
            _turn = 1                                   # 新歌 / 首轮 → 计数归零重来
        else:
            _turn = _st.get('turn', 0) + 1
        _LYRIC_INJECT_STATE[_key] = {'song': song, 'lyric': lyric, 'turn': _turn}

        if (_turn - 1) % WEBCHAT_LYRIC_INTERVAL == 0:   # 第 1、11、21… 轮
            extra_user_block = (
                '【正在听的歌】《' + song + '》\n'
                + ('【完整歌词】\n' + lyric + '\n' if lyric else '')
                + '（以上是用户此刻正在听的歌曲信息，是系统提供的背景，'
                + '不是用户说的话。你可以结合歌曲自然地聊。）'
            )

    bot = _WebBotInstance(int(db_id), _POOL)
    try:
        reply_json, is_error = await asyncio.wait_for(
            chat.generate_reply(_POOL, bot, uid or WEBCHAT_UID, user_text,
                                extra_user_block=extra_user_block,
                                tool_channel="web"),
            timeout=500.0,
        )
    except asyncio.TimeoutError:
        return {'ok': False, 'error': 'AI 响应超时，请稍后再试'}
    except Exception as e:
        print(f"[网页对话] generate_reply 异常 db_id={db_id}: {e}", flush=True)
        traceback.print_exc()
        return {'ok': False, 'error': '对话生成失败'}

    reply = ''
    if isinstance(reply_json, dict):
        reply = reply_json.get('reply') or ''
    if is_error and not reply:
        return {'ok': False, 'error': reply or 'AI 暂时无法回复'}

    # 按该实例的分段配置（instances.split_rule / ignore_punctuation）把回复拆成多条，
    # 与微信端发送时的分段口径一致 —— 这就是「用户的配置」。
    segments = [reply]
    try:
        import utils
        _wx, split_rule, ignore_punc = await utils._fetch_send_config(_POOL, int(db_id))
        parts = utils.split_text(reply, split_rule, ignore_punc)
        if parts:
            segments = parts
    except Exception as e:
        print(f"[网页对话] 分段失败（回退整段）db_id={db_id}: {e}", flush=True)

    return {'ok': True, 'reply': reply, 'segments': segments}


# ---------------------------------------------------------------------
# 极简 HTTP（基于 asyncio.start_server，stdlib，无第三方依赖）
#   只支持 POST /，body 为 JSON。够内部用。
# ---------------------------------------------------------------------
async def _read_http_request(reader):
    """读出 (method, path, headers dict, body bytes)；失败返回 None。"""
    # 读请求行 + 头
    header_data = b''
    while b'\r\n\r\n' not in header_data:
        chunk = await reader.read(1024)
        if not chunk:
            break
        header_data += chunk
        if len(header_data) > 65536:      # 头部过大，拒绝
            return None
    if b'\r\n\r\n' not in header_data:
        return None

    head, _, rest = header_data.partition(b'\r\n\r\n')
    lines = head.split(b'\r\n')
    request_line = lines[0].decode('latin1', 'ignore')
    parts = request_line.split(' ')
    if len(parts) < 2:
        return None
    method, path = parts[0], parts[1]

    headers = {}
    for line in lines[1:]:
        if b':' in line:
            k, _, v = line.partition(b':')
            headers[k.decode('latin1').strip().lower()] = v.decode('latin1').strip()

    # 读 body 余下部分
    body = rest
    try:
        clen = int(headers.get('content-length', '0'))
    except ValueError:
        clen = 0
    while len(body) < clen:
        chunk = await reader.read(clen - len(body))
        if not chunk:
            break
        body += chunk
    return method, path, headers, body


async def _send_http_json(writer, status, obj):
    payload = json.dumps(obj, ensure_ascii=False).encode('utf-8')
    status_text = {200: 'OK', 400: 'Bad Request', 405: 'Method Not Allowed',
                   500: 'Internal Server Error'}.get(status, 'OK')
    head = (
        f"HTTP/1.1 {status} {status_text}\r\n"
        f"Content-Type: application/json; charset=utf-8\r\n"
        f"Content-Length: {len(payload)}\r\n"
        f"Connection: close\r\n"
        f"\r\n"
    ).encode('latin1')
    writer.write(head + payload)
    await writer.drain()


async def _on_client(reader, writer):
    try:
        req = await _read_http_request(reader)
        if not req:
            await _send_http_json(writer, 400, {'ok': False, 'error': '请求格式错误'})
            return
        method, path, headers, body = req

        if method.upper() != 'POST':
            await _send_http_json(writer, 405, {'ok': False, 'error': '仅支持 POST'})
            return

        try:
            data = json.loads(body.decode('utf-8') or '{}')
        except Exception:
            await _send_http_json(writer, 400, {'ok': False, 'error': 'JSON 解析失败'})
            return

        result = await _handle_chat(
            data.get('db_id'),
            data.get('message'),
            data.get('uid'),
            data.get('song'),
            data.get('lyric'),
        )
        await _send_http_json(writer, 200, result)

    except Exception as e:
        print(f"[网页对话] 连接处理异常: {e}", flush=True)
        try:
            await _send_http_json(writer, 500, {'ok': False, 'error': '服务器内部错误'})
        except Exception:
            pass
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass


# ---------------------------------------------------------------------
# 对外入口 —— main.py: asyncio.create_task(webchat_run(pool))
# ---------------------------------------------------------------------
async def run(pool):
    global _POOL
    _POOL = pool
    server = await asyncio.start_server(_on_client, WEBCHAT_HOST, WEBCHAT_PORT)
    print(f"[就绪] 网页端对话服务已挂入主循环 "
          f"(http://{WEBCHAT_HOST}:{WEBCHAT_PORT}，复用 chat.generate_reply)",
          flush=True)
    async with server:
        await server.serve_forever()
