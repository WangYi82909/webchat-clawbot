# 心潮集成说明

## 文件

- `console.php`：底部导航中的心潮入口、状态面板和登录用户范围内的只读状态接口。
- `dynamic_mind.py`：按 `db_id` 隔离的状态机、持久化、梦境和主动消息门控。
- `chat.py`：心潮状态注入、`mind_event` 回写和自然对话提示词。
- `main.py`：心潮主动调度；旧随机主动消息扫描器不再启动。
- `llm_protocol_openai.py`：OpenAI-compatible 请求转换。
- `migrate_dynamic_mind.sql`：数据库迁移。
- `test_dynamic_mind.py`：核心状态规则测试。

这些 Python 文件应放在同一个服务模块目录。`console.php` 放回原控制台位置，继续使用项目现有的 `api/common.php`、登录态和静态资源。

## 部署

1. 备份线上 `chat.py`、`main.py`、`console.php` 和数据库。
2. 执行 `migrate_dynamic_mind.sql`。
3. 把 `dynamic_mind.py` 放入服务目录。
4. 替换 `chat.py`、`main.py` 和 `console.php`。
5. 保留项目原有依赖文件和 `api` 目录。
6. 先给一个实例灰度，确认日志出现 `[心潮·上下文]`、`[心潮·回写]` 和到期后的 `[心潮·主动触发]`。

## 状态归属

- 每个实例以数据库 `instances.id`，也就是 `db_id`，作为隔离键。
- 换模型保留状态。
- 换 `persona_id` 创建新状态；控制台也不会展示旧人格的状态。
- 用户发来新消息后，连续主动未回应计数归零并重新安排时间。
- 最多连续主动两次；用户不回应就停止。
- 北京时间 01:00 到 08:00 不主动触发。

## 心潮面板

进入心潮后控制台切换为专注模式：隐藏顶部入口、头像、页脚及其他底栏项目，只保留心潮按钮。再次点击心潮按钮恢复完整底部导航，页面仍停留在心潮。

控制台同文件接口：

```text
GET console.php?action=dynamic_mind_state&instance_id=实例标识
```

接口复用当前控制台登录态，只查询该用户拥有的实例。返回面板所需的驱动力、关系窗口、念头、梦境和主动计划，不返回模型密钥、上下文令牌或原始聊天历史。

数据库尚未迁移、实例未创建或状态尚未生成时，面板显示对应空状态，不暴露数据库错误。

## 喂给模型的顺序

每轮 `messages` 的顺序是：

1. `system`：人设、自然对话规则、工具规则和三字段输出协议。
2. 截断后的原有 `user`、`assistant` 聊天历史。
3. 一条只在本轮使用、不写进聊天历史的 `user` 心潮状态。
4. 必要时加入过去的操作记录。
5. 本轮真正的用户消息；主动轮则是精简的主动表达指令。

对话提示词不规定共情、分析、建议、追问等固定步骤，也不规定固定句数、开场或结尾。回复内容由人设、历史、本轮消息和心潮状态共同决定，只有 JSON 与工具调用属于硬协议。

旧 `update_emotion_state` 已停用。它不会进入工具清单，模型返回同名调用时会被忽略，文本清洗兼容路径也不能执行它；旧心理状态不再进入提示词，控制台原心理状态卡片已经移除。数据库里已有的旧字段和值可以保留，但不再参与运行。

心潮状态示意：

```text
【心潮动态状态·仅本轮有效·只用于塑造表达】
意识=awake；疲惫=0.000
当前驱动力=惦记对方:0.510；想分享:0.420
当前意图=惦记对方
当前关系窗口=tone:warm warmth:0.720 tension:0.080 attention:0.810 confidence:0.620
表达方式=本轮只让最强意图自然露出一点，不要解释状态。
表达自由=除人设与技术协议外，不预设回复步骤、句式或互动动作。
```

OpenAI-compatible 请求体的主要形状：

```json
{
  "model": "实例当前模型",
  "messages": [
    {"role": "system", "content": "人设、自然对话规则、工具规则、输出协议"},
    {"role": "user", "content": "历史消息"},
    {"role": "assistant", "content": "历史回复"},
    {"role": "user", "content": "心潮动态状态"},
    {"role": "user", "content": "本轮消息"}
  ],
  "temperature": 1.3,
  "max_tokens": 16384,
  "presence_penalty": 0.5,
  "prompt_cache_key": "instance-db_id"
}
```

具体采样参数使用实例当前配置。支持思考的模型还会带 `reasoning_effort`。

## 模型输出

模型只返回 `reply`、`tools`、`mind_event` 三个字段。`mind_event` 由程序白名单化后写回心潮状态，不发给用户，模型也不能直接提交驱动力增减量。

## 回滚

恢复备份的 `chat.py`、`main.py` 和 `console.php` 即可。`dynamic_mind_states` 是独立表，代码回滚时不要删除；确认不再需要后再单独备份和处理。
