# =============================================================================
# skills/search_memory.py — 记忆增强向量检索工具
# =============================================================================
NAME        = "search_memory"
DESCRIPTION = "当你需要更具体或更深入地回忆某个特定话题/事件/约定(例如用户问『还记得我跟你说过的那本书叫啥么』、『上次我们约的是几号』这类指向性提问),且 user_prompt 顶部的【关于这位用户的长期记忆】区块没有覆盖到时,才调用本工具做二次检索。普通对话不要重复调用,避免浪费上下文。reply 禁止传入,需要留空。"
USAGE       = '{"query": "需要回忆或检索的具体问题/关键词"}'
MODE        = "SYNC"

async def run(params: dict, pool, db_id, uid, bot_instance) -> dict:
    import httpx
    import json
    import math

    query = params.get("query", "").strip()
    if not query:
        return {"success": False, "message": "未指定检索词，无法检索记忆。"}

    # ── 从 system_config 读取配置 ────────────────────────────────────────────
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT config_key, config_value FROM system_config "
                "WHERE config_key IN ('embedding_endpoint','embedding_api_key','embedding_model')"
            )
            cfg = {r["config_key"]: r["config_value"] for r in await cur.fetchall()}

    EMB_URL      = cfg.get("embedding_endpoint", "https://api.openlux.ai/v1/embeddings")
    EMB_KEY      = cfg.get("embedding_api_key",  "")
    EMB_MODEL    = cfg.get("embedding_model",    "text-embedding-3-large")
    RERANK_URL   = EMB_URL.replace("/embeddings", "/rerank")
    RERANK_MODEL = "qwen3-rerank"

    def cosine_sim(v1, v2):
        dot   = sum(a * b for a, b in zip(v1, v2))
        norm1 = math.sqrt(sum(a * a for a in v1))
        norm2 = math.sqrt(sum(b * b for b in v2))
        return dot / (norm1 * norm2) if norm1 and norm2 else 0.0

    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            # ── 向量化查询词 ─────────────────────────────────────────────────
            emb_res = await client.post(
                EMB_URL,
                json={"model": EMB_MODEL, "input": query},
                headers={"Authorization": f"Bearer {EMB_KEY}"},
            )
            emb_res.raise_for_status()
            q_vec = emb_res.json()["data"][0]["embedding"]

            # ── 查摘要记忆（memory_type = 'summary'） ────────────────────────
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT content, embedding FROM instance_memories "
                        "WHERE instance_id=%s AND memory_type='summary' AND embedding IS NOT NULL",
                        (db_id,)
                    )
                    summary_rows = await cur.fetchall()

            summary_candidates = []
            for r in summary_rows:
                emb = json.loads(r["embedding"]) if isinstance(r["embedding"], str) else r["embedding"]
                score = cosine_sim(q_vec, emb)
                summary_candidates.append((score, r["content"]))
            summary_candidates.sort(key=lambda x: x[0], reverse=True)
            top_summaries = [c[1] for c in summary_candidates[:5]]

            # ── 查单轮记忆（memory_type = 'turn'） ───────────────────────────
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT content, embedding FROM instance_memories "
                        "WHERE instance_id=%s AND memory_type='turn' AND embedding IS NOT NULL",
                        (db_id,)
                    )
                    turn_rows = await cur.fetchall()

            turn_candidates = []
            for r in turn_rows:
                emb = json.loads(r["embedding"]) if isinstance(r["embedding"], str) else r["embedding"]
                score = cosine_sim(q_vec, emb)
                turn_candidates.append((score, r["content"]))
            turn_candidates.sort(key=lambda x: x[0], reverse=True)
            top_turns = [c[1] for c in turn_candidates[:10]]

            # ── Rerank 合并排序 ───────────────────────────────────────────────
            all_candidates = list(dict.fromkeys(top_summaries + top_turns))
            if not all_candidates:
                return {"success": True, "message": "当前实例没有任何长期记忆记录。"}

            rerank_res = await client.post(
                RERANK_URL,
                json={
                    "model": RERANK_MODEL,
                    "query": query,
                    "documents": all_candidates,
                    "top_n": 8,
                },
                headers={"Authorization": f"Bearer {EMB_KEY}"},
            )
            rerank_res.raise_for_status()
            rerank_data = rerank_res.json()

            ranked = sorted(
                rerank_data.get("results", []),
                key=lambda x: x.get("relevance_score", 0),
                reverse=True,
            )
            final_docs = [all_candidates[r["index"]] for r in ranked if r.get("relevance_score", 0) > 0.1]

            if not final_docs:
                return {"success": True, "message": "未检索到与当前问题相关的记忆。"}

            mem_text = "\n".join([f"- {doc}" for doc in final_docs])
            return {
                "success": True,
                "message": (
                    f"检索到以下相关记忆（已按相关性排序）：\n{mem_text}\n"
                    "请综合以上记忆信息生成回复。"
                ),
            }

    except Exception as e:
        return {"success": False, "message": f"记忆检索执行异常: {str(e)[:150]}"}
