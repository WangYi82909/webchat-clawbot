"""db.py — 远程 MySQL 连接池 (aiomysql).

单例: 整个进程一个 pool, 由 server.py 启动时 init, 关闭时 close.
"""
import aiomysql

from . import config

_pool: aiomysql.Pool | None = None


async def init() -> aiomysql.Pool:
    """启动时调用一次. 已初始化则直接返回."""
    global _pool
    if _pool is not None:
        return _pool
    _pool = await aiomysql.create_pool(
        minsize=config.DB_POOL_MIN,
        maxsize=config.DB_POOL_MAX,
        pool_recycle=1800,                  # 30min 主动回收, 防 MySQL wait_timeout
        cursorclass=aiomysql.DictCursor,
        **config.DB_CONFIG,
    )
    # 自检
    async with _pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute("SELECT 1")
            await cur.fetchone()
    return _pool


async def get_pool() -> aiomysql.Pool:
    if _pool is None:
        raise RuntimeError('db pool 未初始化, 应先调用 db.init()')
    return _pool


async def close() -> None:
    global _pool
    if _pool is not None:
        _pool.close()
        await _pool.wait_closed()
        _pool = None
