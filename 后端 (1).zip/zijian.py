# -*- coding: utf-8 -*-
"""
环境自检.py — 引擎目录文件版本体检（2026-06-05）

用途
  排查"本地源码是新版、服务器进程加载的却是旧版"这类文件不同步 / 模块遮蔽 /
  __pycache__ 陈旧问题。线上报
    · module 'chat' has no attribute 'resolve_model_runtime'
    · generate_reply() got an unexpected keyword argument 'force_rag'
  时，在引擎目录跑一遍本脚本即可定位是哪个文件旧了。

用法（在 main.py 所在目录执行）
    python3 环境自检.py

只读不写、不连数据库、不发请求，随便跑。
"""
import importlib
import inspect
import os
import sys
import time

GREEN, RED, YELL, END = '\033[32m', '\033[31m', '\033[33m', '\033[0m'
OK, BAD = f'{GREEN}✓{END}', f'{RED}✗{END}'
problems = []


def _mt(path):
    try:
        return time.strftime('%m-%d %H:%M:%S', time.localtime(os.path.getmtime(path)))
    except Exception:
        return '?'


def head(t):
    print(f"\n━━ {t} " + "━" * max(0, 46 - len(t)))


print("拼小圈/引擎 环境自检")
print(f"Python {sys.version.split()[0]} · 工作目录 {os.getcwd()}")
print(f"sys.path[0] = {sys.path[0] or '(空=当前目录)'}")

# ── 1. 各模块：进程实际加载哪个文件 + 关键函数在不在 ─────────────────
CHECKS = {
    'chat': ['resolve_model_runtime', 'generate_reply', '_call_llm_with_retry', 'get_http_client'],
    'billing': ['check_quota', 'calc_cost_from_usage', 'commit_usage'],
    'tool_leak_cleaner': ['clean_json_response', 'strip_thinking_tags'],
    'persona': ['get_persona_prompt'],
    'decision': ['decide'],
    'llm_protocol_openai': ['build_payload', 'resolve_endpoint', 'extract_reasoning'],
    'llm_protocol_anthropic': ['build_payload', 'resolve_endpoint', 'build_headers', 'parse_response'],
    'utils': ['get_beijing_time', 'add_temp_log'],
    'group_chat': ['run', 'get_group_context_for_private'],
}

head("模块加载体检")
for mod_name, attrs in CHECKS.items():
    try:
        m = importlib.import_module(mod_name)
    except Exception as e:
        print(f"{BAD} {mod_name:<24} 导入失败: {type(e).__name__}: {str(e)[:80]}")
        problems.append(f"{mod_name} 无法导入（文件缺失或依赖未装）")
        continue
    f = getattr(m, '__file__', '?')
    here = os.path.abspath(os.path.dirname(f or '')) == os.path.abspath(os.getcwd())
    where = '' if here else f"  {YELL}⚠ 不在当前目录(可能被别处同名文件遮蔽){END}"
    print(f"{OK} {mod_name:<24} {f}  (mtime {_mt(f)}){where}")
    if not here:
        problems.append(f"{mod_name} 实际加载自 {f}，不是当前目录 —— 检查重复文件/启动目录")
    for a in attrs:
        if hasattr(m, a):
            print(f"    {OK} {a}")
        else:
            print(f"    {BAD} {a}  ← 旧版文件缺这个")
            problems.append(f"{mod_name}.{a} 缺失 → 服务器上的 {mod_name}.py 是旧版，用本包 data/{mod_name}.py 覆盖")

# ── 2. 新版关键签名（旧版最典型的两处） ───────────────────────────────
head("关键签名体检")
try:
    import chat as _c
    ps = inspect.signature(_c.generate_reply).parameters
    for kw in ('force_rag', 'rag_keywords', 'enable_tools', 'extra_user_block'):
        if kw in ps:
            print(f"{OK} generate_reply 接受 {kw}")
        else:
            print(f"{BAD} generate_reply 不接受 {kw}  ← 这就是微信报 TypeError 的来源")
            problems.append(f"chat.generate_reply 缺参数 {kw} → chat.py 是旧版，覆盖后重启")
except Exception as e:
    print(f"{BAD} 无法检查 generate_reply 签名: {e}")

# ── 3. __pycache__ 陈旧字节码 ────────────────────────────────────────
head("__pycache__ 体检")
stale_hint = False
for root, dirs, files in os.walk('.'):
    if '__pycache__' not in root:
        continue
    for fn in files:
        if not fn.endswith('.pyc'):
            continue
        src_name = fn.split('.')[0] + '.py'
        src_path = os.path.join(os.path.dirname(root), src_name)
        pyc_path = os.path.join(root, fn)
        if os.path.exists(src_path):
            src_m, pyc_m = os.path.getmtime(src_path), os.path.getmtime(pyc_path)
            if pyc_m >= src_m:
                continue  # 正常：源码没比字节码新
        stale_hint = True
print(("提示：发现可疑字节码缓存。" if stale_hint else "未发现明显陈旧字节码。")
      + " 上传文件若用了保留旧 mtime 的工具(部分FTP/同步工具)，Python 可能继续用旧 .pyc。")
print("稳妥做法（任何时候都安全）：  find . -name __pycache__ -type d -exec rm -rf {} +")

# ── 4. 结论 ──────────────────────────────────────────────────────────
head("体检结论")
if not problems:
    print(f"{GREEN}全部正常：进程加载的就是新版文件。若线上仍报错，请确认已重启全部分片：{END}")
    print("    ./start_shards.sh restart")
else:
    print(f"{RED}发现 {len(problems)} 个问题：{END}")
    for i, p in enumerate(problems, 1):
        print(f"  {i}. {p}")
    print("\n修复三步：")
    print("  1) 用本包 data/ 里的对应文件覆盖上面标 ✗ 的模块文件")
    print("  2) find . -name __pycache__ -type d -exec rm -rf {} +")
    print("  3) ./start_shards.sh restart  后重跑本脚本确认全 ✓")
