"""
chat.py — AI 思考决策与回复生成（v2 · 订阅包 + 周额度 + 统一工具协议）

修改说明（v2 · 2026-05-06）：
1. 计费接口对接 billing.py v2：
   - check_quota 返回值改为 {ok, bucket, downgrade_msg, deny_reason}，bucket ∈ {"pack","weekly","balance"}
   - commit_usage 改为按 bucket 分桶扣费，余额桶最小颗粒 0.0001 元，扣费写两条日志
2. 工具调用规则强制约束：
   - 本轮若包含工具，reply 必须为空；文本与工具混合时整轮作废且不执行
   - 等待全部工具结果后，再发起下一轮模型思考并生成最终文字
3. 工具执行记录写入所属 assistant 消息的隐藏字段，下一轮请求时才渲染；
   用户实际收到的正文不包含内部记录。
4. 系统提示词更新：
   - 明确告知 AI 所有工具轮 reply 必须留空
5. 思维链通常只用于诊断；上游把完整最终 JSON 错放入 thought 且正文为空时，
   只允许恢复非空 reply，绝不恢复或执行其中的工具。
6. 计费拦截后会写日志告知用户，不再静默吞掉拦截原因。

【临时补丁 · 2026-05-06 · weekly 桶滥用限速】
   - 仅 bucket=='weekly' 触发；pack / balance 完全不动
   - 维度：每个 user_id 在过去 60 分钟内的请求次数 N
   - 阶梯延迟：N≥5→30s，N≥10→45s，N≥20→60s，其余 0
   - 延迟期间 typing 心跳由 main.py 的 TypingController 保活,用户那头持续显示"正在输入"
   - 延迟期间穿插中性日志（"深度思考中..."），不暴露限流字眼
   - 存储：进程同级 weekly_hourly_counter.json，asyncio.Lock + os.replace 原子写
   - 该方案为临时补丁，后续应迁移至 Redis 或 users 表新增字段

【提示词优化 · 2026-06-10】
   - 人设为内容层最高优先级，仅 JSON 输出格式凌驾。
   - 长期记忆归档改为「带情境的暖记忆」(每条 20-60 字, 含场景/原因/情绪),
     入库解析格式(「用户」开头/按行切分/最多 8 条)完全不变, 解析代码零改动。
   - QE 查询改写新增「TA 的情绪和近况」检索角度, 与新记忆格式呼应。
   - 所有模型统一使用唯一的内置真人聊天系统预设。
"""
import asyncio
import base64
import copy
import httpx
import utils
import hashlib
import json
import logging
import math
import os
import re
import billing
import persona
import time
import uuid
import tempfile
import contextvars
from contextlib import asynccontextmanager
from datetime import datetime
import llm_protocol_openai    as proto_openai     # v7.5: OpenAI 协议适配器
import llm_protocol_anthropic as proto_anthropic  # v12.15 (2026-05-13): Anthropic Messages API 适配器
import llm_protocol_gemini    as proto_gemini     # Gemini 原生 models.generateContent
import tool_leak_cleaner       as tlc             # v?? (2026-05-23) 工具调用残骸统一清洗库
import tool_turn_contract      as tool_contract   # 统一同步工具契约
import dynamic_mind            # per-db_id dynamic state / proactive mind engine

# v25 (2026-05-19) logger 定义
#   原版多处调用 logger.warning(...) 但全文件从未定义 logger,
#   只在清洗器 step 3 触发时才会暴露 NameError;现在补上避免崩溃。
logger = logging.getLogger(__name__)

try:
    import fcntl as _fcntl
except ImportError:  # Windows 本地测试环境；生产 Linux 使用跨进程文件锁。
    _fcntl = None

# 旧心理状态与心潮维护同一类情绪表达，已停用。即使工具目录仍有历史定义，
# 也不得把它暴露给模型或允许任何兼容/清洗路径执行。
_DISABLED_LEGACY_MIND_TOOLS = frozenset({"update_emotion_state"})

# ── 全局共享 HTTP 客户端（连接池复用，避免每次请求重建 TCP）─────────────────
# limits: 每个 host 最多 500 并发连接，总计 2000；keepalive 60s
_http_client: httpx.AsyncClient | None = None

def get_http_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None or _http_client.is_closed:
        limits = httpx.Limits(
            max_connections=2000,
            max_keepalive_connections=500,
            keepalive_expiry=60,
        )
        _http_client = httpx.AsyncClient(
            timeout=httpx.Timeout(
                connect=120.0,
                read=600.0,
                write=600.0,
                pool=120.0,
            ),
            limits=limits,
        )
    return _http_client


# ── 后台任务集合(防止 fire-and-forget 的 task 被 GC 提前回收)────────────────
_BG_TASKS: set = set()

# 同一实例内不同私聊/群聊可以并发；同一个会话必须串行，否则两个请求会读取
# 同一份旧 history，随后互相覆盖，并让显式缓存前缀出现分叉。
_CONVERSATION_LOCKS: dict[tuple[int, str], asyncio.Lock] = {}

# main.py 的 Worker 监控通过 task-local 回调接收 chat 内循环阶段。ContextVar
# 可确保数百个并发会话互不串状态；网页/QQ 未传回调时完全不产生额外行为。
_RUNTIME_STAGE_CALLBACK = contextvars.ContextVar(
    "chat_runtime_stage_callback", default=None
)


def _runtime_stage(stage: str, detail: str = "") -> None:
    """尽力上报当前处理阶段；监控故障绝不能影响聊天主链路。"""
    callback = _RUNTIME_STAGE_CALLBACK.get()
    if callback is None:
        return
    try:
        callback(str(stage or "processing"), str(detail or "")[:240])
    except Exception:
        pass

# Gemini 原生网关的承载能力明显低于 OpenAI 路由。所有 Linux 分片通过
# /tmp 文件锁共享槽位，避免每个 500-worker 进程同时把请求压到上游。
# 默认按逻辑 CPU 数量的 2 倍开放（最低 16）；24 核服务器默认为 48。
# 如需压测或根据上游容量调整，可用环境变量显式覆盖，无需再改代码。
_DEFAULT_GEMINI_GLOBAL_CONCURRENCY = max(16, (os.cpu_count() or 8) * 2)
try:
    GEMINI_GLOBAL_CONCURRENCY = max(
        1,
        int(os.getenv(
            "GEMINI_GLOBAL_CONCURRENCY",
            str(_DEFAULT_GEMINI_GLOBAL_CONCURRENCY),
        )),
    )
except (TypeError, ValueError):
    GEMINI_GLOBAL_CONCURRENCY = _DEFAULT_GEMINI_GLOBAL_CONCURRENCY
_GEMINI_LOCAL_SEMAPHORE = asyncio.Semaphore(GEMINI_GLOBAL_CONCURRENCY)
_GEMINI_SLOT_DIR = os.path.join(
    tempfile.gettempdir(), "cloudlove-gemini-request-slots"
)

# 供应商响应截止时间：取得出网槽位后 60 秒仍未拿到完整 HTTP 响应就主动
# 取消该请求并换一条请求重试。一次调用最多产生 3 次真实上游请求；明确的
# HTTP 错误与非超时网络错误仍立即停止，避免错误风暴。
LLM_RESPONSE_TIMEOUT_SECONDS = 60.0
LLM_TIMEOUT_MAX_ATTEMPTS = 3


async def _log_gemini_gate(pool, db_id: int, message: str) -> None:
    try:
        await utils.add_temp_log(pool, db_id, message)
    except Exception:
        pass


@asynccontextmanager
async def _gemini_request_slot(pool, db_id: int, protocol: str):
    """限制 Gemini 原生出网并发；OpenAI/Anthropic 直接通过。"""
    if str(protocol or "").lower() != "gemini":
        yield 0.0
        return

    started = time.monotonic()
    if _fcntl is None:
        async with _GEMINI_LOCAL_SEMAPHORE:
            waited = time.monotonic() - started
            if waited >= 0.5:
                await _log_gemini_gate(
                    pool, db_id,
                    f"[Gemini并发] 等待 {waited:.1f}s 后取得请求槽位"
                )
            yield waited
        return

    os.makedirs(_GEMINI_SLOT_DIR, mode=0o700, exist_ok=True)
    handle = None
    wait_logged = False
    task = asyncio.current_task()
    start_index = abs(hash((int(db_id), id(task)))) % GEMINI_GLOBAL_CONCURRENCY
    try:
        while handle is None:
            for offset in range(GEMINI_GLOBAL_CONCURRENCY):
                slot = (start_index + offset) % GEMINI_GLOBAL_CONCURRENCY
                candidate = open(
                    os.path.join(_GEMINI_SLOT_DIR, f"slot-{slot}.lock"), "a+b"
                )
                try:
                    _fcntl.flock(
                        candidate.fileno(), _fcntl.LOCK_EX | _fcntl.LOCK_NB
                    )
                except (BlockingIOError, OSError):
                    candidate.close()
                    continue
                handle = candidate
                break

            waited = time.monotonic() - started
            if handle is None:
                if waited >= 1.0 and not wait_logged:
                    wait_logged = True
                    await _log_gemini_gate(
                        pool, db_id,
                        "[Gemini并发] 当前请求较多，正在本机等待请求槽位"
                    )
                await asyncio.sleep(0.25)

        waited = time.monotonic() - started
        if waited >= 0.5:
            await _log_gemini_gate(
                pool, db_id,
                f"[Gemini并发] 等待 {waited:.1f}s 后取得请求槽位"
            )
        yield waited
    finally:
        if handle is not None:
            try:
                _fcntl.flock(handle.fileno(), _fcntl.LOCK_UN)
            finally:
                handle.close()


def _get_conversation_lock(db_id: int, uid) -> asyncio.Lock:
    # 所有渠道共享同一份实例上下文，因此锁也必须按同一个跨平台键串行；
    # 否则微信与 QQ 同时回复会各自读取旧历史再互相覆盖。
    key = (
        int(db_id),
        utils.unified_conversation_uid(db_id) if uid is not None else "",
    )
    lock = _CONVERSATION_LOCKS.get(key)
    if lock is None:
        lock = asyncio.Lock()
        _CONVERSATION_LOCKS[key] = lock
    return lock


_CROSS_PROCESS_CONVERSATION_LOCK_DIR = os.path.join(
    tempfile.gettempdir(), "cloudlove-cross-platform-conversations"
)


@asynccontextmanager
async def _cross_process_conversation_lock(db_id: int):
    """让不同分片中的微信与 QQ 也按实例串行更新同一份历史。"""
    if _fcntl is None:
        yield
        return
    os.makedirs(_CROSS_PROCESS_CONVERSATION_LOCK_DIR, mode=0o700, exist_ok=True)
    handle = open(
        os.path.join(
            _CROSS_PROCESS_CONVERSATION_LOCK_DIR,
            f"instance-{int(db_id)}.lock",
        ),
        "a+b",
    )
    try:
        while True:
            try:
                _fcntl.flock(handle.fileno(), _fcntl.LOCK_EX | _fcntl.LOCK_NB)
                break
            except (BlockingIOError, OSError):
                await asyncio.sleep(0.05)
        yield
    finally:
        try:
            _fcntl.flock(handle.fileno(), _fcntl.LOCK_UN)
        except Exception:
            pass
        handle.close()


async def _has_mind_entitlement(pool, db_id: int) -> bool:
    """Return whether an instance's owner has purchased 心潮.

    The entitlement is owned by ``users`` while chat requests identify an
    ``instances`` row.  Resolve the relationship in the database for every
    request so a purchase or revocation takes effect without a process
    restart.  This helper deliberately fails closed: an unavailable database,
    a missing migration/column, a missing row, NULL, or any value other than
    integer ``1`` is treated as not purchased.
    """
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                try:
                    await cur.execute(
                        "SELECT u.mind_purchased, u.platinum_expires_at "
                        "FROM instances AS i "
                        "INNER JOIN users AS u ON u.id = i.user_id "
                        "WHERE i.id=%s LIMIT 1",
                        (db_id,),
                    )
                except Exception:
                    # 白金迁移未执行时继续兼容旧库的心潮永久权益。
                    await cur.execute(
                        "SELECT u.mind_purchased, 0 AS platinum_expires_at "
                        "FROM instances AS i INNER JOIN users AS u ON u.id=i.user_id "
                        "WHERE i.id=%s LIMIT 1",
                        (db_id,),
                    )
                row = await cur.fetchone()
        if not row:
            return False
        value = row.get("mind_purchased") if hasattr(row, "get") else row[0]
        platinum_expiry = row.get("platinum_expires_at", 0) if hasattr(row, "get") else (row[1] if len(row) > 1 else 0)
        if int(platinum_expiry or 0) > int(time.time()):
            return True
        # bool(True) and numeric 1 are accepted; strings are normalized so
        # drivers returning VARCHAR-like values still work, while values such
        # as 1.0/"01" are not accidentally treated as a purchase.
        if isinstance(value, bool):
            return value
        if isinstance(value, int):
            return value == 1
        if isinstance(value, str):
            return value.strip() == "1"
        return False
    except Exception:
        return False


def _coerce_live_split_config(row, fallback=None) -> dict:
    """把 instances 的实时分段字段整理成稳定的内部结构。"""
    fallback = fallback or {}

    def _field(name, index, default):
        if row is None:
            return default
        if hasattr(row, "get"):
            return row.get(name, default)
        try:
            return row[index]
        except (IndexError, KeyError, TypeError):
            return default

    raw_rule = _field("split_rule", 0, fallback.get("split_rule", ""))
    raw_ignore = _field(
        "ignore_punctuation", 1, fallback.get("ignore_punctuation", False)
    )
    split_rule = "" if raw_rule is None else str(raw_rule)
    if isinstance(raw_ignore, bool):
        ignore_punctuation = raw_ignore
    else:
        ignore_punctuation = str(raw_ignore or "0").strip() == "1"
    return {
        "split_rule": split_rule,
        "ignore_punctuation": ignore_punctuation,
    }


async def _load_live_split_config(pool, db_id: int, fallback=None) -> dict:
    """每次发起模型请求前重新读取控制台中的当前实例分段配置。"""
    fallback_config = _coerce_live_split_config(None, fallback)
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT split_rule, ignore_punctuation "
                    "FROM instances WHERE id=%s LIMIT 1",
                    (db_id,),
                )
                row = await cur.fetchone()
        if row:
            return _coerce_live_split_config(row, fallback_config)
        logger.warning("实时分段配置不存在，沿用本轮初始值 db_id=%s", db_id)
    except Exception as exc:
        # 配置读取异常不能让正常聊天中断；仍保留本轮开始时 SELECT * 取得的值。
        logger.warning(
            "实时分段配置读取失败，沿用本轮初始值 db_id=%s error=%s",
            db_id,
            exc,
        )
    return fallback_config


def _effective_split_markers(split_rule: str) -> list[str]:
    """按 utils.split_text 的规则算出 AI 应写入 reply 的实际分段标识。"""
    markers = []
    for part in str(split_rule or "").split(","):
        # 数据库既可能保存两个字符的 ``\\n``，也可能保存真实换行。
        if part in ("\n", "\\n", "\r", "\r\n"):
            candidates = ["。"]
        else:
            candidates = list(part.strip())
        for char in candidates:
            if char and char not in markers:
                markers.append(char)
    return markers


def _build_split_speaking_rule(config: dict) -> str:
    """把控制台分段标识符渲染为当前预设【说话方式】中的一条规则。"""
    markers = _effective_split_markers(str(config.get("split_rule") or ""))
    if not markers:
        return "- 当前未配置分段标识符，每次 reply 作为一条消息发送。"
    marker_text = "、".join(f"“{char}”" for char in markers)
    return f"- 使用{marker_text}来分割每一句话。"


def _fire_and_forget(coro) -> None:
    """把一个协程丢到后台执行,【不阻塞】调用方,也【不影响】本轮对话链路。

    2026-07-08 引入。专用于每轮 turn 向量入库(_embed_and_save_turn):
      - turn 向量只进 instance_memories(RAG 素材池),与对话上下文 history
        完全无关,不该拖慢用户可感的回复延迟。
      - 之前它是 `await`,嵌入端点抖动时会把回复链路卡到 timeout 秒;现在改成
        后台任务,无论嵌入多慢/超时/失败,用户对话一律不受影响(异常已在
        _embed_and_save_turn 内部 try/except 吞掉并写日志)。
    """
    try:
        task = asyncio.create_task(coro)
    except RuntimeError:
        # 理论上 async 调用链里一定有运行中的事件循环;兜底:拿不到就直接放弃,
        # 关闭协程避免 "coroutine was never awaited" 警告。
        try:
            coro.close()
        except Exception:
            pass
        return
    _BG_TASKS.add(task)
    task.add_done_callback(_BG_TASKS.discard)


# ════════════════════════════════════════════════════════════════════════════
# 【临时补丁 · weekly 桶滥用限速】
# ════════════════════════════════════════════════════════════════════════════
# 仅当本次请求 bucket=="weekly"（免费用户）才会调用本节函数。
# 数据结构：{ "user_id_str": [unix_ts, unix_ts, ...] } 只保留过去 1 小时内的时间戳。
# 后续若上 Redis：
#   - 替换 _weekly_record_and_get_delay 一个函数即可（key=throttle:weekly:<uid>，
#     用 ZADD + ZREMRANGEBYSCORE + ZCARD 三步搞定，原子性更优）
#   - generate_reply 调用点保持不动
# ════════════════════════════════════════════════════════════════════════════
_WEEKLY_COUNTER_FILE = os.path.join(os.path.dirname(__file__), "weekly_hourly_counter.json")
_weekly_lock = asyncio.Lock()

_WEEKLY_THROTTLE_TABLE = (
    # 2026-05-08:取消 weekly 用户速率限制。
    # (10, 45),   # ≥25 轮:45s
    # (15, 30),   # ≥20 轮:30s
    # (20, 20),   # ≥10 轮:20s
)


def _calc_weekly_delay(count: int) -> int:
    """计算周免费额度的请求节流时长。"""
    for threshold, delay in _WEEKLY_THROTTLE_TABLE:
        if count >= threshold:
            return delay
    return 0


# ════════════════════════════════════════════════════════════════════════════
# 【免费桶硬上限】v9.7 (2026-05-11)
# ════════════════════════════════════════════════════════════════════════════
# 仅 bucket=="weekly" 命中。订阅包 (pack) 与余额 (balance) 路径不动。
# 配额: 每小时 5 条 / 每天 40 条 (超出后本窗口内直接拦截,不调 LLM)。
# 首次超限时返回提示文案 (走 _no_split_send),同窗口内后续静默吞掉。
# 状态文件: free_bucket_quota.json (与 weekly_hourly_counter 并存,职责独立)。
# ════════════════════════════════════════════════════════════════════════════
FREE_BUCKET_HOURLY_LIMIT = 15
FREE_BUCKET_DAILY_LIMIT  = 50
FREE_BUCKET_HOUR_MSG     = "本小时免费桶达到限制,切换订阅包/余额。"
FREE_BUCKET_DAY_MSG      = "本天免费桶达到最大消息,切换订阅包/余额。"

_FREE_BUCKET_FILE = os.path.join(os.path.dirname(__file__), "free_bucket_quota.json")
_free_bucket_lock = asyncio.Lock()


async def _check_free_bucket_quota(user_id: int) -> tuple[str, str]:
    """
    检查并消费免费桶配额。

    返回 (status, message):
        status:
          "ok"             配额内,允许调用 LLM
          "hour_limit"     本小时首次超限 → 应回首次提示文案
          "day_limit"      本天首次超限 → 应回首次提示文案
          "silent_block"   本窗口已发过提示,后续静默拦截(不调 LLM,不再推送)
        message:
          status=hour_limit/day_limit 时为对应提示文案,其余为空串

    实现细节:
      - 小时窗口:对齐自然小时 (今天 14:00 ~ 14:59)
      - 天窗口:对齐自然天 (今天 00:00 ~ 23:59)
      - 跨窗口时 notified 标志自动复位
      - 文件 + asyncio.Lock + tmp 原子写,与 _weekly_record_and_get_delay 同模式
      - 仅在调用 LLM "确定能成功" 时 +1 计数 (达限时不计本次,以保证首次提示能立即发出)
    """
    now      = int(time.time())
    hour_win = (now // 3600) * 3600              # 当前自然小时起点
    day_win  = (now - (now + 8 * 3600) % 86400)  # 当前北京自然日 00:00 UTC ts
                                                  # (UTC+8 偏移,与项目北京时间一致)
    key = str(user_id)

    # 同步文件读写丢线程池,理由同 _weekly_record_and_get_delay。
    def _read_bucket():
        if not os.path.exists(_FREE_BUCKET_FILE):
            return {}
        try:
            with open(_FREE_BUCKET_FILE, "r", encoding="utf-8") as f:
                loaded = json.load(f)
                return loaded if isinstance(loaded, dict) else {}
        except Exception as e:
            print(f"[{time.strftime('%H:%M:%S')}][FreeBucket] "
                  f"读取配额文件失败,重建: {type(e).__name__}: {e}", flush=True)
            return {}

    def _write_bucket(payload):
        try:
            tmp = _FREE_BUCKET_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False)
            os.replace(tmp, _FREE_BUCKET_FILE)
        except Exception as e:
            print(f"[{time.strftime('%H:%M:%S')}][FreeBucket] "
                  f"写入配额文件失败: {type(e).__name__}: {e}", flush=True)

    async with _free_bucket_lock:
        # ── 读（线程池）──────────────────────────────────────────────────
        data = await asyncio.to_thread(_read_bucket)

        rec = data.get(key) or {}
        # 窗口切换 → 复位计数 + 通知标志
        if rec.get("hour_win") != hour_win:
            rec["hour_win"]      = hour_win
            rec["hour_count"]    = 0
            rec["hour_notified"] = False
        if rec.get("day_win") != day_win:
            rec["day_win"]      = day_win
            rec["day_count"]    = 0
            rec["day_notified"] = False

        # ── 判定 ────────────────────────────────────────────────────────
        # 优先级: 天限 > 小时限 (天限更严格)
        if rec["day_count"] >= FREE_BUCKET_DAILY_LIMIT:
            if rec.get("day_notified"):
                status, msg = "silent_block", ""
            else:
                rec["day_notified"] = True
                status, msg = "day_limit", FREE_BUCKET_DAY_MSG
        elif rec["hour_count"] >= FREE_BUCKET_HOURLY_LIMIT:
            if rec.get("hour_notified"):
                status, msg = "silent_block", ""
            else:
                rec["hour_notified"] = True
                status, msg = "hour_limit", FREE_BUCKET_HOUR_MSG
        else:
            # 配额内 → 消费一格 (LLM 即将被调用,不消费会导致逃逸)
            rec["hour_count"] += 1
            rec["day_count"]  += 1
            status, msg = "ok", ""

        data[key] = rec

        # ── 清扫陈旧用户 (跨天 + 跨小时都过期的 key) ────────────────────
        stale_day = day_win - 86400 * 2  # 2 天前的记录可丢弃
        for k in list(data.keys()):
            r = data.get(k) or {}
            if (r.get("day_win") or 0) < stale_day:
                del data[k]

        # ── 写（线程池）──────────────────────────────────────────────────
        await asyncio.to_thread(_write_bucket, data)

    return status, msg


async def _weekly_record_and_get_delay(user_id: int) -> tuple[int, int]:
    """
    【临时补丁 · 文件存储版】

    把 user_id 当前请求的时间戳追加进文件，返回 (本小时请求总数, 应延迟秒数)。

    并发安全：
      - 模块级 asyncio.Lock 串行化读-改-写
      - 写入用 tmp + os.replace 实现原子覆盖，避免半截 JSON
      - 读不到 / 解析失败 → 视为空字典，从零开始计数（容错优先于精确）

    清理策略：
      - 每次进入都把所有用户的过期时间戳一起清掉，文件不会无限膨胀
      - 空 list 的 key 也一起删掉，避免遗留垃圾

    返回：
      (count, delay_sec) — count 已包含本次追加的这一条
    """
    now = int(time.time())
    one_hour_ago = now - 3600
    key = str(user_id)

    # ── 同步文件读写小函数:用 asyncio.to_thread 丢到线程池执行 ──────────
    # 关键修复:open / json.load / json.dump / os.replace 是同步阻塞调用,
    # 直接在协程里跑会冻结【整个事件循环】—— 一个 worker 读写大 JSON 时,
    # 全部 worker 一起卡住(看起来都卡在「LLM 思考中」)。
    # 用户越多文件越大,冻结越久。移到线程池后事件循环不再被阻塞。
    def _read_weekly():
        if not os.path.exists(_WEEKLY_COUNTER_FILE):
            return {}
        try:
            with open(_WEEKLY_COUNTER_FILE, "r", encoding="utf-8") as f:
                loaded = json.load(f)
                return loaded if isinstance(loaded, dict) else {}
        except Exception as e:
            print(f"[{time.strftime('%H:%M:%S')}][WeeklyThrottle] "
                  f"读取计数文件失败，重建：{type(e).__name__}: {e}", flush=True)
            return {}

    def _write_weekly(payload):
        try:
            tmp = _WEEKLY_COUNTER_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False)
            os.replace(tmp, _WEEKLY_COUNTER_FILE)
        except Exception as e:
            print(f"[{time.strftime('%H:%M:%S')}][WeeklyThrottle] "
                  f"写入计数文件失败：{type(e).__name__}: {e}", flush=True)

    async with _weekly_lock:
        # ── 读（线程池，不阻塞事件循环）──────────────────────────────────
        data = await asyncio.to_thread(_read_weekly)

        # ── 改：清过期 + 追加本次 ──────────────────────────────────────────
        for k in list(data.keys()):
            ts_list = data.get(k) or []
            cleaned = [t for t in ts_list if isinstance(t, (int, float)) and t > one_hour_ago]
            if cleaned:
                data[k] = cleaned
            else:
                del data[k]

        cur_list = data.get(key, [])
        cur_list.append(now)
        data[key] = cur_list
        count = len(cur_list)

        # ── 写（线程池，不阻塞事件循环）──────────────────────────────────
        await asyncio.to_thread(_write_weekly, data)

    delay = _calc_weekly_delay(count)
    return count, delay


async def _apply_weekly_throttle(pool, db_id: int, user_id: int) -> None:
    """
    weekly 桶限流执行入口。

    流程：
      1. 记录当前用户本次请求时间戳，拿到本小时请求计数 N 与应延迟秒数 delay
      2. delay==0 → 直接返回，不写任何日志（用户毫无感知，避免暴露规则）
      3. delay>0 → 分段 sleep（每段 ~10s），中间穿插中性"思考中..."日志
         · 第一条略不同（"深度思考准备中..."），后续统一"持续推理中..."
         · 文案与正常思考流程相似，前端日志栏看不出限流痕迹
         · typing 心跳由 main.py 的 TypingController 在更早处启动，整段延迟期间持续保活
    """
    count, delay = await _weekly_record_and_get_delay(user_id)
    if delay <= 0:
        return

    # 后台留底：运维侧能在 stdout/journal 看到限流命中，但 temp_log（用户可见）不写
    print(
        f"[{time.strftime('%H:%M:%S')}][WeeklyThrottle] "
        f"user_id={user_id} db_id={db_id} hourly_count={count} delay={delay}s",
        flush=True,
    )

    # 分段：每 10s 一段，最少 1 段；这样长延迟里前端日志栏会有持续动静
    seg_size = 10
    segments = max(1, delay // seg_size)
    last_seg = delay - seg_size * (segments - 1)

    for i in range(segments):
        if i == 0:
            await utils.add_temp_log(pool, db_id, "深度思考准备中...")
        else:
            await utils.add_temp_log(pool, db_id, "持续推理中...")
        await asyncio.sleep(seg_size if i < segments - 1 else last_seg)


# ── v?? (2026-05-23) <thinking> 清洗迁移到 tool_leak_cleaner.strip_thinking_tags
# 旧版 _THINKING_FULL_RE / _THINKING_OPEN_TAIL_RE / _strip_thinking_tags 已删除,
# 调用方一律改 tlc.strip_thinking_tags。


# ── v8 视觉模型兜底判断(2026-05-09) ──────────────────────────────────────────
# 仅在老库 model_pricing.tags 字段为空时作为兜底使用。一旦 admin 在后台给模型
# 勾选了 vision 标签,DB tags 优先,本前缀表自动失效。
# 列表只覆盖主流命名公约,新模型请优先在 admin 勾选 tag,不要往这里堆字符串。
_VISION_MODEL_PREFIXES = (
    "gpt-4o", "gpt-4-vision", "gpt-4-turbo",     # OpenAI
    "gpt-4.1", "gpt-5", "gpt-4-omni",
    "claude-3", "claude-3-5", "claude-3-7",      # Anthropic 3.x 系全系多模态
    "claude-opus-4", "claude-sonnet-4", "claude-haiku-4",
    "qwen-vl", "qwen2-vl", "qwen2.5-vl",         # 阿里
    "qwen3-vl",
    "glm-4v", "glm-4.5v",                        # 智谱
    "yi-vl",                                     # 零一万物
    "internvl", "minicpm-v",                     # 开源系
    "step-1v",
    "doubao",                                    # 字节豆包 全系多模态(识图 + 原生音频)
)


def _is_gemini_named_native_vision_model(model: str, protocol: str) -> bool:
    """OpenAI/Gemini 协议中，模型 ID 任意位置含 gemini 即支持原生识图。"""
    normalized_model = str(model or "").strip().lower()
    normalized_protocol = str(protocol or "openai").strip().lower()
    return (
        normalized_protocol in {"openai", "gemini"}
        and "gemini" in normalized_model
    )


def _model_supports_vision_by_prefix(model: str, protocol: str = "openai") -> bool:
    """
    模型名前缀白名单兜底:DB tags 字段为空(老库未跑 v8 迁移)时使用。
    Gemini 家族不再要求模型 ID 以 gemini 开头：OpenAI/Gemini 协议只要
    ID 任意位置含 gemini 就放行。其它旧模型仍按原前缀兜底。
    """
    if not model:
        return False
    m = model.strip().lower()
    return (
        _is_gemini_named_native_vision_model(m, protocol)
        or any(m.startswith(p) for p in _VISION_MODEL_PREFIXES)
    )


# ── 原生音频模型前缀白名单(2026-06-14) ───────────────────────────────────────
# 收到语音时, 若主模型属于本表前缀, 不再走外部 STT(main.transcribe_audio_auto),
# 而是把原始音频以 OpenAI 多模态 input_audio(base64) 形式直接塞进
# /chat/completions 请求, 由模型原生理解音频。
# 目前确认支持的是字节豆包(doubao-*)系。新模型优先在 admin 给模型勾选 'audio'
# 标签(DB tags 含 audio 即可放行), 本前缀表仅作 tags 缺失时的兜底。
_AUDIO_MODEL_PREFIXES = (
    "doubao",                                    # 字节豆包 全系支持原生音频输入
)
def _model_supports_audio_by_prefix(model: str) -> bool:
    """
    模型名前缀白名单兜底:DB tags 不含 'audio' 时, 用前缀判定是否支持原生音频。
    匹配大小写不敏感, 只看是否以白名单中任一项开头。
    """
    if not model:
        return False
    m = model.strip().lower()
    return any(m.startswith(p) for p in _AUDIO_MODEL_PREFIXES)


# ── 时间戳辅助 ────────────────────────────────────────────────────────────────
def _make_msg(
    role: str,
    content: str,
    reasoning: str | None = None,
    tool_calls: list | None = None,
    *,
    message_id: str | None = None,
    tool_executions: list | None = None,
) -> dict:
    """
    v12.10 (2026-05-12) 重新启用 history 时间戳存储:
      每条 history 条目都存 ts (unix 时间戳整数)。喂给 LLM 时是否注入
      [北京时间 ...] 前缀由 time_aware 开关决定(见 _flatten_for_llm)。

    设计意图:
      - DB 层永远保留时间戳(关掉 time_aware 不会丢历史时间信息)
      - LLM 视角:time_aware=1 时看到时间前缀,=0 时只看到正文
      - 用户随时切换开关,无需重建 history

    reasoning:仅 assistant 角色使用,记录本轮思维链文本。
    用于下一轮被动回复时作为"上一轮我想了什么"的上下文注入(主动消息不注入)。

    工具执行信息不混入 content，避免发送层把内部记录发给用户。它存入同一条
    assistant 的 tool_executions 隐藏字段，仅由 _flatten_for_llm 在下一轮请求
    中临时渲染到该条 assistant.content 末尾。
    """
    msg = {"role": role, "content": content, "ts": int(time.time())}
    if reasoning and isinstance(reasoning, str) and reasoning.strip():
        msg["reasoning"] = reasoning.strip()
    if message_id:
        msg["message_id"] = str(message_id)
    if tool_executions:
        msg["tool_executions"] = copy.deepcopy(tool_executions)
    # 原生 tool_calls 仍不跨轮持久化；只保存协议无关的执行摘要。
    _ = tool_calls
    return msg


def _compact_tool_value(value, limit: int) -> str:
    if isinstance(value, str):
        text = value
    else:
        try:
            text = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
        except Exception:
            text = str(value)
    # 不允许数据本身闭合隐藏块，也不保留会诱发格式模仿的换行。
    text = re.sub(r"\s+", " ", text).strip().replace("【", "(").replace("】", ")")
    return text if len(text) <= limit else text[:limit] + "…"


def _new_tool_execution(
    name: str,
    params: dict,
    *,
    status: str = "pending",
    success: bool | None = None,
    result: str = "",
) -> dict:
    execution = {
        "execution_id": uuid.uuid4().hex,
        "name": str(name or "unknown")[:100],
        "params": copy.deepcopy(params) if isinstance(params, dict) else {},
        "status": str(status or "pending"),
        "result": str(result or "")[:1000],
        "created_at": int(time.time()),
    }
    if success is not None:
        execution["success"] = bool(success)
    return execution


def _render_tool_execution_history(executions: list) -> str:
    """Render system-owned, read-only history into an assistant request message."""
    blocks = []
    for execution in executions or []:
        if not isinstance(execution, dict):
            continue
        name = _compact_tool_value(execution.get("name") or "unknown", 100)
        request_text = _compact_tool_value(execution.get("params") or {}, 500)
        status = str(execution.get("status") or "pending")
        if status == "pending":
            created_at = int(execution.get("created_at") or 0)
            if created_at and int(time.time()) - created_at <= 300:
                result_text = "正在后台执行，结果尚未返回"
            else:
                result_text = "结果未回写，执行状态未知"
        else:
            raw_result = execution.get("result") or (
                "执行成功" if execution.get("success") is not False else "执行失败"
            )
            result_text = _compact_tool_value(raw_result, 1000)
        blocks.append(
            f"【工具执行：你在发送这条消息时调用 {name}、获取 {request_text}，"
            f"{name} 返回了 {result_text}】"
        )
    return "\n".join(blocks)


def _flatten_for_llm(msg: dict, time_aware: bool = False) -> dict:
    """
    把 history 里的一条真实发言拍平成 OpenAI messages 格式。

    2026-08-05 历史压缩规则:
      - 历史只回放 content（用户原话 / assistant 实际回复）。
      - 旧数据库中的 llm_content 是过去持久化的整轮动态提示，只为兼容旧数据
        保留在库中，永远不再送给模型。
      - 每轮的模式、RAG、时间、心潮和临时背景只存在于当前最后一条 user，
        不进入后续历史，避免输入 token 随轮数重复膨胀。
      - 历史也不再逐条添加时间前缀，确保请求里回放的就是纯发言。

    time_aware 参数继续保留以兼容调用方；当前时间仍会在本轮动态区提供。

    原生 tool_calls 不跨轮回放，因为严格端点要求紧邻对应 role:tool 消息。
    跨轮工具事实改用所属 assistant 的 tool_executions 隐藏字段，并在这里
    渲染为只读历史注记，不伪造协议字段。
    """
    role = msg.get("role", "user")
    content = msg.get("content", "") or ""
    if role == "assistant" and msg.get("tool_executions"):
        hidden_history = _render_tool_execution_history(msg.get("tool_executions") or [])
        if hidden_history:
            content = f"{content}\n{hidden_history}" if content else hidden_history
    # 兼容旧调用签名，但历史回放不再添加任何非发言文本。
    _ = time_aware
    # 注意:不输出 tool_calls(见上方注释)
    return {"role": role, "content": content}


def _recent_context_for_tool(history: list, limit: int = 20) -> list[dict]:
    """为需要语境的工具提供最近真实对话，不带系统动态块或工具注记。"""
    try:
        safe_limit = max(1, min(100, int(limit)))
    except (TypeError, ValueError):
        safe_limit = 20
    items = []
    for message in history or []:
        if not isinstance(message, dict) or message.get("llm_only"):
            continue
        role = str(message.get("role") or "").strip().lower()
        content = message.get("content")
        if role not in {"user", "assistant"} or not isinstance(content, str):
            continue
        content = content.strip()
        if content:
            items.append({"role": role, "content": content})
    return items[-safe_limit:]


def _without_legacy_operation_records(history: list) -> list:
    """移除旧版独立 system 操作摘要，其它历史原样保留。"""
    return [
        message for message in history or []
        if not (
            isinstance(message, dict)
            and message.get("role") == "system"
            and str(message.get("content") or "").lstrip().startswith("[操作记录")
        )
    ]


REQUEST_FAILED_REPLY = "消息未发出，请查看日志"

# 所有会话统一使用 60 轮上下文（1 轮约等于 user + assistant 两条消息）。
# 这是服务端固定策略，不再读取 instances.context_turns，避免不同实例因历史
# 数据或控制台配置产生不一致的上下文窗口。
UNIFIED_CONTEXT_TURNS  = 60

# ─────────────────────────────────────────────────────────────────────────────
# 错误日志脱敏(v?? · 2026-05-30)
#   把待打印文本里的上游站点信息(完整 URL / 域名 / IP[:端口])替换成占位符。
#   仅作用于"错误日志打印",绝不改动任何实际请求体或响应数据。
#   目的:排查 4xx/5xx 报错只需要看错误内容本身,日志里不该出现走的是哪个站点。
#   顶级域用白名单,避免把 JSON 字段路径(如 messages.0.content)误当域名抹掉。
# ─────────────────────────────────────────────────────────────────────────────
_SCRUB_URL_RE  = re.compile(r'https?://[^\s"\'<>)\]}]+', re.IGNORECASE)
_SCRUB_IP_RE   = re.compile(r'(?<![\w.])\d{1,3}(?:\.\d{1,3}){3}(?::\d{2,5})?(?![\w.])')
_SCRUB_HOST_RE = re.compile(
    r'(?<![\w.])'                                    # 左边界:前面不是字母数字或点
    r'(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+'   # 一段或多段子域 "label."
    r'(?:com|cn|net|org|io|ai|dev|app|cloud|co)'     # 受控顶级域白名单
    r'(?::\d{2,5})?'                                 # 可选端口
    r'(?![\w])',                                     # 右边界:后面不是字母数字
    re.IGNORECASE,
)


def _scrub_site_info(text: str) -> str:
    """删除文本中的 URL / 域名 / IP[:端口],返回脱敏后的字符串(空输入安全)。"""
    if not text:
        return ""
    text = _SCRUB_URL_RE.sub("[url]", text)
    text = _SCRUB_IP_RE.sub("[ip]", text)
    text = _SCRUB_HOST_RE.sub("[host]", text)
    return text


def _short_response_log(status_code: int, body: str) -> str:
    """生成用户可见的短响应日志，避免泄露/刷屏思维签名和大段响应体。"""
    if 200 <= int(status_code or 0) < 300:
        return "已收到模型响应"

    cleaned = _scrub_site_info(body or "").strip()
    try:
        parsed = json.loads(cleaned)
        if isinstance(parsed, dict):
            error = parsed.get("error")
            if isinstance(error, dict):
                cleaned = str(error.get("message") or error.get("code") or "请求失败")
            elif parsed.get("message"):
                cleaned = str(parsed.get("message"))
    except Exception:
        pass
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    if not cleaned:
        return "请求失败，响应为空"
    return cleaned[:300] + ("…" if len(cleaned) > 300 else "")


_ERROR_SECRET_PATTERNS = (
    re.compile(r"(?i)(authorization\s*[:=]\s*bearer\s+)[^\s,;\"'}]+"),
    re.compile(r"(?i)([?&](?:key|api_key|token)=)[^&#\s]+"),
    re.compile(r"(?i)\bsk-[a-z0-9_-]{8,}\b"),
)


def _redact_upstream_error_text(text: str, request_headers: dict | None = None) -> str:
    """仅为错误日志脱敏；保留上游原始错误结构，不改动实际响应。"""
    value = str(text or "")
    for raw in (request_headers or {}).values():
        secret = str(raw or "").strip()
        if secret.lower().startswith("bearer "):
            secret = secret[7:].strip()
        if len(secret) >= 8:
            value = value.replace(secret, "<redacted-key>")
    value = _ERROR_SECRET_PATTERNS[0].sub(r"\1<redacted-key>", value)
    value = _ERROR_SECRET_PATTERNS[1].sub(r"\1<redacted-key>", value)
    value = _ERROR_SECRET_PATTERNS[2].sub("sk-<redacted>", value)
    return value


def _safe_upstream_endpoint(endpoint: str) -> str:
    """保留请求来源 host/path，删除可能含密钥的 query/fragment。"""
    value = str(endpoint or "").strip()
    return value.split("?", 1)[0].split("#", 1)[0]


def _clean_outgoing_model_text(text: str) -> str:
    """移除模型正文中禁止发送给用户的异常 ASCII 符号。"""
    return str(text or "").replace("/", "")


def _request_key_fingerprint(headers: dict | None) -> str:
    """返回不可逆短指纹，帮助确认运行时到底选中了哪一条 Key。"""
    headers = headers or {}
    candidate = ""
    for name in ("Authorization", "authorization", "x-goog-api-key", "x-api-key"):
        if headers.get(name):
            candidate = str(headers[name]).strip()
            break
    if candidate.lower().startswith("bearer "):
        candidate = candidate[7:].strip()
    if not candidate:
        return "none"
    return hashlib.sha256(candidate.encode("utf-8", errors="ignore")).hexdigest()[:12]


def _upstream_error_record(
    resp: httpx.Response,
    *,
    endpoint: str,
    protocol: str,
    request_headers: dict,
    attempt: int,
    diagnostic_meta: dict | None = None,
    payload: dict | None = None,
) -> str:
    """生成可直接写入运行日志的上游错误源响应；响应体最多保留 12KB。"""
    meta = diagnostic_meta or {}
    safe_headers = {}
    for name in (
        "content-type", "server", "x-request-id", "request-id",
        "retry-after", "x-ratelimit-remaining", "cf-ray", "via",
    ):
        if resp.headers.get(name):
            safe_headers[name] = resp.headers.get(name)
    raw_body = _redact_upstream_error_text(resp.text or "", request_headers)
    if len(raw_body) > 12000:
        raw_body = raw_body[:12000] + f"…<截断 {len(raw_body) - 12000} 字符>"
    record = {
        "status": int(resp.status_code),
        "protocol": str(protocol or "openai"),
        "model": str(meta.get("model") or ""),
        "endpoint": _safe_upstream_endpoint(endpoint),
        "key_source": str(meta.get("key_source") or "unknown"),
        "key_fingerprint": _request_key_fingerprint(request_headers),
        "attempt": int(attempt),
        "request_shape": _request_shape(payload),
        "response_headers": safe_headers,
        "response_body": raw_body,
    }
    return json.dumps(record, ensure_ascii=False, separators=(",", ":"))


def _timeout_config_snapshot(client) -> dict:
    """读取 httpx 客户端四阶段超时，字段不存在时也不影响错误处理。"""
    timeout = getattr(client, "timeout", None)
    result = {}
    for name in ("connect", "read", "write", "pool"):
        value = getattr(timeout, name, None)
        if value is not None:
            try:
                result[name] = float(value)
            except (TypeError, ValueError):
                result[name] = str(value)
    return result


def _request_shape(payload) -> dict:
    """只统计请求结构和内嵌媒体大小，不记录任何提示词正文。"""
    if not isinstance(payload, dict):
        return {"type": type(payload).__name__}
    media_count = 0
    media_chars = 0
    text_chars = 0
    text_parts = 0
    parts_count = 0
    role_counts: dict[str, int] = {}
    visited = 0
    stack = [payload]
    while stack and visited < 50000:
        item = stack.pop()
        visited += 1
        if isinstance(item, dict):
            role = item.get("role")
            if isinstance(role, str):
                role_counts[role] = role_counts.get(role, 0) + 1
            parts = item.get("parts")
            if isinstance(parts, list):
                parts_count += len(parts)
            text_value = item.get("text")
            if isinstance(text_value, str):
                text_parts += 1
                text_chars += len(text_value)
            inline = item.get("inlineData") or item.get("inline_data")
            if isinstance(inline, dict):
                data = inline.get("data")
                if isinstance(data, str):
                    media_count += 1
                    media_chars += len(data)
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)
        elif isinstance(item, str) and item.startswith("data:"):
            media_count += 1
            media_chars += len(item)
    return {
        "keys": sorted(str(key) for key in payload.keys()),
        "messages": len(payload.get("messages") or [])
        if isinstance(payload.get("messages"), list) else 0,
        "contents": len(payload.get("contents") or [])
        if isinstance(payload.get("contents"), list) else 0,
        "inline_media_count": media_count,
        "inline_media_chars": media_chars,
        "roles": role_counts,
        "parts": parts_count,
        "text_parts": text_parts,
        "text_chars": text_chars,
        "generation_config": payload.get("generationConfig")
        if isinstance(payload.get("generationConfig"), dict) else None,
        "scan_truncated": bool(stack),
    }


def _network_error_record(
    exc, *, client, endpoint, protocol, diagnostic_meta, elapsed, attempt, payload
) -> dict:
    """生成不含密钥和正文的网络异常诊断。"""
    meta = diagnostic_meta or {}
    timeout_phase = {
        "ConnectTimeout": "connect",
        "ReadTimeout": "read",
        "WriteTimeout": "write",
        "PoolTimeout": "pool",
    }.get(type(exc).__name__, "network")
    cause = getattr(exc, "__cause__", None)
    context = getattr(exc, "__context__", None)
    return {
        "exception_type": type(exc).__name__,
        "exception_repr": repr(exc),
        "response_received": False,
        "response_status": None,
        "response_body": None,
        "response_note": "请求在收到 HTTP 响应前失败，因此没有上游响应体",
        "timeout_phase": timeout_phase,
        "elapsed_seconds": round(float(elapsed), 3),
        "timeout_config": _timeout_config_snapshot(client),
        "protocol": str(protocol or "openai"),
        "model": str(meta.get("model") or ""),
        "endpoint": _safe_upstream_endpoint(endpoint),
        "attempt": int(attempt),
        "request_shape": _request_shape(payload),
        "cause": repr(cause) if cause is not None else None,
        "context": repr(context) if context is not None and context is not cause else None,
    }


async def _call_llm_with_format_retry(
    llm_client, endpoint, payload, headers, pool, db_id, loop_label,
    protocol: str = "openai",
    diagnostic_meta: dict | None = None,
    allow_format_retry: bool = True,
) -> dict | None:
    """请求模型；超时最多请求 3 次，格式无效仍只纠正一次。

    HTTP 非成功状态、上游显式 error、非超时网络异常和本地请求异常都不重试。
    函数始终把三种原生协议整理为 OpenAI choices 结构供业务层读取。
    """
    format_retry_used = False

    async def _format_invalid(attempt: int, reason: str) -> bool:
        nonlocal format_retry_used
        if (
            allow_format_retry
            and not format_retry_used
            and attempt < LLM_TIMEOUT_MAX_ATTEMPTS
        ):
            format_retry_used = True
            await utils.add_temp_log(
                pool, db_id,
                f"[{loop_label}] 响应格式无效：{reason[:120]}，重新生成 (1/1)"
            )
            return True
        await utils.add_temp_log(
            pool, db_id,
            f"[{loop_label}] 连续两次响应格式无效，停止：{reason[:120]}"
        )
        return False

    for attempt in range(1, LLM_TIMEOUT_MAX_ATTEMPTS + 1):
        request_started = time.monotonic()
        try:
            if protocol == "gemini":
                _runtime_stage(
                    "gemini_queue",
                    f"{loop_label} · 等待 Gemini 出网槽位",
                )
            else:
                _runtime_stage(
                    "llm_request",
                    f"{loop_label} · 正在连接 {protocol} 上游",
                )
            async with _gemini_request_slot(pool, db_id, protocol):
                # 排队时间不计入 HTTP connect/read/write 超时。
                _runtime_stage(
                    "llm_request",
                    f"{loop_label} · 已发送请求，等待 {protocol} 响应",
                )
                request_started = time.monotonic()
                resp = await asyncio.wait_for(
                    llm_client.post(endpoint, json=payload, headers=headers),
                    timeout=LLM_RESPONSE_TIMEOUT_SECONDS,
                )
        except (asyncio.TimeoutError, httpx.TimeoutException) as exc:
            elapsed = time.monotonic() - request_started
            detail = _network_error_record(
                exc,
                client=llm_client,
                endpoint=endpoint,
                protocol=protocol,
                diagnostic_meta=diagnostic_meta,
                elapsed=elapsed,
                attempt=attempt,
                payload=payload,
            )
            detail["timeout_phase"] = "response_deadline"
            detail["response_deadline_seconds"] = LLM_RESPONSE_TIMEOUT_SECONDS
            reason = (
                f"超过 {LLM_RESPONSE_TIMEOUT_SECONDS:g} 秒未拿到完整模型响应"
            )
            will_retry = attempt < LLM_TIMEOUT_MAX_ATTEMPTS
            await utils.add_temp_log(
                pool, db_id,
                f"[{loop_label}] {reason}；实际耗时 {elapsed:.1f}s，"
                f"模型={detail['model'] or '<unknown>'}，协议={detail['protocol']}，"
                f"端点={detail['endpoint']}，"
                + (
                    f"重新请求 ({attempt + 1}/{LLM_TIMEOUT_MAX_ATTEMPTS})"
                    if will_retry else "已达到 3 次上限，停止请求"
                )
            )
            await utils.add_temp_log(
                pool, db_id,
                "[网络异常·诊断] "
                + json.dumps(detail, ensure_ascii=False, separators=(",", ":"))
            )
            print(
                f"[{time.strftime('%H:%M:%S')}][LLM-NETWORK-ERROR] "
                f"db_id={db_id} loop={loop_label} "
                f"{json.dumps(detail, ensure_ascii=False, separators=(',', ':'))}",
                flush=True,
            )
            if will_retry:
                _runtime_stage(
                    "llm_timeout_retry",
                    f"{loop_label} · 第{attempt}次超时，准备第{attempt + 1}次请求",
                )
                continue
            return None
        except (httpx.ConnectError, httpx.ReadError,
                httpx.RemoteProtocolError) as exc:
            elapsed = time.monotonic() - request_started
            detail = _network_error_record(
                exc,
                client=llm_client,
                endpoint=endpoint,
                protocol=protocol,
                diagnostic_meta=diagnostic_meta,
                elapsed=elapsed,
                attempt=attempt,
                payload=payload,
            )
            await utils.add_temp_log(
                pool, db_id,
                f"[{loop_label}] 网络异常 {type(exc).__name__}；实际耗时 "
                f"{elapsed:.1f}s，未收到 HTTP 响应，不再重试"
            )
            await utils.add_temp_log(
                pool, db_id,
                "[网络异常·诊断] "
                + json.dumps(detail, ensure_ascii=False, separators=(",", ":"))
            )
            print(
                f"[{time.strftime('%H:%M:%S')}][LLM-NETWORK-ERROR] "
                f"db_id={db_id} loop={loop_label} "
                f"{json.dumps(detail, ensure_ascii=False, separators=(',', ':'))}",
                flush=True,
            )
            return None
        except Exception as exc:
            await utils.add_temp_log(
                pool, db_id,
                f"[{loop_label}] 请求异常 {type(exc).__name__}: {str(exc)[:80]}，不再重试"
            )
            print(
                f"[{time.strftime('%H:%M:%S')}][LLM-REQUEST-ERROR] "
                f"db_id={db_id} loop={loop_label} {type(exc).__name__}: {exc}",
                flush=True,
            )
            return None

        await utils.add_temp_log(
            pool, db_id,
            f"[模型响应] status={resp.status_code} "
            f"{_short_response_log(resp.status_code, resp.text or '')}"
        )
        _runtime_stage(
            "llm_response_parse",
            f"{loop_label} · HTTP {resp.status_code}，正在解析响应",
        )

        if not 200 <= resp.status_code < 300:
            raw_error = _upstream_error_record(
                resp,
                endpoint=endpoint,
                protocol=protocol,
                request_headers=headers,
                attempt=attempt,
                diagnostic_meta=diagnostic_meta,
                payload=payload,
            )
            await utils.add_temp_log(pool, db_id, f"[上游错误·源响应] {raw_error}")
            await utils.add_temp_log(
                pool, db_id,
                f"[{loop_label}] HTTP {resp.status_code}，不再重试"
            )
            print(
                f"[{time.strftime('%H:%M:%S')}][LLM-UPSTREAM-ERROR] "
                f"db_id={db_id} loop={loop_label} {raw_error}",
                flush=True,
            )
            return None

        try:
            resp_json = resp.json()
        except Exception as exc:
            malformed = _redact_upstream_error_text(resp.text or "", headers)
            await utils.add_temp_log(
                pool, db_id,
                f"[上游错误·源响应] status={resp.status_code} "
                f"endpoint={_safe_upstream_endpoint(endpoint)} body={malformed[:12000]}"
            )
            if await _format_invalid(attempt, f"响应不是合法 JSON: {exc}"):
                _runtime_stage(
                    "llm_format_retry", f"{loop_label} · 非法 JSON，重新生成"
                )
                continue
            return None

        # 有些中转会用 HTTP 200 包装上游错误。它仍是明确错误响应，不属于
        # “格式无效”，因此不能消耗格式重生额度或再次请求。
        if isinstance(resp_json, dict) and isinstance(resp_json.get("error"), dict):
            err_info = resp_json.get("error") or {}
            message = _scrub_site_info(
                str(err_info.get("message") or err_info.get("code") or "上游请求失败")
            )
            raw_error = _upstream_error_record(
                resp,
                endpoint=endpoint,
                protocol=protocol,
                request_headers=headers,
                attempt=attempt,
                diagnostic_meta=diagnostic_meta,
                payload=payload,
            )
            await utils.add_temp_log(
                pool, db_id, f"[上游错误·源响应] {raw_error}"
            )
            print(
                f"[{time.strftime('%H:%M:%S')}][LLM-UPSTREAM-ERROR] "
                f"db_id={db_id} loop={loop_label} {raw_error}",
                flush=True,
            )
            await utils.add_temp_log(
                pool, db_id,
                f"[{loop_label}] 上游错误 {message[:200]}，不再重试"
            )
            return None

        if protocol == "anthropic":
            if isinstance(resp_json, dict) and resp_json.get("type") == "error":
                err_info = resp_json.get("error") or {}
                message = _scrub_site_info(
                    f"{err_info.get('type', '?')}: {err_info.get('message', '?')}"
                )
                await utils.add_temp_log(
                    pool, db_id, f"[{loop_label}] 上游错误 {message[:200]}，不再重试"
                )
                return None
            try:
                resp_json = proto_anthropic.parse_response(resp_json)
            except Exception as exc:
                if await _format_invalid(attempt, f"Anthropic 响应解析失败: {exc}"):
                    _runtime_stage(
                        "llm_format_retry",
                        f"{loop_label} · Anthropic 响应格式无效，重新生成",
                    )
                    continue
                return None

        elif protocol == "gemini":
            try:
                resp_json = proto_gemini.parse_response(resp_json)
            except Exception as exc:
                if await _format_invalid(attempt, f"Gemini 响应解析失败: {exc}"):
                    _runtime_stage(
                        "llm_format_retry",
                        f"{loop_label} · Gemini 响应格式无效，重新生成",
                    )
                    continue
                return None

        if not isinstance(resp_json, dict) or not resp_json.get("choices"):
            if await _format_invalid(attempt, "响应缺少 choices"):
                _runtime_stage(
                    "llm_format_retry", f"{loop_label} · 响应缺少正文，重新生成"
                )
                continue
            return None

        # 业务层继续校验 reply JSON；标记本函数是否已经消耗唯一一次格式重生。
        resp_json["_format_retry_used"] = format_retry_used
        return resp_json

    return None
# =============================================================================
# 被动 RAG · 每轮请求自动检索相关记忆并注入 user_prompt（v2 · 2026-05-07）
# =============================================================================
# 设计目标：
#   不依赖 LLM 主动调用 search_memory 工具，每条用户消息都【强制】检索一次，
#   把相关记忆放进最后一条 user 的动态区，让 LLM 被动看到。search_memory 工具
#   保留作为"指向性深挖"的备用通道（双轨制）。
#
# 【v2 改动】:
#   - 检索池只用 summary(AI 主动总结的"用户....."事实陈述),不再查 turn 池
#   - turn 池数据仍由 _embed_and_save_turn 持续写入,但只作为 _summarize_and_embed
#     的原料,不直接参与检索。这样可避免"今天天气不错"这种闲聊噪声污染 prompt
#
# 流程：
#   1. Query Expansion：用【轻量快速模型】(qe_model)把用户原句改写出 3-4 个
#      相关查询,覆盖明示意图/隐含偏好/相关习惯/扩展话题。失败→只用原句。
#   2. 并行 embedding：所有查询同时向量化。
#   3. 拉 summary 池打分：余弦 + 时间衰减(近 7 天 ×1.2,半年外 ×0.8) + 阈值过滤。
#   4. 候选池：summary 余弦 top-N。
#   5. Rerank：把候选池交给 rerank 模型精排,取 top-K。失败 → 余弦兜底。
#   6. 任一阶段全失败 → 返回空字符串,主流程不感知,不抛异常。
# =============================================================================

# 候选池广度
_RAG_SUMMARY_POOL_SIZE  = 30   # summary 池余弦 top-N(原 turn+summary 现在合并到这一池)
_RAG_FINAL_TOP_K        = 8    # rerank 后保留 top-K
_RAG_MIN_COSINE         = 0.25 # 余弦阈值（带时间衰减后）
_RAG_MIN_RERANK_SCORE   = 0.1  # rerank 相关性阈值
_RAG_QE_TIMEOUT         = 15.0  # Query Expansion 超时（秒）。超时直接降级到原句单查询,不会再让 QE 拖慢整轮

# QE 计费价格(¥/1M token)·硬编码
# 嵌入与重排序由系统补贴,只对 QE 这一次主模型调用按下面的单价计费,
# 直接从 users.balance 扣(无视当前 bucket;即使 pack/weekly 桶用户也要付,
# 因为这是【实验性功能】的额外开销,不应被订阅包覆盖)。余额不足不阻塞流水线,
# 仅写一条警告日志,系统补贴本次。
_RAG_QE_INPUT_PRICE     = 3  # ¥ / 1M prompt tokens
_RAG_QE_OUTPUT_PRICE    = 5  # ¥ / 1M completion tokens


# 被动 RAG · 余弦相似度 + 时间衰减(已恢复)
def _cosine_sim(v1, v2) -> float:
    """两向量余弦相似度。任一为空 → 0.0。"""
    if not v1 or not v2:
        return 0.0
    dot = sum(a * b for a, b in zip(v1, v2))
    n1  = math.sqrt(sum(a * a for a in v1))
    n2  = math.sqrt(sum(b * b for b in v2))
    return dot / (n1 * n2) if n1 and n2 else 0.0


def _time_decay_weight(created_at) -> float:
    """近期记忆加权,远期降权。近 7 天 ×1.2,半年外 ×0.8,中间线性插值。"""
    if not created_at:
        return 1.0
    days = max(0, (int(time.time()) - int(created_at)) / 86400)
    if days <= 7:
        return 1.2
    if days >= 180:
        return 0.8
    # ⚠️ v?? (2026-05-30) 修复: 此行曾被注释掉, 导致 7<days<180 的记忆
    #    (即绝大多数历史记忆) 落空所有分支隐式返回 None,
    #    在调用处 best * _time_decay_weight(...) 触发
    #    "unsupported operand type(s) for *: 'float' and 'NoneType'"。
    #    恢复为线性插值: days=7→1.2, days=180→0.8, 两端连续。
    return 1.2 - (days - 7) / (180 - 7) * 0.4


# _rag_embed_one:单查询向量化,供 RAG 检索与归档共用
async def _rag_embed_one(client: httpx.AsyncClient, text: str,
                         emb_url: str, emb_key: str, emb_model: str):
    """单查询向量化。失败返回 None,不抛异常(让 gather 不被一次失败带崩)。"""
    try:
        resp = await client.post(
            emb_url,
            json={"model": emb_model, "input": text},
            headers={"Authorization": f"Bearer {emb_key}"},
            timeout=15.0,
        )
        resp.raise_for_status()
        return resp.json()["data"][0]["embedding"]
    except Exception:
        return None


async def _rag_query_expansion(pool, client: httpx.AsyncClient, db_id: int,
                               user_text: str, history: list,
                               qe_endpoint: str, qe_api_key: str, qe_model: str,
                               persona_text: str = "",
                               timeout: float = 8.0):
    """
    用【轻量快速模型】把用户当前发言改写成 3-4 个不同角度的【AI 视角】检索查询。
    返回 (queries: list, used_model: str, in_tokens: int, out_tokens: int)。
    失败 → ([原句], qe_model + "(失败)", 0, 0)。

    【关键点 · v2 改造】检索的是【AI 总结的"用户....."事实记忆】,所以查询
    必须以"AI 应该回忆什么"为视角。例如:
        角色:夏以昼  当前发言:"晚安"
        ✗ 错误的查询(用户视角):  晚安前用户说什么 / 用户睡前习惯
        ✓ 正确的查询(AI 视角):   夏以昼通常如何回应晚安 / 夏以昼睡前给用户做什么 /
                                 用户希望听到怎样的晚安

    QE 任务非常简单(只输出几个短查询),不需要主模型那种推理能力,所以
    这里强制把 qe_endpoint/qe_api_key/qe_model 作为独立参数传入。调用方
    应当从 system_config 读取 qe_*,如果没配置 → 回退到主模型(慢但能用)。

    返回值带回 token 用量供调用方按硬编码价格(_RAG_QE_INPUT_PRICE /
    _RAG_QE_OUTPUT_PRICE)单独计费。
    """
    # 取最近 3 条用户消息(不含本轮)作为上下文
    recent = []
    for msg in reversed(history[:-1] if history else []):
        if msg.get("role") == "user":
            c = msg.get("content", "")
            if isinstance(c, str) and c.strip():
                recent.append(c.strip())
                if len(recent) >= 3:
                    break
    recent.reverse()
    ctx_block = "\n".join(f"- {t}" for t in recent) if recent else "(无)"

    # 从 persona_text 抠出角色名:取第一行去掉常见标点开头,作为角色代称
    # persona_text 可能空,退化成"AI"
    role_name = ""
    if persona_text:
        first_line = persona_text.strip().splitlines()[0] if persona_text.strip() else ""
        # 简单清洗:去掉前后引号、冒号、"你是""我是""你叫"等开头
        cleaned = re.sub(r"^[\s\"'「『:`#*\-]+", "", first_line)
        cleaned = re.sub(r"^(你是|你叫|我是|我叫|名字是|角色名:?)\s*", "", cleaned)
        role_name = cleaned[:20].strip()
    if not role_name:
        role_name = "AI"

    # AI 视角 QE prompt:目标是让查询更贴近"AI 总结的用户事实"的语义
    qe_prompt = (
        f"你是检索查询改写器。我们的长期记忆库里存的是【AI 已总结好的、关于用户的"
        f"带情境的事实】,每条形如「用户喜欢…,因为…」「用户最近在…,当时心情…」,"
        f"不是聊天原文。\n\n"
        f"现在 AI 扮演的角色是【{role_name}】。请站在"
        f"「{role_name} 要把这句话回好、回得贴心,需要想起用户的哪些事」的角度,"
        f"生成 3-4 个检索短查询,每个 5-15 字。角度尽量铺开:"
        f"明面意图 / TA 可能的情绪和近况 / 相关的习惯偏好 / 关联话题。\n\n"
        f"最近上下文:\n{ctx_block}\n\n"
        f"用户当前发言:{user_text}\n\n"
        f"角度示例(以「晚安」为例):\n"
        f'  ["用户睡前的习惯","用户最近的烦心事","用户喜欢被怎么关心"]\n\n'
        f'只输出 JSON 数组,无解释。例:["查询1","查询2","查询3"]'
    )
    qe_payload = {
        "model": qe_model,
        "messages": [{"role": "user", "content": qe_prompt}],
        "temperature": 0.3,
        "max_tokens": 200,
        # 显式禁用思考(QE 是简单查询改写,不需要思考,也避免思考吃满 max_tokens
        # 导致模型没输出正文)。
        # ⚠ 2026-07-08 修复 400 Bad Request(请求体错误):
        #   旧代码用 "enable_thinking": False + "reasoning_effort": "none" 关思考,
        #   但这两个都不是 DeepSeek 的合法参数——
        #     · enable_thinking 是 Qwen/DashScope 系参数,DeepSeek 根本不认;
        #     · DeepSeek 的 reasoning_effort 只接受 "high"/"max","none" 属越界值。
        #   DeepSeek V4(deepseek-v4-flash / deepseek-chat 别名)关思考的正确写法是
        #   顶层字段 "thinking": {"type": "disabled"}。非思考模式下 temperature /
        #   max_tokens 正常生效,200 token 输出一个短 JSON 数组绰绰有余。
        "thinking": {"type": "disabled"},
    }

    try:
        resp = await client.post(
            qe_endpoint,
            json=qe_payload,
            headers={"Authorization": f"Bearer {qe_api_key}",
                     "Content-Type": "application/json"},
            timeout=timeout,
        )

        resp.raise_for_status()
        body = resp.json()
        text = body["choices"][0]["message"]["content"].strip()
        usage = body.get("usage") or {}
        in_tok  = int(usage.get("prompt_tokens",     0) or 0)
        out_tok = int(usage.get("completion_tokens", 0) or 0)
        # 容错:剥掉可能的 ``` 包裹
        if text.startswith("```"):
            text = text.strip("`").strip()
            if text.lower().startswith("json"):
                text = text[4:].strip()
        # 提取 JSON 数组的最长有效片段
        m = re.search(r"\[.*\]", text, re.DOTALL)
        if m:
            text = m.group(0)
        arr = json.loads(text)
        if isinstance(arr, list):
            cleaned = [str(q).strip() for q in arr if str(q).strip()]
            queries = [user_text] + cleaned
            seen, out = set(), []
            for q in queries:
                if q not in seen:
                    seen.add(q)
                    out.append(q)
            return out[:6], qe_model, in_tok, out_tok
    except Exception as _qe_exc:
        # 不再吞异常,也不再 print(那只进 admin 后台 stdout)——写到用户可见的
        # 临时日志,和 [长期记忆·计数] 走同一通道(utils.add_temp_log),
        # 直接在实例日志栏就能看到 QE 为什么失败。
        await utils.add_temp_log(
            pool, db_id,
            f"[搜索记忆·改写关键词] ✗ QE 调用异常 model={qe_model} "
            f"{type(_qe_exc).__name__}: {str(_qe_exc)[:120]}"
        )
    return [user_text], f"{qe_model}(失败)", 0, 0


async def _rag_rerank(client: httpx.AsyncClient, query: str, documents: list,
                      rerank_url: str, rerank_key: str, rerank_model: str,
                      top_n: int):
    """
    精排。失败 → 返回 None(调用方据此降级到余弦)。
    成功 → 返回排序后的 docs 列表(已按 _RAG_MIN_RERANK_SCORE 阈值过滤)。
    """
    if not documents:
        return []
    try:
        resp = await client.post(
            rerank_url,
            json={
                "model": rerank_model,
                "query": query,
                "documents": documents,
                "top_n": min(top_n, len(documents)),
            },
            headers={"Authorization": f"Bearer {rerank_key}"},
            timeout=15.0,
        )
        resp.raise_for_status()
        ranked = sorted(
            resp.json().get("results", []),
            key=lambda x: x.get("relevance_score", 0),
            reverse=True,
        )
        return [
            documents[r["index"]]
            for r in ranked[:top_n]
            if r.get("relevance_score", 0) > _RAG_MIN_RERANK_SCORE
        ]
    except Exception:
        return None


async def _passive_retrieve_memory(pool, db_id: int, user_id: int, user_text: str,
                                   history: list, p_endpoint: str,
                                   p_api_key: str, p_model: str,
                                   persona_text: str = ""):
    """
    被动 RAG 总入口。
    返回 (memory_block: str, hit_count: int)。任何失败 → ("", 0),主流程不感知。

    内部全程通过 utils.add_temp_log 实时打日志,每个流水线节点完成立刻写一条:
      [搜索记忆]         流水线启动 / 完成 / 异常
      [搜索记忆·配置]    system_config 读取
      [搜索记忆·改写关键词]      Query Expansion 改写
      [搜索记忆·向量化]   查询向量化
      [搜索记忆·查库]      记忆库 SQL
      [搜索记忆·打分]   余弦打分阈值统计
      [搜索记忆·候选池]    候选池组装
      [搜索记忆·重排]  精排
      [搜索记忆·已找到]    每条命中记忆的预览
    """
    if not user_text or not user_text.strip():
        return "", 0

    await utils.add_temp_log(pool, db_id, f"[搜索记忆] 启动检索 query=「{user_text[:50]}」")
    t_total = time.monotonic()

    # ── 读 system_config ──────────────────────────────────────────────────
    # 含 6 个 key:embedding_*(3) + qe_*(3)
    # qe_* 是 QE(Query Expansion)的【独立配置】,允许指定一个【轻量快速模型】
    # 专门跑改写任务,避免每轮请求都用主模型(慢、贵)。如果 qe_* 没配置,
    # 自动回退到主模型(向后兼容)。
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT config_key, config_value FROM system_config "
                    "WHERE config_key IN ("
                    "  'embedding_endpoint','embedding_api_key','embedding_model'"
                    ")"
                )
                cfg = {r["config_key"]: r["config_value"] for r in await cur.fetchall()}
    except Exception as e:
        await utils.add_temp_log(pool, db_id, f"[搜索记忆·配置] ✗ 读取 system_config 失败: {str(e)[:60]}")
        return "", 0

    emb_url      = (cfg.get("embedding_endpoint") or "https://api.openlux.ai/v1/embeddings").strip()
    emb_key      = (cfg.get("embedding_api_key")  or "").strip()
    emb_model    = (cfg.get("embedding_model")    or "text-embedding-3-large").strip()
    rerank_url   = emb_url.replace("/embeddings", "/rerank")
    rerank_model = "qwen3-rerank"

    # QE 配置:
    #   - 模型固定 deepseek-v4-flash。DeepSeek V4(2026-04-24 起)默认开启思考,
    #     所以必须在请求体里显式关思考(见 _rag_query_expansion 的 qe_payload:
    #     "thinking": {"type": "disabled"}),否则思考会吃满 200 max_tokens、
    #     不吐正文。⚠ 不要改成 deepseek-chat:该别名 2026-07-24 15:59 UTC 退役,
    #     退役后只剩 deepseek-v4-flash / deepseek-v4-pro。
    #   - endpoint / api_key / model **全部硬编在代码里**,不再读 system_config(DB),
    #     也不再跟随主对话端点(p_endpoint)。改端点直接改下面这行字符串即可。
    #   - qe_using_main 仍保留(给老日志兼容),恒 False(qe_model 不会等于主模型名)
    qe_endpoint   = "https://api.deepseek.com/chat/completions"
    qe_api_key    = ""
    qe_model      = "deepseek-v4-flash"
    qe_using_main = False

    if not emb_key:
        await utils.add_temp_log(pool, db_id, "[搜索记忆·配置] ✗ embedding_api_key 未配置,中止流水线")
        return "", 0
    await utils.add_temp_log(
        pool, db_id,
        f"[搜索记忆·配置] ✓ embedding={emb_model} rerank={rerank_model} qe={qe_model} (硬编端点)"
    )

    try:
        client = get_http_client()
        if True:  # keep indent level
            # ── 1. Query Expansion ──────────────────────────────────────
            t_qe = time.monotonic()
            queries, qe_used_model, qe_in_tok, qe_out_tok = await _rag_query_expansion(
                pool, client, db_id, user_text, history,
                qe_endpoint, qe_api_key, qe_model,
                persona_text=persona_text,
                timeout=_RAG_QE_TIMEOUT,
            )
            qe_elapsed = time.monotonic() - t_qe
            if len(queries) <= 1:
                await utils.add_temp_log(
                    pool, db_id,
                    f"[搜索记忆·改写关键词] ⚠ 改写失败/超时,回退单查询 (model={qe_used_model}, {qe_elapsed:.2f}s)"
                )
            else:
                preview = " | ".join(f"「{q[:18]}」" for q in queries)
                await utils.add_temp_log(
                    pool, db_id,
                    f"[搜索记忆·改写关键词] ✓ {len(queries)} 个查询 (model={qe_used_model}, {qe_elapsed:.2f}s): {preview}"
                )

            # ── 1.5 QE 计费(硬编码 ¥0.2/M·in + ¥1.2/M·out,从 users.balance 扣)
            # 嵌入与重排序系统补贴,只对 QE 这一次主模型调用计费。
            # 余额不足:GREATEST(0, balance - cost) 让余额下钳到 0,不阻塞流水线;
            # 系统补贴本次,但写一条警告日志便于运维侧追溯。
            # 白金会员的全模型权益也覆盖记忆检索的 QE 调用；仍保留检索本身，
            # 但不从余额扣除这段系统辅助请求。
            _qe_platinum = False
            if user_id and (qe_in_tok > 0 or qe_out_tok > 0):
                try:
                    _qe_platinum = await billing._has_active_platinum(pool, user_id)
                except Exception:
                    _qe_platinum = False
            if user_id and (qe_in_tok > 0 or qe_out_tok > 0) and not _qe_platinum:
                qe_cost = (
                    qe_in_tok  * _RAG_QE_INPUT_PRICE  +
                    qe_out_tok * _RAG_QE_OUTPUT_PRICE
                ) / 1_000_000.0
                qe_cost = round(qe_cost, 6)
                try:
                    async with pool.acquire() as conn:
                        async with conn.cursor() as cur:
                            await cur.execute(
                                "SELECT balance FROM users WHERE id=%s",
                                (user_id,),
                            )
                            row = await cur.fetchone()
                            bal_before = float(row["balance"]) if row else 0.0
                            await cur.execute(
                                "UPDATE users SET balance = GREATEST(0, balance - %s) WHERE id=%s",
                                (qe_cost, user_id),
                            )
                        await conn.commit()
                    bal_after = max(0.0, bal_before - qe_cost)
                    if bal_before < qe_cost:
                        await utils.add_temp_log(
                            pool, db_id,
                            f"[搜索记忆·扣费] ⚠ 余额不足({bal_before:.4f}<{qe_cost:.4f}),"
                            f"扣到 0,本次差额由系统补贴。in={qe_in_tok} out={qe_out_tok}"
                        )
                    else:
                        await utils.add_temp_log(
                            pool, db_id,
                            f"[搜索记忆·扣费] ✓ QE 扣费 ¥{qe_cost:.4f} "
                            f"(in={qe_in_tok}×¥{_RAG_QE_INPUT_PRICE}/M + out={qe_out_tok}×¥{_RAG_QE_OUTPUT_PRICE}/M) "
                            f"余额 ¥{bal_before:.4f} → ¥{bal_after:.4f}"
                        )
                except Exception as _bill_e:
                    await utils.add_temp_log(
                        pool, db_id,
                        f"[搜索记忆·扣费] ✗ 扣费 SQL 异常已忽略: {str(_bill_e)[:80]}"
                    )
            elif _qe_platinum and (qe_in_tok > 0 or qe_out_tok > 0):
                await utils.add_temp_log(
                    pool, db_id,
                    f"[白金会员] 记忆检索 QE 不计费 (in={qe_in_tok} out={qe_out_tok})"
                )

            # ── 2. 并行 embedding ───────────────────────────────────────
            t_emb = time.monotonic()
            q_vecs_raw = await asyncio.gather(*[
                _rag_embed_one(client, q, emb_url, emb_key, emb_model)
                for q in queries
            ])
            emb_elapsed = time.monotonic() - t_emb
            q_vecs = [v for v in q_vecs_raw if v]
            await utils.add_temp_log(
                pool, db_id,
                f"[搜索记忆·向量化] {'✓' if q_vecs else '✗'} {len(q_vecs)}/{len(queries)} 查询向量化成功 ({emb_elapsed:.2f}s)"
            )
            if not q_vecs:
                await utils.add_temp_log(pool, db_id, "[搜索记忆·向量化] ✗ 全部失败,中止流水线")
                return "", 0

            # ── 3. 拉记忆(只查 summary 池;turn 池不再参与检索) ──────
            t_db = time.monotonic()
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT content, embedding, created_at "
                        "FROM instance_memories "
                        "WHERE instance_id=%s AND memory_type='summary' "
                        "AND embedding IS NOT NULL",
                        (db_id,),
                    )
                    rows = await cur.fetchall()
            db_elapsed = time.monotonic() - t_db
            await utils.add_temp_log(
                pool, db_id,
                f"[搜索记忆·查库] ✓ summary 库 {len(rows)} 条 ({db_elapsed:.2f}s)"
            )
            if not rows:
                await utils.add_temp_log(
                    pool, db_id,
                    "[搜索记忆·查库] ⓘ summary 库为空(还没攒够 20 轮触发归档,或本实例从未对话过)"
                )
                return "", 0

            # ── 余弦打分 + 时间衰减 + 阈值过滤 ─────────────────────────
            scored = []          # (weighted_score, content)
            best_filtered = 0.0  # 被阈值过滤的最高分(用于调参参考)
            for r in rows:
                emb = r["embedding"]
                if isinstance(emb, str):
                    try:
                        emb = json.loads(emb)
                    except Exception:
                        continue
                if not emb:
                    continue
                content = r.get("content") or ""
                if not content.strip():
                    continue
                # 多查询取最大相似度
                best = max(_cosine_sim(qv, emb) for qv in q_vecs)
                weighted = best * _time_decay_weight(r.get("created_at"))
                if weighted < _RAG_MIN_COSINE:
                    if weighted > best_filtered:
                        best_filtered = weighted
                    continue
                scored.append((weighted, content))

            scored.sort(key=lambda x: x[0], reverse=True)
            top_score = scored[0][0] if scored else 0.0
            await utils.add_temp_log(
                pool, db_id,
                f"[搜索记忆·打分] 阈值={_RAG_MIN_COSINE} 通过 {len(scored)}/{len(rows)} | "
                f"通过最高分={top_score:.3f} | 被过滤最高分={best_filtered:.3f}"
            )

            # ── 4. 候选池:summary 池余弦 top-N ────────────────────────
            seen, candidates = set(), []
            for _s, c in scored[:_RAG_SUMMARY_POOL_SIZE]:
                if c not in seen:
                    seen.add(c)
                    candidates.append(c)
            await utils.add_temp_log(
                pool, db_id,
                f"[搜索记忆·候选池] 候选池 {len(candidates)} 条 "
                f"(summary 余弦 top-{_RAG_SUMMARY_POOL_SIZE},去重后)"
            )
            if not candidates:
                await utils.add_temp_log(
                    pool, db_id,
                    "[搜索记忆·候选池] ✗ 候选池为空(全部被余弦阈值挡掉),中止流水线"
                )
                return "", 0

            # ── 5. Rerank;失败 → 余弦兜底 ─────────────────────────────
            t_rr = time.monotonic()
            top_docs = await _rag_rerank(
                client, user_text, candidates,
                rerank_url, emb_key, rerank_model, _RAG_FINAL_TOP_K,
            )
            rr_elapsed = time.monotonic() - t_rr
            rerank_used = top_docs is not None
            if top_docs is None:
                await utils.add_temp_log(
                    pool, db_id,
                    f"[搜索记忆·重排] ⚠ 不可用,余弦兜底取 top-{_RAG_FINAL_TOP_K} ({rr_elapsed:.2f}s)"
                )
                top_docs, dedup = [], set()
                for _s, c in scored[:_RAG_SUMMARY_POOL_SIZE]:
                    if c not in dedup:
                        dedup.add(c)
                        top_docs.append(c)
                        if len(top_docs) >= _RAG_FINAL_TOP_K:
                            break
            else:
                await utils.add_temp_log(
                    pool, db_id,
                    f"[搜索记忆·重排] ✓ 输入 {len(candidates)} → 输出 {len(top_docs)} "
                    f"(阈值={_RAG_MIN_RERANK_SCORE}, {rr_elapsed:.2f}s)"
                )

            if not top_docs:
                await utils.add_temp_log(pool, db_id, "[搜索记忆·重排] ✗ 精排后无内容,中止流水线")
                return "", 0

            # ── 注入预览(每条记忆的前 60 字),让用户能直观对照 ──────────
            for i, doc in enumerate(top_docs, 1):
                preview = doc[:60].replace("\n", " ")
                trail = "..." if len(doc) > 60 else ""
                await utils.add_temp_log(
                    pool, db_id,
                    f"[搜索记忆·已找到] {i}/{len(top_docs)} → {preview}{trail}"
                )

            block = (
                "【本轮检索到的相关记忆·只属于这一轮的检索结果】"
                "(系统帮你翻出来的记忆。跟这轮话有关"
                "就自然用上，别照念。要像自己想起来的那样带进话里;与本轮会话无关就当没看见。"
                "注意:这些是你记住的旧事实,不是 TA 现在说的话，不允许照搬。)\n"
                + "\n".join(f"- {d}" for d in top_docs)
            )

            total_elapsed = time.monotonic() - t_total
            await utils.add_temp_log(
                pool, db_id,
                f"[搜索记忆] ✓ 完成 注入 {len(top_docs)} 条 | 总耗时 {total_elapsed:.2f}s "
                f"(QE={qe_elapsed:.2f} Embed={emb_elapsed:.2f} DB={db_elapsed:.2f} "
                f"Rerank={rr_elapsed:.2f}{' [兜底]' if not rerank_used else ''})"
            )
            return block, len(top_docs)
    except Exception as e:
        try:
            await utils.add_temp_log(
                pool, db_id,
                f"[搜索记忆] ✗ 流水线异常已忽略: {str(e)[:100]}"
            )
        except Exception:
            pass
        return "", 0


async def _request_memory_summary(
    pool, db_id, endpoint, api_key, model, protocol, messages,
) -> str:
    """用当前模型协议整理记忆；与主聊天共用请求策略和 Gemini 并发闸门。"""
    protocol = (protocol or "openai").strip().lower()
    if protocol == "gemini":
        adapter = proto_gemini
    elif protocol == "anthropic":
        adapter = proto_anthropic
    else:
        adapter = proto_openai

    payload = adapter.build_payload(
        model,
        messages,
        temperature=0.1,
        presence_penalty=0.0,
        tools=None,
        enable_thinking=False,
        supports_thinking=False,
        tool_choice=None,
    )
    headers = (
        adapter.build_headers(api_key)
        if protocol in ("gemini", "anthropic") else
        {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
    )

    limits = httpx.Limits(max_connections=2, max_keepalive_connections=0)
    timeout = httpx.Timeout(
        connect=120.0, read=600.0, write=600.0, pool=120.0
    )
    async with httpx.AsyncClient(timeout=timeout, limits=limits) as client:
        data = await _call_llm_with_format_retry(
            client,
            endpoint,
            payload,
            headers,
            pool,
            db_id,
            "长期记忆·整理",
            protocol=protocol,
            diagnostic_meta={
                "model": model,
                "key_source": "memory_summary",
            },
        )
    if not data:
        return ""
    choices = data.get("choices")
    if not isinstance(choices, list) or not choices:
        return ""
    message = choices[0].get("message") or {}
    content = message.get("content")
    return content.strip() if isinstance(content, str) else ""

async def _summarize_and_embed(
    pool, db_id, persona_id, history, endpoint, p_api_key, model,
    protocol="openai",
):
    """
    长记忆归档:每 20 轮 AI 回复触发一次。

    输出格式约定(已硬编码进 prompt):
      纯文本,每行一条"用户...."的事实陈述,不带任何 markdown 标点。
    每行单独 embedding 后入库为一条 instance_memories(memory_type='summary'),
    与库中已存在的完全相同 content 做简单去重。检索流水线只查 summary 池,
    所以这里入的每一条都是会被检索到的。
    """
    if not history:
        return

    visible_history = [m for m in history if not m.get("llm_only")]
    history_str = "\n".join(
        f"{m['role']}: {m['content']}" for m in visible_history[-20:]
    )
    current_time = utils.get_beijing_time()

    sys_prompt = (
        f"你是这个 AI 角色的「记忆整理师」。当前北京时间:{current_time}。\n"
        "你的工作:从以下聊天记录里,把关于【用户】值得记住的事整理出来——\n"
        "就像一个用心的恋人/好友会默默记在心里的那种:TA 的喜好、习惯、心事、\n"
        "近况、说过的约定、提过的人和事、忌讳和雷点。\n"
        "\n"
        "【什么样的记忆是好记忆】\n"
        "别只记干巴巴的结论,把「情境」一起写进去——什么时候、因为什么、\n"
        "TA 当时什么心情。这些细节将来能让 AI 像真朋友一样把话接回去。\n"
        "  太干:用户喜欢吃草莓蛋糕\n"
        "  更好:用户喜欢吃草莓蛋糕,说小时候过生日妈妈总买,吃到会想家\n"
        "  太干:用户工作忙\n"
        "  更好:用户 2026 年 6 月初在赶项目上线,连着加班到很晚,当时明显很烦躁\n"
        "  太干:用户养猫\n"
        "  更好:用户养了只叫小白的猫,经常拍它的照片分享,提到它语气会变软\n"
        "\n"
        "【输出格式】必须严格遵守:\n"
        "1. 纯文本,一行一条,不使用任何 markdown 标点。禁止出现 - * # ` 这类符号,禁止空行。\n"
        "2. 每行必须以「用户」两字开头,是一句完整的话。可以写长一点(20-60 字),\n"
        "   把场景/原因/当时的情绪带上。\n"
        "3. 含相对时间(今天/昨天/刚才/明天/上周等),必须结合当前北京时间转成绝对日期。\n"
        "   例:用户在 2026 年 5 月 4 日去了上海\n"
        "4. 主语统一写「用户」,不要用「他」「她」「TA」等代词。\n"
        "5. 一次最多输出 8 条,挑信息量最大的;同一件事在多处提到的,合并成一条写全。\n"
        "6. 只记用户的事,不记 AI 自己说了什么。\n"
        "7. 没有任何值得长期保存的内容时,只输出一个字:无\n"
        "8. 不要输出任何解释、标题、引号、JSON,只输出符合上述格式的文本行。\n"
    )
    messages = [
        {"role": "system", "content": sys_prompt},
        {"role": "user",   "content": f"【对话记录】\n{history_str}"},
    ]

    try:
        # ── 读 embedding 配置 ─────────────────────────────────────────────
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT config_key, config_value FROM system_config "
                    "WHERE config_key IN ('embedding_endpoint', 'embedding_api_key', 'embedding_model')"
                )
                rows = await cur.fetchall()
                cfg = {r['config_key']: r['config_value'] for r in rows}
        emb_url = cfg.get('embedding_endpoint')
        emb_key = cfg.get('embedding_api_key')
        emb_mod = cfg.get('embedding_model', 'text-embedding-3-large')

        if True:  # keep indent level
            # ── 1. 让总结模型输出多行事实 ──────────────────────────────
            raw = await _request_memory_summary(
                pool,
                db_id,
                endpoint,
                p_api_key,
                model,
                protocol,
                messages,
            )

            if not raw or raw == "无" or "无重要节点" in raw or len(raw) < 2:
                await utils.add_temp_log(pool, db_id, "[长期记忆·整理] 本轮无值得长期保存的事实")
                return

            # ── 2. 切分多行 + 过滤格式不符 ─────────────────────────────
            facts = []
            for line in raw.splitlines():
                line = line.strip()
                # 剥掉常见 markdown 残留(以防模型偶尔违规)
                line = line.lstrip("-*•·").strip()
                # 剥前后引号
                line = line.strip('"').strip("'").strip("「").strip("」").strip()
                if not line or len(line) < 4:
                    continue
                # 必须以「用户」开头;容错:把代词改写为「用户」
                if line.startswith("用户"):
                    pass
                elif line.startswith(("他", "她")):
                    # "她喜欢吃辣" → "用户喜欢吃辣"
                    line = "用户" + line[1:].lstrip()
                else:
                    continue
                facts.append(line)
            # 去重(同一轮总结内的重复)
            seen, dedup_facts = set(), []
            for f in facts:
                if f not in seen:
                    seen.add(f)
                    dedup_facts.append(f)
            facts = dedup_facts[:8]

            if not facts:
                await utils.add_temp_log(
                    pool, db_id,
                    f"[长期记忆·整理] ⚠ 模型输出不符合格式,已丢弃。原始首段:{raw[:60]}"
                )
                return

            # ── 3. 与库内已存在记忆做简单去重(完全相同 content 跳过) ──
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    placeholders = ",".join(["%s"] * len(facts))
                    await cur.execute(
                        f"SELECT content FROM instance_memories "
                        f"WHERE instance_id=%s AND memory_type='summary' "
                        f"AND content IN ({placeholders})",
                        (db_id, *facts),
                    )
                    existed = {r["content"] for r in await cur.fetchall()}
            new_facts = [f for f in facts if f not in existed]

            if not new_facts:
                await utils.add_temp_log(
                    pool, db_id,
                    f"[长期记忆·整理] 提炼 {len(facts)} 条,全部已存在于库中,无新增"
                )
                return

            # ── 4. 并行 embedding 所有新事实 ────────────────────────────
            async with httpx.AsyncClient(timeout=20.0) as embedding_client:
                emb_results = await asyncio.gather(*[
                    _rag_embed_one(embedding_client, f, emb_url, emb_key, emb_mod)
                    for f in new_facts
                ])

            # ── 5. 逐条入库(只入向量化成功的) ─────────────────────────
            inserted_facts = []
            now = int(time.time())
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    for fact, vec in zip(new_facts, emb_results):
                        if not vec:
                            continue
                        await cur.execute(
                            "INSERT INTO instance_memories "
                            "(instance_id, persona_id, memory_type, content, embedding, created_at) "
                            "VALUES (%s, %s, 'summary', %s, %s, %s)",
                            (db_id, persona_id, fact, json.dumps(vec), now),
                        )
                        inserted_facts.append(fact)
                await conn.commit()

            await utils.add_temp_log(
                pool, db_id,
                f"[长期记忆·整理] ✓ 模型提炼 {len(facts)} 条 | 已存在 {len(facts) - len(new_facts)} | "
                f"新增入库 {len(inserted_facts)} | 向量化失败 {len(new_facts) - len(inserted_facts)}"
            )
            # 把每条新入库的事实打到日志,前端日志栏直接看见
            for fact in inserted_facts:
                await utils.add_temp_log(pool, db_id, f"[长期记忆·整理] + {fact}")

    except Exception as e:
        # v13 (2026-05-13) 显示异常类型;某些异常(如 ReadTimeout、CancelledError)
        # str() 是空字符串,原版会出现"[长期记忆·整理] 异常: "后什么都没有的诡异日志。
        if isinstance(e, httpx.RemoteProtocolError):
            message = "远端连续断开，本轮整理已跳过"
        else:
            detail = str(e).strip() or type(e).__name__
            message = f"失败：{type(e).__name__}: {detail[:100]}"
        await utils.add_temp_log(pool, db_id, f"[长期记忆·整理] {message}")


async def _embed_and_save_turn(pool, db_id, persona_id, role, content):
    """单轮向量入库（用户/助手都会进）。

    v13 (2026-05-13) 修复 worker 启动 30s+ 延迟根因:
      原版没传 timeout,用全局 _http_client 的 120s。OpenAI embedding API
      抖动时本调用会卡到 120s 才超时,且 except Exception: pass 静默吞,
      使得用户视感"从收到消息到 [工具] 已加载之间卡了几十秒,没日志"。

    2026-07-08 修复"每轮存档 ReadTimeout 拖慢对话":
      - timeout 5.0 → 10.0(给抖动的嵌入端点更宽裕的窗口,减少 ReadTimeout)。
      - 更关键:两个调用点(user turn / assistant turn)改为经 _fire_and_forget
        丢后台执行,不再 await。所以即便嵌入慢到 10s 或超时,【用户对话链路
        零延迟影响】。
      - 本函数只写 instance_memories(RAG 素材),【与对话上下文 history 无关】,
        失败也只是这条 turn 不进 RAG 池,不会让模型"忘记"对话——上下文由
        history/save_context 单独保证。
      失败仅写一条 [每轮存档] temp_log,主流程本就"尽力而为"。
    """
    if not content:
        return
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT config_key, config_value FROM system_config "
                    "WHERE config_key IN ('embedding_endpoint', 'embedding_api_key', 'embedding_model')"
                )
                rows = await cur.fetchall()
                cfg = {r['config_key']: r['config_value'] for r in rows}

        emb_url = cfg.get('embedding_endpoint')
        emb_key = cfg.get('embedding_api_key')
        emb_mod = cfg.get('embedding_model', 'text-embedding-3-large')

        _c = get_http_client()
        res = await _c.post(
            emb_url,
            json={"model": emb_mod, "input": content},
            headers={"Authorization": f"Bearer {emb_key}"},
            timeout=10.0,
        )
        res.raise_for_status()
        emb = res.json()["data"][0]["embedding"]

        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "INSERT INTO instance_memories (instance_id, persona_id, memory_type, role, content, embedding, created_at) "
                    "VALUES (%s, %s, 'turn', %s, %s, %s, %s)",
                    (db_id, persona_id, role, content, json.dumps(emb), int(time.time()))
                )
            await conn.commit()
    except Exception as e:
        # 不再静默吞 — 写一条诊断日志(异常类型 + 80 字消息),让你能看到
        # 是 ReadTimeout 还是 4xx 还是 DB 问题。主流程不受影响,turn 入库
        # 本就是"尽力而为"。
        try:
            await utils.add_temp_log(
                pool, db_id,
                f"[每轮存档] ✗ {type(e).__name__}: {str(e)[:80]}"
            )
        except Exception:
            pass




async def generate_reply(pool, bot_instance, uid, user_text, context_token=None,
                         is_proactive=False, image_paths: list | None = None,
                         extra_user_block: str | None = None,
                         audio_paths: list | None = None,
                         video_paths: list | None = None,
                         model_override: str | None = None,
                         force_balance: bool = False,
                         tool_channel: str = "wechat",
                         stage_callback=None):
    """按会话串行的公开入口；tool_channel 只控制工具可用渠道。"""
    stage_token = _RUNTIME_STAGE_CALLBACK.set(stage_callback)
    try:
        _runtime_stage("conversation_lock", "等待同一会话的上一条消息处理完成")
        async with _get_conversation_lock(bot_instance.db_id, uid):
            _runtime_stage(
                "conversation_lock",
                "本进程会话锁已取得，等待跨分片实例锁",
            )
            async with _cross_process_conversation_lock(bot_instance.db_id):
                _runtime_stage("chat_initializing", "已取得跨平台会话锁，开始读取聊天配置")
                return await _generate_reply_locked(
                    pool, bot_instance, uid, user_text, context_token=context_token,
                    is_proactive=is_proactive, image_paths=image_paths,
                    extra_user_block=extra_user_block,
                    audio_paths=audio_paths, video_paths=video_paths,
                    model_override=model_override,
                    force_balance=force_balance,
                    tool_channel=tool_channel,
                )
    finally:
        _RUNTIME_STAGE_CALLBACK.reset(stage_token)


async def _generate_reply_locked(pool, bot_instance, uid, user_text, context_token=None,
                         is_proactive=False, image_paths: list | None = None,
                         extra_user_block: str | None = None,
                         audio_paths: list | None = None,
                         video_paths: list | None = None,
                         model_override: str | None = None,
                         force_balance: bool = False,
                         tool_channel: str = "wechat"):
    """
    AI 思考决策与回复生成主入口。

    参数:
      image_paths: list[str] | None
        本地解密后的图片绝对路径(可多张)。仅在「主模型 tags 含 vision」且
        本调用为被动回复(非主动消息)时由 main.py 透传。
        若给定且模型支持识图,本函数会把图片以 OpenAI 多模态 image_url(base64
        data URI) 形式塞进最后一条 user 消息,跳过外部识图 API,token 计费由
        主模型 usage 自然返回,直接走现有 billing.commit_usage 入账。

      audio_paths: list[str] | None (2026-06-14)
        本地解密转码后的音频绝对路径(mp3,可多条)。仅在「主模型支持原生音频」
        (DB tags 含 audio,或前缀命中 doubao-*)且本调用为被动回复时由 main.py
        透传。若给定且模型支持原生音频,本函数会把音频以 OpenAI 多模态
        input_audio(base64) 形式塞进最后一条 user 消息,直接发往通用 OpenAI 协议
        /chat/completions 端点, 跳过外部 STT(main.transcribe_audio_auto)。
        与识图直连一致: token 计费由主模型 usage 自然返回, 不再单独扣语音识别费。
        图片与音频可同时存在, 会合并进同一条 user 消息的 content list。

      video_paths: list[str] | None
        微信 CDN 解密后的本地视频路径。仅当当前模型在 model_pricing 中配置为
        protocol=gemini 时使用；不检查模型名前缀或固定型号。视频原始字节会在
        Gemini 协议边界转换为 generateContent 的 inlineData，沿用主模型上下文、
        usage 和计费链路。

      extra_user_block: str | None
        可选的本轮背景块。它与 RAG、当前消息、时间和心潮一起合并进请求中
        **最后一条 user 消息**，不会进入 system。网页听歌对话用它放
        “正在听的歌 + 歌词”。

      tool_channel: str
        工具可用渠道。wechat 可加载微信媒体/笔记工具，web 和 voice 只加载
        CHANNELS 允许的通用工具；该参数不改变执行方式。

    返回：
      ({"reply": str, "tools": [], "stop_proactive": bool}, is_error: bool)
    """
    tool_channel = str(tool_channel or "wechat").strip().lower()
    # 发送/工具渠道必须与本次会话适配器一致。QQ 适配器携带自己的
    # access_token/openid，微信 BotInstance 携带 wx_token；发现调用方把
    # 两者混用时立即中止，避免模型虽然生成成功但消息发到错误通道。
    bound_channel = getattr(bot_instance, "tool_channel", None)
    if bound_channel:
        bound_channel = str(bound_channel).strip().lower()
        if bound_channel != tool_channel:
            message = f"消息通道配置不一致（实例={bound_channel}，请求={tool_channel}）"
            try:
                await utils.add_temp_log(pool, bot_instance.db_id, f"[通道隔离] {message}")
            except Exception:
                pass
            return {
                "reply": "",
                "tools": [],
                "stop_proactive": False,
                "deny_reason": "消息未发出，请查看日志",
                "channel_mismatch": True,
            }, True
    db_id = bot_instance.db_id
    # v12.1 (2026-05-12) typing 指示器已移至 main.py message_worker 用
    # TypingController 管理。chat.py 不再起 typing 心跳任务,避免与 main.py
    # 那套并发争用,也避免老 CancelledError 处理慢/漏发 status:2 的问题。

    try:
        _runtime_stage("config_loading", "读取实例、模型与人格配置")
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute("SELECT * FROM instances WHERE id=%s", (db_id,))
                inst_config = await cur.fetchone()

        if not inst_config:
            await utils.add_temp_log(pool, db_id, "[错误] 实例配置读取失败")
            return {"reply": "", "tools": [], "stop_proactive": False}, True

        # 本轮初值用作数据库瞬时异常时的兜底；构造当前启用的系统预设前会再
        # SELECT 一次，将控制台配置渲染进【说话方式】，保存后无需重启即可生效。
        _live_split_config = _coerce_live_split_config(inst_config)

        user_id          = inst_config["user_id"]
        model            = inst_config.get("model", "")
        # 语音通话: 强制切到指定模型(豆包), 覆盖实例本身的模型。端点/密钥/协议/单价
        # 全部随之从该模型的 model_pricing 行读取 → 请求协议自动对齐。
        # 微信侧调用不传 model_override → model 保持实例原值, 行为完全不变。
        if model_override:
            model = model_override
        ai_message_count = inst_config.get("ai_message_count", 0)
        persona_id       = inst_config.get("persona_id")

        # persona 接口仍可能返回旧的 (人设, 心理状态) 元组，只取人设文本。
        _runtime_stage("persona_loading", "加载当前实例人格")
        _persona_result = await persona.get_persona_prompt(pool, db_id)
        persona_text = _persona_result[0] if isinstance(_persona_result, tuple) else _persona_result
        if not persona_text:
            persona_text = "你是一个友好的 AI 助手。"

        # 心潮是独立购买权益。普通聊天不依赖该权益，未购买时继续走
        # 原有的历史、缓存、RAG、工具和计费链路；只有心潮状态机及主动
        # 消息被短路。查询异常/字段缺失由 helper 按 fail-closed 处理。
        _runtime_stage("mind_preparing", "检查并结算心潮状态")
        mind_entitled = await _has_mind_entitlement(pool, db_id)
        if not mind_entitled:
            if is_proactive:
                await utils.add_temp_log(pool, db_id, "[心潮·权益] 未购买，静默跳过主动消息")
                return {
                    "reply": "",
                    "tools": [],
                    "stop_proactive": False,
                    "_mind_skip_proactive": True,
                    "_allow_silent": True,
                }, False
            mind_context = ""

        # ── 心潮动态状态：结算真实经过时间，并为本轮生成一次性上下文 ──────
        # 状态按 db_id 隔离并使用 MySQL 行锁更新。模型切换不重置；persona_id
        # 变化会开启新的心智状态，避免旧角色的亲密/愤怒等状态串入新人格。
        if mind_entitled:
            try:
                mind_turn = await dynamic_mind.prepare_turn(
                    pool,
                    db_id,
                    persona_id,
                    is_proactive=is_proactive,
                    record_presence=not is_proactive,
                )
                mind_context = mind_turn.get("context", "")
                if is_proactive and not mind_turn.get("allowed", False):
                    await utils.add_temp_log(
                        pool, db_id,
                        f"[心潮·主动门控] 本轮取消: {mind_turn.get('reason', 'unknown')}"
                    )
                    return {
                        "reply": "",
                        "tools": [],
                        "stop_proactive": False,
                        "_mind_skip_proactive": True,
                        "_allow_silent": True,
                    }, False
            except Exception as _mind_prepare_error:
                # 状态层故障不能拖垮用户的正常聊天；主动消息则宁可不发，避免在
                # 门控失效时骚扰用户。
                mind_context = ""
                await utils.add_temp_log(
                    pool, db_id,
                    f"[心潮·准备失败] {type(_mind_prepare_error).__name__}: "
                    f"{str(_mind_prepare_error)[:160]}"
                )
                if is_proactive:
                    return {
                        "reply": "",
                        "tools": [],
                        "stop_proactive": False,
                        "_mind_skip_proactive": True,
                        "_allow_silent": True,
                    }, True

        # v9.8:删除[热载入配置 model=]、[采样]、[配置 model= 思维链=]、[开始进入决策...]
        #       几条启动噪音日志 — 用户关心的是回复,不是每条消息都看一遍模型名。
        #       计费拦截 / 降级提示仍保留。

        # ── 计费配额校验（v2 · bucket 路由） ─────────────────────────────────
        # billing.check_quota 返回:
        #   {
        #     "ok": bool,              # False 时表示拦截（计费/模型权限不通过）
        #     "bucket": "pack"|"weekly"|"balance",  # 本次请求扣哪个桶
        #     "downgrade_msg": str|None,            # 自动降级提示（如包用尽转周额度）
        #     "deny_reason": str|None,              # ok=False 时的人话原因
        #   }
        _runtime_stage("quota_check", "检查模型权限与本轮计费方式")
        if force_balance:
            # 语音通话默认走余额桶；白金会员例外，语音与主模型均不计费。
            # 这里不能只依赖 billing.check_quota，因为 force_balance 是语音专用快捷路径。
            _voice_platinum = False
            try:
                _voice_platinum = await billing._has_active_platinum(pool, user_id)
            except Exception as _pt_voice_error:
                await utils.add_temp_log(
                    pool, db_id,
                    f"[白金会员·语音] 状态读取失败，按普通余额计费: {type(_pt_voice_error).__name__}"
                )
            if _voice_platinum:
                bucket        = "platinum_free"
                count_pack_id = None
                downgrade_msg = None
                await utils.add_temp_log(pool, db_id, "[白金会员] 语音通话本轮不计费")
            else:
                # 普通语音用户先做余额预检: 余额<=0 直接提醒充值, 不调模型。
                # 豆包对所有语音通话用户开放，仍保持原余额计费行为。
                _vbal = 0.0
                try:
                    async with pool.acquire() as conn:
                        async with conn.cursor() as cur:
                            await cur.execute("SELECT balance FROM users WHERE id=%s", (user_id,))
                            _vr = await cur.fetchone()
                            _vbal = float(_vr["balance"]) if _vr else 0.0
                except Exception:
                    _vbal = 0.0
                if _vbal <= 0:
                    await utils.add_temp_log(pool, db_id, "[语音通话·余额不足] 已拦截, 提醒用户充值")
                    _voice_deny = "语音通话按余额计费,你的余额已用完,请充值后再拨。"
                    return {"reply": _voice_deny, "tools": [], "stop_proactive": False,
                            "deny_reason": _voice_deny, "_no_split_send": True}, False
                bucket        = "balance"
                count_pack_id = None
                downgrade_msg = None
        else:
            quota = await billing.check_quota(pool, user_id, db_id, model)
            if not quota["ok"]:
                reason = quota.get("deny_reason") or "配额不足或无权限使用该模型"
                await utils.add_temp_log(pool, db_id, f"[扣费·余额不足] {reason}")
                return {
                    "reply": reason,
                    "tools": [],
                    "stop_proactive": False,
                    "deny_reason": reason,
                    "_no_split_send": True,
                }, False

            bucket = quota["bucket"]
            count_pack_id = quota.get("count_pack_id")   # 多次数包：本次扣哪个包
            downgrade_msg = quota.get("downgrade_msg")
            if downgrade_msg:
                # 例如："您的订阅包额度已用完，本次起按周额度计费"
                await utils.add_temp_log(pool, db_id, f"[扣费·切换计费桶] {downgrade_msg}")

        # ── 次数包桶 · 反滥用临时限制检查 ──────────────────────────────────
        # 只有走「次数包」计费的请求受此限制；余额 / token 包不受限。
        # 若用户处于封禁中,直接返回提示语(每次封禁只发一次),不调模型。
        if bucket == "count":
            _ban = billing.count_pack_ban_check(user_id)
            if _ban is not None:
                await utils.add_temp_log(
                    pool, db_id,
                    "[次数包·反滥用] 用户处于临时限制中,拦截本次请求"
                )
                _ban_msg = _ban.get("msg")
                if _ban_msg:
                    # 还没发过提示语 → 本次把提示语发给用户
                    return {"reply": _ban_msg, "tools": [],
                            "stop_proactive": False, "_no_split_send": True}, True
                # 已发过 → 静默拦截,不再刷屏
                return {
                    "reply": "",
                    "tools": [],
                    "stop_proactive": False,
                    "_allow_silent": True,
                }, False

        # ── 【免费通道关闭】v8.6 (2026-05-10) ─────────────────────────────
        # 后台开关:system_config.free_channel_blocked == "1" 时,
        # 所有 bucket=="weekly" 的请求不调 LLM,直接返回提醒词。
        # 订阅包(pack)、余额(balance)路径完全不受影响。
        # 提醒词由后台 system_config.free_channel_block_message 配置。
        # 返回时带 _no_split_send=True 标志,main.py 看到后会用整段发送
        # (不按 split_rule 切分),保证提醒词原样到达。
        if bucket == "weekly":
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT config_key, config_value FROM system_config "
                        "WHERE config_key IN ('free_channel_blocked', 'free_channel_block_message')"
                    )
                    _fb_rows = await cur.fetchall()
            _fb = {r['config_key']: r['config_value'] for r in _fb_rows}
            if (_fb.get('free_channel_blocked') or '').strip() == '1':
                _msg = (_fb.get('free_channel_block_message') or '').strip()
                if not _msg:
                    _msg = '免费通道已临时关闭,请稍后再试或购买订阅包/充值后继续使用。'
                await utils.add_temp_log(
                    pool, db_id,
                    f"[免费通道·已关闭] 用户 {user_id} 走 weekly 路径被拦截,直接发提醒词,不调用 LLM"
                )
                return {
                    "reply": _msg,
                    "tools": [],
                    "stop_proactive": False,
                    "_no_split_send": True,   # main.py 看到这个标志后整段发,不切分
                }, False

        # ── 【免费桶硬上限】已取消(多进程改造 · 2026) ──────────────────
        # 原小时 5 条 / 天 40 条限制依赖共享 JSON 文件,多进程下文件互相覆盖、
        # 计数不准,且产品上已决定不再限速。整块停用,免费桶用户直接放行。
        # _check_free_bucket_quota 函数体保留(未删),仅不再调用。
        # if bucket == "weekly":
        #     _q_status, _q_msg = await _check_free_bucket_quota(user_id)
        #     ...(原限速逻辑已停用)

        # ── 【weekly 桶滥用限速】已取消(多进程改造 · 2026) ────────────────
        # 原 5/10/20 轮阶梯延迟,同样依赖共享文件,多进程下失效;一并停用。
        # _apply_weekly_throttle / _weekly_record_and_get_delay 函数体保留,
        # 仅不再调用。
        # if bucket == "weekly":
        #     await _apply_weekly_throttle(pool, db_id, user_id)

        _runtime_stage("model_config_loading", "读取模型协议、端点、密钥来源与定价")
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT config_key, config_value FROM system_config "
                    "WHERE config_key IN ('platform_endpoint', 'platform_api_key')"
                )
                sys_rows = await cur.fetchall()
                sys_cfg  = {r["config_key"]: r["config_value"] for r in sys_rows}
                p_endpoint = sys_cfg.get("platform_endpoint", "").strip()
                p_api_key  = sys_cfg.get("platform_api_key", "").strip()

                # v8:再多 SELECT 1 个字段(tags 能力标签),用于本轮决定是否走多模态
                # 兼容老库:字段不存在时报 1054,逐级降级到 v7 / v6
                try:
                    await cur.execute(
                        "SELECT input_price, output_price, "
                        "endpoint AS model_endpoint, api_key AS model_api_key, "
                        "protocol AS model_protocol, supports_thinking, tags "
                        "FROM model_pricing WHERE model_name=%s", (model,)
                    )
                    price_row = await cur.fetchone()
                except Exception as _e_v8:
                    # v8 字段缺失 → 退到 v7
                    try:
                        await cur.execute(
                            "SELECT input_price, output_price, "
                            "endpoint AS model_endpoint, api_key AS model_api_key, "
                            "protocol AS model_protocol, supports_thinking "
                            "FROM model_pricing WHERE model_name=%s", (model,)
                        )
                        price_row = await cur.fetchone()
                        if price_row is not None:
                            price_row = dict(price_row)
                            price_row["tags"] = ""   # 老库无 tags → 空串,前缀白名单兜底
                    except Exception as _e_v7:
                        # v7 字段也缺失 → 退到 v6
                        await cur.execute(
                            "SELECT input_price, output_price FROM model_pricing WHERE model_name=%s", (model,)
                        )
                        price_row = await cur.fetchone()
                        if price_row is not None:
                            price_row = dict(price_row)
                            price_row.update({
                                "model_endpoint":    None,
                                "model_api_key":     None,
                                "model_protocol":    "openai",
                                "supports_thinking": None,  # ← None 触发 _build_payload 兜底前缀匹配
                                "tags":              "",
                            })

        if not price_row:
            await utils.add_temp_log(pool, db_id, f"[拦截] 平台未配置模型 {model} 的定价。")
            return {"reply": "", "tools": [], "stop_proactive": False}, False

        in_price  = float(price_row["input_price"])
        out_price = float(price_row["output_price"])
        cached_input_price = None
        try:
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT cached_input_price FROM model_pricing WHERE model_name=%s",
                        (model,),
                    )
                    _cache_price_row = await cur.fetchone()
                    if _cache_price_row and _cache_price_row.get("cached_input_price") is not None:
                        cached_input_price = float(_cache_price_row["cached_input_price"])
        except Exception:
            # 迁移前按普通输入价计费，不少算费用，也不中断请求。
            cached_input_price = None

        # ── v7:端点 / API Key 选择(模型自有 → 全局兜底)+ 自动补全 ──────────
        # v12.15 (2026-05-13) 新增:按 model_pricing.protocol 字段选择协议适配器
        #   "openai"    → proto_openai (默认,/v1/chat/completions)
        #   "anthropic" → proto_anthropic
        #   "gemini"    → proto_gemini (原生 /v1beta/models/{model}:generateContent)
        m_endpoint = (price_row.get("model_endpoint") or "").strip() or None
        m_api_key  = (price_row.get("model_api_key")  or "").strip() or None
        m_protocol = (price_row.get("model_protocol") or "openai").strip().lower()
        # 协议只听后台 model_pricing.protocol。模型名和媒体能力不得覆盖协议，
        # 否则会把模型独立配置的第三方 Key 错发到另一家上游。
        if m_protocol == "anthropic":
            proto = proto_anthropic
        elif m_protocol == "gemini":
            proto = proto_gemini
        else:
            proto = proto_openai
            m_protocol = "openai"  # 规范化
        if m_protocol == "gemini":
            # Gemini 原生适配器优先使用模型独立端点，未填才回退默认中转。
            endpoint = proto.resolve_endpoint(m_endpoint, p_endpoint, model=model)
        else:
            endpoint = proto.resolve_endpoint(m_endpoint, p_endpoint)
        # API Key:模型自有优先,否则全局
        request_api_key = m_api_key or p_api_key
        # supports_thinking:None 表示老库未跑迁移 → build_payload 内部回退前缀白名单
        model_supports_thinking_db = price_row.get("supports_thinking")
        if model_supports_thinking_db is not None:
            model_supports_thinking_db = bool(int(model_supports_thinking_db))

        # v?? (2026-05-27) 历史读取加 try/except 兜底
        # 失败原因可能是 DB 连接断、history 字段 JSON 反序列化失败、编码异常等。
        # 旧实现: 异常会沿调用链一直冒到 main.py worker 的 except Exception,
        #         前台只看到笼统的"后台进程·出错: ...", 看不出是历史读取挂了。
        # 新实现: 在这里就 catch, 把根因明确写到该实例的 temp_log
        #         (admin 前台日志栏直接可见), 本轮以空 history 继续, 不让用户
        #         感受到"AI 完全不回应"——至少能基于当前 user_text 走完一轮。
        _runtime_stage("history_loading", "读取最近 60 轮对话上下文")
        try:
            history = await utils.get_context(pool, db_id, uid=uid)
        except Exception as _e_hist:
            import traceback as _tb_hist
            print(
                f"[chat] 读取历史失败 db_id={db_id}: "
                f"{type(_e_hist).__name__}: {_e_hist}",
                flush=True,
            )
            _tb_hist.print_exc()
            try:
                await utils.add_temp_log(
                    pool, db_id,
                    f"[历史读取异常] {type(_e_hist).__name__}: {str(_e_hist)[:200]} "
                    f"(本轮以空历史继续, 不影响本条消息处理)"
                )
            except Exception:
                pass
            history = []
        # 旧版把简化工具摘要存成独立 system 「[操作记录…]」。
        # 新版只使用所属 assistant.tool_executions；先从内存历史剔除
        # 旧条目，本轮下一次 save_context 会自然完成持久化清理。
        history = _without_legacy_operation_records(history)
        current_time = utils.get_beijing_time()

        # 精准计算"AI 连续回复未得到回应的轮数"
        # 工具结果用 system 角色，遇到要跳过（既不是 AI 自言自语也不是用户回应）
        consecutive_ai = 0
        for msg in reversed(history):
            r = msg["role"]
            if r == "assistant":
                consecutive_ai += 1
            elif r == "user":
                break
            # r == "system" → 跳过

        # 主动消息的“最多连续两次、等待用户回应、睡眠、安静时段、驱动力
        # 阈值”全部由 dynamic_mind 的持久化状态机门控。这里不再依据截断后的
        # history 猜测连续轮数，避免工具记录/上下文窗口变化造成误判。

        if not is_proactive:
            # 在调用模型前保存用户消息；上游失败也不会丢失上下文。
            history.append(_make_msg("user", user_text))
            await utils.save_context(pool, db_id, history, uid=uid)
            # 向量入库只服务 RAG，不阻塞当前回复。
            _fire_and_forget(
                _embed_and_save_turn(pool, db_id, persona_id, "user", user_text)
            )
        # ── 加载 OpenAI tools 规格(应用实例黑名单) ───────────────────────
        # tool_specs:仅用于生成正文 JSON 工具清单，不注册厂商原生工具字段。
        # 黑名单已在 utils 内部应用。
        _runtime_stage("tools_loading", "加载当前渠道可用工具")
        try:
            tool_specs = await utils.load_skill_specs_for_openai(
                pool, db_id, tool_channel=tool_channel,
            )
        except Exception as _e:
            tool_specs = []
            await utils.add_temp_log(pool, db_id, f"[工具] 加载工具规格失败: {str(_e)[:80]}")
        tool_specs = [
            spec for spec in tool_specs
            if str((spec.get("function") or {}).get("name", "")).lower()
            not in _DISABLED_LEGACY_MIND_TOOLS
        ]
        if tool_specs:
            await utils.add_temp_log(
                pool, db_id,
                f"[工具] 已加载 {len(tool_specs)} 个可用工具: "
                + ",".join(s["function"]["name"] for s in tool_specs)
            )
        else:
            await utils.add_temp_log(pool, db_id, "[工具] 当前无可用工具(全部被禁用或目录为空)")

        # ── 用户设定:实例配置 user_persona,空(NULL/空串/纯空白)时不展示 ─
        # 故意采用"为空就完全不输出该区块"而不是"暂无设定"占位文本——后者会
        # 让 AI 误以为有该字段但用户拒绝填写,反而出现"我注意到你没有填写设定"
        # 之类的尴尬回应。完全不出现该区块,AI 自然不会提及。
        user_persona_raw = inst_config.get("user_persona")
        user_persona     = user_persona_raw.strip() if isinstance(user_persona_raw, str) else ""
        user_persona_block = f"\n【用户设定】\n{user_persona}\n" if user_persona else ""

        # 历史时间展示开关。上下文统一固定为最近 60 轮，不再读取实例配置。
        time_aware_inst = bool(int(inst_config.get("time_aware") or 0))
        # 当前北京时间始终进入本轮动态 user_prompt。
        _ct = current_time

        # 分段规则必须属于当前启用预设的【说话方式】，不能伪装成额外 user 消息。
        # 在构造 system_prompt 前读取控制台最新配置，每次新聊天请求都会实时生效。
        _live_split_config = await _load_live_split_config(
            pool, db_id, _live_split_config
        )
        _split_speaking_rule = _build_split_speaking_rule(_live_split_config)

        # ── v?? (2026-05-27) 统一硬编码 system_prompt ──────────────────────
        # 不再读 DB 预设, 所有用户使用同一份加强版系统模板。
        # 来源: 01_基础模板.md。
        # 工具说明块由外侧 utils.build_tools_system_block 构造,
        # 拼到 system_prompt 末尾。无工具时是空串。
        tools_system_block = utils.build_tools_system_block(
            tool_specs, allow_silent=is_proactive,
        )
        _response_format_intro = (
            "每次响应必须是纯 JSON，直接以 { 开头、} 结尾，"
            "不要 markdown 代码块或额外文字。"
        )
        _reply_field_hint = (
            "给用户的话（工具中间轮或主动选择不打扰时可为空）"
            if is_proactive else
            "给用户的话（调用工具的中间轮必须为空）"
        )
        _silent_contract = (
            "\n④ 主动选择不打扰：仅主动消息模式允许 reply=\"\"、tools=[]，系统不发送消息。"
            if is_proactive else ""
        )
        _response_tool_contract = f"""
【合法走法】
① 纯回复：reply 有文字，tools=[]。
② 调用工具：reply=""，tools 写入一个或多个工具；系统等待全部结果后再让你思考。
③ 工具结果返回后的下一轮：根据结果输出非空 reply；仍需其他工具时可继续调用。{_silent_contract}
只要 tools 非空，reply 就必须为空。reply 与 tools 同时有内容时整轮作废，工具不会执行。
""".strip()

        # 唯一启用的真人聊天系统预设。动态时间、心潮、RAG 与当前消息仍由
        # 后面的最后一条 user 注入，以保持稳定的 system 前缀与缓存命中。
        _runtime_stage("prompt_building", "拼接人格、历史与本轮动态提示")
        system_prompt = f"""\
【你是谁】
{persona_text}
以上是你需要扮演的角色。

【用户的信息（可能有）】
{user_persona_block}

【要做什么】
你是一个真实的人，有自己的情绪、节奏和说话习惯。你在用手机和对方聊天，
不是在写作文、不是在做客服。像真人一样：会有口头禅、会偶尔答非所问、
会先回一句再补一句，也会有不想多说的时候。

【说话方式】
- 一次说的话不要长，最低回复一个字，根据上下文语境决定回复字数多少。
{_split_speaking_rule}
- 允许不确定、反问和留白，情绪顺着上下文语境走，不要无缘无故换情绪。
- 不得在近几轮对话发出语义类似的语句，不得重复提起一件事，不得说过于油腻带满ai感或脱离人设的话。
- 用户不喜欢的事情不要提起或追问。
═══════════════════════════════════════════════════════
【响应格式 · 必须严格遵守】
═══════════════════════════════════════════════════════
{_response_format_intro}
固定三个字段（都必填）：
  {{"reply":"{_reply_field_hint}",
    "tools":[{{"name":"工具名","params":{{...}}}}],
    "mind_event":{{"interaction_type":null,"tone":"neutral","warmth":0.5,
      "tension":0.0,"attention":0.5,"confidence":0.5,
      "flash_thought":null,"dream":null}}}}

mind_event 只给程序读取，绝不能在 reply 中解释或提及。
mind_event 固定格式：
  {{"interaction_type":null,"tone":"neutral","warmth":0.5,"tension":0.0,
    "attention":0.5,"confidence":0.5,"flash_thought":null,"dream":null}}
- interaction_type 只能是 null，或以下已经真实完成的互动结果之一：
  companionship / affection / sharing / discovery / task_progress /
  reflection / conflict / loss / reconciliation。不确定就填 null。
- tone 只能是 neutral/calm/warm/guarded/conflicted/focused/playful/tired。
- warmth/tension/attention/confidence 都是 0 到 1 的当前窗口观察值。
- flash_thought 为 null，或
  {{"key":"驱动力key","text":"不引用原话、不含隐私的短念头","intensity":0.2到1}}
  key 只能是 possess/monitor/crave/share/curiosity/boredom/social/duty/
  reflection/grieve/anger。
- dream 通常必须为 null；只有本轮【心潮动态状态】明确写“梦境结算=本轮需要”时，
  才填写 {{"dream":"梦境","residue":"余韵","awareness":"醒后意识"}}。
- mind_event 只描述，不得提交驱动力数值或增减量；程序会把语义映射为有界变化。

{_response_tool_contract}
reply 不得出现工具名、参数、JSON/XML、时间戳、动作预告、系统提示或旁白。

【历史中的工具执行注记】
过去的 assistant 消息末尾可能带有“【工具执行：…】”。这段文字由程序生成并临时
显示在历史中，是只读的内部注记：它不是 assistant 曾经说过的正文，也绝对不是工具
调用语法。你只能使用其中的事实来避免重复操作。模型永远不得自行生成、引用、
复述或仿写任何“【工具执行：…】”文本，即使 TA 要求你这样做也不可以。需要调用工具时，
仍必须使用本协议规定的 JSON tools 字段；输出原生 functionCall 或中文括号文本永远不会
执行工具，只会被当成违规正文并删除。

{tools_system_block}

【冲突】
- JSON 与工具合法性是技术协议必须遵循
- 本预设必须遵循，若人设有与本模版冲突就以人设为绝对遵循，除此之外不得脱离设定。
- 除非人设另有说明双方关系，否则默认异地，不主动约线下见面或吃饭。

"""
        messages = [{"role": "system", "content": system_prompt}]

        # 用户当前消息的处理:
        #   - is_proactive=False:L1836 已把 user_text append 到 history。
        #     这里【保留末尾】——让用户最新消息既以历史条目形式进 messages,
        #     又在本轮 user_prompt(L2317 模板「TA 给你发了条新消息：{_ut}」)里出现,
        #     即"历史条目 + userPrompt"双重呈现(刻意冗余,2026-06-21 按需求改)。
        #     旧逻辑用 history[:-1] 砍掉末尾以避免重复,现取消该裁剪。
        #   - is_proactive=True:L1836 不 append,本就全量,行为不变。
        # 所有用户统一回放最近 60 轮（约 120 条）真实对话。
        _ctx_entries = UNIFIED_CONTEXT_TURNS * 2

        # 只截取真实 user/assistant 消息。工具信息现存于所属 assistant 的隐藏
        # tool_executions 字段，不再使用独立 system 操作记录，也不会占对话名额。
        _convo_history = [
            m for m in history
            if m.get("role") != "system"
            # llm_only 的语义就是合成的模型触发项，不是真实发言。旧版本通常
            # content 为空，但这里无条件过滤，防止旧库里存在非空变体。
            and not m.get("llm_only")
        ]

        # 被动消息已先以原话写入 history；先从本轮历史回放窗口拿掉，避免它以
        # 原话出现一次、随后又在最后一条动态 user 中出现一次。完整 user_prompt
        # 只在本轮发送，不再持久化；数据库始终只保存真实发言。
        _current_user_history_entry = None
        if (
            not is_proactive
            and _convo_history
            and _convo_history[-1].get("role") == "user"
        ):
            _current_user_history_entry = _convo_history[-1]
            _convo_history = _convo_history[:-1]

        # 严格限制为最近 60 轮。旧的滞后截断会在窗口之间临时保留到 1.5 倍，
        # 与“统一 60 轮”的服务端策略不一致，因此这里使用明确的硬上限。
        history_for_llm = _convo_history[-_ctx_entries:]

        # history_for_llm 现已不含 system 条目(上面已分离);仍保留一道防御性
        # system 跳过作双保险,正常情况下不会触发。
        for msg in history_for_llm:
            if msg.get("role", "user") == "system":
                continue
            # v12.10: 用 _flatten_for_llm 注入时间前缀(time_aware=0 时不带)
            flat = _flatten_for_llm(msg, time_aware=time_aware_inst)
            messages.append(flat)

        # Gemini 2.5+ 的隐式缓存依赖请求前缀稳定。上面的量化锚点历史会原样
        # 留在 messages 前部；当前 OpenLux 不提供 Google 的 CachedContent
        # 资源接口，因此这里不再截取前缀、创建或引用显式缓存资源。

        # ─────────────────────────────────────────────────────────────────
        # user_prompt 重构 (2026-05-09)
        # 排序:
        #   1. 触发场景 / 用户消息引导
        #   2. 【思考与输出规则】(原"思考维度" + "输出规则" 合并)
        #   3. 【决策】(三选一)
        #   4. 【附加约束】(技术性硬规则,不归思考也不归决策)
        # 注: system_prompt 不变,这里是 user 视角的本轮提示。
        # 主动消息和被动消息共享同一份"思考与输出规则",通过下方常量复用。
        # ─────────────────────────────────────────────────────────────────
        # v22 (2026-05-19) 取消 _HARD_TOOL_PROTOCOL_RULES ⚠ 重要
        # 历史:
        #   v18 加了 1183 字的"系统级硬规则"追加到 user_prompt 末尾。
        #   v22 彻底删除整段。原因:即使去掉反例,只要 prompt 里反复提到
        #       "tool_calls / action / arguments / function" 这些关键字,
        #       小模型(gemini lite 等)就会把这些当 token 重要性提升,
        #       反而在 content 里输出复合 JSON {"content":"...","tool_calls":[...]}。
        # 不再依靠 prompt 强制约束,改为**代码层强制清洗**,见:
        #   D1: _sanitize_outgoing_text step 3 复合 JSON 提取 content
        #   D2: _looks_like_tool_call_dict 强弱关键字判定
        #   D3: 防误伤层硬否决
        #   D4: 末级硬防御(发送前最后 json.loads 一次)
        # 用户不可见任何工具调用 JSON 泄漏的责任完全由清洗器承担。

        # ── v?? (2026-05-27) 统一硬编码 user_prompt ────────────────────────
        # 不再读 DB 预设里的 passive_reply_prompt / proactive_message_prompt,
        # 所有用户使用同一份。
        # 被动来源: 02_被动消息预设.md  (最高频, 用户主动发消息时触发)
        # 主动来源: 03_主动消息预设.md  (定时器到点, 自主决定是否找用户)
        # content / tools 配对规则与 system 中的统一同步协议保持一致。
        _ut = user_text or ""
        _turn_output_header = "【输出】必须是合法 JSON，固定字段 reply、tools、mind_event。"
        _turn_tool_choice = (
            "reply=\"\"，tools 写入需要调用的工具，等下一轮拿到结果再回复。"
        )
        _turn_tool_summary = (
            "只要 tools 非空，reply 必须为空；工具结果返回后再生成最终文字。"
        )
        if is_proactive:
            _turn_mode_block = f"""\
【触发场景】
现在是主动消息模式——系统定时器到点了，没有新的用户消息。你要判断现在要不要主动给对方发一条消息。

【先在心里想一想】（只是心里想，不发出去）
- 对方在表达什么情绪、什么意图，他想要什么样的回应？
- 对方最近在干什么？有没有特别的情绪（比如在生气）？按上下文你现在是什么状态？
- 现在是合适的打扰时机吗？对方大概率方便回吗？
- 我想发的话在上下文中有没有重复，是否过多重复提及一个话题？
- 该发吗？会不会让对方觉得突兀？怎么说才像你这个人，接得上上文吗？
- 这次跟最近几轮有没有太像的地方，需要换个角度？

【挑时机】
优先选合适的时机：别打断对方，避开凌晨、工作和学习的专注时段，也别跟上一条主动消息隔得太近。
时机不合适、拿不准时，优先选择不发。

{_turn_output_header}
① 想发，直接发：reply 有文字，tools=[]。
② 不发（决定不打扰）：reply=""，tools=[]，系统判定这次不打扰对方；时机不合适、拿不准优先选此项。
③ 需要工具后再决定：{_turn_tool_choice}
{_turn_tool_summary}
如果这一轮选择说话，reply 不能出现括号或方括号旁白、时间戳、数据样花括号、动作预告、工具名、参数、JSON/XML。
确认完毕后输出 JSON；不允许重复主动提及同一话题或频繁重复词汇。
"""
        else:
            _turn_mode_block = f"""\
【触发场景】
对方发来一条新消息。你要针对这句话回复，结合上下文、相关记忆和当前心潮决定内容。

【先在心里想一想】（只是心里想，不发出去）
- 对方在表达什么情绪、什么意图，他想要什么样的回应？
- 对方最近在干什么？有没有特别的情绪（比如在生气）？按上下文你现在是什么状态？
- 现在是合适的回应时机吗？我想说的话有没有重复或突兀？
- 怎么说才像你这个人，接得上上文？这次跟最近几轮有没有太像的地方，需要换个角度？

{_turn_output_header}
① 直接说话（最常见）：reply 有文字，tools=[]。
② 调用工具后再回复：{_turn_tool_choice}
{_turn_tool_summary}
如果这一轮选择说话，reply 不能出现“我去查/稍等”等预告、动作自述、括号旁白、时间戳、数据样方括号/花括号、工具名、参数、JSON/XML 或系统动作。
reply 只允许写这一刻会对 TA 说的话。确认完毕后输出 JSON。
"""
        _turn_memory_block = ""

        # v22 (2026-05-19) 此处原 v18 追加了 _HARD_TOOL_PROTOCOL_RULES (1183 字)
        # 到 user_prompt 末尾,试图用近因偏置强制 AI 遵守 function calling 协议。
        # 实测:即使去掉具体反例(v21),prompt 里反复提"tool_calls/action/arguments"
        # 等关键字,小模型仍会被反向引导,在 content 输出复合 JSON。
        # 彻底删除追加。工具协议遵循靠:
        #   ① 工具 description 里的统一同步说明(utils.py 注入)
        #   ② 预设里的工具调用规则
        #   ③ 代码层 D1-D4 清洗(详见 _sanitize_outgoing_text 和发送前守卫)

        # ── 被动 RAG · 每轮检索结果放入最后一条 user 的动态区 ─────────────
        # 主动消息或空 user_text 跳过(主动模式没有"用户当前发言"做检索词)。
        # 实例配置 rag_enabled=1 才启用(实验性功能,默认关)。开启后 QE 调用按
        # 硬编码价(¥0.2/M·in + ¥1.2/M·out)从 users.balance 单独扣费,嵌入与
        # 重排序由系统补贴。流水线内部全程通过 utils.add_temp_log 实时打日志,
        # 涵盖配置/QE/计费/Embed/DB/Score/Pool/Rerank/注入 9 个节点 + 总耗时分解,
        # 调参时直接看实例日志栏。任何异常静默吞掉,主流程不受影响。
        # search_memory 工具仍保留作为"指向性深挖"的备用通道。
        rag_enabled = bool(int(inst_config.get("rag_enabled") or 0))
        if not is_proactive and user_text and user_text.strip() and rag_enabled:
            _runtime_stage("memory_search", "检索并重排与当前消息相关的长期记忆")
            try:
                memory_block, hit_count = await _passive_retrieve_memory(
                    pool, db_id, user_id, user_text, history,
                    p_endpoint, p_api_key, model,
                    persona_text=persona_text,
                )
                if hit_count > 0:
                    _turn_memory_block = memory_block.strip()
            except Exception as _e:
                # 兜底:正常情况内部已 try,这里只防呆,不应触发
                await utils.add_temp_log(
                    pool, db_id,
                    f"[搜索记忆ERROR] 异常兜底: {str(_e)[:80]}"
                )
        elif not is_proactive and user_text and user_text.strip() and not rag_enabled:
            # 静默跳过,但写一条 debug 日志便于排查"为什么没注入记忆"
            await utils.add_temp_log(
                pool, db_id,
                "[搜索记忆] 未启用 rag_enabled=0,本次不检索记忆"
            )

        # ── 上一轮思维链注入：已移除 (2026-06-21) ──────────────────────────
        # 按需求砍掉「被动消息把上一轮 assistant 的 reasoning 拼到 user_prompt
        # 顶部」这一注入。被动请求体不再携带上一轮思维链。
        # 注意:_make_msg 仍会把当轮 reasoning 存进 history(见 L3142/L3234),
        #   该字段保留用于 admin 审计 / temp_log 展示, 但【不再注入到任何请求体】。
        #   _flatten_for_llm 本就不输出 reasoning, 故历史条目回放也不会带它。
        #   如需彻底停止存储, 把上述两处 _make_msg 的 reasoning=... 改成 None 即可。



        # ── 当前北京时间:只进入最后一条 user 的高频动态区 ────────────────
        # 原因:system_prompt 必须保持完全静态才能让 LLM 网关 prompt cache 命中,
        # 时间戳每秒变 → cache 命中率被打到 ~20%。挪到 user 后 system 完全稳定,
        # 同一个实例下 system_prompt 哈希一致,前缀缓存可大幅提升命中率。
        # 时间靠近 user_prompt 末端,工具/规则相关引用仍能读到。
        #
        # v11 (2026-05-12) 改造:
        #   1. 预设模板里用户已经能用 {current_time} 自由放置,本处不再硬加
        #   2. 即使是内置默认,也尊重 time_aware 开关——关时不注入,防部分模型掉格式
        # v?? (2026-05-27) 原 time_aware 硬加时间戳逻辑删除。
        # 新硬编码 user_prompt 模板自带【现在几点】{_ct}, 已包含真实北京时间,
        # 不需要也不应再在外面追加(否则会出现两次时间戳)。
        # time_aware 字段仍存于 inst_config, 但本路径不再消费。如果未来要恢复
        # "可关闭时间感知", 应该回到 user_prompt 模板里把时间块包成可选段。

        # ───────────────────────────────────────────────────────────────
        # v8 · 2026-05-09:多模态识图直连
        # 触发条件全部满足时,把 user_prompt 升级为 OpenAI 多模态 content list
        # (text + 多张 image_url base64 data URI),跳过外部 vision API。
        #   1. main.py 通过 image_paths 透传了至少一张本地解密的 jpg
        #   2. 当前模型 tags 字段含 'vision'(老库无 tags → 走前缀白名单兜底)
        #   3. 不是主动消息(is_proactive=False)
        # 不满足 → 走旧路径(main.py 已用外部 vision API 把描述文本拼进 user_text)
        # token 计费由主模型 usage 自然返回,无需改动 billing。
        # ───────────────────────────────────────────────────────────────
        model_tags_str = (price_row.get("tags") or "").strip().lower()
        model_tags_set = {t.strip() for t in model_tags_str.split(",") if t.strip()}
        # OpenAI/Gemini 协议只要模型 ID 任意位置包含 gemini，就无条件启用
        # 原生识图。该规则优先于展示 tags，解决路由前缀导致的漏匹配。
        gemini_named_native_vision = _is_gemini_named_native_vision_model(
            model, m_protocol
        )
        # 老库无 tags 时,用协议感知的家族规则兜底识别常见多模态模型
        if not model_tags_set:
            model_supports_vision = _model_supports_vision_by_prefix(
                model, m_protocol
            )
            vision_source = "前缀兜底"
        else:
            model_supports_vision = "vision" in model_tags_set
            vision_source = "DB-tags"
        if gemini_named_native_vision:
            # OpenAI 协议使用 image_url(base64 data URI)；Gemini 协议适配器会
            # 在出网前转换成原生 inlineData。模型 ID 的路由前缀不会影响判定。
            model_supports_vision = True
            vision_source = f"{m_protocol}协议+ID含gemini"

        use_inline_vision = (
            bool(image_paths)
            and model_supports_vision
            and not is_proactive
        )

        # ── 原生音频直连判定 (2026-06-14) ────────────────────────────────────
        # 与识图同样的判定手法: DB tags 含 'audio' → 支持; tags 空 → 前缀兜底
        # (doubao-* 命中)。满足且本轮被动 + main.py 透传了 audio_paths 时,
        # 把原始音频以 OpenAI input_audio 形式直接塞进 user 消息发往 /chat/completions,
        # 跳过外部 STT, token 随主模型 usage 计费。
        if not model_tags_set:
            model_supports_audio = _model_supports_audio_by_prefix(model)
            audio_source = "前缀兜底"
        else:
            model_supports_audio = ("audio" in model_tags_set) or _model_supports_audio_by_prefix(model)
            audio_source = "DB-tags" if "audio" in model_tags_set else "前缀兜底"

        use_inline_audio = (
            bool(audio_paths)
            and model_supports_audio
            and not is_proactive
        )

        # 视频能力只由后台协议配置决定。任何 model_pricing.protocol=gemini 的
        # 当前模型都走同一个原生 generateContent 适配器，不绑定 2.5 Pro、模型
        # 前缀或 tags。Google 官方说明所有 Gemini 模型均可处理视频。
        model_supports_video = (m_protocol == "gemini")
        use_inline_video = (
            bool(video_paths)
            and model_supports_video
            and not is_proactive
        )

        if image_paths:
            await utils.add_temp_log(
                pool, db_id,
                f"[看图] 收到 {len(image_paths)} 张图,模型识图能力={'是' if model_supports_vision else '否'}({vision_source}),"
                f"决策={'主模型直连' if use_inline_vision else '已走外部 vision API(描述已嵌入文本)'}"
            )
        if audio_paths:
            await utils.add_temp_log(
                pool, db_id,
                f"[听语音] 收到 {len(audio_paths)} 条音频,模型原生音频能力={'是' if model_supports_audio else '否'}({audio_source}),"
                f"决策={'主模型直连' if use_inline_audio else '已走外部 STT(转写文本已嵌入)'}"
            )
        if video_paths:
            await utils.add_temp_log(
                pool, db_id,
                f"[看视频] 收到 {len(video_paths)} 个视频,"
                f"决策={'Gemini原生直连' if use_inline_video else '当前模型不是Gemini协议'}"
            )

        # ── 本轮动态信息统一收敛到 messages 的最后一条 user ─────────────
        # 排序原则：稳定内容在前，越频繁变化越靠后。system 只放人设、输出协议、
        # 工具规则等低频配置；RAG、临时背景、当前发言、时间、心潮绝不进入 system。
        _turn_user_sections = [_turn_mode_block.strip()]

        # 调用方背景通常可跨若干轮保持（歌曲、歌词、页面状态等）。
        if extra_user_block and extra_user_block.strip():
            _turn_user_sections.append(
                "【本轮额外背景·仅属于这一轮】\n" + extra_user_block.strip()
            )
            await utils.add_temp_log(
                pool, db_id,
                f"[额外背景] 已合并到最后一条 user（{len(extra_user_block.strip())}字）"
            )

        # 下面的内容按变化频率从低到高排列：RAG、时间、心潮、当前消息。
        # 它们全部位于本轮 user 的尾部，不进入 system 或 Gemini 稳定缓存种子。
        if _turn_memory_block:
            _turn_user_sections.append(_turn_memory_block)

        _turn_user_sections.append(
            "【这一轮发生时的北京时间·历史回放时不要当成现在】\n" + _ct
        )

        # 变化频繁且只对当轮有效：心潮靠近末端。
        if mind_context and mind_context.strip():
            _turn_user_sections.append(
                "【本轮心潮动态状态·只解释本轮，后续以新状态为准】\n"
                + mind_context.strip()
            )
            await utils.add_temp_log(
                pool, db_id,
                f"[心潮·上下文] 已放到最后一条 user 的高频动态区 "
                f"({len(mind_context.strip())}字)"
            )

        # 当前真实消息每轮必变，并且应获得最高近因权重，因此绝对放在文本
        # user 的最后；多模态图片/音频 Part 会紧随其后。
        if not is_proactive:
            _turn_user_sections.append("【这一轮 TA 发来的消息】\n" + _ut)

        user_prompt = "\n\n".join(
            section for section in _turn_user_sections if section
        )

        # 主动轮的动态触发提示只服务当前请求，不再伪造隐藏 user 入库。真正发送
        # 出去的 assistant 发言仍会照常保存，下一轮只回放这条真实发言。

        # 清理由旧版重试流程留下的当前 user.llm_content。历史中的旧字段无需迁移
        # 或删除，因为 _flatten_for_llm 已统一忽略；当前条目顺手清理，确保以后
        # 新写入的数据从源头上只有原始发言。
        if _current_user_history_entry is not None:
            _removed_legacy_llm_content = False
            if "llm_content" in _current_user_history_entry:
                _current_user_history_entry.pop("llm_content", None)
                _removed_legacy_llm_content = True
            if "llm_only" in _current_user_history_entry:
                _current_user_history_entry.pop("llm_only", None)
                _removed_legacy_llm_content = True
            if _removed_legacy_llm_content:
                await utils.save_context(pool, db_id, history, uid=uid)
            await utils.add_temp_log(
                pool, db_id,
                f"[历史压缩] 当前 user 仅保存原始发言；完整动态提示 "
                f"({len(user_prompt)}字) 只发送本轮"
            )

        if use_inline_vision or use_inline_audio or use_inline_video:
            # 构造内部多模态 content list。Gemini 视频先于文本放置（官方最佳实践），
            # 图片/音频仍保持原有 text → media 顺序。协议适配器会在出网前把
            # video 块转换为原生 inlineData。
            # 读盘用同步 IO:单条媒体通常 < 1MB,网关上传压力远高于本地读盘,不必 aiofiles。
            # 图片、音频与视频可同时出现, 合并进同一条 user 消息。
            multimodal_content = []
            ok_imgs = 0
            ok_auds = 0
            ok_videos = 0
            video_bytes_used = 0

            if use_inline_video:
                for vpath in video_paths:
                    try:
                        if not os.path.isfile(vpath):
                            await utils.add_temp_log(pool, db_id, "[看视频] 视频文件不存在")
                            continue
                        vsize = os.path.getsize(vpath)
                        if (
                            vsize <= 0
                            or video_bytes_used + vsize > proto_gemini.GEMINI_INLINE_VIDEO_MAX_BYTES
                        ):
                            await utils.add_temp_log(pool, db_id, "[看视频] 视频超过内联大小限制")
                            continue
                        vext = os.path.splitext(vpath)[1].lower()
                        vmime = proto_gemini.GEMINI_VIDEO_MIME_BY_EXTENSION.get(vext)
                        if not vmime:
                            await utils.add_temp_log(pool, db_id, "[看视频] 视频格式不受支持")
                            continue
                        with open(vpath, "rb") as f:
                            vb64 = base64.b64encode(f.read()).decode("utf-8")
                        multimodal_content.append({
                            "type": "video",
                            "data": vb64,
                            "mime_type": vmime,
                        })
                        video_bytes_used += vsize
                        ok_videos += 1
                    except Exception as _e_video:
                        await utils.add_temp_log(
                            pool, db_id,
                            f"[看视频] 读取失败: {type(_e_video).__name__}"
                        )

            # 有视频时此文本位于视频 Part 之后；没有视频时保持旧版文本在前。
            multimodal_content.append({"type": "text", "text": user_prompt})
            if use_inline_vision:
                for ipath in image_paths:
                    try:
                        if not os.path.isfile(ipath):
                            await utils.add_temp_log(pool, db_id, f"[看图] 跳过不存在的图: {ipath}")
                            continue
                        with open(ipath, "rb") as f:
                            b64 = base64.b64encode(f.read()).decode("utf-8")
                        # MIME 从解密后真实扩展名推断；BMP 不能再伪装为 JPEG，
                        # 否则严格的多模态接口会把已成功收到的图片判为损坏。
                        ext = os.path.splitext(ipath)[1].lower().lstrip(".")
                        mime = {"jpg": "jpeg", "jpeg": "jpeg", "png": "png",
                                "gif": "gif", "webp": "webp", "bmp": "bmp"}.get(ext, "jpeg")
                        multimodal_content.append({
                            "type": "image_url",
                            "image_url": {"url": f"data:image/{mime};base64,{b64}"}
                        })
                        ok_imgs += 1
                    except Exception as _e_img:
                        await utils.add_temp_log(pool, db_id, f"[看图] 读图失败 {ipath}: {str(_e_img)[:80]}")

            if use_inline_audio:
                # OpenAI 通用多模态音频字段: input_audio.data=base64, input_audio.format=容器格式。
                # main.py 解密转码后统一产出 mp3, 故默认 format=mp3; 其它扩展名按映射推断。
                for apath in audio_paths:
                    try:
                        if not os.path.isfile(apath):
                            await utils.add_temp_log(pool, db_id, f"[听语音] 跳过不存在的音频: {apath}")
                            continue
                        with open(apath, "rb") as f:
                            ab64 = base64.b64encode(f.read()).decode("utf-8")
                        aext = os.path.splitext(apath)[1].lower().lstrip(".")
                        afmt = {"mp3": "mp3", "wav": "wav", "m4a": "m4a",
                                "ogg": "ogg", "webm": "webm", "flac": "flac"}.get(aext, "mp3")
                        multimodal_content.append({
                            "type": "input_audio",
                            "input_audio": {"data": ab64, "format": afmt}
                        })
                        ok_auds += 1
                    except Exception as _e_aud:
                        await utils.add_temp_log(pool, db_id, f"[听语音] 读音频失败 {apath}: {str(_e_aud)[:80]}")

            if ok_imgs == 0 and ok_auds == 0 and ok_videos == 0:
                # 兜底:所有媒体都没读成,降级回纯文本(避免空 content list)
                await utils.add_temp_log(pool, db_id, "[多模态] 所有媒体均读取失败,降级为纯文本调用")
                messages.append({"role": "user", "content": user_prompt})
            else:
                messages.append({"role": "user", "content": multimodal_content})
                if ok_imgs:
                    await utils.add_temp_log(
                        pool, db_id,
                        f"[看图] 已把 {ok_imgs} 张图直接塞入主模型 user 消息,token 由主模型计费"
                    )
                if ok_auds:
                    await utils.add_temp_log(
                        pool, db_id,
                        f"[听语音] 已把 {ok_auds} 条音频直接塞入主模型 user 消息(/chat/completions),token 由主模型计费"
                    )
                if ok_videos:
                    await utils.add_temp_log(
                        pool, db_id,
                        f"[看视频] 已把 {ok_videos} 个视频交给当前Gemini协议模型"
                    )
        else:
            messages.append({"role": "user", "content": user_prompt})

        # 请求头由原生协议各自构造；OpenAI 保持历史 Bearer 行为。
        if m_protocol in ("anthropic", "gemini"):
            req_headers = proto.build_headers(request_api_key)
        else:
            req_headers = {
                "Authorization": f"Bearer {request_api_key}",
                "Content-Type": "application/json",
            }

        # 采样参数：2026-07-12 起全员硬编码，不再读取 instances 表 ★
        # 变更前：采样参数从 inst_config(instances 表)
        #        读取，数据库未填时才回退出厂默认值，不同实例可各自配置。
        # 变更后：不论 instances 表里存的是什么，一律使用下面两个固定值，
        #        对所有用户 / 所有实例统一生效，不再区分。
        # 如需恢复"按实例可调"，改回：
        #   inst_temperature       = float(inst_config.get("temperature")       or 1.0)
        #   inst_presence_penalty  = float(inst_config.get("presence_penalty")  or 0.1)
        # ⚠ 前端"运行配置"弹窗如果还留着这两个输入框，用户改了也不再生效，
        #   建议同步隐藏，或标注"暂不生效"，避免造成"改了没用"的困惑工单。
        inst_temperature      = 1.1
        inst_presence_penalty = 0.15

        # v9.8:删除[采样 T=..]日志,内部诊断,不需要刷屏给用户

        loop_count              = 0
        max_loops               = 10
        accumulated_replies     = []
        completed_tool_executions = []
        executed_tool_results = {}
        total_prompt_tokens     = 0
        total_completion_tokens = 0
        total_cached_tokens     = 0
        total_cost              = 0.0
        tools_called_in_round   = []

        # 思维链(深度思考)实例级开关:实例配置 thinking_enabled=0 时,即使是
        # 思考型模型也不下发 reasoning 参数。Claude/Grok 等本就不支持思维链
        # 的模型不受影响。默认开(向后兼容旧实例字段缺失)。
        # 字段每次 generate_reply 都从 inst_config 实时读(L1327 SELECT),
        # 不存在缓存问题——admin 改 thinking_enabled 后下一条用户消息即生效。
        thinking_enabled_inst = bool(int(inst_config.get("thinking_enabled") or 1))
        # v7:模型层是否支持思维链 → 优先 DB 字段,缺失则前缀白名单兜底
        if model_supports_thinking_db is not None:
            is_thinking_model_flag = model_supports_thinking_db
            ts_source = "DB"
        else:
            # v?? (2026-05-27) 修复 NameError: _is_thinking_model 未定义
            # 改用 proto.supports_thinking_by_prefix (协议文件里的官方实现)。
            # 老库 model_pricing.supports_thinking 字段缺失时, 此处原本会崩溃,
            # 整个 try 块异常 → 用户看到"后台进程·出错", 思维链当然抽不到。
            is_thinking_model_flag = proto.supports_thinking_by_prefix(model)
            ts_source = "前缀兜底"
        if m_protocol == "gemini":
            # 产品要求：Gemini 原生链路不允许实例或 DB 关闭思考摘要。
            thinking_enabled_inst = True
            is_thinking_model_flag = True
            ts_source = "Gemini原生强制"
        thinking_will_send = thinking_enabled_inst and is_thinking_model_flag
        # v9.8:删除[配置 model=...]、[开始进入决策]日志,内部诊断,刷屏

        llm_client = get_http_client()
        # 统一回复协议:
        #   ① reply 有文字 + tools=[]  → 最终文本
        #   ② reply="" + tools 非空   → 等待工具结果后继续内循环
        # 其它组合全部非法。工具执行不存在后台分支。
        # 非法 JSON/无 JSON 和空终态都只有首次 + 一次重生机会。
        # 整个用户请求共用一次格式重生额度，空回复、正文 JSON 无效、工具
        # 组合无效和原生响应结构无效不会各自额外获得一次。
        _format_retry_used = False
        _terminal_reply_fallback = REQUEST_FAILED_REPLY
        # 多轮工具链中保留最新一份合法 mind_event；最终回复成功后只
        # 提交一次，避免中间轮重复结算互动效果。
        mind_event_for_commit = None
        # 兼容旧名: chat.py 其它地方可能引用了 _force_text_only,
        # 新协议下不再使用该变量, 但保留赋值避免老代码 NameError。
        _force_text_only = False
        while loop_count < max_loops:
            loop_count += 1
            _runtime_stage(
                "payload_building",
                f"第{loop_count}轮 · 构造 {m_protocol} 请求体",
            )
            # 所有协议统一使用正文 JSON tools。Gemini 原生函数字段不下发，
            # 避免一套业务工具同时存在两种调用语法与两套中间轮状态机。
            # 2026-07-12 缓存命中优化: 按实例(db_id)分 key。
            # 同一个 db_id 的所有请求共享同一段 system_prompt+历史前缀,
            # 用同一个 key 有助于路由到同一台已有缓存的机器; 不同实例之间
            # 天然前缀不同, 分开的 key 也不会互相抢流量。db_id 本身量级
            # (单个实例几乎不可能一分钟内发 15+ 次请求)远低于官方建议的
            # ~15 RPM/key 上限, 不需要再做分桶。仅 OpenAI 协议下实际生效,
            # Anthropic 协议下会被 build_payload 接收但静默忽略(见该文件
            # 内注释)。
            full_payload = proto.build_payload(
                model, messages,
                temperature=inst_temperature,
                presence_penalty=inst_presence_penalty,
                tools=None,
                enable_thinking=thinking_enabled_inst,
                supports_thinking=is_thinking_model_flag,
                tool_choice=None,
                prompt_cache_key=f"instance-{db_id}",
            )
            payload = full_payload

            # ── 思维链诊断 (2026-05-17 hotfix) ────────────────────────
            # 排查"思维链开了但日志看不到 + 输出 token 少"问题。
            # 必看字段:
            #   inst_enabled  : instances.thinking_enabled (实例开关)
            #   model_support : model_pricing.supports_thinking (DB) 或前缀兜底
            #   payload.enable_thinking : 实际进入请求体的字段(<not-set>=没带)
            # 三个值不一致即可定位:
            #   inst_enabled=1 但 model_support=0 → 模型 gate 拦截,改 DB 字段
            #   两者都 1 但 enable_thinking=<not-set> → protocol 层漏发,看 build_payload
            #   都正确但响应 reasoning_len=0 → 上游聚合层/模型没听,不是本地代码 bug
            try:
                _diag_generation = payload.get("generationConfig") or {}
                _diag_thinking = _diag_generation.get("thinkingConfig") or {}
                print(
                    f"[chat.thinking.diag][第{loop_count}轮] db_id={db_id} model={model} "
                    f"inst_enabled={int(thinking_enabled_inst)} "
                    f"model_support={int(bool(is_thinking_model_flag))}({ts_source}) "
                    f"thinking_will_send={int(thinking_will_send)} "
                    f"payload.enable_thinking={payload.get('enable_thinking', '<not-set>')} "
                    f"gemini.thinkingConfig={_diag_thinking or '<not-set>'} "
                    f"max_tokens={payload.get('max_tokens', _diag_generation.get('maxOutputTokens'))}",
                    flush=True,
                )
            except Exception as _diag_e:
                print(f"[chat.thinking.diag] 打印失败: {_diag_e}", flush=True)

            # v17 (2026-05-18) 同步把"本轮思考开关下发情况"写一条 temp_log,
            # 让 admin 前台能直接看到, 不用再 SSH 看 stdout。
            # 关键字段: 实例开关、模型支持、实际下发字段、思考预算。
            # 字段全不全是判断"思维链失效到底卡哪一步"的第一手证据。
            #
            # v?? 改动:此处 temp_log 已移除 — 每轮都写一条对前台用户太刷屏,
            # 影响观看体验。同等信息上面 [chat.thinking.diag] 已 print 到
            # stdout,后端排查走日志即可,不再污染实例日志栏。
            # 如需恢复,反注释下方 try 块即可。
            #
            # try:
            #     _diag_fields = []
            #     for _f in ("enable_thinking", "reasoning_effort", "thinking", "extra_body"):
            #         if _f in payload:
            #             _diag_fields.append(_f)
            #     await utils.add_temp_log(
            #         pool, db_id,
            #         f"[第{loop_count}轮·思考开关] "
            #         f"实例={int(thinking_enabled_inst)} "
            #         f"模型支持={int(bool(is_thinking_model_flag))}({ts_source}) "
            #         f"下发字段=[{', '.join(_diag_fields) or '无'}] "
            #         f"max_tokens={payload.get('max_tokens')}"
            #     )
            # except Exception as _tlog_e:
            #     print(f"[chat.thinking.diag.tlog] 写 temp_log 失败: {_tlog_e}", flush=True)

            # v12.3 (2026-05-12) 诊断:把发给 LLM 的整个 messages 列表打到 stdout
            # 只在第 1 轮打(后续轮次会有工具结果累积,体积膨胀,刷屏没意义)
            # 用户反映 AI 重复发同一段消息时,这是验证"发给 LLM 的消息列表究竟
            # 是不是预期"的唯一可靠手段
            if loop_count == 1:
                try:
                    _dbg_lines = [f"[chat.diag] db_id={db_id} uid={uid} is_proactive={is_proactive} 共 {len(messages)} 条:"]
                    for _i, _m in enumerate(messages):
                        _role = _m.get("role", "?")
                        _c    = _m.get("content", "")
                        if isinstance(_c, list):
                            # 多模态 content list
                            _c = f"<multimodal x{len(_c)} items>"
                        elif not isinstance(_c, str):
                            _c = str(_c)
                        # 每条最多打 200 字预览,前后各 100
                        if len(_c) > 200:
                            _preview = _c[:100] + " ...[省略" + str(len(_c) - 200) + "字]... " + _c[-100:]
                        else:
                            _preview = _c
                        # 把换行替换为可见标记,方便单行查看
                        _preview = _preview.replace("\n", "⏎")
                        _dbg_lines.append(f"  [{_i}] {_role}: {_preview}")
                    print("\n".join(_dbg_lines), flush=True)
                except Exception as _e:
                    print(f"[chat.diag] 打印 messages 失败: {_e}", flush=True)

            # v9.8:删除[第N轮 请求主模型 思维链入参 max_tokens]日志,内部诊断

            # 仅 2xx 响应的 JSON/结构无效时额外生成一次；任何 HTTP
            # 错误或网络异常都立即返回，不做后台重发。
            resp_json = await _call_llm_with_format_retry(
                llm_client, endpoint, payload, req_headers,
                pool, db_id, f"第{loop_count}轮",
                protocol=m_protocol,
                allow_format_retry=not _format_retry_used,
                diagnostic_meta={
                    "model": model,
                    "key_source": (
                        "model_pricing.api_key" if m_api_key
                        else "system_config.platform_api_key"
                    ),
                },
            )
            if resp_json is None:
                await utils.add_temp_log(
                    pool, db_id,
                    f"[统一回复协议] 请求失败，返回“{REQUEST_FAILED_REPLY}”"
                )
                return {
                    "reply": REQUEST_FAILED_REPLY,
                    "tools": [],
                    "stop_proactive": False,
                }, True
            _format_retry_used = bool(
                _format_retry_used or resp_json.pop("_format_retry_used", False)
            )
            # 请求函数已经把三种协议响应整理为统一 choices 形式。
            try:
                _runtime_stage(
                    "response_processing",
                    f"第{loop_count}轮 · 提取正文、工具和心潮事件",
                )
                # ── 1. 解析响应 ─────────────────────────────────────────
                # v?? (2026-05-27) 工具调用协议大改:
                #   不再读 message.tool_calls (协议层已经不下发 tools 字段)。
                #   改为从 message.content 解析 JSON: {"reply": "...", "tools": [...]}
                #   清洗器 tlc.clean_json_response 负责:
                #     1) JSON 解析(自动剥 markdown 围栏)
                #     2) 提取 reply / tools 字段
                #     3) 全失败时标记 _invalid_json，由本层最多生成两次
                #   清洗后的 content 是纯 reply 文本, tools 是工具调用列表。
                message    = resp_json["choices"][0]["message"]
                raw_content = (message.get("content") or "").strip()
                # 先剥 <thinking> 标签 (老 hotfix, 部分模型把思维链塞 content)
                _content_raw_len = len(raw_content)
                raw_content = tlc.strip_thinking_tags(raw_content)
                if _content_raw_len != len(raw_content):
                    await utils.add_temp_log(
                        pool, db_id,
                        f"[整理] <thinking> 标签命中,正文 {_content_raw_len} → {len(raw_content)} 字"
                    )

                # 业务工具统一由正文 JSON tools 承载。请求体没有注册原生函数，
                # 若上游仍返回原生 functionCall，按协议错误处理，绝不执行。
                native_calls = message.get("tool_calls")
                has_native_calls = isinstance(native_calls, list) and bool(native_calls)

                # clean_json_response 只归一化 reply/tools，会有意丢弃其它字段；
                # 因此先从原始 JSON 中提取并白名单化隐藏的 mind_event。
                # 候选事件必须等整轮响应通过 JSON 与工具协议校验后才可提交；
                # 非法响应里的 mind_event 不能污染心潮状态。
                _mind_event_candidate = dynamic_mind.extract_mind_event(raw_content)

                # 异步日志诊断回调
                async def _tlc_log(msg: str):
                    try:
                        await utils.add_temp_log(pool, db_id, msg)
                    except Exception:
                        pass

                # 思维链主要用于诊断。若 Gemini 中转把完整回复信封放进 thought
                # 且正式正文为空，清洗器只可恢复 reply，工具始终强制清空。
                reasoning  = proto.extract_reasoning(resp_json)

                parsed = await tlc.clean_json_response(
                    raw_content,
                    diag_logger=_tlc_log,
                    reasoning_fallback=reasoning,
                )
                if has_native_calls:
                    parsed = {"reply": "", "tools": [], "_invalid_json": True}
                    await utils.add_temp_log(
                        pool, db_id,
                        "[工具协议] 收到未注册的原生 functionCall，已拒绝执行"
                    )
                invalid_json_response = bool(parsed.pop("_invalid_json", False))
                content    = (parsed.get("reply") or "").strip()
                tool_calls_raw = parsed.get("tools") or []

                # 把正文 JSON tools 翻译成内部统一格式。
                # 输入:  [{"name":"send_emoji","params":{"emoji_id":3}}, ...]
                # 输出:  [{"id":"tc_0","function":{"name":"send_emoji","arguments":'{"emoji_id":3}'}}, ...]
                tool_calls = []
                for i, tc in enumerate(tool_calls_raw):
                    if not isinstance(tc, dict):
                        continue
                    name = tc.get("name") or ""
                    if not name or not isinstance(name, str):
                        continue
                    if name.lower() in _DISABLED_LEGACY_MIND_TOOLS:
                        await utils.add_temp_log(
                            pool, db_id,
                            f"[工具] 已忽略停用的旧心理状态工具: {name}"
                        )
                        continue
                    params = tc.get("params") if isinstance(tc.get("params"), dict) else {}
                    try:
                        args_str = json.dumps(params, ensure_ascii=False)
                    except Exception:
                        args_str = "{}"
                    tool_calls.append({
                        "id": f"tc_{loop_count}_{i}",
                        "type": "function",
                        "function": {"name": name, "arguments": args_str},
                    })

                # ── 思维链响应诊断 (2026-05-17 hotfix) ────────────────────
                # 必看字段:
                #   reasoning_len : extract_reasoning 抽到的字数,0 = 上游没返思维链
                #   prompt/completion/reasoning_tokens : 计费侧的细分 token
                # 排查路径:
                #   reasoning_len=0 但 inst_enabled=1 且 payload.enable_thinking=True
                #   → 上游聚合层/模型没听话(本地代码完整发出去了),改请求侧无用,
                #     要么换支持的模型, 要么在 llm_protocol_openai 里恢复多字段下发
                #   reasoning_len>0 但日志里看不到
                #   → 走到了下面 if reasoning and thinking_enabled_inst 的另一侧,
                #     检查 thinking_enabled_inst 是否在某处被改写
                try:
                    _usage_dbg = resp_json.get("usage", {}) or {}
                    _rsn_tok = (
                        _usage_dbg.get("reasoning_tokens")
                        or _usage_dbg.get("completion_tokens_details", {}).get("reasoning_tokens")
                        or 0
                    )
                    print(
                        f"[chat.thinking.resp][第{loop_count}轮] db_id={db_id} "
                        f"reasoning_len={len(reasoning) if reasoning else 0} "
                        f"content_len={len(content)} "
                        f"prompt_tok={_usage_dbg.get('prompt_tokens', 0)} "
                        f"completion_tok={_usage_dbg.get('completion_tokens', 0)} "
                        f"reasoning_tok={_rsn_tok} "
                        f"tool_calls={len(tool_calls)}",
                        flush=True,
                    )
                except Exception as _diag_e:
                    print(f"[chat.thinking.resp] 打印失败: {_diag_e}", flush=True)

                # ── v12.10 (2026-05-12) 思维链覆盖式写入 ───────────────────
                # 用户明确要求:temp_log 只保留**最新一轮**思维链,旧的覆盖,不积累。
                # 时机:这里就是 LLM 一轮 return 之后、推送给微信之前的位置,
                #       用户在控制台看到的就是最新决策过程。
                # 多轮:有工具时本轮会 continue 进入第二轮,届时再次覆盖
                #       即可,只保留最后一轮思维链。
                # v17 (2026-05-18) 曾改成"reasoning 空也写一条诊断"以暴露失效;
                # 2026-06-14 按用户需求回退该行为: 思维链**抽到才显示**, 没抽到
                # 就不写"自动诊断"那段 rsn=... 的噪音。仍保留两点:
                #   1) 第 1 轮用 overwrite, 即使没思维链也清掉上一轮残留;
                #   2) "rsn 计费>0 却没抽到"时仍 dump 到**控制台**(非用户日志)供排查。
                if thinking_enabled_inst:
                    _ts = time.strftime("%H:%M:%S")
                    _usage_preview = resp_json.get("usage", {})
                    _p_tok = _usage_preview.get("prompt_tokens", 0)
                    _c_tok = _usage_preview.get("completion_tokens", 0)
                    _rsn_tok = (
                        _usage_preview.get("reasoning_tokens")
                        or _usage_preview.get("completion_tokens_details", {}).get("reasoning_tokens")
                        or 0
                    )
                    if reasoning and reasoning.strip():
                        _think_body = f"【思维链】\n{reasoning.strip()}"
                    else:
                        # 2026-06-14 (用户需求): 思维链没抽到时, 用户日志**不再**写
                        # "本轮未抽到, 自动诊断: rsn=..." 那一大段。_think_body=None
                        # 表示本轮不展示思维链段(下方 _log_body 只留 header + 回复)。
                        # 抽到思维链才照常展示 —— 即"抽到就显示, 没抽到就不显示"。
                        _think_body = None

                        # ── v?? (2026-05-27) rsn 计了费却没抽到 → dump 完整原始响应 ──
                        # ⚠ 这是**控制台** dump(print 到服务端 stdout), 不是用户日志,
                        #    用户前台看不到, 故按用户需求保留, 方便 admin 排查
                        #    "上游计了 reasoning_tokens 却没抽到"的字段错位问题。
                        # 目的: 上游(yunwu/gemini)把 reasoning 塞到了我们 4 个备选
                        #       字段之外的位置(比如 choices[0] 直挂、delta、嵌套 dict、
                        #       甚至混进 content)。把整个原始【响应】(不是请求)打到
                        #       控制台, 下次复现时一眼定位 rsn 到底在哪。
                        # 触发条件: 仅当 rsn_tokens>0(确实思考了)但没抽到时才 dump,
                        #          rsn=0(本就没思考)不 dump, 避免日志刷屏。
                        # 只打响应、不打请求: 请求里含 system+history+可能的图片 base64,
                        #          又大又敏感, 且本问题的答案只在响应里。
                        if _rsn_tok and _rsn_tok > 0:
                            try:
                                _choices0 = (resp_json.get("choices") or [{}])[0] or {}
                                _finish_reason = _choices0.get("finish_reason")
                                _raw_dump = json.dumps(
                                    resp_json, ensure_ascii=False, indent=2
                                )
                                _DUMP_MAX = 12000
                                _dump_full_len = len(_raw_dump)
                                if _dump_full_len > _DUMP_MAX:
                                    _raw_dump = (
                                        _raw_dump[:_DUMP_MAX]
                                        + f"\n...[已截断, 完整长度 {_dump_full_len} 字, "
                                        f"如 rsn 不在前 {_DUMP_MAX} 字内请调大 _DUMP_MAX]"
                                    )
                                print(
                                    f"\n{'='*70}\n"
                                    f"[{_ts}][RSN-MISSING-DUMP] db_id={db_id} "
                                    f"第{loop_count}轮 model={model}\n"
                                    f"  现象: rsn_tokens={_rsn_tok} 计费了, 但 4 个备选字段都没抽到\n"
                                    f"  ── max_tokens 排查 ──\n"
                                    f"  finish_reason = {_finish_reason!r}\n"
                                    f"    ('length' = 被 max_tokens 截断, JSON 可能没写完;\n"
                                    f"     'stop'   = 自然结束, 不是 token 不够;\n"
                                    f"     'content_filter' = 被内容过滤吞掉)\n"
                                    f"  completion_tokens(out) = {_c_tok}  "
                                    f"(对比 payload max_tokens=16384, 越接近越可疑)\n"
                                    f"  reasoning_tokens(rsn)  = {_rsn_tok}\n"
                                    f"  ── 完整原始响应(非请求) ──\n"
                                    f"{_raw_dump}\n"
                                    f"{'='*70}",
                                    flush=True,
                                )
                            except Exception as _e_dump:
                                print(
                                    f"[RSN-MISSING-DUMP] db_id={db_id} "
                                    f"dump 原始响应失败: {type(_e_dump).__name__}: {_e_dump}",
                                    flush=True,
                                )

                    # v?? (2026-05-27) 关键修复: 思维链 temp_log 改为"累积",不再"覆盖"
                    # 原因: 工具循环场景下, 第 1 轮 LLM 思考完整 reasoning_content,
                    #       第 2 轮拿到工具结果出最终回复时, 部分上游(如 yunwu/gemini)
                    #       会跳过思考导致第 2 轮 reasoning_content=""。
                    #       老逻辑用 set_temp_log_overwrite 每轮覆盖, 用户最终只看到
                    #       第 2 轮的"未抽到"诊断, 误以为思维链坏了 —— 实际第 1 轮
                    #       是有完整思维链的, 只是被第 2 轮覆盖。
                    # 新逻辑: 第 1 轮用 overwrite 清空旧实例残留, 后续轮用 add_temp_log
                    #         追加, 这样 admin 能看完整的工具循环每一轮思考状态。
                    # 2026-06-14 (用户需求): 抽到思维链 → 照常展示思维链段;
                    # 没抽到(_think_body=None)→ 只写 header + 回复, 不写诊断, 也不留
                    # 空的分隔线。第 1 轮仍用 overwrite, 这样即使本轮没思维链, 也能
                    # 清掉上一轮对话残留的旧思维链(不会出现"上轮思维链赖着不走")。
                    if _think_body:
                        _log_body = (
                            f"[{_ts}] [第{loop_count}轮 · {model}] in={_p_tok} out={_c_tok} rsn={_rsn_tok}\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"{_think_body}\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"【回复】\n{content if content else ('(工具中间轮)' if tool_calls else '(非法空回复·将重试)')}"
                        )
                    else:
                        _log_body = (
                            f"[{_ts}] [第{loop_count}轮 · {model}] in={_p_tok} out={_c_tok} rsn={_rsn_tok}\n"
                            f"【回复】\n{content if content else ('(工具中间轮)' if tool_calls else '(非法空回复·将重试)')}"
                        )
                    if loop_count == 1:
                        # 第 1 轮: 用 overwrite 清空上次对话的残留思维链
                        await utils.set_temp_log_overwrite(pool, db_id, _log_body)
                    else:
                        # 第 2 轮起: 追加, 不覆盖第 1 轮已写入的思维链
                        await utils.add_temp_log(pool, db_id, _log_body)

                # ── 计费 ────────────────────────────────────────────────
                usage = resp_json.get("usage", {})
                cost, p_tok, c_tok, br = billing.calc_cost_from_usage(
                    usage, in_price, out_price, cached_input_price
                )
                cached_tok = int(
                    usage.get("cached_tokens")
                    or (usage.get("prompt_tokens_details") or {}).get("cached_tokens")
                    or 0
                )
                total_prompt_tokens     += p_tok
                total_completion_tokens += c_tok
                total_cached_tokens     += cached_tok
                total_cost              += cost
                _cache_ratio = (cached_tok / p_tok * 100.0) if p_tok else 0.0
                await utils.add_temp_log(
                    pool, db_id,
                    f"[第{loop_count}轮] in={p_tok} out={c_tok}"
                    f" cache_hit={cached_tok} hit_ratio={_cache_ratio:.1f}% "
                    f"cost=¥{cost:.4f} "
                    f"累计=¥{total_cost:.4f}"
                )

                # ── 次数包桶 · 反滥用检测 ───────────────────────────────
                # 只针对走「次数包」计费的请求;判断的是【本次请求】单独的
                # 输入/输出 token(p_tok / c_tok),不是一轮累计。
                # 任意一方 > 30000 → 触发 1 小时封禁(内存)。
                if bucket == "count" and (
                        p_tok > billing.COUNT_PACK_ABUSE_TOKEN_LIMIT
                        or c_tok > billing.COUNT_PACK_ABUSE_TOKEN_LIMIT):
                    _is_new_ban = billing.count_pack_ban_trigger(user_id)
                    await utils.add_temp_log(
                        pool, db_id,
                        f"[次数包·反滥用] 单次请求 token 异常 in={p_tok} out={c_tok} "
                        f"(上限 {billing.COUNT_PACK_ABUSE_TOKEN_LIMIT}),"
                        f"已临时封禁该用户 1 小时"
                    )
                    if _is_new_ban:
                        # 本次新触发 → 立即把提示语发给用户,不再继续生成回复
                        return {"reply": billing.COUNT_PACK_ABUSE_MSG, "tools": [],
                                "stop_proactive": False, "_no_split_send": True}, True

                # 非法 JSON、没有 JSON、空白响应都属于“响应信封损坏”。此处必须
                # 在计费后、任何正文发送或工具执行前截断。绝不能把模型输出的半截
                # 系统指令裸提取成 reply。最多生成两次：第一次纠正，第二次致命。
                if invalid_json_response:
                    if not _format_retry_used and loop_count < max_loops:
                        _format_retry_used = True
                        if raw_content:
                            messages.append({
                                "role": "assistant",
                                "content": raw_content,
                            })
                        messages.append({
                            "role": "user",
                            "content": (
                                "[系统纠正·响应格式] 上一轮没有返回可解析的完整 JSON，"
                                "任何残片都不会发给用户。请重新生成一次完整响应："
                                "必须输出含 reply、tools、mind_event 的完整 JSON；"
                                "调用任何工具时只能写在 JSON tools 中且 reply 为空。"
                                "如果上下文中已有工具结果，"
                                "请直接依据结果生成最终 JSON，不要重复调用同一个工具。"
                            ),
                        })
                        await utils.add_temp_log(
                            pool, db_id,
                            "[响应格式] 无法获取回复内容，重新生成 (1/1)"
                        )
                        await utils.save_context(pool, db_id, history, uid=uid)
                        continue

                    content = REQUEST_FAILED_REPLY
                    accumulated_replies.append(content)
                    _assistant_message_id = (
                        uuid.uuid4().hex if completed_tool_executions else None
                    )
                    history.append(_make_msg(
                        "assistant",
                        content,
                        message_id=_assistant_message_id,
                        tool_executions=completed_tool_executions,
                    ))
                    completed_tool_executions = []
                    await utils.save_context(pool, db_id, history, uid=uid)
                    await utils.add_temp_log(
                        pool, db_id,
                        "[响应格式] 连续两次无法获取回复内容，已停止生成"
                    )
                    break

                # ── 4a. 主动模式 · 旧 "false" 哨兵兼容 ──────────────────
                # 老 prompt 曾允许用 false 表示不发送。统一回复协议已取消静默状态;
                # 若模型仍输出旧哨兵,把它当作空回复违规,进入下方统一重试链路。
                if is_proactive and content and not tool_calls:
                    _stripped = content.strip()
                    _quoted_chars = "\"'`‘’“”「」『』"
                    while _stripped and _stripped[0] in _quoted_chars:
                        _stripped = _stripped[1:]
                    while _stripped and _stripped[-1] in _quoted_chars:
                        _stripped = _stripped[:-1]
                    _stripped = _stripped.rstrip(".。").strip()
                    if _stripped.lower() == "false":
                        content = ""
                        await utils.add_temp_log(
                            pool, db_id,
                            "[统一回复协议] 命中旧 false 哨兵,按空回复违规重新生成"
                        )

                # ── 5. 没有工具调用 → 终结本轮,content 直接发给用户 ─────
                if not tool_calls:
                    if not content:
                        # 旧版主动消息预设允许 reply="" + tools=[] 表示本次不打扰。
                        # 被动消息仍沿用统一协议的非空回复兜底，避免用户消息无响应。
                        if is_proactive:
                            await utils.add_temp_log(
                                pool, db_id,
                                "[主动消息] 模型选择不打扰，接受空 reply，不发送消息"
                            )
                            break
                        if not _format_retry_used and loop_count < max_loops:
                            _format_retry_used = True
                            _empty_reply_correction = (
                                "[系统纠正·统一回复协议] 你上一轮返回了空 reply 且"
                                "没有调用工具，这是非法终态，不能结束本轮。请重新生成:"
                                "如果不需要工具，必须输出非空 reply 和 tools=[]；"
                                "如果必须先使用工具，只能写入 JSON tools 并暂时令"
                                " reply=\"\"，拿到结果后仍必须生成文字。"
                            )
                            messages.append({
                                "role": "user",
                                "content": _empty_reply_correction,
                            })
                            await utils.add_temp_log(
                                pool, db_id,
                                "[统一回复协议] 空 reply + tools=[]，重新生成 (1/1)"
                            )
                            await utils.save_context(pool, db_id, history, uid=uid)
                            continue

                        # 两次生成均为空时按既定协议终止，不能用省略号冒充回复。
                        content = REQUEST_FAILED_REPLY
                        await utils.add_temp_log(
                            pool, db_id,
                            "[统一回复协议] 连续两次空回复，已停止生成"
                        )

                    if _mind_event_candidate is not None:
                        mind_event_for_commit = _mind_event_candidate
                    accumulated_replies.append(content)
                    # 工具在前面的内循环完成后，把执行信息附着到最终可见的
                    # assistant 消息；content 本身仍只有真正发给用户的正文。
                    _assistant_message_id = (
                        uuid.uuid4().hex if completed_tool_executions else None
                    )
                    history.append(_make_msg(
                        "assistant", content,
                        reasoning=(reasoning if thinking_enabled_inst else None),
                        message_id=_assistant_message_id,
                        tool_executions=completed_tool_executions,
                    ))
                    completed_tool_executions = []
                    await utils.save_context(pool, db_id, history, uid=uid)
                    break

                # ── 7. 严格的单一工具协议 ────────────────────────────────
                # 有工具时 reply 必须为空；所有工具执行完并拿到结果后，才进入
                # 下一轮思考。reply 与 tools 同时存在时整轮作废。
                tool_requests = []
                for tc in tool_calls:
                    fn_name = tc.get("function", {}).get("name", "")
                    try:
                        fn_args = json.loads(tc.get("function", {}).get("arguments") or "{}")
                    except Exception:
                        fn_args = {}
                    tool_requests.append((tc, fn_name, fn_args))

                tool_state = tool_contract.classify(bool(content), tool_calls)

                invalid_instructions = {
                    tool_contract.TOOL_WITH_TEXT: (
                        "上一轮同时输出了 reply 和工具调用，整轮已作废，任何工具都"
                        "没有执行。需要工具时必须令 reply=\"\"；系统会等待工具结果，"
                        "下一轮再输出最终文字。若不需要工具，则输出非空 reply 和 tools=[]。"
                    ),
                }
                if tool_state in invalid_instructions:
                    if not _format_retry_used and loop_count < max_loops:
                        _format_retry_used = True
                        messages.append({
                            "role": "user",
                            "content": "[系统纠正·工具协议] " + invalid_instructions[tool_state],
                        })
                        await utils.add_temp_log(
                            pool, db_id,
                            "[工具协议] 组合不合法，未执行工具，重新生成 (1/1)"
                        )
                        continue

                    content = REQUEST_FAILED_REPLY
                    accumulated_replies.append(content)
                    history.append(_make_msg("assistant", content))
                    await utils.save_context(pool, db_id, history, uid=uid)
                    await utils.add_temp_log(
                        pool, db_id,
                        "[工具协议] 连续两次组合不合法，已停止执行"
                    )
                    break

                if _mind_event_candidate is not None:
                    mind_event_for_commit = _mind_event_candidate

                # 只把本轮真正会执行的工具写入计费诊断。
                parsed_for_log = [
                    {"name": name, "params": params}
                    for _, name, params in tool_requests
                ]
                for _parsed in parsed_for_log:
                    _executed_name = _parsed.get("name", "")
                    if _executed_name and _executed_name not in tools_called_in_round:
                        tools_called_in_round.append(_executed_name)

                # 工具中间轮只在本次请求的 messages 中回放，不写入用户可见历史。
                messages.append({"role": "assistant", "content": raw_content})

                # ── 8. 工具串行执行，收齐结果后一次性回传 AI ───────────
                internal_results = []
                for tc, name, params in tool_requests:
                    try:
                        call_key = (
                            str(name),
                            json.dumps(
                                params, ensure_ascii=False, sort_keys=True,
                                separators=(",", ":"),
                            ),
                        )
                    except Exception:
                        call_key = (str(name), str(params))

                    previous_result = executed_tool_results.get(call_key)
                    if previous_result is not None:
                        res_success, res_msg = previous_result
                        duplicate_ignored = True
                        await utils.add_temp_log(
                            pool, db_id,
                            f"[工具][重复调用已跳过] {name}"
                        )
                        history_result = (
                            f"本轮相同调用已执行，未重复执行。原结果：{res_msg}"
                        )
                        completed_tool_executions.append(_new_tool_execution(
                            name,
                            params,
                            status="skipped",
                            success=res_success,
                            result=history_result,
                        ))
                        internal_results.append({
                            "name": name,
                            "success": res_success,
                            "result": history_result,
                            "duplicate_ignored": True,
                        })
                        continue

                    await utils.add_temp_log(pool, db_id, f"[工具][等结果执行] {name}")
                    _runtime_stage(
                        f"tool:{name}",
                        f"第{loop_count}轮 · 等待工具 {name} 执行完成",
                    )
                    try:
                        run_params = dict(params)
                        if name == "send_emoji":
                            # 合并后的表情工具不再由主模型传 ID。它使用
                            # 最近 20 条真实对话 + instances.emojis_json
                            # 交给内部 QE 模型选择；这个内部字段不记入工具历史。
                            run_params["_conversation_context"] = (
                                _recent_context_for_tool(history, limit=20)
                            )
                        if tool_channel == "wechat" and context_token:
                            run_params["_context_token"] = context_token
                        res = await utils.run_skill(
                            name, run_params, pool, db_id, uid, bot_instance,
                            tool_channel=tool_channel,
                        )
                        if isinstance(res, dict):
                            res_success = bool(res.get("success", True))
                            res_msg = str(
                                res.get("message", "")
                                or ("已执行" if res_success else "执行失败")
                            )
                        else:
                            res_success = True
                            res_msg = str(res)
                    except Exception as _exc:
                        res_success = False
                        res_msg = f"工具执行异常: {str(_exc)[:120]}"
                    executed_tool_results[call_key] = (res_success, res_msg)
                    completed_tool_executions.append(_new_tool_execution(
                        name,
                        params,
                        status="completed",
                        success=res_success,
                        result=res_msg,
                    ))
                    internal_results.append({
                        "name": name,
                        "success": res_success,
                        "result": res_msg,
                        "duplicate_ignored": False,
                    })

                result_payload = json.dumps(
                    {"tool_results": internal_results},
                    ensure_ascii=False,
                    separators=(",", ":"),
                )
                messages.append({
                    "role": "user",
                    "content": (
                        "<internal_tool_results>\n"
                        f"{result_payload}\n"
                        "</internal_tool_results>\n"
                        "以上是系统刚刚完成的工具执行结果，不是用户发言，也不是工具"
                        "调用语法。请基于结果继续当前回复，不要向 TA 提到工具、系统或"
                        "内部数据。信息够用时输出非空 reply 和 tools=[]；仍需其他工具时"
                        "可继续在 tools 中调用且 reply 保持为空。不得输出或仿写这个内部块。"
                    ),
                })

                # 结果已写入本次模型消息，继续内循环进行下一轮思考。
                _runtime_stage(
                    "tool_result_ready",
                    f"第{loop_count}轮 · 工具结果已收齐，准备再次思考",
                )
                await utils.save_context(pool, db_id, history, uid=uid)
                continue

            except Exception as e:
                # 处理响应阶段的未预期异常。
                ts_now = time.strftime("%H:%M:%S")
                import traceback
                print(
                    f"[{ts_now}][PostProcessError] db_id={db_id} loop={loop_count} {type(e).__name__}: {e}",
                    flush=True,
                )
                traceback.print_exc()
                await utils.add_temp_log(
                    pool, db_id,
                    f"[第{loop_count}轮][后处理·出错] {type(e).__name__}: "
                    f"{str(e)[:80]},已改用非空文本兜底。"
                )
                return {
                    "reply": _terminal_reply_fallback,
                    "tools": [],
                    "stop_proactive": False,
                }, True

        _runtime_stage("reply_finalizing", "整理最终回复并执行发送前清洗")
        final_reply = "\n".join(accumulated_replies).strip()

        # 终态诊断:让你看到 accumulated_replies 是怎么拼成 final_reply 的
        await utils.add_temp_log(
            pool, db_id,
            f"[最终回复] accumulated_replies 共 {len(accumulated_replies)} 段 → "
            f"final_reply={len(final_reply)}字: "
            f"{final_reply[:120]}{'...' if len(final_reply) > 120 else ''}"
        )
        # v12.3 (2026-05-12) stdout 也打一份,便于跟 [chat.diag] 的输入对照
        # 用户报告 "AI 重复发同一段消息" 时,可以直接 grep db_id 看输入和输出
        print(
            f"[chat.out] db_id={db_id} uid={uid} is_proactive={is_proactive} "
            f"loops={loop_count} final_reply({len(final_reply)}字): "
            f"{final_reply[:300].replace(chr(10), '⏎')}"
            f"{'...' if len(final_reply) > 300 else ''}",
            flush=True,
        )
        if accumulated_replies:
            for i, seg in enumerate(accumulated_replies, 1):
                await utils.add_temp_log(
                    pool, db_id,
                    f"[最终回复·分段{i}] {len(seg)}字: {seg[:100]}{'...' if len(seg) > 100 else ''}"
                )

        if loop_count >= max_loops and not final_reply:
            final_reply = _terminal_reply_fallback
            _assistant_message_id = (
                uuid.uuid4().hex if completed_tool_executions else None
            )
            history.append(_make_msg(
                "assistant",
                final_reply,
                message_id=_assistant_message_id,
                tool_executions=completed_tool_executions,
            ))
            completed_tool_executions = []
            await utils.save_context(pool, db_id, history, uid=uid)
            await utils.add_temp_log(
                pool, db_id,
                "[统一回复协议] 达到最大循环次数，使用最小非空文本兜底"
            )

        # ─────────────────────────────────────────────────────────────────
        # 【发送前清洗】v?? (2026-05-23) — 收敛进 tool_leak_cleaner
        # ─────────────────────────────────────────────────────────────────
        # 历史上这里堆了 D1-D5 + _sanitize_outgoing_text 内部 6 个 step,共约
        # 286 行散落的清洗 + 各种防误伤分支。问题:
        #   1. 每加一种新形态(XML/YAML/中文括号)都要打补丁,代码越积越乱
        #   2. 防御层之间互相不知道彼此判定,出现"清洗后还漏"的怪样本
        #     (如线上 `tool_calls: []` 无引号 YAML 风残骸)
        #   3. 兜底逻辑分散,有些路径清洗后是空也不裸提取,用户静默无回复
        #
        # 现在全部收敛到 tlc.clean() 一个入口:
        #   - 形态层:XML / 中文方括号 / 英文方括号 / fence / YAML 裸 / JSON dict
        #   - 关键字白名单驱动,普通中文括号用法零误伤
        #   - 只做文本清洗:泄漏到正文的调用一律剥除，绝不旁路执行
        #   - 空兜底:cleaned 为空时调用 extract_bare_natural_language,从原文
        #     扫所有未嵌入可疑符号块的中文段拼接,保证用户至少收到一些自然语言
        # ─────────────────────────────────────────────────────────────────
        if final_reply:
            # 日志回调:把 tlc 内部的诊断日志透传到 admin 控制台
            async def _diag_log(msg: str):
                try:
                    await utils.add_temp_log(pool, db_id, msg)
                except Exception:
                    pass

            _reply_before_clean = final_reply
            _before_len = len(final_reply)
            final_reply = await tlc.clean(
                final_reply,
                diag_logger=_diag_log,
            )
            _after_tlc_len = len(final_reply or "")
            if _after_tlc_len != _before_len:
                await utils.add_temp_log(
                    pool, db_id,
                    f"[发送前清洗] 回复内容 {_before_len} → {_after_tlc_len} 字"
                )
            # 模型偶尔会在自然语言正文中夹带异常 ASCII 斜杠。这里是所有渠道
            # 共用的最终模型正文出口：发送前统一移除，同时让下方历史同步逻辑
            # 保存真正发给用户的文本。工具参数和系统生成的链接不经过此清洗。
            _removed_slashes = (final_reply or "").count("/")
            if _removed_slashes:
                final_reply = _clean_outgoing_model_text(final_reply)
                await utils.add_temp_log(
                    pool,
                    db_id,
                    f"[发送前清洗] 已移除异常符号 / 共 {_removed_slashes} 个",
                )
            if not final_reply:
                final_reply = _terminal_reply_fallback
                await utils.add_temp_log(
                    pool, db_id,
                    "[统一回复协议] 发送前清洗结果为空，使用最小非空文本兜底"
                )
            if final_reply != _reply_before_clean:
                # assistant 消息为了抗异常已在轮内入库。清洗改动正文时，
                # 同步成真正发给用户的文本，但保留同一条消息上的工具记录。
                for _saved_message in reversed(history):
                    if _saved_message.get("role") == "assistant":
                        _saved_message["content"] = final_reply
                        await utils.save_context(pool, db_id, history, uid=uid)
                        break

        # ── 心潮回写：最终文本确定后，语义事件只提交一次 ─────────────────
        # 未购买用户的普通聊天不触碰心潮状态；已购买用户保持原有回写。
        if mind_entitled:
            _runtime_stage("mind_commit", "回写本轮心潮状态")
            try:
                mind_commit = await dynamic_mind.commit_turn(
                    pool,
                    db_id,
                    persona_id,
                    is_proactive=is_proactive,
                    mind_event=mind_event_for_commit,
                    final_reply=final_reply,
                    event_id=(mind_event_for_commit or {}).get("event_id") if isinstance(mind_event_for_commit, dict) else None,
                )
                await utils.add_temp_log(
                    pool, db_id,
                    f"[心潮·回写] revision={mind_commit.get('revision')} "
                    f"event={'yes' if mind_event_for_commit else 'missing'} "
                    f"result={mind_commit.get('event_result')} "
                    f"next={mind_commit.get('next_proactive_at')}"
                )
            except Exception as _mind_commit_error:
                # 回复已经成功生成，状态回写失败不能阻止用户收到消息。
                await utils.add_temp_log(
                    pool, db_id,
                    f"[心潮·回写失败] {type(_mind_commit_error).__name__}: "
                    f"{str(_mind_commit_error)[:160]}"
                )

        # ── 计费提交（v2 · 按 bucket 分桶扣费） ────────────────────────────
        # 只要消耗了 token 就提交（即使免费模型 cost=0，也要把 token 量记进对应桶）
        if total_prompt_tokens > 0 or total_completion_tokens > 0:
            _runtime_stage("billing_commit", "提交本轮模型用量与计费记录")
            await billing.commit_usage(
                pool=pool,
                user_id=user_id,
                db_id=db_id,
                bucket=bucket,
                total_cost=total_cost,
                total_prompt_tokens=total_prompt_tokens,
                total_completion_tokens=total_completion_tokens,
                model=model,
                count_pack_id=count_pack_id,
                count_units=loop_count,   # 次数包：一个请求计一次 → 本轮共 loop_count 次请求
            )
            await utils.add_temp_log(
                pool, db_id,
                f"[扣费·总账] {model} 共{loop_count}轮 桶={bucket} "
                f"In:{total_prompt_tokens} Cached:{total_cached_tokens} "
                f"HitRatio:{((total_cached_tokens / total_prompt_tokens * 100.0) if total_prompt_tokens else 0.0):.1f}% "
                f"Out:{total_completion_tokens} Cost:{total_cost:.4f} | "
                f"工具:{tools_called_in_round}",
            )

        # 终态日志:工具已在内循环全部完成，发送层只接收最终正文。
        final_preview = final_reply if len(final_reply) <= 300 else final_reply[:300] + "..."
        await utils.add_temp_log(
            pool, db_id,
            f"[最终回复] reply={final_preview!r} | 工具均已等待完成"
        )

        if final_reply:
            # 同上:后台入库,不阻塞本轮返回;与对话上下文无关。
            _fire_and_forget(_embed_and_save_turn(pool, db_id, persona_id, "assistant", final_reply))

        # 计数自增
        ai_inc   = 1 if final_reply else 0
        user_inc = 0 if is_proactive else 1
        new_ai_count = ai_message_count + ai_inc

        _runtime_stage("stats_commit", "更新实例消息计数")
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "UPDATE instances SET "
                    "  ai_message_count   = ai_message_count   + %s, "
                    "  user_message_count = user_message_count + %s "
                    "WHERE id=%s",
                    (ai_inc, user_inc, db_id),
                )
            await conn.commit()

        # 每满 20 条 AI 回复，归档一次长记忆摘要（仅在真有 AI 回复时触发）
        # v?? (2026-05-27) 加诊断日志: 每次计数后打"距下次总结还差 N 轮",
        # 让 admin 一眼看到是不是计数器没到, 避免误以为长记忆功能坏了。
        if ai_inc:
            _distance = 20 - (new_ai_count % 20)
            if _distance == 20:
                _distance = 0  # 这一轮就是要触发的
            await utils.add_temp_log(
                pool, db_id,
                f"[长期记忆·计数] AI 回复累计 {new_ai_count} 条, "
                f"{'本轮触发总结' if new_ai_count % 20 == 0 else f'距下次总结还差 {_distance} 轮'}"
            )

        if ai_inc and new_ai_count > 0 and new_ai_count % 20 == 0:
            # 长期记忆不属于当前回复的交付条件，放入受引用保护的后台任务；
            # history 深拷贝确保下一轮追加消息不会改变本次待整理快照。
            _fire_and_forget(_summarize_and_embed(
                pool,
                db_id,
                persona_id,
                copy.deepcopy(history),
                endpoint,
                request_api_key,
                model,
                m_protocol,
            ))
            await utils.add_temp_log(
                pool, db_id, "[长期记忆·整理] 已在后台开始"
            )

        return {
            "reply": final_reply,
            "tools": [],
            "stop_proactive": False,
            # 发送层使用模型最终一轮实际收到的同一份配置，避免生成结束与发送
            # 之间控制台恰好被修改，导致 AI 边界和发送切分规则错位。
            "_live_split_rule": _live_split_config["split_rule"],
            "_live_ignore_punctuation": _live_split_config["ignore_punctuation"],
        }, False

    finally:
        # v12.1: typing 指示器由 main.py message_worker 管理,这里 no-op
        pass
