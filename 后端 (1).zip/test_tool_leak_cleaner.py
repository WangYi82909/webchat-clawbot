import unittest

import tool_leak_cleaner as cleaner


class CleanJsonResponseTests(unittest.IsolatedAsyncioTestCase):
    async def test_never_executes_tool_planned_only_inside_reasoning(self):
        reasoning = """
First I should update the emotional state:
{"state":"sweet but reserved"}

The final response is:
```json
{"reply":"嘴挺甜。 刚才问你的还没回答。","tools":[{"name":"update_emotion_state","params":{"state":"sweet"}}]}
```
Ready to send.
"""
        result = await cleaner.clean_json_response(
            "",
            reasoning_fallback=reasoning,
        )
        self.assertEqual(result["reply"], "嘴挺甜。 刚才问你的还没回答。")
        self.assertEqual(result["tools"], [])
        self.assertTrue(result["_recovered_from_reasoning"])

    async def test_reasoning_response_envelopes_are_not_authoritative(self):
        reasoning = """
{"reply":"第一版","tools":[]}
I can do better.
{"reply":"最终版","tools":[]}
"""
        result = await cleaner.clean_json_response(
            "",
            reasoning_fallback=reasoning,
        )
        self.assertEqual(result["reply"], "最终版")
        self.assertEqual(result["tools"], [])
        self.assertTrue(result["_recovered_from_reasoning"])

    async def test_does_not_treat_analysis_state_as_response(self):
        result = await cleaner.clean_json_response(
            "",
            reasoning_fallback='analysis {"state":"thinking"} done',
        )
        self.assertEqual(
            result,
            {"reply": "", "tools": [], "_invalid_json": True},
        )

    async def test_invalid_protocol_fragment_is_never_used_as_reply(self):
        fragment = "现在不能写“或任何格式的旁白或思维链只能输出最终的"
        result = await cleaner.clean_json_response(fragment)
        self.assertEqual(result["reply"], "")
        self.assertEqual(result["tools"], [])
        self.assertTrue(result["_invalid_json"])

    async def test_preserves_explicit_silence_from_reasoning(self):
        result = await cleaner.clean_json_response(
            "",
            reasoning_fallback='final: {"reply":"","tools":[]}',
        )
        self.assertEqual(
            result,
            {"reply": "", "tools": [], "_invalid_json": True},
        )

    async def test_content_with_multiple_json_prefers_response_envelope(self):
        content = (
            'analysis {"state":"thinking"} '
            'final {"reply":"回来了","tools":[]}'
        )
        result = await cleaner.clean_json_response(content)
        self.assertEqual(result, {"reply": "回来了", "tools": []})

    async def test_direct_json_behavior_is_unchanged(self):
        result = await cleaner.clean_json_response(
            '{"reply":"正常正文","tools":[]}'
        )
        self.assertEqual(result, {"reply": "正常正文", "tools": []})

    async def test_normalizes_nested_function_call_tool_shape(self):
        result = await cleaner.clean_json_response(
            '{"reply":"在呢。","tools":[{"function_call":{'
            '"name":"write_couple_note","args":{"content":"记下这一刻"}}}]}'
        )
        self.assertEqual(result["reply"], "在呢。")
        self.assertEqual(
            result["tools"],
            [{
                "name": "write_couple_note",
                "params": {"content": "记下这一刻"},
            }],
        )


class HiddenToolHistoryLeakTests(unittest.IsolatedAsyncioTestCase):
    async def test_special_tags_are_removed_but_text_is_preserved(self):
        result = await cleaner.clean("<special>字</special>")
        self.assertEqual(result, "字")

    async def test_special_tags_support_attributes_case_and_partial_tags(self):
        self.assertEqual(
            await cleaner.clean('<SPECIAL tone="soft">你好</SPECIAL>'),
            "你好",
        )
        self.assertEqual(await cleaner.clean("<special>只有开始"), "只有开始")
        self.assertEqual(await cleaner.clean("只有结束</special>"), "只有结束")

    async def test_special_cleaning_does_not_remove_other_tags(self):
        result = await cleaner.clean("<em>保留</em><special>内容</special>")
        self.assertEqual(result, "<em>保留</em>内容")

    async def test_system_owned_tool_note_is_never_sent_to_user(self):
        result = await cleaner.clean(
            "今晚有点冷。\n【工具执行：你在发送这条消息时调用 get_weather、"
            "获取 北京，get_weather 返回了 8℃】"
        )
        self.assertEqual(result, "今晚有点冷。")

    async def test_note_only_output_is_cleared(self):
        result = await cleaner.clean(
            "【工具执行：你在发送这条消息时调用 send_emoji、获取 3，"
            "send_emoji 返回了已发送】"
        )
        self.assertEqual(result, "")


if __name__ == "__main__":
    unittest.main()
