#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
瑞幸咖啡 MCP × OpenAI 兼容接口 命令行助手
=========================================

把「瑞幸咖啡 MCP 服务」(Streamable HTTP) 暴露的 8 个工具, 桥接到任意
OpenAI 兼容的  /v1/chat/completions  接口 (OpenAI / 各类中转 / 本地推理),
让大模型用 function calling 自动串联「找店 → 选品 → 预览 → 下单 → 支付 → 查询」。

首次运行会引导你填写:
  1. OpenAI 兼容接口 Base URL (到 /v1 为止)
  2. 接口密钥 API Key
  3. 模型名称 (需支持 function calling / tool use)
  4. 瑞幸 MCP 地址 (默认已填)
  5. 瑞幸 MCP Token (登录后复制的 Token)
  6. (可选) 默认经纬度, 省得每次报坐标

依赖:
    pip install openai mcp
    # 可选, 装了会在终端里直接渲染支付二维码:
    pip install qrcode

运行:
    python luckin_mcp_agent.py
    python luckin_mcp_agent.py --reconfigure   # 重新配置

对话中的命令:
    /quit 或 退出   结束(退出时会打印本次累计 token 用量)
    /reset          清空当前对话(重新开始上下文, 累计 token 不清零)
    /tools          查看已加载的工具
    /tokens         查看本次运行累计的 token 用量
    /help           帮助

特性:
    - 若模型返回思维链(reasoning_content / reasoning / <think> 标签), 会以 [思考] 显示
    - 每处理完一条用户消息, 打印本轮 输入/输出/合计 token
"""

import argparse
import asyncio
import json
import re
import sys
from getpass import getpass
from pathlib import Path

# ---- 依赖检查 --------------------------------------------------------------
_missing = []
try:
    from openai import AsyncOpenAI
except ImportError:
    AsyncOpenAI = None
    _missing.append("openai")

try:
    from mcp import ClientSession
    from mcp.client.streamable_http import streamablehttp_client
except ImportError:
    ClientSession = None
    streamablehttp_client = None
    _missing.append("mcp")

if _missing:
    print("缺少依赖: " + ", ".join(_missing))
    print("请先运行:  pip install " + " ".join(_missing))
    sys.exit(1)

try:
    import qrcode  # 可选依赖: 终端渲染支付二维码
except ImportError:
    qrcode = None


# ---- 编码修复 --------------------------------------------------------------
def setup_io() -> None:
    """强制把标准输入/输出设为 UTF-8。
    某些 SSH / 容器环境 LANG 未设或为 C/POSIX, input() 会用非 UTF-8 解码,
    敲中文会产生孤立代理项(lone surrogate), 拼进请求体做 UTF-8 编码时报
    'surrogates not allowed'。这里在启动时纠正编码, 从根源避免。"""
    for name in ("stdin", "stdout", "stderr"):
        stream = getattr(sys, name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        try:
            if name == "stdin":
                # 读端遇到非法字节用 U+FFFD 替换, 不产生代理项
                reconfigure(encoding="utf-8", errors="replace")
            else:
                reconfigure(encoding="utf-8")
        except Exception:
            pass


def sanitize(s):
    """兜底: 去掉字符串里的孤立代理项, 保证能安全 UTF-8 编码进 JSON 请求体。
    正常文本原样返回; 只有异常字符会被替换为 '?'。"""
    if not isinstance(s, str):
        return s
    try:
        s.encode("utf-8")
        return s
    except UnicodeEncodeError:
        return s.encode("utf-8", "replace").decode("utf-8")


# ---- 常量 ------------------------------------------------------------------
CONFIG_DIR = Path.home() / ".luckin_coffee_mcp"
CONFIG_PATH = CONFIG_DIR / "config.json"
DEFAULT_MCP_URL = "https://gwmcp.lkcoffee.com/order/user/mcp"
DEFAULT_BASE_URL = "https://api.openai.com/v1"
DEFAULT_MODEL = "gpt-4o"
MAX_TOOL_ROUNDS = 15  # 单轮用户消息内, 允许模型连续调用工具的最大回合(防死循环)

REQUIRED_KEYS = ("base_url", "api_key", "model", "mcp_url", "mcp_token")


# ---- token 用量追踪 --------------------------------------------------------
class Usage:
    """累计本次运行的 token 用量。"""

    def __init__(self):
        self.prompt = 0
        self.completion = 0
        self.total = 0
        self.calls = 0

    def add(self, u) -> tuple:
        """把一次响应的 usage 累加进来, 返回本次的 (输入, 输出, 合计)。"""
        if u is None:
            return (0, 0, 0)
        p = getattr(u, "prompt_tokens", 0) or 0
        c = getattr(u, "completion_tokens", 0) or 0
        t = getattr(u, "total_tokens", 0) or (p + c)
        self.prompt += p
        self.completion += c
        self.total += t
        self.calls += 1
        return (p, c, t)


# ---- 思维链 / 正文 提取 ----------------------------------------------------
def _split_think(content: str):
    """从正文里剥离 <think>...</think>, 返回 (思考, 去掉think后的正文)。"""
    if not content:
        return None, content
    m = re.search(r"<think>(.*?)</think>", content, re.DOTALL)
    if m:
        reasoning = m.group(1).strip()
        cleaned = (content[: m.start()] + content[m.end():]).strip()
        return reasoning, cleaned
    return None, content


def extract_reasoning_and_content(msg):
    """兼容多种返回思维链的方式:
    1) message.reasoning_content (DeepSeek 等)
    2) message.reasoning (部分中转/OpenRouter)
    3) 正文里的 <think>...</think> (部分本地/开源模型)
    返回 (思维链, 用于展示与回填历史的正文)。
    """
    content = msg.content or ""
    reasoning = None
    for attr in ("reasoning_content", "reasoning"):
        v = getattr(msg, attr, None)
        if v:
            reasoning = v
            break
    if reasoning is None:
        extra = getattr(msg, "model_extra", None)
        if isinstance(extra, dict):
            reasoning = extra.get("reasoning_content") or extra.get("reasoning")

    think, cleaned = _split_think(content)
    if think:
        content = cleaned
        if not reasoning:
            reasoning = think
    return reasoning, content


# ---- 系统提示词 ------------------------------------------------------------
# 这段是重点: 告诉模型自己有哪些工具、按什么顺序用、每个参数从哪来、
# 以及下单/支付/查询这些关键节点该怎么处理。
SYSTEM_PROMPT_TEMPLATE = """你是「瑞幸咖啡点单助手」。你可以调用一组瑞幸咖啡 MCP 工具, 帮用户完成从找店、选品到下单、支付、查询的完整点咖啡流程。请用简洁、友好的中文与用户交流。

# 你拥有的工具
- queryShopList: 根据经纬度查询附近瑞幸门店, 返回 deptId(门店ID)、门店名、地址、distance(距离)等。后续几乎所有工具都依赖 deptId。
- searchProductForMcp: 在指定门店内, 按用户的自然语言描述搜索并推荐商品, 返回 productId、skuCode、价格、可选属性(温度/糖度/规格等)。
- switchProduct: 切换商品属性, 返回切换后的新 skuCode。切换后必须使用新的 skuCode。
- queryProductDetailInfo: 查询某个商品的详细属性。
- previewOrder: 下单前预览, 返回实付价格 discountPrice、预计取餐时间 aboutTime、可用优惠券 couponCodeList 等。
- createOrder: 正式创建订单, 返回 orderId、支付链接 payOrderUrl、支付二维码图片 payOrderQrCodeUrl、实付价 discountPrice。
- queryOrderDetailInfo: 查询订单状态、取餐码等。
- cancelOrder: 取消未完成的订单。

# 标准下单流程(请严格按顺序执行)
1. 【定位门店】调用 queryShopList, 必须传经纬度 longitude / latitude。若用户没给位置, 先询问, 或使用系统提供的默认坐标。可按 distance 推荐最近门店, 并与用户确认在哪家门店下单, 记住该门店的 deptId。
2. 【搜索商品】调用 searchProductForMcp(传 deptId 和用户原话 query)匹配商品, 记住 productId 和 skuCode。
3. 【调整属性 · 可选】若用户对温度/甜度/规格等有要求且默认不符, 调用 switchProduct 切换(operation 传 3 表示选中该属性值), 得到新的 skuCode。每次切换都基于当前最新的 skuCode。
4. 【预览订单】调用 previewOrder, 向用户展示实付价格与预计取餐时间。优惠券只能来自本步返回的 couponCodeList, 绝不能自行编造或用其它来源的券码。
5. 【确认后创建订单】用户确认无误后调用 createOrder, 传 deptId、商品列表 productList(每项含 productId / skuCode / amount)、经纬度; 如有优惠券带上 couponCodeList; 如有"少冰/少糖/去奶泡"等要求放进 remark。
6. 【引导支付】拿到 payOrderUrl 和 payOrderQrCodeUrl 后, 清晰地把支付链接和二维码图片地址展示给用户, 提醒尽快支付(支付有超时)。不要假装订单已支付。
7. 【查询状态 · 可选】需要时用 queryOrderDetailInfo 查询/轮询订单状态; 当状态为"等待取餐(60)"时, 把取餐码 takeMealCodeInfo.code 醒目地告诉用户。

# 订单状态码
10=待付款, 20=下单成功, 30=制作中, 60=等待取餐, 80=已完成, 100=已取消。

# 关键规则(务必遵守)
- deptId、skuCode、couponCodeList、orderId 等参数一律使用对应工具的真实返回值, 不要凭空编造。
- 切换属性后一定用新的 skuCode; 创建订单用最终确认的 skuCode。
- 在"创建订单"和"支付"这类关键节点前, 先跟用户确认(商品、数量、口味、价格)。
- 缺少必要信息(位置、门店、商品、口味、数量等)时, 主动而简洁地向用户提问, 一次尽量只问关键的一两点。
- 多杯 / 多种商品时, productList 里可包含多个商品项, 注意各自的 amount。
- 展示价格、预计取餐时间(aboutTime 是时间戳, 可换算成易读时间)、取餐码时, 要清晰醒目。
- 用户要退单时用 cancelOrder; 已完成订单无法取消。
- 回复中禁止使用任何 Emoji / 表情符号, 用纯文本表达。

请始终围绕"帮用户顺利点到并取到咖啡"来行动, 每一步调用工具前先想清楚参数来源。"""


def build_system_prompt(cfg: dict) -> str:
    """根据配置拼接系统提示词; 如配置了默认坐标, 追加到提示词末尾。"""
    prompt = SYSTEM_PROMPT_TEMPLATE
    lng = cfg.get("default_longitude")
    lat = cfg.get("default_latitude")
    if lng and lat:
        prompt += (
            "\n\n# 用户默认位置\n"
            f"用户已配置默认坐标: 经度 {lng}, 纬度 {lat}。"
            "当用户没有特别指定其它位置时, 默认用这组坐标去 queryShopList 查询门店。"
        )
    return prompt


# ---- 配置读写 --------------------------------------------------------------
def _ask(text: str, default: str = None, secret: bool = False) -> str:
    suffix = f" [{default}]" if default else ""
    while True:
        if secret:
            val = getpass(f"{text}{suffix}: ").strip()
        else:
            val = input(f"{text}{suffix}: ").strip()
        if not val and default is not None:
            return default
        if val:
            return val
        print("  该项必填, 请输入。")


def _normalize(cfg: dict) -> dict:
    """规整用户输入: 去掉 base_url 末尾的 /chat/completions, 去掉 token 的 'Bearer '。"""
    base = (cfg.get("base_url") or "").strip().rstrip("/")
    if base.lower().endswith("/chat/completions"):
        base = base[: -len("/chat/completions")].rstrip("/")
    cfg["base_url"] = base

    token = (cfg.get("mcp_token") or "").strip()
    if token.lower().startswith("bearer "):
        token = token[7:].strip()
    cfg["mcp_token"] = token
    return cfg


def load_or_create_config(force: bool = False) -> dict:
    if CONFIG_PATH.exists() and not force:
        try:
            cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            if all(cfg.get(k) for k in REQUIRED_KEYS):
                return _normalize(cfg)
            print("检测到配置不完整, 需要重新配置。\n")
        except Exception:
            print("配置文件读取失败, 需要重新配置。\n")

    print("=" * 48)
    print(" 首次配置 (以后会记住; 用 --reconfigure 可重配)")
    print("=" * 48)
    cfg = {}
    cfg["base_url"] = _ask("OpenAI 兼容接口 Base URL(到 /v1 为止)", default=DEFAULT_BASE_URL)
    cfg["api_key"] = _ask("接口密钥 API Key", secret=True)
    cfg["model"] = _ask("模型名称(需支持 tool use, 如 gpt-4o)", default=DEFAULT_MODEL)
    cfg["mcp_url"] = _ask("瑞幸 MCP 地址", default=DEFAULT_MCP_URL)
    cfg["mcp_token"] = _ask("瑞幸 MCP Token(无需带 Bearer)", secret=True)

    lng = input("默认经度 longitude(可选, 回车跳过): ").strip()
    lat = input("默认纬度 latitude(可选, 回车跳过): ").strip()
    if lng:
        cfg["default_longitude"] = lng
    if lat:
        cfg["default_latitude"] = lat

    cfg = _normalize(cfg)
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        CONFIG_PATH.chmod(0o600)  # 仅本人可读, 保护密钥
    except Exception:
        pass
    print(f"\n配置已保存到: {CONFIG_PATH}\n")
    return cfg


# ---- MCP 工具 → OpenAI 工具 格式转换 --------------------------------------
def mcp_tools_to_openai(tools) -> list:
    result = []
    for t in tools:
        schema = getattr(t, "inputSchema", None) or {"type": "object", "properties": {}}
        result.append(
            {
                "type": "function",
                "function": {
                    "name": t.name,
                    "description": (t.description or "").strip(),
                    "parameters": schema,
                },
            }
        )
    return result


async def call_mcp_tool(session: "ClientSession", name: str, args: dict) -> str:
    """执行一次 MCP 工具调用, 把返回内容拼成字符串(通常是 JSON 文本)。"""
    try:
        result = await session.call_tool(name, args)
    except Exception as e:
        return json.dumps({"error": f"工具调用失败: {e}"}, ensure_ascii=False)

    parts = []
    for block in getattr(result, "content", []) or []:
        text = getattr(block, "text", None)
        if text is not None:
            parts.append(text)
        else:
            data = getattr(block, "data", None)
            parts.append(str(data) if data is not None else str(block))
    out = "\n".join(parts) if parts else "(工具无返回内容)"
    if getattr(result, "isError", False):
        out = "工具返回错误: " + out
    return sanitize(out)


# ---- 输出美化 / 高亮关键信息 ----------------------------------------------
def _compact(args: dict, limit: int = 140) -> str:
    try:
        s = json.dumps(args, ensure_ascii=False)
    except Exception:
        s = str(args)
    return s if len(s) <= limit else s[:limit] + "…"


def _banner(title: str, lines: list) -> None:
    print("\n" + "─" * 44)
    print(title)
    print("─" * 44)
    for line in lines:
        print(line)
    print("─" * 44)


def _try_parse_json(text: str):
    if not isinstance(text, str):
        return None
    t = text.strip()
    if t.startswith("```"):
        t = t.strip("`")
        nl = t.find("\n")
        if nl != -1:
            t = t[nl + 1:]
    try:
        return json.loads(t)
    except Exception:
        return None


def _find_first(obj, key):
    """在嵌套 dict/list 里深度优先查找第一个匹配 key 的值。"""
    found = [None]

    def rec(o):
        if found[0] is not None:
            return
        if isinstance(o, dict):
            if key in o:
                found[0] = o[key]
                return
            for v in o.values():
                rec(v)
        elif isinstance(o, list):
            for it in o:
                rec(it)

    rec(obj)
    return found[0]


def render_highlights(name: str, result_text: str) -> None:
    """针对下单/查询订单, 把支付链接、取餐码等关键信息醒目地打印出来。"""
    data = _try_parse_json(result_text)
    if data is None:
        return

    if name == "createOrder":
        pay_url = _find_first(data, "payOrderUrl")
        qr_url = _find_first(data, "payOrderQrCodeUrl")
        order_id = _find_first(data, "orderId")
        price = _find_first(data, "discountPrice")
        if pay_url or qr_url:
            lines = []
            if order_id is not None:
                lines.append(f"订单号  : {order_id}")
            if price is not None:
                lines.append(f"实付金额: {price}")
            if pay_url:
                lines.append(f"支付链接: {pay_url}")
            if qr_url:
                lines.append(f"二维码图: {qr_url}")
            _banner("[订单待支付] 请尽快完成付款", lines)
            if qrcode is not None and pay_url:
                print("扫码支付(若无法识别, 请打开上方“二维码图”链接):")
                try:
                    qr = qrcode.QRCode(border=1)
                    qr.add_data(pay_url)
                    qr.make(fit=True)
                    qr.print_ascii(invert=True)
                except Exception:
                    pass

    elif name == "queryOrderDetailInfo":
        tmc = _find_first(data, "takeMealCodeInfo")
        code = tmc.get("code") if isinstance(tmc, dict) else None
        status_name = _find_first(data, "orderStatusName")
        if code:
            lines = []
            if status_name:
                lines.append(f"订单状态: {status_name}")
            lines.append(f"取餐码  : {code}")
            _banner("[取餐码]", lines)


# ---- 对话主循环 ------------------------------------------------------------
def print_reasoning(reasoning: str) -> None:
    """打印模型的思维链(思考过程)。"""
    if not reasoning:
        return
    text = reasoning.strip()
    print("\n[思考]")
    for line in text.splitlines():
        print("  " + line)


def print_turn_usage(p: int, c: int, t: int, calls: int) -> None:
    print(f"[本轮 tokens] 输入 {p} · 输出 {c} · 合计 {t}  (模型调用 {calls} 次)")


async def run_turn(client, session, cfg, openai_tools, messages, usage: "Usage") -> None:
    """处理一条用户消息: 反复请求模型, 模型要调工具就执行并回填, 直到给出文字回复。"""
    turn_p = turn_c = turn_t = turn_calls = 0

    for _ in range(MAX_TOOL_ROUNDS):
        try:
            resp = await client.chat.completions.create(
                model=cfg["model"],
                messages=messages,
                tools=openai_tools,
                tool_choice="auto",
            )
        except UnicodeEncodeError as e:
            print(f"\n[编码错误] {e}")
            print("终端疑似非 UTF-8 环境。建议在启动前设置:")
            print("  export LANG=C.UTF-8 LC_ALL=C.UTF-8   (或 zh_CN.UTF-8)")
            print("然后重新运行本脚本。")
            if turn_calls:
                print_turn_usage(turn_p, turn_c, turn_t, turn_calls)
            return
        except Exception as e:
            print(f"\n[调用模型出错] {e}")
            print("(请检查 Base URL / API Key / 模型名, 或该模型是否支持工具调用)")
            if turn_calls:
                print_turn_usage(turn_p, turn_c, turn_t, turn_calls)
            return

        # 统计本次调用的 token(累加进本轮与全局)
        p, c, t = usage.add(getattr(resp, "usage", None))
        turn_p += p
        turn_c += c
        turn_t += t
        turn_calls += 1

        msg = resp.choices[0].message
        reasoning, content = extract_reasoning_and_content(msg)

        # 先打思维链, 再打模型正文
        print_reasoning(reasoning)
        if content:
            print(f"\n助手: {content}")

        # 记录 assistant 这一步的输出(含可能的工具调用), 供下一次请求携带
        # 历史里只保留正文(去掉 <think>), 不回填思维链
        assistant_msg = {"role": "assistant", "content": content}
        if msg.tool_calls:
            assistant_msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in msg.tool_calls
            ]
        messages.append(assistant_msg)

        # 没有工具调用 → 本轮结束
        if not msg.tool_calls:
            print_turn_usage(turn_p, turn_c, turn_t, turn_calls)
            return

        # 逐个执行工具调用, 结果回填为 role=tool 消息
        for tc in msg.tool_calls:
            name = tc.function.name
            try:
                args = json.loads(tc.function.arguments or "{}")
            except json.JSONDecodeError:
                args = {}
            print(f"   -> 调用工具 {name}({_compact(args)})")
            result_text = await call_mcp_tool(session, name, args)
            render_highlights(name, result_text)
            messages.append(
                {"role": "tool", "tool_call_id": tc.id, "content": result_text}
            )
        # 回到循环顶部, 让模型基于工具结果继续

    print("\n[已达到工具调用回合上限, 已停止本轮。可继续输入以推进。]")
    print_turn_usage(turn_p, turn_c, turn_t, turn_calls)


def print_tools(mcp_tools) -> None:
    print(f"已加载 {len(mcp_tools)} 个瑞幸工具:")
    for t in mcp_tools:
        desc = ""
        if t.description:
            desc = t.description.strip().splitlines()[0]
        print(f"  • {t.name} — {desc}")


HELP_TEXT = """可用命令:
  /tools   查看已加载的工具
  /tokens  查看本次运行累计的 token 用量
  /reset   清空当前对话, 重新开始
  /help    显示本帮助
  /quit    退出 (也可输入 退出 / exit / quit)

示例说说看:
  帮我来一杯冰美式
  在海西金谷广场下一杯葡萄冰萃, 少少甜, 冰
  来两杯热拿铁
  使用优惠券, 下一杯生椰拿铁
  找一下附近的瑞幸门店
  帮我看一下最近这单到哪了"""


def print_total_usage(usage: "Usage") -> None:
    print("\n本次运行累计 token 用量:")
    print(f"  输入 prompt     : {usage.prompt}")
    print(f"  输出 completion : {usage.completion}")
    print(f"  合计 total      : {usage.total}")
    print(f"  模型调用次数     : {usage.calls}")


async def chat_loop(client, session, cfg, openai_tools, mcp_tools) -> None:
    system_prompt = build_system_prompt(cfg)
    messages = [{"role": "system", "content": system_prompt}]
    usage = Usage()  # 本次运行的累计 token 用量

    print("\n" + "=" * 48)
    print(" 瑞幸咖啡助手已就绪")
    print("=" * 48)
    print_tools(mcp_tools)
    print("\n输入需求开始点单, /help 查看帮助, /tokens 看用量, /quit 退出。")

    while True:
        try:
            user_input = await asyncio.to_thread(input, "\n你 > ")
        except (EOFError, KeyboardInterrupt):
            print_total_usage(usage)
            print("\n再见")
            return

        user_input = sanitize(user_input.strip())
        if not user_input:
            continue
        low = user_input.lower()
        if low in ("/quit", "/exit", "exit", "quit") or user_input == "退出":
            print_total_usage(usage)
            print("\n再见")
            return
        if low == "/reset":
            messages = [{"role": "system", "content": system_prompt}]
            print("(对话已重置; 累计 token 用量不清零)")
            continue
        if low == "/tools":
            print_tools(mcp_tools)
            continue
        if low in ("/tokens", "/usage"):
            print_total_usage(usage)
            continue
        if low == "/help":
            print(HELP_TEXT)
            continue

        messages.append({"role": "user", "content": user_input})
        await run_turn(client, session, cfg, openai_tools, messages, usage)


# ---- 入口 ------------------------------------------------------------------
async def main_async(cfg: dict) -> None:
    headers = {"Authorization": f"Bearer {cfg['mcp_token']}"}
    print("正在连接瑞幸 MCP ...")
    try:
        async with streamablehttp_client(cfg["mcp_url"], headers=headers) as (read, write, _):
            async with ClientSession(read, write) as session:
                await session.initialize()
                tools_result = await session.list_tools()
                mcp_tools = tools_result.tools
                openai_tools = mcp_tools_to_openai(mcp_tools)

                client = AsyncOpenAI(base_url=cfg["base_url"], api_key=cfg["api_key"])
                await chat_loop(client, session, cfg, openai_tools, mcp_tools)
    except Exception as e:
        print(f"\n[连接 MCP 失败] {e}")
        print("请检查: 1) MCP 地址是否正确  2) Token 是否有效/未过期(可用 --reconfigure 重配)  3) 网络是否可访问该服务。")
        sys.exit(1)


def main() -> None:
    setup_io()  # 首先纠正标准输入/输出编码, 避免中文输入产生代理项
    parser = argparse.ArgumentParser(description="瑞幸咖啡 MCP × OpenAI 兼容接口 命令行助手")
    parser.add_argument("--reconfigure", "--config", action="store_true",
                        help="强制重新配置端点/密钥/模型/MCP Token")
    args = parser.parse_args()

    cfg = load_or_create_config(force=args.reconfigure)

    try:
        asyncio.run(main_async(cfg))
    except KeyboardInterrupt:
        print("\n再见")


if __name__ == "__main__":
    main()