import unittest
import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

import httpx

import chat


class _Response:
    def __init__(self, data):
        self._data = data
        self.status_code = 200
        self.headers = {"content-type": "application/json"}
        self.text = json.dumps(data, ensure_ascii=False)

    def raise_for_status(self):
        return None

    def json(self):
        return self._data


class _Client:
    def __init__(self, result, calls):
        self.result = result
        self.calls = calls

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return False

    async def post(self, endpoint, **kwargs):
        self.calls.append((endpoint, kwargs))
        if isinstance(self.result, Exception):
            raise self.result
        return _Response(self.result)


class _ClientFactory:
    def __init__(self, results):
        self.results = list(results)
        self.calls = []
        self.create_kwargs = []

    def __call__(self, **kwargs):
        self.create_kwargs.append(kwargs)
        return _Client(self.results.pop(0), self.calls)


class MemorySummaryResilienceTests(unittest.IsolatedAsyncioTestCase):
    async def test_remote_disconnect_is_not_retried(self):
        factory = _ClientFactory([
            httpx.RemoteProtocolError("Server disconnected without sending a response."),
            {
                "choices": [{
                    "message": {"content": "用户喜欢草莓蛋糕"},
                }],
            },
        ])
        with (
            patch("chat.httpx.AsyncClient", side_effect=factory),
            patch("chat.utils.add_temp_log", new=AsyncMock()) as log,
        ):
            result = await chat._request_memory_summary(
                None,
                12,
                "https://model.test/v1/chat/completions",
                "key",
                "model",
                "openai",
                [{"role": "user", "content": "整理"}],
            )
        self.assertEqual(result, "")
        self.assertEqual(len(factory.create_kwargs), 1)
        self.assertGreaterEqual(log.await_count, 1)
        messages = [str(call.args[2]) for call in log.await_args_list]
        self.assertTrue(any("网络异常" in message for message in messages))
        for kwargs in factory.create_kwargs:
            self.assertEqual(kwargs["limits"].max_keepalive_connections, 0)

    async def test_gemini_summary_uses_native_generate_content_payload(self):
        factory = _ClientFactory([{
            "candidates": [{
                "content": {
                    "role": "model",
                    "parts": [{"text": "用户最近在准备考试"}],
                },
            }],
            "usageMetadata": {},
        }])
        with patch("chat.httpx.AsyncClient", side_effect=factory):
            result = await chat._request_memory_summary(
                None,
                12,
                "https://model.test/v1beta/models/gemini:generateContent",
                "key",
                "gemini",
                "gemini",
                [
                    {"role": "system", "content": "整理记忆"},
                    {"role": "user", "content": "对话"},
                ],
            )
        self.assertEqual(result, "用户最近在准备考试")
        payload = factory.calls[0][1]["json"]
        self.assertIn("contents", payload)
        self.assertIn("systemInstruction", payload)
        self.assertNotIn("messages", payload)

    def test_summary_is_scheduled_after_reply_not_awaited(self):
        source = (Path(__file__).parent / "chat.py").read_text(encoding="utf-8")
        trigger = source[source.index("if ai_inc and new_ai_count > 0"):]
        self.assertIn("_fire_and_forget(_summarize_and_embed(", trigger)
        self.assertNotIn("await _summarize_and_embed(", trigger)


if __name__ == "__main__":
    unittest.main()
