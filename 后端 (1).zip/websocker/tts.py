"""tts.py — 语音合成 (DashScope cosyvoice-v3.5-plus + 用户自带 key + 用户音色).

dashscope SpeechSynthesizer.call() 是同步阻塞 (一次性返回完整 mp3 字节). 在
asyncio 里走 run_in_executor.

2026-06-02 改造:
  · api_key 改为每次合成由调用方传入 —— 来自 user_voice_credentials 解密后的
    用户自己 DashScope API key, 不再吃 config.DASHSCOPE_API_KEY (平台 key).
  · dashscope SDK 的 api_key 是模块级全局, 多个用户并发调用时若直接覆盖会互相
    串话(A 的 key 被 B 覆盖 → A 的请求扣到 B 账号). 为避免对 SDK 内部行为做
    假设, 用一把进程级 asyncio.Lock 把"设置 dashscope.api_key + 同步调用"
    序列化掉 —— 牺牲一点并发, 换确定性。语音通话场景每次合成 1-3 秒, 用户
    数量级有限, 串行化代价可接受。

注意:
  · 模型必须是 cosyvoice-v3.5-plus, 因为用户音色是用 plus 克隆的, flash 不通用
  · base_websocket_api_url 是全局变量, 一旦 dashscope 模块加载就锁定. 我们在
    模块第一次被 import 时设置一次, 不再动它.
"""
import asyncio
import logging

import dashscope
from dashscope.audio.tts_v2 import SpeechSynthesizer

from . import config

log = logging.getLogger('voice_ws.tts')

# dashscope 全局 ws 基地址 — 模块加载时设一次
dashscope.base_websocket_api_url = config.TTS_WS_BASE_URL

# 进程级锁: 保证"设置 dashscope.api_key + 调用 synth" 这一对操作的原子性,
# 避免并发合成互相覆盖全局 api_key。ASR 使用实例级 key，不再参与此锁。
# 2026-07 修: 锁挪到 config.py (无 dashscope 依赖), 避免本文件 import dashscope
# 失败时锁也跟着消失、连带 ASR 一起挂掉.
_DASHSCOPE_KEY_LOCK = config.DASHSCOPE_KEY_LOCK


def _sync_synthesize(text: str, voice_id: str, api_key: str) -> bytes:
    """同步合成 — 仅供 run_in_executor 调用. 调用方必须先持有 _DASHSCOPE_KEY_LOCK。"""
    if not api_key:
        raise RuntimeError('TTS 缺少 api_key (用户未填或解密失败)')
    # 仍然设全局, 兼容 SDK 内部任何位置直接读 dashscope.api_key 的实现细节
    dashscope.api_key = api_key
    synth = SpeechSynthesizer(model=config.TTS_MODEL, voice=voice_id)
    audio = synth.call(text)
    if audio is None:
        raise RuntimeError('TTS 返回空音频 (模型/音色 ID 是否匹配?)')
    return audio


async def synthesize(text: str, voice_id: str, api_key: str) -> bytes:
    """文本 -> mp3 字节. 用调用方提供的 api_key (= 用户自己的 DashScope key)。失败抛异常."""
    if not text or not text.strip():
        raise ValueError('合成文本为空')
    if not voice_id:
        raise ValueError('voice_id 为空')
    if not api_key:
        raise ValueError('api_key 为空 (用户语音凭证缺失)')

    loop = asyncio.get_running_loop()
    # 锁内: 设 global + 同步调 — 与并发的其它会话不会互相串 key
    async with _DASHSCOPE_KEY_LOCK:
        return await loop.run_in_executor(None, _sync_synthesize, text, voice_id, api_key)
