"""
write_couple_note.py — 异步工具:为情侣空间「今日笔记」新增一条记录
                       (v1.0 · 2026-05-17)

AI 在和用户聊天过程中遇到值得留念的瞬间(约定 / 心情 / 重要小事)时,
调用本工具悄悄写下一条笔记。笔记会出现在用户的
「我们的小世界(demo.php) → 今日笔记」卡片上(最新一条),
以及该卡片右上角「历史」按钮里的历史列表中。

──────────────────────────────────────────────────────────────────
重要:用户隔离机制
──────────────────────────────────────────────────────────────────
本仓库的 skill 入参 `uid` 是「微信好友的 openid」(聊天对方),
**不是**系统 users.id。所以我们不能直接用 uid 写入 couple_notes.user_id,
否则相当于把所有用户的笔记串成一锅粥。

正确做法:
  通过 db_id 反查 instances.user_id, 拿到 bot 实例的拥有者
  (= 当前控制台登录用户 = 情侣空间的归属者), 再写入 couple_notes.

这样每个用户的情侣空间笔记只会被自己 bot 写入, 互不影响。
"""

import utils

NAME = "write_couple_note"

DESCRIPTION = (
    "在合适的时机，为「我们的小世界 / 情侣空间」新增一条今日笔记(异步)。"
    "当你和用户聊到值得记住的小事 — 心情、约定、温柔细节、彼此承诺、"
    "今天发生过的有意义的瞬间 — 调用本工具悄悄记下,会出现在用户的"
    "「今日笔记」卡片上。每条笔记自动带时间戳,只对该用户可见。"
    "调用本工具时,本轮**必须同时输出一句文字回复**给用户 — 异步工具不"
    "阻塞,你的文字回复会和笔记入库并行进行。**严禁**把回复写到思维链里"
    "而 content 留空,这会被系统判定违规并强制重新生成。"
)

# 标准 JSON Schema (优先级高于 USAGE)
PARAMETERS = {
    "type": "object",
    "properties": {
        "content": {
            "type": "string",
            "description": (
                "笔记正文。建议 20-300 字, 上限 2000 字。"
                "可以是当下的小心情、值得记下的细节、彼此约定。"
                "示例:「今天她说梅雨季让人发愁,我陪她聊了好久花茶的味道,"
                "答应下周一起去她想看的那家书店。」"
            ),
            "minLength": 1,
            "maxLength": 2000,
        }
    },
    "required": ["content"],
    "additionalProperties": False,
}

USAGE = '{"content": "今天她说想去看樱花,我答应她下周末一起去。禁止放置在正文中"}'
MODE = "ASYNC"

MAX_LEN = 2000


async def run(params: dict, pool, db_id, uid, bot_instance) -> dict:
    # ── 1. 校验入参 ──────────────────────────────────────────────────
    content = params.get("content")
    if not isinstance(content, str):
        return {"success": False, "message": "参数 content 必须是字符串"}

    content = content.strip()
    if not content:
        return {"success": False, "message": "笔记内容不能为空"}

    # 长度兜底:静默截断,不要把错误丢回 AI(避免 AI 反复重试浪费 token)
    if len(content) > MAX_LEN:
        content = content[:MAX_LEN]

    if not db_id:
        return {"success": False, "message": "缺少 db_id, 无法定位实例归属"}

    # ── 2. 从 db_id 反查 owner_user_id (情侣空间的真·归属用户) ────────
    # 关键防御:仓库里 skill 的 `uid` 是微信好友 openid (聊天对方),
    # 不能直接拿来当 couple_notes.user_id。必须通过 instances.user_id
    # 拿到 bot 实例的拥有者 (= 控制台登录用户 = 情侣空间归属)。
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT user_id FROM instances WHERE id=%s",
                    (db_id,),
                )
                inst = await cur.fetchone()
    except Exception as e:
        return {
            "success": False,
            "message": f"查询实例归属失败: {str(e)[:120]}",
        }

    if not inst or not inst.get("user_id"):
        return {
            "success": False,
            "message": "未能定位实例所属的用户,无法写入情侣空间笔记。",
        }

    owner_user_id = int(inst["user_id"])

    # ── 3. 写入 couple_notes ────────────────────────────────────────
    import time
    created_at = int(time.time())

    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "INSERT INTO couple_notes (user_id, content, created_at) "
                    "VALUES (%s, %s, %s)",
                    (owner_user_id, content, created_at),
                )
            await conn.commit()
    except Exception as e:
        msg = str(e)
        # 表不存在 → 友好提示, 提醒管理员跑迁移脚本
        if "couple_notes" in msg and "doesn't exist" in msg:
            return {
                "success": False,
                "message": (
                    "couple_notes 表不存在, 请管理员先执行 "
                    "migration_couple_space.sql 后重试。"
                ),
            }
        return {
            "success": False,
            "message": f"数据库写入失败: {msg[:120]}",
        }

    # ── 4. 写一条实例日志(可选, 方便用户在控制台看到 AI 写了笔记) ───
    try:
        preview = content[:60] + ("…" if len(content) > 60 else "")
        await utils.add_temp_log(
            pool, db_id,
            f"[今日笔记] AI 写入 user_id={owner_user_id}: {preview}",
        )
    except Exception:
        # 日志失败不影响主流程
        pass

    # ── 5. 异步工具:成功返回, message 留空 ──────────────────────────
    # ASYNC 工具的 message 不会回流给用户,只用于工具系统内部判定。
    return {"success": True, "message": ""}