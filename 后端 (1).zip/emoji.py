"""
emoji.py — 后台服务引擎（邮件队列 / 邀请奖励 / 周额度重置 / 订阅包过期）

v2 改动（2026-05-06）：
  1. 邮件文案重写：
       - 不再提"每天免费额度"、"邀请 3 人升 plus"
       - 改为"每周 50 万 token / 邀请 1 位永久 +20 万/周"
  2. 邀请奖励规则：
       - 不再发余额（旧：邀请人 +¥2，被邀请人 +¥1，里程碑 +token）
       - 改为：邀请人永久 bonus_weekly_tokens += 200000
       - 不再升 plus，邀请上限无限
  3. 新用户初始化（process_invitation_rewards 也负责）：
       - base_weekly_tokens = 500000
       - last_reset_week = 当前 ISO 周
       - balance += 1.00 元（新用户注册赠送，所有人无差别 · v2.1 恢复）
  4. 把 reset_daily_tokens 改名为 reset_weekly_tokens：
       - WHERE last_reset_week != 当前周
       - UPDATE 仅 weekly_used_tokens=0 与 last_reset_week=当前周
       - 不再触碰 base_weekly_tokens / bonus_weekly_tokens（永久数据）
  5. 新增 expire_pro_packs：
       - plan_expired_at 已过期的 pro 用户 → 清零包字段
"""
import smtplib
import time
import datetime
import pymysql
from email.mime.text import MIMEText

SENDER   = 'cloudloce@foxmail.com'
PASSWORD = ''

DB_CONFIG = {
    'host':        '127.0.0.1',
    'port':        3306,
    'user':        'webchat',
    'password':    '',
    'db':          'webchat',
    'autocommit':  True,
    'cursorclass': pymysql.cursors.DictCursor,
}

# ── 业务常量（与 billing.py / migrate_v2.py / api_user.php 严格对齐） ────
# v?? (2026-05-17) 注册赠送 10 万 → 20 万,与新策略对齐。邀请奖励保持 5 万/人。
REGISTER_GIFT_TOKENS  = 200_000   # 新用户注册赠送:20 万 token / 周
REGISTER_GIFT_BALANCE = 0.50      # 新用户注册赠送:¥0.5 余额(所有用户,与邀请码无关)
INVITE_BONUS_TOKENS   = 50_000    # 邀请 1 人永久叠加:+5 万 token / 周


def current_iso_week() -> str:
    """ISO 周字符串 'YYYY-Www'，与 billing.py.current_iso_week 完全一致。"""
    return datetime.date.today().strftime('%Y-W%V')


# =============================================================================
# 邮件发送
# =============================================================================
# 兼容两种邮件模式:
#   1. 验证码邮件:code 非空,subject/body 留 NULL,渲染固定欢迎模板
#   2. 通用邮件:  code 留 NULL,subject/body 必填,直接当 HTML 邮件发送
#                  ← 用户留言通知管理员、管理员回复通知用户都走这条
# =============================================================================
ADMIN_EMAIL = '2661972761@qq.com'   # 用户留言通知管理员邮箱(硬编码,改这一行即可)


def send_mail(to_email, code=None, subject=None, body=None, is_html=False):
    """
    发送邮件。两种调用方式:
      - send_mail(to, code='123456')                          → 验证码模板
      - send_mail(to, subject='主题', body='<p>正文</p>', is_html=True)  → 通用 HTML
      - send_mail(to, subject='主题', body='正文')            → 通用纯文本
    """
    if code:
        content = (
            f"尊敬的用户，欢迎加入「云上恋人」。\n"
            f"您的验证码是「{code}」\n"
            f"\n"
            f"注册即送 50 万 Token / 周 的免费额度，每周自动刷新，无需任何操作。\n"
            f"另赠送 ¥{REGISTER_GIFT_BALANCE:.2f} 余额，供您体验余额计费模式（全模型解锁，按 Token 实时扣费）。\n"
            f"邀请 1 位新朋友，您将永久获得额外 +20 万 Token / 周 的额度奖励，\n"
            f"奖励叠加到周基础额度上，无上限。\n"
            f"\n"
            f"我们也提供丰富的原生工具体系（生图、识图、语音识别、天气查询等），\n"
            f"推荐使用余额计费，按 Token 实时扣费更透明。\n"
            f"\n"
            f"使用建议：\n"
            f"1. 设定人格时请避免固定化词汇（即不要约束 AI 必须输出某个词汇）\n"
            f"2. 模型默认走订阅包扣费；切换为「余额优先」可解锁全模型\n"
            f"\n"
            f"您的额度已激活：免费版（每周 {REGISTER_GIFT_TOKENS:,} Token + ¥{REGISTER_GIFT_BALANCE:.2f} 余额）"
        )
        msg = MIMEText(content, 'plain', 'utf-8')
        msg['Subject'] = 'Cloud Love 团队验证码'
        log_label = f"Code: {code}"
    elif subject and body:
        msg = MIMEText(body, 'html' if is_html else 'plain', 'utf-8')
        msg['Subject'] = subject
        log_label = f"Subject: {subject[:30]}"
    else:
        print(f"[邮件发送] ✗ 参数错误,需要 code 或 (subject+body)")
        return False

    msg['From'] = SENDER
    msg['To']   = to_email
    try:
        with smtplib.SMTP_SSL('smtp.qq.com', 465) as smtp:
            smtp.login(SENDER, PASSWORD)
            smtp.sendmail(SENDER, [to_email], msg.as_string())
        print(f"[邮件发送] 成功发送给 -> {to_email} ({log_label})")
        return True
    except Exception as e:
        print(f"[邮件发送] 发送失败 -> {to_email}: {e}")
        return False


def ensure_email_queue_schema(conn):
    """
    幂等地给 email_queue 表加缺失字段(2026-05-08):
      subject  VARCHAR(255)  通用邮件主题(NULL=验证码模式)
      body     TEXT          通用邮件正文 HTML/纯文本
      is_html  TINYINT(1)    1=正文按 HTML 渲染,0=纯文本
    重复调用安全。仅在服务启动时执行一次。
    """
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT column_name AS name FROM information_schema.columns "
                "WHERE table_schema = DATABASE() AND table_name = 'email_queue'"
            )
            existing = {(r.get('name') or '').lower() for r in cur.fetchall()}
            need = []
            if 'subject' not in existing:
                need.append("ADD COLUMN `subject` VARCHAR(255) DEFAULT NULL "
                            "COMMENT '通用邮件主题;NULL=走验证码模板'")
            if 'body' not in existing:
                need.append("ADD COLUMN `body` TEXT DEFAULT NULL "
                            "COMMENT '通用邮件正文(HTML 或纯文本)'")
            if 'is_html' not in existing:
                need.append("ADD COLUMN `is_html` TINYINT(1) NOT NULL DEFAULT 0 "
                            "COMMENT '1=body 按 HTML 渲染'")
            if need:
                cur.execute("ALTER TABLE email_queue " + ", ".join(need))
                conn.commit()
                added = [n.split('`')[1] for n in need]
                print(f"[启动检查] email_queue 表已自动补齐字段: {added}")
            else:
                print("[启动检查] email_queue 表字段已齐全")
    except Exception as e:
        print(f"[启动检查] ✗ ensure_email_queue_schema 异常(不影响启动): {e}")


def process_email_queue(conn):
    """处理邮件队列,状态机:0=待发 / 1=成功 / 2=失败 / 3=处理中(乐观锁)。"""
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id, email, code, subject, body, is_html "
                "FROM email_queue WHERE status = 0 LIMIT 5"
            )
            tasks = cur.fetchall()
            for task in tasks:
                cur.execute(
                    "UPDATE email_queue SET status = 3 WHERE id = %s AND status = 0",
                    (task['id'],),
                )
                if cur.rowcount > 0:
                    if task.get('code'):
                        success = send_mail(task['email'], code=task['code'])
                    elif task.get('subject'):
                        success = send_mail(
                            task['email'],
                            subject=task['subject'],
                            body=task.get('body') or '',
                            is_html=bool(int(task.get('is_html') or 0)),
                        )
                    else:
                        success = False
                        print(f"[队列处理] ✗ 任务 ID:{task['id']} 既无 code 也无 subject,标失败")
                    final_status = 1 if success else 2
                    cur.execute(
                        "UPDATE email_queue SET status = %s WHERE id = %s",
                        (final_status, task['id']),
                    )
                    conn.commit()
                    print(f"[队列处理] 邮件任务 ID:{task['id']} 处理完成。")
                else:
                    print(f"[队列处理] 邮件任务 ID:{task['id']} 已被其他进程处理,跳过。")
    except Exception as e:
        conn.rollback()
        print(f"[错误] 处理邮件队列异常: {e}")


# =============================================================================
# 邀请奖励：永久 +20 万 token / 周（v2）
# =============================================================================
def process_invitation_rewards(conn):
    """
    扫描 invite_reward_status=0 的新用户，结算：
      - 新用户：base_weekly_tokens = 500000；last_reset_week = 当前周
                 weekly_used_tokens = 0；plan_type='free'
                 不再发 1 元余额（旧版赠送已下线）
      - 邀请人（如果有）：bonus_weekly_tokens += 200000；invite_count += 1
                          不再发余额、不再升 plus、不再有里程碑奖励
      - 自填邀请码 / 邀请人不存在 → 仅初始化新用户

    最后把 invite_reward_status=1 标记为已结算。
    """
    try:
        cur_week = current_iso_week()

        with conn.cursor() as cur:
            cur.execute(
                "SELECT id, username, invited_by FROM users "
                "WHERE invite_reward_status = 0 FOR UPDATE"
            )
            new_users = cur.fetchall()

            if not new_users:
                return

            for new_user in new_users:
                try:
                    print(f"\n[奖励结算] 发现待处理新用户: {new_user['username']} (ID: {new_user['id']})")

                    # ── 1) 初始化新用户的周额度 + 注册赠送余额 ────────────────
                    #   v2.1 恢复：所有新用户都送 ¥1 余额（与是否填邀请码无关）
                    #   用 balance + ? 的方式累加，避免覆盖任何之前的入账（理论上新用户为 0）
                    cur.execute(
                        "UPDATE users SET "
                        "  plan_type           = 'free', "
                        "  base_weekly_tokens  = %s, "
                        "  bonus_weekly_tokens = 0, "
                        "  weekly_used_tokens  = 0, "
                        "  last_reset_week     = %s, "
                        "  balance             = balance + %s "
                        "WHERE id = %s",
                        (REGISTER_GIFT_TOKENS, cur_week, REGISTER_GIFT_BALANCE, new_user['id']),
                    )
                    print(
                        f" > [新用户初始化] base_weekly_tokens={REGISTER_GIFT_TOKENS}, "
                        f"last_reset_week={cur_week}, balance += ¥{REGISTER_GIFT_BALANCE:.2f}"
                    )

                    # ── 2) 结算邀请人（如果有） ────────────────────────────
                    invite_code_used = (new_user.get('invited_by') or '').strip()
                    if invite_code_used:
                        cur.execute(
                            "SELECT id, username, invite_count "
                            "FROM users WHERE invite_code = %s FOR UPDATE",
                            (invite_code_used,),
                        )
                        inviter = cur.fetchone()

                        if inviter and inviter['id'] != new_user['id']:
                            cur.execute(
                                "UPDATE users SET "
                                "  bonus_weekly_tokens = bonus_weekly_tokens + %s, "
                                "  invite_count        = invite_count + 1 "
                                "WHERE id = %s",
                                (INVITE_BONUS_TOKENS, inviter['id']),
                            )
                            print(
                                f" > [邀请人奖励] 邀请人[{inviter['username']}] "
                                f"永久 +{INVITE_BONUS_TOKENS:,} token/周 "
                                f"(累计邀请 {(inviter['invite_count'] or 0) + 1} 人)"
                            )
                        else:
                            print(f" > [跳过邀请] 未找到有效邀请人或属于自填码。")
                    else:
                        print(f" > [无邀请码] 用户系自主注册。")

                    # ── 3) 标记结算完成 ────────────────────────────────────
                    cur.execute(
                        "UPDATE users SET invite_reward_status = 1 WHERE id = %s",
                        (new_user['id'],),
                    )
                    conn.commit()
                    print(f" > [状态更新] 用户奖励结算流程完成。")

                except Exception as e:
                    conn.rollback()
                    print(f" > [结算失败] 用户 {new_user['username']} (ID: {new_user['id']}) 处理异常: {e}")
                    continue

    except Exception as e:
        conn.rollback()
        print(f"[错误] 处理邀请奖励逻辑异常: {e}")


# =============================================================================
# 周额度重置（替代旧的 reset_daily_tokens · v2）
# =============================================================================
def reset_weekly_tokens(conn):
    """
    跨周重置：last_reset_week != 当前周 的用户 → weekly_used_tokens = 0。

    与 v1 的核心差异：
      - 不再每天跑、不再重置 base_*（base 是稳定数据，只在邀请/admin 改时变）
      - 仅在 weekly_used_tokens 与 last_reset_week 两列上做最小变更

    注：billing.check_quota 也有懒重置（用户访问时立即触发），这里 cron 主要是
    给"长期不上线但有挂机实例"的边缘账户兜底用，避免脏数据无限累积。
    """
    try:
        cur_week = current_iso_week()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT COUNT(*) AS n FROM users "
                "WHERE last_reset_week IS NULL OR last_reset_week = '' OR last_reset_week != %s",
                (cur_week,),
            )
            n = (cur.fetchone() or {}).get('n', 0)
            if not n:
                return

            cur.execute(
                "UPDATE users SET "
                "  weekly_used_tokens = 0, "
                "  last_reset_week    = %s "
                "WHERE last_reset_week IS NULL OR last_reset_week = '' OR last_reset_week != %s",
                (cur_week, cur_week),
            )
            conn.commit()
            print(f"[每周重置] 已重置 {n} 个用户的 weekly_used_tokens (week={cur_week})")
    except Exception as e:
        conn.rollback()
        print(f"[错误] 周额度重置异常: {e}")


# =============================================================================
# 订阅包过期清零（v2 新增）
# =============================================================================
def expire_pro_packs(conn):
    """
    清理已过期的订阅包：
      WHERE plan_type='pro' AND plan_expired_at>0 AND plan_expired_at<now
      → plan_type='free', pro_pack_total=0, pro_pack_used=0

    plan_expired_at=0 视为永久（admin 手动赠送场景），不清理。
    """
    try:
        now = int(time.time())
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id, username, plan_expired_at FROM users "
                "WHERE plan_type = 'pro' AND plan_expired_at > 0 AND plan_expired_at < %s",
                (now,),
            )
            rows = cur.fetchall()
            if not rows:
                return

            cur.execute(
                "UPDATE users SET "
                "  plan_type      = 'free', "
                "  pro_pack_total = 0, "
                "  pro_pack_used  = 0 "
                "WHERE plan_type = 'pro' AND plan_expired_at > 0 AND plan_expired_at < %s",
                (now,),
            )
            conn.commit()

            for r in rows:
                expired_at = datetime.datetime.fromtimestamp(int(r['plan_expired_at'])).strftime('%Y-%m-%d')
                print(
                    f"[包过期清零] user_id={r['id']} ({r['username']}) "
                    f"已过期于 {expired_at}，已降级为 free 并清零 pro_pack_*"
                )
            print(f"[包过期清零] 共清理 {len(rows)} 个过期订阅包")
    except Exception as e:
        conn.rollback()
        print(f"[错误] 订阅包过期清零异常: {e}")


# =============================================================================
# 主循环
# =============================================================================
def run():
    print("==========================================")
    print(" WebChat 后台服务引擎 (邮件/邀请/周重置/包过期) v2 启动...")
    print("==========================================")

    # 启动时检查 email_queue 表结构,缺 subject/body/is_html 字段则自动补齐
    # 让 PHP 端 INSERT 通用邮件(留言通知/回复通知)安全可用
    try:
        _boot_conn = pymysql.connect(**DB_CONFIG)
        ensure_email_queue_schema(_boot_conn)
        _boot_conn.close()
    except Exception as e:
        print(f"[启动检查] ✗ 无法连接数据库或建表失败: {e}")

    while True:
        conn = None
        try:
            conn = pymysql.connect(**DB_CONFIG)
            process_email_queue(conn)
            process_invitation_rewards(conn)
            reset_weekly_tokens(conn)
            expire_pro_packs(conn)
        except Exception as e:
            print(f"[核心异常] 数据库连接或执行中断: {e}")
            if conn:
                try:
                    conn.rollback()
                except Exception:
                    pass
        finally:
            if conn:
                try:
                    conn.close()
                except Exception:
                    pass

        time.sleep(3)


if __name__ == "__main__":
    try:
        run()
    except KeyboardInterrupt:
        print("\n[系统退出] 服务已停止。")
