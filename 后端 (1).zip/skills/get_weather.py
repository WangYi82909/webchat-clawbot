NAME        = "get_weather"
DESCRIPTION = "查询指定城市的当前实时天气，适合用户出门时"
USAGE       = '{"city": "城市名称"}'
MODE        = "SYNC"
CHANNELS    = ("*",)

async def run(params: dict, pool, db_id, uid, bot_instance) -> dict:
    import httpx
    
    city = params.get("city", "").strip()
    print(f"[工具调用] [同步] 查询 {city} 的天气...")

    if not city:
        return {"success": False, "message": "未指定城市，无法查询。"}

    try:
        url = f"https://wttr.in/{city}?format=%C+%t&lang=zh"
        async with httpx.AsyncClient(timeout=10.0) as client:
            res = await client.get(url)
            if res.status_code == 200:
                weather_info = res.text.strip()
                return {
                    "success": True,
                    "message": f"通过接口查询到 {city} 的当前天气情况是：{weather_info}。请根据此内容生成对用户的答复。"
                }
            else:
                return {"success": False, "message": f"天气接口请求失败，HTTP 状态码: {res.status_code}"}
    except Exception as e:
        return {"success": False, "message": f"查询执行异常: {str(e)[:50]}"}
