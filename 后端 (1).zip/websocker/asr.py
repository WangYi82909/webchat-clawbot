"""asr.py — 实时语音识别 (dashscope qwen3-asr-flash-realtime).

调试增强版: 用 print(flush=True) 而不是 logging, 确保 main.py 控制台
立即看到每个事件. 排查完后可以把 print 改回 log.

修复历史:
  · 2026-05-15: _BridgeCallback 里 self.on_event 与基类钩子方法同名,
    被实例属性覆盖, 导致 SDK 调不到分发器, ASR 事件全部丢失.
    本版本改名为 _evt_cb / _partial_cb / _final_cb, 并加调试 print.
"""
import asyncio
import base64
import sys
from typing import Awaitable, Callable, Optional

from dashscope.audio.qwen_omni import (
    OmniRealtimeConversation,
    OmniRealtimeCallback,
    MultiModality,
)
from dashscope.audio.qwen_omni.omni_realtime import TranscriptionParams

from . import config


def _p(msg: str) -> None:
    """所有 asr 模块日志走这个, 直写 stdout 并 flush, 不经过 logging."""
    print(f'[ASR] {msg}', flush=True, file=sys.stdout)


PartialCallback = Callable[[str], Awaitable[None]]
FinalCallback   = Callable[[str], Awaitable[None]]
EventCallback   = Callable[[str], Awaitable[None]]


class _BridgeCallback(OmniRealtimeCallback):
    """运行在 dashscope 内部线程. 异步 callback 用 run_coroutine_threadsafe 投回主 loop.

    重要: 所有上层 callback 名称都用下划线前缀, 避免与基类钩子方法
          (on_open / on_close / on_event) 重名 — 实例属性会覆盖类方法.
    """

    def __init__(
        self,
        loop: asyncio.AbstractEventLoop,
        partial_cb: Optional[PartialCallback],
        final_cb:   Optional[FinalCallback],
        evt_cb:     Optional[EventCallback],
        tag: str,
    ) -> None:
        self.loop        = loop
        self._partial_cb = partial_cb
        self._final_cb   = final_cb
        self._evt_cb     = evt_cb
        self.tag         = tag
        self._event_count = 0

    # ── SDK 钩子方法 ────────────────────────────────────────────
    def on_open(self):
        _p(f'[{self.tag}] connection OPEN')

    def on_close(self, code, msg):
        _p(f'[{self.tag}] connection CLOSE code={code} msg={msg}')

    def on_event(self, response):
        self._event_count += 1
        try:
            t = response.get('type', '')
            # 前 5 个事件打全量, 后续只打类型 (省日志)
            if self._event_count <= 5:
                _p(f'[{self.tag}] EVT #{self._event_count} type={t} payload={response}')
            else:
                _p(f'[{self.tag}] EVT #{self._event_count} type={t}')

            if t == 'input_audio_buffer.speech_started':
                self._fire(self._evt_cb, 'speech_started')
            elif t == 'input_audio_buffer.speech_stopped':
                self._fire(self._evt_cb, 'speech_stopped')
            elif t == 'conversation.item.input_audio_transcription.text':
                text = (response.get('text') or '') + (response.get('stash') or '')
                _p(f'[{self.tag}] PARTIAL -> "{text}"')
                self._fire(self._partial_cb, text)
            elif t == 'conversation.item.input_audio_transcription.completed':
                final_text = (response.get('transcript') or '').strip()
                _p(f'[{self.tag}] FINAL   -> "{final_text}"')
                if final_text:
                    self._fire(self._final_cb, final_text)
            elif 'error' in t.lower():
                _p(f'[{self.tag}] ERROR event: {response}')
        except Exception as e:
            _p(f'[{self.tag}] callback dispatch EXCEPTION: {type(e).__name__}: {e}')
            import traceback; traceback.print_exc()

    def _fire(self, cb, *args):
        """把异步 callback 投回主 loop. 跑在 dashscope 线程里, 必须 threadsafe."""
        if cb is None:
            _p(f'[{self.tag}] _fire: cb is None, skip')
            return
        try:
            asyncio.run_coroutine_threadsafe(cb(*args), self.loop)
        except RuntimeError as e:
            _p(f'[{self.tag}] _fire: loop closed, dropped. err={e}')
        except Exception as e:
            _p(f'[{self.tag}] _fire: unexpected error {type(e).__name__}: {e}')


class RealtimeASRSession:
    def __init__(
        self,
        on_partial: Optional[PartialCallback] = None,
        on_final:   Optional[FinalCallback]   = None,
        on_event:   Optional[EventCallback]   = None,
        api_key:    str = '',
        language:   str = '',
        sample_rate: int = 16000,
        tag: str = 'asr',
    ) -> None:
        self._partial_cb = on_partial
        self._final_cb   = on_final
        self._evt_cb     = on_event
        # 调用方显式注入 DashScope key；OmniRealtimeConversation 支持会话级 api_key，
        # 不需要改写 dashscope.api_key 全局变量。
        self.api_key     = api_key or ''
        self.language    = language or config.ASR_LANGUAGE
        self.sample_rate = sample_rate
        self.tag         = tag
        self._conv: Optional[OmniRealtimeConversation] = None
        self._started = False
        self._audio_chunks = 0
        self._audio_bytes  = 0

    async def start(self) -> None:
        if self._started:
            _p(f'[{self.tag}] start() called but already started')
            return

        if not self.api_key:
            raise RuntimeError('ASR 缺少 api_key (用户语音凭证缺失或解密失败)')

        _p(f'[{self.tag}] start: model={config.ASR_MODEL} url={config.ASR_WS_URL}')

        loop = asyncio.get_running_loop()
        cb = _BridgeCallback(
            loop,
            partial_cb=self._partial_cb,
            final_cb=self._final_cb,
            evt_cb=self._evt_cb,
            tag=self.tag,
        )
        self._conv = OmniRealtimeConversation(
            model=config.ASR_MODEL,
            url=config.ASR_WS_URL,
            callback=cb,
            api_key=self.api_key,
        )

        def _setup():
            _p(f'[{self.tag}] _setup: connecting...')
            self._conv.connect()
            _p(f'[{self.tag}] _setup: connected, sending update_session...')
            self._conv.update_session(
                output_modalities=[MultiModality.TEXT],
                enable_input_audio_transcription=True,
                turn_detection={
                    'type': 'server_vad',
                    'threshold': 0.5,
                    'silence_duration_ms': 700,
                    'prefix_padding_ms': 300,
                },
                transcription_params=TranscriptionParams(
                    language=self.language,
                    sample_rate=self.sample_rate,
                    input_audio_format='pcm',
                ),
            )
            _p(f'[{self.tag}] _setup: update_session done (with server_vad turn_detection)')

        try:
            # ASR 使用实例级 key 后无需与整段 TTS 共用全局锁。否则某个用户合成长语音时，
            # 新连接会一直排队，前端就表现为多次点击才能接通。
            await loop.run_in_executor(None, _setup)
        except Exception as e:
            _p(f'[{self.tag}] _setup FAILED: {type(e).__name__}: {e}')
            import traceback; traceback.print_exc()
            raise

        self._started = True
        _p(f'[{self.tag}] session started OK (lang={self.language} rate={self.sample_rate})')

    async def feed_audio(self, pcm_chunk: bytes) -> None:
        if not self._started or self._conv is None:
            _p(f'[{self.tag}] feed_audio called but not started, dropping {len(pcm_chunk)}B')
            return
        self._audio_chunks += 1
        self._audio_bytes  += len(pcm_chunk)
        # 前 3 块和每 50 块打一次, 不要刷屏
        if self._audio_chunks <= 3 or self._audio_chunks % 50 == 0:
            _p(f'[{self.tag}] feed_audio #{self._audio_chunks} '
               f'size={len(pcm_chunk)}B total={self._audio_bytes}B')

        audio_b64 = base64.b64encode(pcm_chunk).decode('ascii')
        try:
            self._conv.append_audio(audio_b64)
        except Exception as e:
            _p(f'[{self.tag}] append_audio EXCEPTION: {type(e).__name__}: {e}')

    async def close(self) -> None:
        if not self._started or self._conv is None:
            return
        self._started = False
        conv = self._conv
        self._conv = None
        _p(f'[{self.tag}] closing (sent {self._audio_chunks} chunks, {self._audio_bytes} bytes total)')

        loop = asyncio.get_running_loop()

        def _teardown():
            try:
                conv.end_session()
            except Exception as e:
                _p(f'[{self.tag}] end_session error: {e}')
            try:
                conv.close()
            except Exception as e:
                _p(f'[{self.tag}] close error: {e}')

        await loop.run_in_executor(None, _teardown)
        _p(f'[{self.tag}] session closed')
