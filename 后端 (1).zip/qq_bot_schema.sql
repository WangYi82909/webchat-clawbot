-- CloudLove QQ C2C 机器人配置
-- 每个 CloudLove 用户暂时绑定一个 QQ 机器人；控制台断开时会删除该配置。
-- client_secret 是机器人凭据，部署时请限制数据库和备份文件的访问权限。

CREATE TABLE IF NOT EXISTS qq_bot_accounts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    app_id VARCHAR(128) NOT NULL,
    client_secret VARCHAR(255) NOT NULL,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    connection_state VARCHAR(20) NOT NULL DEFAULT 'online',
    last_error VARCHAR(500) NOT NULL DEFAULT '',
    last_seen_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_qq_bot_user (user_id),
    KEY idx_qq_bot_enabled (enabled),
    KEY idx_qq_bot_app_id (app_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
