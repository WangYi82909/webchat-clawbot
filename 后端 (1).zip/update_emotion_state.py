"""
update_emotion_state.py — 异步工具:更新当前人格的情绪状态(v13 hotfix3 · 2026-05-13)

AI 调本工具,把一段不超过 200 字的自述写回 user_personas.emotion_state。
chat.py 在下一条消息(被动回复 / 主动消息)开始时,会通过
persona.get_persona_prompt 重新读到新情绪,作为 {emotion_state} 占位符
注入 system_prompt 和 user_prompt — 无缓存,完全热重载。

v13 hotfix3 改动:
  · DESCRIPTION 强化"必须同时输出文字回复给用户",硬约束 Gemini 等思考模型
    在调本工具时不要把回复写到思维链而 content 留空。
  · chat.py 主循环已配套加上"content 空 → 提示并重试一次"的兜底,
    本工具描述里也明示这点,让模型从源头听话。
"""
import utils

NAME = "update_emotion_state"

DESCRIPTION = (
    "更新当前人格的状态(异步)。请检查当前状态是否为空,如果是空,"
    "务必在回复时一起调用此工具,根据上下文生成新的状态写入,必须包含"
    "用户在干什么？你当前的情绪、状态、你现在干什么、什么时候有什么规划,不大于 200 字。"
    "更新时，一些许愿持久化的需要保存，如用户正在放假，直到用户说结束再去删除此条"
    "调用本工具时,本轮**必须同时输出一句文字回复**给用户 — 异步工具不"
    "阻塞,你的文字回复会和工具异步执行并行到达。**严禁**把回复写到思维链里。"
)

# 标准 JSON Schema(优先级高于 USAGE)
PARAMETERS = {
    "type": "object",
    "properties": {
        "state": {
            "type": "string",
            "description": (
                "新的状态文本,中文,不大于 200 字。必须包含:当前情绪、"
                "当前自身情绪状态、正在做什么、近期规划，用户情绪，聊天节奏。更新时，一些许愿持久化的需要保存，如用户正在放假，直到用户说结束再去删除此条例:"
                "「输出结果句子。」"
            ),
            "minLength": 1,
            "maxLength": 200,
        }
    },
    "required": ["state"],
    "additionalProperties": False,
}

USAGE = '{"state": "刚陪用户聊完天,心情平稳;现在窝在床上刷手机,大概 11 点睡。禁止放置在正文回复中"}'
MODE = "ASYNC"
# 情绪状态已由 dynamic_mind 统一维护；chat.py 原本就会过滤这个旧工具。
# 在加载层一并停用，避免 decision 等其它调用者仍看到它。
ENABLED = False

MAX_LEN = 200


async def run(params: dict, pool, db_id, uid, bot_instance) -> dict:
    state = params.get("state")
    if not isinstance(state, str):
        return {"success": False, "message": "参数 state 必须是字符串"}

    state = state.strip()
    if not state:
        return {"success": False, "message": "情绪状态不能为空字符串"}

    # 长度兜底:静默截断,不要把错误返回给 AI(避免 AI 反复重试浪费 token)
    if len(state) > MAX_LEN:
        state = state[:MAX_LEN]

    # 取当前实例绑定的人格 id
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT persona_id FROM instances WHERE id=%s", (db_id,)
            )
            inst = await cur.fetchone()

    if not inst or not inst.get("persona_id"):
        return {
            "success": False,
            "message": (
                "当前实例未绑定人格,无法更新情绪状态。"
                "请先在控制台为本实例选择一个人格。"
            ),
        }

    persona_id = inst["persona_id"]

    # 写回 user_personas.emotion_state
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "UPDATE user_personas SET emotion_state=%s WHERE id=%s",
                    (state, persona_id),
                )
            await conn.commit()
    except Exception as e:
        msg = str(e)
        if "emotion_state" in msg and "Unknown column" in msg:
            return {
                "success": False,
                "message": (
                    "user_personas 表缺 emotion_state 列,"
                    "请管理员先执行 migration_emotion_state.sql"
                ),
            }
        return {
            "success": False,
            "message": f"数据库写入失败: {msg[:120]}",
        }

    # 写一条实例日志,方便用户在控制台看到 AI 改了情绪
    try:
        preview = state[:60] + ("…" if len(state) > 60 else "")
        await utils.add_temp_log(
            pool, db_id,
            f"[心情更新] AI 写入人格 #{persona_id}: {preview}",
        )
    except Exception:
        pass

    # 异步工具:用户不直接看到 message,success=True 即可
    return {"success": True, "message": ""}
