"""chat_bridge.py — 语音通话调用 chat.generate_reply 的桥接层.

v2 (2026-05-15) 完全重写:
    旧版做法 (已弃用):
        - 在 instances 表里 INSERT 一条 deploy_type='voice' 的独立行
        - 只复制 5 个字段 (model / persona_id / 三大采样参数)
        - 主实例改其他字段 (人格、合并、标点、预设、merge、运行配置 ...)
          voice 这条不变, 配置严重脱节

    新版做法 (v2):
        - 完全不创建 voice 独立行, 不写 instances 表
        - 每次通话连接建立时, 实时查主实例 (deploy_type 不是 'voice') 的最新行
        - 直接用主实例的 db_id 构造 BotInstance, 所有字段 (model / persona_id /
          merge_enabled / merge_window_seconds / temperature / 三大采样 /
          以及 instances 表里所有其他列) 都是主实例的实时值
        - 主实例改任何一个字段, 用户下次重连通话立即生效, 0 同步成本

    意味着:
        · voice 通话本质是"主实例的一个临时 view", 不是独立实例
        · 用户的对话历史 (messages 表) 跟微信侧完全打通 (按 db_id + uid 索引,
          voice 用 控制台 user_id, 微信用 wxid, 不会撞)
        · 删 voice 独立行 = 不影响, 因为新版根本不读它们

依赖前提:
    用户必须先在控制台创建一个实例 (不一定要启动). 没有的话 ValueError 抛出,
    server.py 拒绝接通并提示创建.
"""
import asyncio
import logging
import time
from typing import TYPE_CHECKING

import chat

if TYPE_CHECKING:
    from main import BotInstance


log = logging.getLogger('voice_ws.chat_bridge')


async def _has_active_platinum(pool, uid: int) -> bool:
    """读取白金有效期；旧库没有字段时不阻断语音，按普通计费。"""
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT platinum_expires_at FROM users WHERE id=%s LIMIT 1",
                    (int(uid),),
                )
                row = await cur.fetchone()
        value = row.get('platinum_expires_at') if hasattr(row, 'get') else (row[0] if row else 0)
        return int(value or 0) > int(time.time())
    except Exception:
        return False

# ── 语音通话专用模型 (2026-07) ────────────────────────────────────────────────
# 语音通话对【所有用户】强制切到这个可情绪识别的豆包模型, 覆盖各自实例本身的模型;
# 且强制按【余额】计费。端点 / api_key / 协议 / 单价(输入20 输出45)全部由后台
# model_pricing 表里这一行提供 —— 上线前务必先在 model_pricing 添加该行, 否则
# chat.generate_reply 会因"未配置模型定价"拦截, 语音通话无法接通。
# 微信侧对话不受影响 (不传 model_override / force_balance)。
VOICE_CALL_MODEL = 'doubao-seed-2-0-lite-260428'

# 语音合成计费: ¥8 / 1万字 = ¥0.0008/字, 从余额扣 (语音通话侧 TTS)
VOICE_TTS_YUAN_PER_10K = 8.0

async def _charge_voice_tts(pool, uid: int, nchars: int):
    """语音合成按字数从 users.balance 扣费 (¥8/万字)。GREATEST 兜底不为负。失败仅告警。"""
    if not nchars or nchars <= 0:
        return
    if await _has_active_platinum(pool, uid):
        log.info('platinum voice tts free uid=%d chars=%d', uid, nchars)
        return
    cost = round(nchars * VOICE_TTS_YUAN_PER_10K / 10000.0, 4)
    if cost <= 0:
        return
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute("UPDATE users SET balance = GREATEST(0, balance - %s) WHERE id=%s", (cost, uid))
            await conn.commit()
        log.info('voice tts charge uid=%d chars=%d cost=%.4f', uid, nchars, cost)
    except Exception as e:
        log.warning('voice tts charge failed uid=%s: %s', uid, e)

# uid -> BotInstance. 不是"缓存", 只是登记表用于 drop_user 时清理.
# 每次通话连接时重新构造, 因此主实例改字段后下次重连就生效.
_voice_instances: dict[int, 'BotInstance'] = {}
_lock = asyncio.Lock()


async def _load_main_instance_row(pool, uid: int) -> dict | None:
    """查用户的主实例 (排除 deploy_type='voice' 的虚拟残行).

    老库没有 deploy_type 列时自动 fallback 拿最新一条.
    """
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            try:
                await cur.execute(
                    "SELECT * FROM instances "
                    "WHERE user_id=%s "
                    "  AND (deploy_type IS NULL OR deploy_type != 'voice') "
                    "ORDER BY id DESC LIMIT 1",
                    (uid,),
                )
                row = await cur.fetchone()
                if row:
                    return row
            except Exception as e:
                msg = str(e)
                if 'Unknown column' in msg and 'deploy_type' in msg:
                    # 老库: 没有 deploy_type 列, 任何 instances 行都是"主实例"
                    await cur.execute(
                        "SELECT * FROM instances WHERE user_id=%s "
                        "ORDER BY id DESC LIMIT 1",
                        (uid,),
                    )
                    return await cur.fetchone()
                raise
    return None


async def get_or_create_voice_instance(pool, uid: int) -> 'BotInstance':
    """获取该 uid 用于语音通话的 BotInstance.

    每次通话连接建立时调一次. 实时读主实例最新配置, 构造一个独立的 BotInstance
    (独立的 httpx client, 不复用 main.py running_tasks 里跑微信 bot 的对象,
    避免互相影响).

    主实例改任何字段, 下次通话连接时这里再调用就拿到新值. 完全同步, 0 延迟.

    Raises:
        ValueError: 用户没有主实例. server.py 应抓住, 拒绝接通并提示创建.
    """
    async with _lock:
        row = await _load_main_instance_row(pool, uid)
        if not row:
            raise ValueError(
                '你还没有创建任何实例。请先到控制台创建一个微信实例 '
                '(可以不启动), 再开始语音通话。'
            )

        # 延迟 import 避免循环依赖 (main.py 早 import chat, chat 不 import main)
        from main import BotInstance
        bot = BotInstance(row, pool)
        # 语音通话复用模型/人格，但发送通道不是微信；绑定后可由 chat.py
        # 和工具执行器阻止任何误用微信 wx_token 的路径。
        bot.tool_channel = "voice"
        bot.channel = "voice"

        # 旧的 BotInstance 如果还在 (上次通话没正常断开), 先清掉再覆盖
        old = _voice_instances.get(uid)
        if old is not None and old is not bot:
            try:
                old.is_running = False
                if getattr(old, 'msg_task', None) is not None:
                    old.msg_task.cancel()
            except Exception:
                pass

        _voice_instances[uid] = bot
        log.info('voice instance ready: uid=%d db_id=%d model=%s persona=%s',
                 uid, row['id'], row.get('model'), row.get('persona_id'))
        return bot


async def respond(pool, uid: int, user_text: str) -> tuple[str, str | None]:
    """让 chat 引擎处理一句话.

    返回:
        (reply, error_message)
        · 成功: reply 是要 TTS 的纯文本, error_message=None
        · 失败: reply='', error_message 是给用户看的人话
    """
    if not user_text or not user_text.strip():
        return '', '识别结果为空'

    try:
        bot = await get_or_create_voice_instance(pool, uid)
    except ValueError as ve:
        return '', str(ve)
    except Exception as e:
        log.exception('get voice instance failed, uid=%d', uid)
        return '', f'无法初始化对话上下文: {e}'

    try:
        # 语音通话: 强制豆包模型 + 强制余额计费。微信侧不会走到这里, 不受影响。
        # ↓ 这行只有【语音通话】会打印。语音通话日志里没有它 = 跑的还是旧代码(没重启进程)。
        print(f"[语音通话] chat_bridge.respond uid={uid} → 强制模型 {VOICE_CALL_MODEL} + 余额计费", flush=True)
        result, is_error = await chat.generate_reply(
            pool, bot, uid, user_text,
            model_override=VOICE_CALL_MODEL,
            force_balance=True,
            tool_channel="voice",
        )
    except Exception as e:
        log.exception('chat.generate_reply crashed, uid=%d', uid)
        return '', f'AI 调用失败: {e}'

    if is_error:
        return '', '系统繁忙, 请稍后再试'
    if not result:
        return '', 'AI 未返回结果'

    # 余额不足等拦截原因 → 直接把这句人话回传给用户 (语音通话界面会念/显示)
    _deny = ''
    if isinstance(result, dict):
        _deny = (result.get('deny_reason') or '').strip()
    if _deny:
        return '', _deny

    reply = (result.get('reply') or '').strip()
    if not reply:
        return '', 'AI 未返回内容 (可能配额不足或被节流, 见控制台日志)'

    # 语音合成计费: 本轮要 TTS 的回复文本, 按 ¥8/万字 从余额扣
    await _charge_voice_tts(pool, uid, len(reply))
    return reply, None


def drop_user(uid: int) -> None:
    """用户断开后清掉内存里的 BotInstance (httpx client 会被回收)."""
    bot = _voice_instances.pop(uid, None)
    if bot is not None:
        try:
            bot.is_running = False
            if bot.msg_task:
                bot.msg_task.cancel()
        except Exception:
            pass
