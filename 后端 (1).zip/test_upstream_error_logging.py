import hashlib
import json
import unittest

import httpx

import chat


class UpstreamErrorLoggingTests(unittest.TestCase):
    def test_outgoing_model_text_removes_ascii_slashes(self):
        self.assertEqual(
            chat._clean_outgoing_model_text("你好/世界//下一句"),
            "你好世界下一句",
        )

    def test_record_keeps_source_response_and_redacts_credentials(self):
        key = ""
        request = httpx.Request(
            "POST",
            "https://mixed.example/v1/chat/completions?key=" + key,
        )
        response = httpx.Response(
            401,
            request=request,
            headers={
                "content-type": "application/json",
                "x-request-id": "req-401",
                "set-cookie": "private-cookie",
            },
            json={"error": {"message": "Invalid token " + key}},
        )
        headers = {
            "Authorization": "Bearer " + key,
            "Content-Type": "application/json",
        }

        raw = chat._upstream_error_record(
            response,
            endpoint=str(request.url),
            protocol="openai",
            request_headers=headers,
            attempt=1,
            diagnostic_meta={
                "model": "test-model",
                "key_source": "model_pricing.api_key",
            },
        )
        record = json.loads(raw)

        self.assertEqual(record["status"], 401)
        self.assertEqual(record["endpoint"], "https://mixed.example/v1/chat/completions")
        self.assertEqual(record["model"], "test-model")
        self.assertEqual(record["key_source"], "model_pricing.api_key")
        self.assertEqual(
            record["key_fingerprint"],
            hashlib.sha256(key.encode()).hexdigest()[:12],
        )
        self.assertNotIn(key, raw)
        self.assertIn("<redacted-key>", record["response_body"])
        self.assertEqual(record["response_headers"]["x-request-id"], "req-401")
        self.assertNotIn("set-cookie", record["response_headers"])


if __name__ == "__main__":
    unittest.main()
