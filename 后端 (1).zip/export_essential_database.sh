#!/usr/bin/env bash
# Cloud Love 新服务器基础数据库导出。
#
# 结果是一个扩展名为 .txt 的纯 SQL 文件，可直接执行：
#   mysql -h HOST -P 3306 -u USER -p webchat < cloudlove-essential-xxxx.txt
#
# 导出范围：
#   1. 当前数据库全部表结构、索引与触发器（不带用户业务数据）；
#   2. 系统配置、模型、套餐、支付、提示词等运行必需的全局数据。
# 用户、实例、聊天、记忆、订单等数据不在本脚本内，由 .clove 文件逐用户迁移。

set -Eeuo pipefail

DB_HOST="${CLOUDLOVE_DB_HOST:-127.0.0.1}"
DB_PORT="${CLOUDLOVE_DB_PORT:-3306}"
DB_NAME="${CLOUDLOVE_DB_NAME:-webchat}"
DB_USER="${CLOUDLOVE_DB_USER:-webchat}"
DB_PASSWORD="${CLOUDLOVE_DB_PASSWORD:-}"
OUTPUT_FILE="${1:-cloudlove-essential-$(date '+%Y%m%d-%H%M%S').txt}"
TEMP_FILE="${OUTPUT_FILE}.tmp.$$"

[[ "$DB_NAME" =~ ^[A-Za-z0-9_]+$ ]] \
    || { echo "错误：数据库名称只允许字母、数字和下划线" >&2; exit 1; }

command -v mysql >/dev/null 2>&1 || { echo "错误：未找到 mysql 客户端" >&2; exit 1; }
command -v mysqldump >/dev/null 2>&1 || { echo "错误：未找到 mysqldump" >&2; exit 1; }

export MYSQL_PWD="$DB_PASSWORD"
cleanup() {
    unset MYSQL_PWD
    if [ -f "$TEMP_FILE" ]; then rm -f -- "$TEMP_FILE"; fi
}
trap cleanup EXIT INT TERM

MYSQL_ARGS=(
    --host="$DB_HOST"
    --port="$DB_PORT"
    --user="$DB_USER"
    --default-character-set=utf8mb4
)
DUMP_COMMON=(
    "${MYSQL_ARGS[@]}"
    --single-transaction
    --skip-lock-tables
    --hex-blob
    --skip-comments
    --skip-add-locks
    --default-character-set=utf8mb4
)

mysql "${MYSQL_ARGS[@]}" --batch --skip-column-names \
    -e "SELECT 1 FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='${DB_NAME}'" \
    | grep -qx '1' || { echo "错误：数据库 ${DB_NAME} 不存在或当前账号无权访问" >&2; exit 1; }

cat > "$TEMP_FILE" <<'SQL_HEADER'
-- Cloud Love 基础数据库迁移文件（直接用 mysql 执行）
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;
SET UNIQUE_CHECKS=0;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
START TRANSACTION;
SQL_HEADER

# 新服务器需要完整空表结构；这里不导出任何业务行。
mysqldump "${DUMP_COMMON[@]}" \
    --no-data --triggers \
    "$DB_NAME" >> "$TEMP_FILE"

# 这些表的行本身就是运行配置，而不是某个用户的私有数据。
# 表不存在时自动跳过，以兼容不同版本的数据库。
ESSENTIAL_TABLES=(
    system_config
    model_pricing
    pack_tiers
    count_pack_tiers
    payment_channels
    prompt_presets
    market_personas
    meme_library
    voice_square
    version_logs
    testimonials
)

for table_name in "${ESSENTIAL_TABLES[@]}"; do
    exists="$(mysql "${MYSQL_ARGS[@]}" --batch --skip-column-names \
        -e "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA='${DB_NAME}' AND TABLE_NAME='${table_name}'")"
    if [ "$exists" = "1" ]; then
        printf '\n-- 全局配置数据：%s\n' "$table_name" >> "$TEMP_FILE"
        WHERE_ARGS=()
        if [ "$table_name" = "system_config" ]; then
            # 运行快照和瞬时负载不是配置；迁移它们会让新后台短暂显示旧分片。
            WHERE_ARGS+=(--where="config_key NOT LIKE 'runtime_snapshot_%' AND config_key <> 'load_value'")
        fi
        mysqldump "${DUMP_COMMON[@]}" \
            --no-create-info --complete-insert --replace --skip-triggers \
            "${WHERE_ARGS[@]}" \
            "$DB_NAME" "$table_name" >> "$TEMP_FILE"
    fi
done

cat >> "$TEMP_FILE" <<'SQL_FOOTER'
COMMIT;
SET UNIQUE_CHECKS=1;
SET FOREIGN_KEY_CHECKS=1;
SQL_FOOTER

mv -- "$TEMP_FILE" "$OUTPUT_FILE"
trap - EXIT INT TERM
unset MYSQL_PWD

echo "导出完成：${OUTPUT_FILE}"
echo "该文件包含全部空表结构和必需的全局配置，不包含用户私有数据。"
