# -*- coding: utf-8 -*-
"""
decision.py — 意图决策前置(2026-06-03)

定位
  收到用户消息(语音已在 main.py 转成文字、图片走主模型原生识别不在此处)后、
  调 chat.generate_reply 之前,用「用户配置的主模型」跑一次轻量决策,判断本轮:
    · 要不要 RAG 检索(并给出检索关键词)
    · 要不要带工具
  输出一个极简 JSON,main / webchat 据此给 generate_reply 传参。

输出契约(decide() 的返回值)
    {"rag": ["关键词", ...], "tool": bool}
      rag 非空 → 强制检索(无视实例 rag_enabled,对所有用户生效),
                关键词直接作为查询词传入(替换 chat 里的 Query Expansion)。
      tool True → 把"用户没禁用的工具清单"注入本轮 chat 请求(否则本轮不带工具)。
    任何失败 / 超时 → {"rag": [], "tool": False}(纯回复兜底,不影响主流程)。
    rag 与 tool 可同时成立:两个标志一起传进同一次 generate_reply,
    chat 内部会先把检索结果拼进 user 消息、工具清单在 system,等价于"先 RAG 后带工具"。

设计要点
  1. 决策是【独立 LLM 调用】,有自己的 system,完全不碰主回复的 system 前缀,
     因此不影响正常回复的上游前缀缓存命中。
  2. 复用现成轮子:chat.resolve_model_runtime(端点/协议/计费解析)、
     chat._call_llm_with_format_retry(统一请求 + 脱敏原始响应日志)。
  3. 解析复用 tool_leak_cleaner 的低层函数(三段式 JSON 提取),
     不走 clean_json_response —— 那个会把结果硬归一化成 {reply, tools}。
  4. 精简 payload:不强开思维链、max_tokens 给小值,降低这一前置调用的延迟与费用。
  5. 决策调用的 token 用量按用户的 model + bucket 计费(billing.commit_usage)。
  6. 历史窗口固定为 60 轮，与主回复口径一致，不读取实例配置。
"""
from __future__ import annotations
import asyncio

import utils
import billing
import chat
import tool_leak_cleaner as tlc
import llm_protocol_openai as proto_openai

# ── 可调参数 ──────────────────────────────────────────────────────────────
# 决策调用超时(秒)。它挡在用户回复前面,短一点;超时即兜底纯回复。
DECISION_TIMEOUT_S = 20.0
# 决策输出很小,max_tokens 给小值(精简 payload)。
DECISION_MAX_TOKENS = 512
# rag 关键词最多取几个(防模型给一大串)。
DECISION_MAX_KEYWORDS = 5
# 思维链下发:精简优先,默认 "none" 抑制思考,让这一前置路由调用尽量快、便宜。
#   ⚠ 注意上游差异(见 llm_protocol_openai.build_payload 注释):
#     - 某些 gemini-3 兼容层在"完全不下发 reasoning_effort"时默认 high(过度思考、慢)。
#       这里显式发 "none" 来主动抑制,而不是省略。
#     - 若你的上游不认 "none"、希望保留轻量思考:把本值改成 "low",
#       并把 DECISION_MAX_TOKENS 提到 ≥2048(low 在 gemini-2.5 映射 budget=1024,
#       budget 必须 < max_tokens,否则请求体自相矛盾会 500)。
DECISION_REASONING_EFFORT = "none"

# ── 决策提示词 ────────────────────────────────────────────────────────────
DECISION_SYSTEM_PROMPT = "你是一个意图判断模型,根据上下文,选择合适的动作,以 JSON 格式输出。"

# {tools_block} 预留:渲染当前"用户没禁用的"可用工具,供模型判断 tool 字段。
DECISION_USER_TEMPLATE = """\
[最近对话]
{history}

[最新消息]
{latest}

[可用工具]（本轮要用其中某个工具才把 tool 置 true；下面为空说明没有可用工具）
{tools_block}

[判定规则]
- rag：需要查这位用户的历史记忆/资料才能答好本轮 → 给 1-{max_kw} 个检索关键词（字符串数组）；否则给 []。
- tool：本轮需要调用上面[可用工具]里的某个工具 → true；否则 false。
- 两者可同时成立。

只输出 JSON，禁止任何多余文字或 markdown 代码块：
{{"rag": [], "tool": false}}"""


# ─────────────────────────────────────────────────────────────────────────
# 内部辅助
# ─────────────────────────────────────────────────────────────────────────
async def _safe_log(pool, db_id, msg: str) -> None:
    try:
        await utils.add_temp_log(pool, db_id, msg)
    except Exception:
        print(msg, flush=True)


def _format_history(history: list) -> str:
    """
    取统一 60 轮(1 轮≈2 条)压成紧凑文本,只保留 user/assistant,
    跳过 system / [操作记录] 等内部条目;每条限长,防 token 膨胀。
    """
    if not history:
        return "（无）"
    entries = chat.UNIFIED_CONTEXT_TURNS * 2
    lines = []
    for m in history[-entries:]:
        if not isinstance(m, dict):
            continue
        role = m.get("role")
        if role not in ("user", "assistant"):
            continue
        c = m.get("content")
        if not isinstance(c, str):
            continue
        c = c.strip().replace("\n", " ")
        if not c:
            continue
        if len(c) > 200:
            c = c[:200] + "…"
        lines.append(("用户: " if role == "user" else "我: ") + c)
    return "\n".join(lines) if lines else "（无）"


def _normalize_decision(parsed) -> dict:
    """把解析出的 dict 归一化成 {"rag": list[str], "tool": bool}。容错。"""
    if not isinstance(parsed, dict):
        return {"rag": [], "tool": False}

    rag_raw = parsed.get("rag")
    kws: list[str] = []
    if isinstance(rag_raw, list):
        for k in rag_raw:
            if isinstance(k, str):
                k = k.strip()
                if k and k not in kws:
                    kws.append(k)
    elif isinstance(rag_raw, str):
        k = rag_raw.strip()
        if k:
            kws = [k]
    kws = kws[:DECISION_MAX_KEYWORDS]

    tool_raw = parsed.get("tool")
    if isinstance(tool_raw, bool):
        tool = tool_raw
    elif isinstance(tool_raw, (int, float)):
        tool = bool(tool_raw)
    elif isinstance(tool_raw, str):
        tool = tool_raw.strip().lower() in ("true", "1", "yes", "y", "是")
    else:
        tool = False

    return {"rag": kws, "tool": tool}


def _parse_decision(raw_content: str, reasoning: str | None) -> dict:
    """
    复用 tool_leak_cleaner 的低层三段式解析,抽出本决策自己的字段。
    不走 clean_json_response(它会硬塞 reply/tools)。解析不出 → 兜底。
    """
    text = tlc.strip_thinking_tags(raw_content or "").strip()
    parsed = None
    if text:
        parsed = tlc._try_json_parse(text)
        if parsed is None:
            stripped = tlc._strip_markdown_fences(text)
            if stripped != text:
                parsed = tlc._try_json_parse(stripped)
            if parsed is None:
                block = tlc._find_first_json_object(stripped or text)
                if block:
                    parsed = tlc._try_json_parse(block)
    # 正文全失败 → 从思维链里找 JSON(最后一根稻草)
    if parsed is None and reasoning and reasoning.strip():
        rsn = reasoning.strip()
        block = tlc._find_first_json_object(tlc._strip_markdown_fences(rsn) or rsn)
        if block:
            parsed = tlc._try_json_parse(block)
    return _normalize_decision(parsed)


# ─────────────────────────────────────────────────────────────────────────
# 入口
# ─────────────────────────────────────────────────────────────────────────
async def decide(pool, db_id: int, user_id: int, content: str, uid=None) -> dict:
    """
    意图决策入口。返回 {"rag": [...], "tool": bool}。永不抛异常。
    调用方:main.message_worker / webchat_server,在调 generate_reply 之前。
    uid 非空时读取该联系人的独立上下文；网页等无 uid 场景兼容旧实例上下文。
    """
    fallback = {"rag": [], "tool": False}
    if not content or not content.strip():
        return fallback

    # ── 读实例配置:决策模型(复用主模型) + user_id ──────────────────────────
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT user_id, model FROM instances WHERE id=%s",
                    (db_id,),
                )
                inst = await cur.fetchone()
    except Exception as e:
        await _safe_log(pool, db_id, f"[决策] ✗ 读实例配置失败,兜底纯回复: {str(e)[:80]}")
        return fallback
    if not inst:
        return fallback

    # 调用方(如 webchat)可能没有 user_id,这里从实例行兜底取。
    if not user_id:
        user_id = inst.get("user_id") or 0
    model = (inst.get("model") or "").strip()
    if not model:
        await _safe_log(pool, db_id, "[决策] ✗ 实例未配置 model,兜底纯回复")
        return fallback
    # ── 配额校验(用决策模型查):不通过 → 跳过决策,交给正常回复链路出拒绝词 ──
    try:
        quota = await billing.check_quota(pool, user_id, db_id, model)
    except Exception as e:
        await _safe_log(pool, db_id, f"[决策] ✗ check_quota 异常,兜底纯回复: {str(e)[:80]}")
        return fallback
    if not quota.get("ok"):
        await _safe_log(pool, db_id, "[决策] 配额/权限不通过,跳过决策(交给正常回复链路处理)")
        return fallback
    bucket        = quota.get("bucket")
    count_pack_id = quota.get("count_pack_id")

    # ── 解析模型运行时:endpoint / api_key / protocol / 计费单价 ──────────────
    try:
        rt = await chat.resolve_model_runtime(pool, model)
    except Exception as e:
        await _safe_log(pool, db_id, f"[决策] ✗ 解析模型运行时异常,兜底纯回复: {str(e)[:80]}")
        return fallback
    if not rt:
        await _safe_log(pool, db_id, f"[决策] ✗ 模型 {model} 未配置定价,兜底纯回复")
        return fallback
    endpoint   = rt["endpoint"]
    api_key    = rt["api_key"]
    m_protocol = rt["protocol"]
    in_price   = rt["in_price"]
    out_price  = rt["out_price"]
    if not endpoint:
        await _safe_log(pool, db_id, "[决策] ✗ 模型端点为空,兜底纯回复")
        return fallback

    # ── 取历史 + 工具清单(load_skill_specs 已按实例黑名单过滤) ───────────────
    try:
        history = await utils.get_context(pool, db_id, uid=uid)
    except Exception:
        history = []
    try:
        tool_specs = await utils.load_skill_specs_for_openai(
            pool, db_id, tool_channel="wechat",
        )
    except Exception:
        tool_specs = []
    tools_block = utils.build_tools_system_block(tool_specs) or "（无可用工具）"

    # ── 构造决策请求(精简 payload) ────────────────────────────────────────
    user_prompt = DECISION_USER_TEMPLATE.format(
        history=_format_history(history),
        latest=content.strip()[:1500],
        tools_block=tools_block,
        max_kw=DECISION_MAX_KEYWORDS,
    )
    messages = [
        {"role": "system", "content": DECISION_SYSTEM_PROMPT},
        {"role": "user", "content": user_prompt},
    ]

    if m_protocol == "anthropic":
        # Anthropic 走其兼容层适配器:thinking 关掉、不依赖 reasoning_effort。
        import llm_protocol_anthropic as proto_anthropic
        try:
            payload = proto_anthropic.build_payload(
                model, messages,
                temperature=0.0,
                enable_thinking=False,
                supports_thinking=False,
            )
        except Exception:
            payload = {"model": model, "messages": messages,
                       "temperature": 0.0, "max_tokens": DECISION_MAX_TOKENS}
        req_headers = proto_anthropic.build_headers(api_key)
    else:
        # OpenAI 协议:手搓精简 payload(不复用 proto_openai.build_payload,
        # 那个会强制 reasoning_effort="low" + max_tokens=16384)。
        payload = {
            "model": model,
            "messages": messages,
            "temperature": 0.0,
            "max_tokens": DECISION_MAX_TOKENS,
            "reasoning_effort": DECISION_REASONING_EFFORT,
        }
        req_headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

    # ── 发请求（复用 chat 的统一请求状态机与脱敏日志）─────────────────────
    llm_client = chat.get_http_client()
    try:
        resp_json = await asyncio.wait_for(
            chat._call_llm_with_format_retry(
                llm_client, endpoint, payload, req_headers,
                pool, db_id, "决策",
                protocol=m_protocol,
            ),
            timeout=DECISION_TIMEOUT_S,
        )
    except asyncio.TimeoutError:
        await _safe_log(pool, db_id, f"[决策] ⚠ 超时 {DECISION_TIMEOUT_S:.0f}s,兜底纯回复")
        return fallback
    except Exception as e:
        await _safe_log(pool, db_id, f"[决策] ✗ 请求异常,兜底纯回复: {str(e)[:80]}")
        return fallback
    if not resp_json:
        await _safe_log(pool, db_id, "[决策] ✗ 请求无响应，兜底纯回复")
        return fallback

    # ── 计费(决策这一次调用的 token 用量,按用户 model + bucket 扣) ──────────
    try:
        usage = resp_json.get("usage", {}) or {}
        cost, p_tok, c_tok, _br = billing.calc_cost_from_usage(usage, in_price, out_price)
        if p_tok > 0 or c_tok > 0:
            await billing.commit_usage(
                pool=pool, user_id=user_id, db_id=db_id, bucket=bucket,
                total_cost=cost, total_prompt_tokens=p_tok,
                total_completion_tokens=c_tok, model=model,
                count_pack_id=count_pack_id,
            )
            await _safe_log(
                pool, db_id,
                f"[决策·扣费] {model} 桶={bucket} in={p_tok} out={c_tok} cost=¥{cost:.4f}"
            )
    except Exception as e:
        await _safe_log(pool, db_id, f"[决策·扣费] ✗ 已忽略: {str(e)[:80]}")

    # ── 解析决策 JSON ──────────────────────────────────────────────────────
    try:
        message = resp_json["choices"][0]["message"]
        raw_content = message.get("content") or ""
    except (KeyError, IndexError, TypeError):
        raw_content = ""
    try:
        reasoning = proto_openai.extract_reasoning(resp_json)
    except Exception:
        reasoning = None

    result = _parse_decision(raw_content, reasoning)
    await _safe_log(pool, db_id, f"[决策] rag={result['rag']} tool={result['tool']}")
    return result
