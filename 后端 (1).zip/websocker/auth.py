"""auth.py — HMAC token 校验 + 从远程库读用户身份和语音凭证.

token 结构:  base64url(payload_json) + "." + base64url(hmac_sha256(secret, payload_b64))
payload:     {"uid": 123, "username": "...", "iat": ..., "exp": ..., "nonce": "..."}

2026-06-02 改造:
  旧版从 users.voice_ids JSON 读 voice_id, 用平台 config.DASHSCOPE_API_KEY 合成。
  新版改为从 user_voice_credentials 表读 (voice_id, key_cipher), 用 utils.decrypt_data
  把 key_cipher 还原成用户自己的 DashScope api key, 一起挂到 user 字典上,
  后续 ASR / TTS 都用这把用户自己的 key 调用 DashScope (走用户自己的账号 + 配额)。

  这里依赖 utils.PRIV_KEY 已经初始化 —— 由 main.py 启动时 await utils.init_rsa_keys(pool) 完成,
  与微信侧 wx_token 解密的初始化路径同源 (utils.py:430 同款解密)。
"""
import base64
import hmac
import hashlib
import json
import time
from typing import Optional

import utils
from . import config


class AuthError(Exception):
    """token / 用户身份 / 语音凭证等校验失败的统一异常."""


def _b64url_decode(s: str) -> bytes:
    pad = '=' * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def verify_token(token: str) -> dict:
    """验签 + 检查过期, 返回 payload dict. 失败抛 AuthError."""
    if not token or '.' not in token:
        raise AuthError('token 格式错误')
    try:
        payload_b64, sig_b64 = token.split('.', 1)
    except ValueError:
        raise AuthError('token 格式错误')

    expected_sig = hmac.new(
        config.WS_SECRET.encode('utf-8'),
        payload_b64.encode('ascii'),
        hashlib.sha256,
    ).digest()
    try:
        given_sig = _b64url_decode(sig_b64)
    except Exception:
        raise AuthError('token 签名解码失败')
    if not hmac.compare_digest(expected_sig, given_sig):
        raise AuthError('token 签名不匹配')

    try:
        payload = json.loads(_b64url_decode(payload_b64))
    except Exception:
        raise AuthError('token payload 解码失败')

    now = int(time.time())
    exp = int(payload.get('exp', 0))
    if exp <= 0:
        raise AuthError('token 缺少 exp')
    if now > exp:
        raise AuthError('token 已过期')

    iat = int(payload.get('iat', 0))
    if iat > now + 30:
        raise AuthError('token iat 异常 (时钟漂移?)')

    if 'uid' not in payload:
        raise AuthError('token 缺少 uid')

    return payload


async def load_user(pool, uid: int) -> Optional[dict]:
    """从 users 表读出语音通话需要的基础字段 (身份/余额/计划)。"""
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            try:
                await cur.execute(
                    "SELECT id, username, email, plan_type, plan_expired_at, "
                    "billing_mode, balance, platinum_expires_at "
                    "FROM users WHERE id = %s LIMIT 1",
                    (int(uid),),
                )
            except Exception:
                await cur.execute(
                    "SELECT id, username, email, plan_type, plan_expired_at, "
                    "billing_mode, balance, 0 AS platinum_expires_at "
                    "FROM users WHERE id = %s LIMIT 1",
                    (int(uid),),
                )
            return await cur.fetchone()


async def load_voice_member(pool, uid: int) -> Optional[dict]:
    """从 voice_members(新独立表)读语音会员状态与音色。
    表不存在 / 行不存在 → 返回 None, 上层据此报错引导用户去开通/克隆。

    返回字段: voice_expired_at, voice_id, voice_name, wechat_enabled
    """
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            try:
                await cur.execute(
                    "SELECT voice_expired_at, voice_id, voice_name, wechat_enabled "
                    "FROM voice_members WHERE user_id = %s LIMIT 1",
                    (int(uid),),
                )
                return await cur.fetchone()
            except Exception:
                # 表不存在(未跑 migration_voice_membership.sql)等情况, 视为未开通
                return None


async def authenticate(pool, token: str) -> dict:
    """一站式: 验 token → 查 user → 校验语音会员 + 取音色 id。失败抛 AuthError。

    2026-07 改造(语音会员制):
      · 语音需付费会员 (¥28/月)。从 voice_members 表读会员状态, 过期/未开通直接拒。
      · 音色 id 来自 voice_members.voice_id (平台用硬编码 DashScope key 帮用户克隆的)。
      · DashScope key 一律用平台硬编码 key (config.DASHSCOPE_API_KEY), 不再用用户自带 key。

    成功后 user 字典挂上:
      user['_voice_id']        平台帮用户克隆好的音色 id
      user['_voice_name']      站内展示名
      user['_dashscope_key']   平台硬编码 DashScope key (ASR / TTS 都用这把)
      user['_wechat_enabled']  是否作用于微信 (1/0)
    """
    payload = verify_token(token)
    uid = int(payload['uid'])
    user = await load_user(pool, uid)
    if not user:
        raise AuthError('用户不存在或已注销')

    platinum_active = int(user.get('platinum_expires_at') or 0) > int(time.time())
    vm = await load_voice_member(pool, uid)
    if not vm:
        if platinum_active:
            raise AuthError('白金会员已包含语音通话，但还没有可用音色，请先上传样音')
        raise AuthError('云通话是会员功能，请先开通语音会员(¥28/月)')

    now = int(time.time())
    expired_at = int(vm.get('voice_expired_at') or 0)
    if platinum_active:
        expired_at = max(expired_at, int(user.get('platinum_expires_at') or 0))
    if expired_at <= now:
        raise AuthError('语音会员已过期，请续费后再使用云通话')

    voice_id = str(vm.get('voice_id') or '').strip()
    if not voice_id:
        raise AuthError('你还没有上传样音生成音色，请先在语音会员页上传一段音频')

    platform_key = str(getattr(config, 'DASHSCOPE_API_KEY', '') or '')
    if not platform_key:
        raise AuthError('服务端未配置 DashScope key (config.DASHSCOPE_API_KEY)')

    user['_voice_id']       = voice_id
    user['_voice_name']     = str(vm.get('voice_name') or '')
    user['_dashscope_key']  = platform_key
    user['_wechat_enabled'] = int(vm.get('wechat_enabled') or 0)
    return user
