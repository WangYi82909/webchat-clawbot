"""
period_care.py — 「让 Ta 更懂你」经期关怀模块

定位
  本模块随 main.py 一起加载（main.py 顶部 `import period_care`），
  不是独立进程、不是热加载（模块在程序启动时加载一次）。
  但 maybe_build_care_prefix(...) 由 main.py 在【每一条用户消息】处理时
  调用，且每次都重新查库，所以 demo 里刚拨的开关下一条消息立即生效。

关键修复（v3 · 排查后重写）
  旧版把关怀通知作为一条 role="system" 消息写进 instances.context。
  但 chat.py 构造发给 LLM 的 messages 时，会**跳过所有 role=system 的
  history 条目**（只保留 [操作记录] 开头的那种）——
  见 chat.py「history_for_llm 循环」。
  结果：通知写进了 context，却被 chat.py 过滤掉，LLM 根本看不到。
  这就是"调试人设没看到关怀通知"的根因。

  新做法：maybe_build_care_prefix() 不再写 context，而是**返回一段文本**，
  由 main.py 把它拼到用户本轮消息 content 的最前面。这样它就是用户
  消息的一部分，必定进入 user_prompt 发给 LLM，不会被任何过滤跳过，
  也不破坏 OpenAI / Anthropic 的 user/assistant 交替协议。

推送时机 / 去重（couple_period_care_push 表）
  - daily      ：每个用户每天最多注入一次（push_key = 当天日期）。
  - period_end ：用户某段经期结束日 == 今天时，额外注入一次。
  两类各自去重。

排查日志
  每步决策写进该实例 temp_log（带 [让Ta更懂你] 前缀，前端按实例可见），
  同时打 stdout。启动时打印一行就绪 banner。

集成方式（main.py 已改好）
  顶部：    import period_care
  启动时：  period_care.startup_banner()
  调 generate_reply 之前：
      _care_prefix = await period_care.maybe_build_care_prefix(
                          pool, bot_instance.db_id, user_id)
      if _care_prefix:
          content = _care_prefix + content
"""
import json
import time
import datetime

import utils   # 复用 add_temp_log

FLOW_LABEL = {'none': '无', 'light': '少', 'mid': '较多', 'heavy': '大量'}
MOOD_LABEL = {'happy': '开心', 'calm': '平静', 'tired': '疲惫', 'irritable': '烦躁'}

LOG_TAG = "[让Ta更懂你]"


# =====================================================================
# 启动 banner —— main.py 启动时调一次，确认模块已加载
# =====================================================================
def startup_banner():
    print("=" * 60, flush=True)
    print(f"{LOG_TAG} 模块已启动 (period_care v3)", flush=True)
    print(f"{LOG_TAG} 工作方式：每条用户消息 → 查 care_switch → 开启则把经期"
          f"关怀文本拼到用户消息最前", flush=True)
    print(f"{LOG_TAG} 注入方式：作为 user 消息前缀（不写 context、不会被 "
          f"chat.py 的 system 过滤跳过）", flush=True)
    print("=" * 60, flush=True)


# =====================================================================
# 日志助手
# =====================================================================
async def _log(pool, db_id, msg):
    line = f"{LOG_TAG} {msg}"
    try:
        await utils.add_temp_log(pool, db_id, line)
    except Exception as e:
        print(f"{LOG_TAG} 写 temp_log 失败: {e}", flush=True)
    print(line, flush=True)


# =====================================================================
# 日期工具
# =====================================================================
def _today():
    return datetime.date.today()


def _d2s(d):
    return d.strftime('%Y-%m-%d')


def _parse_date(v):
    if isinstance(v, datetime.datetime):
        return v.date()
    if isinstance(v, datetime.date):
        return v
    # MySQL 驱动或旧数据可能把 NULL 返回成 None / "None" / 空串。
    # 这类记录不能参与日期计算，但也不应让整轮聊天因 strptime 报错。
    text = str(v or "").strip()
    if not text or text.lower() in {"none", "null", "0000-00-00"}:
        return None
    try:
        return datetime.datetime.strptime(text[:10], '%Y-%m-%d').date()
    except (TypeError, ValueError):
        return None


# =====================================================================
# 阶段判定 —— 依据《测量说明》
# =====================================================================
def _compute_phase(today, segments, cycle):
    cycle_len = min(35, max(22, cycle.get('cycle_len') or 28))

    for seg in segments:
        if seg['start'] <= today <= seg['end']:
            day_n = (today - seg['start']).days + 1
            if today == seg['end']:
                return f"经期结束（经期第 {day_n} 天）"
            return f"经期第 {day_n} 天"

    if not segments:
        return None

    last = segments[-1]
    next_start = last['start']
    guard = 0
    while next_start <= today and guard < 60:
        next_start = next_start + datetime.timedelta(days=cycle_len)
        guard += 1
    days_to_next = (next_start - today).days

    if days_to_next == 1:
        return "月经前一天"
    if days_to_next == 2:
        return "月经前两天"
    if days_to_next == 3:
        return "月经前三天"

    ovu_day = next_start - datetime.timedelta(days=14)
    delta_ovu = (today - ovu_day).days
    if delta_ovu == 0:
        return "排卵日"
    if -5 <= delta_ovu <= 4:
        return "易孕期"
    if today < ovu_day:
        return "卵泡期"
    return "黄体期"


# =====================================================================
# 近 7 天每日数据文本
# =====================================================================
def _recent_7days_text(today, days_map, segments):
    def in_period(d):
        for seg in segments:
            if seg['start'] <= d <= seg['end']:
                return True
        return False

    lines = []
    for i in range(6, -1, -1):
        d = today - datetime.timedelta(days=i)
        ds = _d2s(d)
        rec = days_map.get(ds) or {}
        parts = []
        if in_period(d):
            parts.append("经期")
        if rec.get('flow'):
            parts.append("出血量" + FLOW_LABEL.get(rec['flow'], rec['flow']))
        if rec.get('mood'):
            parts.append("心情" + MOOD_LABEL.get(rec['mood'], rec['mood']))
        syms = rec.get('symptoms') or []
        if syms:
            parts.append("症状：" + "、".join(syms))
        if rec.get('sym_note'):
            parts.append("补充：" + rec['sym_note'])
        lines.append(f"  {ds}：" + ("，".join(parts) if parts else "无记录"))
    return "\n".join(lines)


def _build_notice(phase, days_text):
    # 用清晰的分隔标记包裹，AI 一眼能认出这是系统给的背景信息
    return (
        f"【系统背景·让Ta更懂你】（这是系统提供给你的背景信息，不是用户说的话，"
        f"请自然地把关心融进你的回复里，不要直接复述本段）\n"
        f"【特殊阶段】用户现在是 {phase}，"
        f"他在近 7 天的数据是：\n{days_text}\n"
        f"你可以适当地关心一下。\n"
        f"【系统背景结束】\n\n"
    )


# =====================================================================
# DB 读取
# =====================================================================
async def _load_user_period(pool, user_id):
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT period_len, cycle_len, care_switch "
                "FROM couple_period_cycle WHERE user_id=%s",
                (user_id,),
            )
            crow = await cur.fetchone()
            if not crow:
                return None, [], {}
            cycle = {
                'period_len':  int(crow['period_len']),
                'cycle_len':   int(crow['cycle_len']),
                'care_switch': int(crow['care_switch']),
            }

            await cur.execute(
                "SELECT start_date, end_date FROM couple_period_segment "
                "WHERE user_id=%s ORDER BY start_date",
                (user_id,),
            )
            segments = []
            for r in (await cur.fetchall() or []):
                start = _parse_date(r['start_date'])
                end = _parse_date(r['end_date'])
                if start is not None and end is not None and start <= end:
                    segments.append({'start': start, 'end': end})

            await cur.execute(
                "SELECT log_date, flow, mood, symptoms, sym_note "
                "FROM couple_period_day WHERE user_id=%s",
                (user_id,),
            )
            days_map = {}
            for r in (await cur.fetchall() or []):
                rec = {}
                if r['flow']:
                    rec['flow'] = r['flow']
                if r['mood']:
                    rec['mood'] = r['mood']
                if r['symptoms']:
                    try:
                        arr = json.loads(r['symptoms'])
                        if isinstance(arr, list) and arr:
                            rec['symptoms'] = arr
                    except Exception:
                        pass
                if r['sym_note']:
                    rec['sym_note'] = r['sym_note']
                log_date = _parse_date(r['log_date'])
                if log_date is not None:
                    days_map[_d2s(log_date)] = rec
    return cycle, segments, days_map


# =====================================================================
# 去重
# =====================================================================
async def _already_pushed(pool, user_id, push_type, push_key):
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT id FROM couple_period_care_push "
                "WHERE user_id=%s AND push_type=%s AND push_key=%s",
                (user_id, push_type, push_key),
            )
            return (await cur.fetchone()) is not None


async def _mark_pushed(pool, user_id, push_type, push_key):
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "INSERT IGNORE INTO couple_period_care_push "
                "(user_id, push_type, push_key, created_at) VALUES (%s,%s,%s,%s)",
                (user_id, push_type, push_key, int(time.time())),
            )
        await conn.commit()


# =====================================================================
# 对外入口 —— main.py 在调 generate_reply 之前调用本函数
#   返回值：
#     非空字符串 = 要拼到用户消息最前面的关怀文本
#     ""        = 不注入（开关关 / 已去重 / 无记录 / 出错）
# =====================================================================
async def maybe_build_care_prefix(pool, db_id, user_id):
    try:
        if not user_id:
            await _log(pool, db_id, "跳过：该实例没有绑定 user_id")
            return ""

        cycle, segments, days_map = await _load_user_period(pool, user_id)

        if not cycle:
            await _log(pool, db_id,
                       f"跳过：user_id={user_id} 没有周期设置（从未使用经期功能）")
            return ""

        if cycle.get('care_switch') != 1:
            await _log(pool, db_id,
                       f"跳过：user_id={user_id} 开关未开启（care_switch=0），走原逻辑")
            return ""

        today = _today()
        today_s = _d2s(today)

        phase = _compute_phase(today, segments, cycle)
        if not phase:
            await _log(pool, db_id,
                       f"跳过：user_id={user_id} 已开启开关，但没有任何经期记录段，"
                       f"算不出当前阶段")
            return ""

        await _log(pool, db_id,
                   f"user_id={user_id} 开关已开启 | 当前阶段：{phase} | "
                   f"经期段 {len(segments)} 条 | 每日记录 {len(days_map)} 条")

        days_text = _recent_7days_text(today, days_map, segments)
        notice = _build_notice(phase, days_text)

        # 判断今天/本结束日是否已推送过
        need_daily = not await _already_pushed(pool, user_id, 'daily', today_s)
        end_seg = next((s for s in segments if s['end'] == today), None)
        end_key = _d2s(end_seg['end']) if end_seg else None
        need_end = bool(end_seg) and not await _already_pushed(
            pool, user_id, 'period_end', end_key)

        if not need_daily and not need_end:
            await _log(pool, db_id,
                       f"本次不注入：今日({today_s})每日推送已做过"
                       + (f"、经期结束({end_key})也已做过" if end_seg else "")
                       + "（去重）")
            return ""

        # 标记去重 —— 注意：这里就标记，因为 main.py 拿到 prefix 后必定拼进 content
        if need_daily:
            await _mark_pushed(pool, user_id, 'daily', today_s)
        if need_end:
            await _mark_pushed(pool, user_id, 'period_end', end_key)

        reason = []
        if need_daily:
            reason.append("每日推送")
        if need_end:
            reason.append(f"经期结束({end_key})")
        await _log(pool, db_id,
                   f"✓ 已生成关怀前缀（{' + '.join(reason)}）| 阶段：{phase} | "
                   f"长度 {len(notice)} 字，将拼到用户本轮消息最前 → 必定进入 "
                   f"user_prompt 发给 LLM")

        return notice

    except Exception as e:
        try:
            await _log(pool, db_id,
                       f"✗ 异常（已忽略，不影响消息处理）：{type(e).__name__}: {e}")
        except Exception:
            print(f"{LOG_TAG} maybe_build_care_prefix 异常: {e}", flush=True)
        return ""
