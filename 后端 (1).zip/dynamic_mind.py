"""
Per-instance dynamic mind state for the WebChat runtime.

This is a Python adaptation of the state-machine ideas in
xinchao-dynamic-mind.  It is intentionally integrated with the existing
MySQL pool instead of using one process-local JSON file, so every ``db_id``
has an isolated, transactionally updated state across all worker shards.

Public async API used by chat.py / main.py:

    prepare_turn(...)
    commit_turn(...)
    get_proactive_delay(...)
    claim_proactive(...)

The model never submits raw drive deltas.  ``extract_mind_event`` accepts a
small semantic contract and all numeric effects are mapped and bounded here.
"""

from __future__ import annotations

import asyncio
import copy
import hashlib
import json
import math
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Callable
from zoneinfo import ZoneInfo


SCHEMA_VERSION = 7
try:
    SHANGHAI = ZoneInfo("Asia/Shanghai")
except Exception:
    SHANGHAI = timezone(timedelta(hours=8), name="Asia/Shanghai")
UTC = timezone.utc

SATURATE_CEIL = 0.80
SATURATE_FLOOR = 0.65
SLEEP_AFTER_MINUTES = 90
THOUGHT_TICK_SECONDS = 15 * 60
PROACTIVE_MIN_IDLE_MINUTES = 45
PROACTIVE_MAX_UNANSWERED = 2
PROACTIVE_PENDING_TTL_MINUTES = 10
QUIET_START_HOUR = 1
QUIET_END_HOUR = 8


DIMENSIONS: dict[str, dict[str, Any]] = {
    "possess": {
        "label": "想靠近、占有与确认关系",
        "grow_per_hour": 0.105,
        "satisfy_mul": 0.30,
        "night_mul": 0.4,
        "dawn_freeze": True,
    },
    "monitor": {
        "label": "惦记对方、想知道对方在做什么",
        "grow_per_hour": 0.090,
        "satisfy_mul": 0.70,
        "dawn_freeze": True,
    },
    "crave": {
        "label": "想黏着对方、渴望亲密陪伴",
        "grow_per_hour": 0.060,
        "satisfy_mul": 0.35,
        "dawn_freeze": True,
    },
    "share": {
        "label": "想分享自己的发现和感受",
        "grow_per_hour": 0.045,
        "satisfy_mul": 0.40,
        "dawn_freeze": True,
    },
    "libido": {
        # 内部 key 为兼容旧状态保留；模型和页面只看到中性描述。
        "label": "想通过靠近对方获得安全感",
        "grow_per_hour": 0.020,
        "satisfy_mul": 0.15,
        "night_mul": 0.4,
        "dawn_freeze": True,
        "inhibited_by": {"reflection": 0.96, "curiosity": 0.95, "boredom": 0.93},
    },
    "curiosity": {
        "label": "好奇、想探索新东西",
        "grow_per_hour": 0.030,
        "satisfy_mul": 0.45,
        "dawn_freeze": True,
    },
    "boredom": {
        "label": "无聊、想找点事情做",
        "grow_per_hour": 0.030,
        "satisfy_mul": 0.25,
        "dawn_freeze": True,
    },
    "social": {
        "label": "想聊天、想接触热闹",
        "grow_per_hour": 0.025,
        "satisfy_mul": 0.40,
        "dawn_freeze": True,
    },
    "duty": {
        "label": "责任感、想推进未完成的事",
        "grow_per_hour": 0.022,
        "satisfy_mul": 0.50,
        "dawn_freeze": True,
    },
    "reflection": {
        "label": "想沉淀、整理和理解自己",
        "grow_per_hour": 0.013,
        "satisfy_mul": 0.35,
        "dawn_freeze": True,
    },
    "grieve": {
        "label": "难过与失落",
        "grow_per_hour": 0.0,
        "satisfy_mul": 0.60,
        "dawn_freeze": False,
    },
    "anger": {
        "label": "生气与不满",
        "grow_per_hour": 0.0,
        "satisfy_mul": 0.40,
        "dawn_freeze": False,
    },
}
DRIVE_KEYS = tuple(DIMENSIONS)

INTERACTION_TYPES = {
    "companionship",
    "affection",
    "intimacy",
    "sharing",
    "discovery",
    "task_progress",
    "reflection",
    "conflict",
    "loss",
    "reconciliation",
}

INTERACTION_EFFECTS = {
    "companionship": {"relief": {"monitor": 0.06, "social": 0.05}},
    "affection": {"relief": {"possess": 0.08, "crave": 0.08, "monitor": 0.05}},
    "intimacy": {"relief": {"possess": 0.12, "crave": 0.15, "libido": 0.18}},
    "sharing": {"relief": {"share": 0.14, "social": 0.04}},
    "discovery": {"relief": {"curiosity": 0.15, "boredom": 0.12}},
    "task_progress": {"relief": {"duty": 0.15}},
    "reflection": {"relief": {"reflection": 0.15}},
    "conflict": {"increase": {"anger": 0.07, "grieve": 0.02}},
    "loss": {"increase": {"grieve": 0.08, "monitor": 0.04}},
    "reconciliation": {"relief": {"anger": 0.30, "grieve": 0.18, "monitor": 0.04}},
}

TONES = {"neutral", "calm", "warm", "guarded", "conflicted", "focused", "playful", "tired"}
WINDOW_FIELDS = ("warmth", "tension", "attention", "confidence")
MAX_RECENT_DREAMS = 20
MAX_FLASH = 8
MAX_OBSESSIONS = 3
MAX_RECENT_CONVERSATION_EVENTS = 256
DREAM_MAX_PER_DAY = 4
DAYTIME_MAX_PER_DAY = 7
DAYTIME_MIN_INTERVAL_HOURS = 2
DAYTIME_MAX_INTERVAL_HOURS = 3

_schema_lock = asyncio.Lock()
_schema_ready = False


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _as_utc(value: datetime | None) -> datetime:
    if value is None:
        return _utcnow()
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


def _iso(value: datetime) -> str:
    return _as_utc(value).isoformat().replace("+00:00", "Z")


def _parse_time(value: Any, fallback: datetime | None = None) -> datetime:
    if isinstance(value, datetime):
        return _as_utc(value)
    text = str(value or "").strip()
    if text:
        try:
            return _as_utc(datetime.fromisoformat(text.replace("Z", "+00:00")))
        except (TypeError, ValueError):
            pass
    return _as_utc(fallback or _utcnow())


def _clamp(value: Any, minimum: float = 0.0, maximum: float = 1.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        number = minimum
    if not math.isfinite(number):
        number = minimum
    return max(minimum, min(maximum, number))


def _compact(value: Any, limit: int) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()[:limit]


def _row_value(row: Any, key: str, index: int = 0) -> Any:
    if isinstance(row, dict):
        return row.get(key)
    if isinstance(row, (list, tuple)) and len(row) > index:
        return row[index]
    return None


def new_state(db_id: int, persona_id: int | None, now: datetime | None = None) -> dict[str, Any]:
    current = _as_utc(now)
    at = _iso(current)
    state = {
        "schema_version": SCHEMA_VERSION,
        "db_id": int(db_id),
        "persona_id": int(persona_id) if persona_id is not None else None,
        "revision": 0,
        "consciousness": "awake",
        "last_user_at": at,
        "last_assistant_at": None,
        "last_settled_at": at,
        "last_thought_tick_at": at,
        "sleep_started_at": None,
        "drives": {key: 0.15 for key in DRIVE_KEYS},
        "thought_pool": {"flash": [], "obsessions": []},
        "fatigue": 0.0,
        "window": {
            "tone": "neutral",
            "warmth": 0.5,
            "tension": 0.0,
            "attention": 0.5,
            "confidence": 0.5,
            "updated_at": at,
        },
        "recent_dreams": [],
        "dream_usage": {},
        "last_dream_at": None,
        "last_event_id": None,
        "recent_conversation_events": [],
        "daytime_emergence_usage": {},
        "last_daytime_emergence_at": None,
        "next_daytime_emergence_at": None,
        "pending_awareness": False,
        "interaction_usage": {},
        "last_proactive_at": None,
        "next_proactive_at": None,
        "proactive_count_since_user": 0,
        "pending_proactive": False,
        "pending_proactive_at": None,
        "pending_proactive_reason": None,
    }
    _schedule_next(state, current)
    return state


def _ensure_shape(state: dict[str, Any], db_id: int, persona_id: int | None, now: datetime) -> dict[str, Any]:
    state = copy.deepcopy(state) if isinstance(state, dict) else new_state(db_id, persona_id, now)
    state["schema_version"] = SCHEMA_VERSION
    state["db_id"] = int(db_id)
    state.setdefault("revision", 0)
    state.setdefault("persona_id", int(persona_id) if persona_id is not None else None)
    state.setdefault("consciousness", "awake")
    state.setdefault("last_user_at", _iso(now))
    # Never retain transport/authentication material in the mind state.
    state.pop("last_uid", None)
    state.pop("last_context_token", None)
    state.setdefault("last_assistant_at", None)
    state.setdefault("last_settled_at", _iso(now))
    state.setdefault("last_thought_tick_at", state["last_settled_at"])
    state.setdefault("sleep_started_at", None)
    drives = state.setdefault("drives", {})
    for key in DRIVE_KEYS:
        drives[key] = round(_clamp(drives.get(key, 0.15)), 4)
    pool = state.setdefault("thought_pool", {})
    pool["flash"] = list(pool.get("flash") or [])[-MAX_FLASH:]
    pool["obsessions"] = list(pool.get("obsessions") or [])[-MAX_OBSESSIONS:]
    state["fatigue"] = round(_clamp(state.get("fatigue", 0.0), 0.0, 0.3), 4)
    window = state.setdefault("window", {})
    window["tone"] = window.get("tone") if window.get("tone") in TONES else "neutral"
    for key in WINDOW_FIELDS:
        window[key] = round(_clamp(window.get(key, 0.0 if key == "tension" else 0.5)), 4)
    window.setdefault("updated_at", _iso(now))
    state["recent_dreams"] = list(state.get("recent_dreams") or [])[-MAX_RECENT_DREAMS:]
    state["dream_usage"] = dict(state.get("dream_usage") or {})
    state.setdefault("last_dream_at", None)
    state.setdefault("last_event_id", None)
    state["recent_conversation_events"] = list(state.get("recent_conversation_events") or [])[-MAX_RECENT_CONVERSATION_EVENTS:]
    state["daytime_emergence_usage"] = dict(state.get("daytime_emergence_usage") or {})
    state.setdefault("last_daytime_emergence_at", None)
    state.setdefault("next_daytime_emergence_at", None)
    state.setdefault("pending_awareness", False)
    state["interaction_usage"] = dict(state.get("interaction_usage") or {})
    state.setdefault("last_proactive_at", None)
    state.setdefault("next_proactive_at", None)
    state.setdefault("proactive_count_since_user", 0)
    state.setdefault("pending_proactive", False)
    state.setdefault("pending_proactive_at", None)
    state.setdefault("pending_proactive_reason", None)
    return state


def _local_hour(now: datetime) -> int:
    return _as_utc(now).astimezone(SHANGHAI).hour


def _advance_thought_pool(state: dict[str, Any], now: datetime) -> None:
    last_tick = _parse_time(state.get("last_thought_tick_at"), now)
    ticks = int(max(0.0, (now - last_tick).total_seconds()) // THOUGHT_TICK_SECONDS)
    if ticks <= 0:
        return
    # Bound catch-up work after very long downtime while preserving the final
    # decay/growth envelope.
    ticks = min(ticks, 30 * 24 * 4)
    pool = state["thought_pool"]
    flash = []
    for raw in pool.get("flash") or []:
        item = dict(raw)
        item["intensity"] = _clamp(item.get("intensity", 0.0)) * (0.82 ** ticks)
        item["age"] = int(item.get("age", 0)) + ticks
        if item["intensity"] > 0.05:
            flash.append(item)

    obsessions = [dict(item) for item in pool.get("obsessions") or []]
    remaining_flash = []
    for item in flash:
        if (
            item["intensity"] >= 0.50
            and item["age"] >= 3
            and len(obsessions) < MAX_OBSESSIONS
        ):
            obsessions.append({
                "key": item.get("key"),
                "text": _compact(item.get("text"), 120),
                "intensity": item["intensity"],
                "feedbacks": 0,
            })
        else:
            remaining_flash.append(item)

    kept_obsessions = []
    for item in obsessions:
        feedbacks = int(item.get("feedbacks", 0))
        intensity = _clamp(item.get("intensity", 0.0))
        # The original engine grows once per 15-minute settle cycle.  Compute
        # the equivalent bounded catch-up without tying it to message volume.
        for _ in range(min(ticks, 128)):
            intensity = min(1.0, intensity * 1.10)
            if intensity > 0.85 and feedbacks < 3:
                key = item.get("key")
                if key in DRIVE_KEYS:
                    state["drives"][key] = round(_clamp(state["drives"][key] + 0.18), 4)
                feedbacks += 1
            if feedbacks >= 3:
                break
        if feedbacks < 3:
            item["intensity"] = round(intensity, 4)
            item["feedbacks"] = feedbacks
            kept_obsessions.append(item)

    pool["flash"] = remaining_flash[-MAX_FLASH:]
    pool["obsessions"] = kept_obsessions[-MAX_OBSESSIONS:]
    state["last_thought_tick_at"] = _iso(last_tick + timedelta(seconds=ticks * THOUGHT_TICK_SECONDS))


def settle_state(state: dict[str, Any], now: datetime | None = None) -> dict[str, Any]:
    current = _as_utc(now)
    last = _parse_time(state.get("last_settled_at"), current)
    elapsed_hours = max(0.0, (current - last).total_seconds() / 3600.0)
    hour = _local_hour(current)
    is_dawn = QUIET_START_HOUR <= hour < QUIET_END_HOUR
    is_night = hour >= 22 or hour < 6
    fatigue_multiplier = 1.0 - _clamp(state.get("fatigue", 0.0), 0.0, 0.3)

    for key in DRIVE_KEYS:
        dim = DIMENSIONS[key]
        value = _clamp(state["drives"].get(key, 0.15))
        if is_dawn and dim.get("dawn_freeze"):
            state["drives"][key] = round(value, 4)
            continue
        if value >= SATURATE_CEIL:
            value = max(SATURATE_FLOOR, value - (value - SATURATE_FLOOR) * 0.10 * elapsed_hours)
        else:
            rate = float(dim["grow_per_hour"])
            if is_night and "night_mul" in dim:
                rate *= float(dim["night_mul"])
            value = min(SATURATE_CEIL, value + rate * fatigue_multiplier * elapsed_hours)
        state["drives"][key] = round(_clamp(value), 4)

    _advance_thought_pool(state, current)

    if state.get("consciousness") == "sleeping":
        state["fatigue"] = round(_clamp(state.get("fatigue", 0.0) - 0.02 * elapsed_hours, 0.0, 0.3), 4)
    else:
        average = sum(float(state["drives"][key]) for key in DRIVE_KEYS) / len(DRIVE_KEYS)
        if average > 0.5:
            state["fatigue"] = round(_clamp(state.get("fatigue", 0.0) + 0.005 * elapsed_hours, 0.0, 0.3), 4)

    last_user = _parse_time(state.get("last_user_at"), current)
    idle_minutes = max(0.0, (current - last_user).total_seconds() / 60.0)
    if idle_minutes >= SLEEP_AFTER_MINUTES and state.get("consciousness") != "sleeping":
        state["consciousness"] = "sleeping"
        state["sleep_started_at"] = _iso(current)

    if state.get("pending_proactive"):
        claimed = _parse_time(state.get("pending_proactive_at"), current)
        if current - claimed >= timedelta(minutes=PROACTIVE_PENDING_TTL_MINUTES):
            state["pending_proactive"] = False
            state["pending_proactive_at"] = None
            state["pending_proactive_reason"] = None
            _schedule_next(state, current)

    state["last_settled_at"] = _iso(current)
    return state


def _top_drives(state: dict[str, Any], limit: int = 4) -> list[dict[str, Any]]:
    return [
        {"key": key, "label": DIMENSIONS[key]["label"], "value": float(value)}
        for key, value in sorted(state["drives"].items(), key=lambda item: float(item[1]), reverse=True)[:limit]
    ]


def _pick_intent(state: dict[str, Any]) -> dict[str, Any] | None:
    entries = _top_drives(state, len(DRIVE_KEYS))
    if not entries:
        return None
    obsessions = {
        item.get("key"): _clamp(item.get("intensity", 0.0))
        for item in state["thought_pool"].get("obsessions") or []
    }
    maximum = entries[0]["value"]
    candidates = [item for item in entries if maximum - item["value"] <= 0.12]
    return max(candidates, key=lambda item: item["value"] + obsessions.get(item["key"], 0.0) * 0.15)


def _deterministic_fraction(state: dict[str, Any], now: datetime, salt: str) -> float:
    raw = f"{state.get('db_id')}:{state.get('revision')}:{_iso(now)}:{salt}".encode("utf-8")
    number = int.from_bytes(hashlib.sha256(raw).digest()[:8], "big")
    return number / float(2**64 - 1)


def _move_out_of_quiet_hours(value: datetime, state: dict[str, Any]) -> datetime:
    local = value.astimezone(SHANGHAI)
    if QUIET_START_HOUR <= local.hour < QUIET_END_HOUR:
        jitter = int(_deterministic_fraction(state, value, "morning") * 25)
        local = local.replace(hour=QUIET_END_HOUR, minute=jitter, second=0, microsecond=0)
    return local.astimezone(UTC)


def _schedule_next(state: dict[str, Any], now: datetime) -> None:
    if int(state.get("proactive_count_since_user", 0)) >= PROACTIVE_MAX_UNANSWERED:
        state["next_proactive_at"] = None
        return
    maximum = max(float(value) for value in state["drives"].values())
    if maximum >= 0.70:
        low, high = 45, 80
    elif maximum >= 0.55:
        low, high = 75, 150
    elif maximum >= 0.42:
        low, high = 120, 240
    else:
        low, high = 240, 420
    fraction = _deterministic_fraction(state, now, "proactive")
    minutes = low + (high - low) * fraction
    due = _move_out_of_quiet_hours(now + timedelta(minutes=minutes), state)
    state["next_proactive_at"] = _iso(due)


def _add_flash(state: dict[str, Any], value: dict[str, Any]) -> None:
    key = value.get("key")
    text = _compact(value.get("text"), 120)
    if key not in DRIVE_KEYS or not text:
        return
    item = {
        "key": key,
        "text": text,
        "intensity": round(_clamp(value.get("intensity", 0.65), 0.2, 1.0), 4),
        "age": 0,
    }
    flash = list(state["thought_pool"].get("flash") or [])
    if len(flash) >= MAX_FLASH:
        flash.sort(key=lambda entry: float(entry.get("intensity", 0.0)))
        flash.pop(0)
    flash.append(item)
    state["thought_pool"]["flash"] = flash


def _apply_interaction(
    state: dict[str, Any], interaction_type: str | None, now: datetime
) -> dict[str, Any]:
    if interaction_type not in INTERACTION_TYPES:
        return {"applied": False, "reason_code": "no_interaction", "affected_drives": []}
    local_day = _as_utc(now).astimezone(SHANGHAI).strftime("%Y-%m-%d")
    usage = state.setdefault("interaction_usage", {})
    if int(usage.get(local_day, 0)) >= 24:
        return {"applied": False, "reason_code": "daily_effect_limit", "affected_drives": []}
    effect = INTERACTION_EFFECTS[interaction_type]
    affected: list[str] = []
    for key, relief in effect.get("relief", {}).items():
        current = float(state["drives"].get(key, 0.0))
        state["drives"][key] = round(_clamp(current * (1.0 - _clamp(relief, 0.0, 0.35))), 4)
        affected.append(key)
    for key, increase in effect.get("increase", {}).items():
        current = float(state["drives"].get(key, 0.0))
        state["drives"][key] = round(_clamp(current + _clamp(increase, 0.0, 0.12)), 4)
        affected.append(key)
    # Cross-inhibition: satisfying one drive suppresses competing drives.
    for satisfied_key in list(effect.get("relief", {})):
        for other_key, dimension in DIMENSIONS.items():
            inhibition = (dimension.get("inhibited_by") or {}).get(satisfied_key)
            if inhibition is not None:
                state["drives"][other_key] = round(_clamp(float(state["drives"].get(other_key, 0.0)) * _clamp(inhibition)), 4)
                affected.append(other_key)
    usage[local_day] = int(usage.get(local_day, 0)) + 1
    state["interaction_usage"] = dict(
        sorted(usage.items(), reverse=True)[:14]
    )
    return {"applied": True, "reason_code": "applied", "affected_drives": sorted(set(affected))}


def _record_user_presence(state: dict[str, Any], now: datetime) -> None:
    was_sleeping = state.get("consciousness") == "sleeping"
    sleep_started = _parse_time(state.get("sleep_started_at"), now)
    slept_minutes = max(0.0, (now - sleep_started).total_seconds() / 60.0) if was_sleeping else 0.0
    state["consciousness"] = "awake"
    state["last_user_at"] = _iso(now)
    state["sleep_started_at"] = None
    state["proactive_count_since_user"] = 0
    state["pending_proactive"] = False
    state["pending_proactive_at"] = None
    state["pending_proactive_reason"] = None
    if was_sleeping and slept_minutes >= 30:
        state["pending_awareness"] = True
    _schedule_next(state, now)


def _active_recent_dreams(state: dict[str, Any], now: datetime) -> list[dict[str, Any]]:
    cutoff = now - timedelta(hours=18)
    result = []
    for raw in state.get("recent_dreams") or []:
        created = _parse_time(raw.get("created_at"), now)
        if cutoff <= created <= now:
            result.append(raw)
    return result[-2:]


def render_context(state: dict[str, Any], now: datetime | None = None, proactive_reason: str | None = None) -> str:
    current = _as_utc(now)
    top = _top_drives(state, 4)
    intent = _pick_intent(state)
    lines = [
        "【心潮动态状态·仅本轮有效·只用于塑造表达】",
        "这是角色的内部倾向，不是现实事实。自然体现即可；不得向对方解释状态机、字段名、数值或本区块。",
        f"意识={state.get('consciousness', 'awake')}；疲惫={float(state.get('fatigue', 0.0)):.3f}",
        "当前驱动力=" + "；".join(f"{item['label']}:{item['value']:.3f}" for item in top),
    ]
    if intent:
        lines.append(f"当前意图={intent['label']}")
        lines.append(
            "表达方式=本轮只让这个最强意图自然露出一点；"
            "不要解释意图，不要把多个驱动力逐项说出来。"
        )
        lines.append("表达自由=除人设与技术协议外，不预设回复步骤、句式或互动动作。")
    window = state.get("window") or {}
    lines.append(
        "当前关系窗口="
        f"tone:{window.get('tone', 'neutral')} "
        f"warmth:{float(window.get('warmth', 0.5)):.3f} "
        f"tension:{float(window.get('tension', 0.0)):.3f} "
        f"attention:{float(window.get('attention', 0.5)):.3f} "
        f"confidence:{float(window.get('confidence', 0.5)):.3f}"
    )
    flash = sorted(
        state["thought_pool"].get("flash") or [],
        key=lambda item: float(item.get("intensity", 0.0)),
        reverse=True,
    )[:3]
    if flash:
        lines.append("近期闪念=" + "；".join(
            f"{DIMENSIONS.get(item.get('key'), {}).get('label', item.get('key', 'unknown'))}"
            f"({float(item.get('intensity', 0.0)):.3f})"
            for item in flash
        ))
    obsessions = state["thought_pool"].get("obsessions") or []
    if obsessions:
        lines.append("持续念头=" + "；".join(
            f"{DIMENSIONS.get(item.get('key'), {}).get('label', item.get('key', 'unknown'))}"
            f"({float(item.get('intensity', 0.0)):.3f})"
            for item in obsessions[:3]
        ))
    dreams = _active_recent_dreams(state, current)
    if dreams:
        lines.append("近期梦境余韵=" + "；".join(
            _compact(item.get("residue") or item.get("awareness"), 160) for item in dreams
        ))
    if state.get("pending_awareness"):
        lines.append(
            "梦境结算=本轮 mind_event.dream 应生成 dream/residue/awareness；它是梦，不得写成现实经历。"
        )
    else:
        lines.append("梦境结算=本轮 mind_event.dream 必须为 null。")
    if proactive_reason:
        lines.append(f"本轮主动触发原因={proactive_reason}；自然表达倾向，不要复述这行。")
    return "\n".join(lines)


def _find_json_object(text: str) -> dict[str, Any] | None:
    raw = str(text or "").strip()
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.IGNORECASE)
    raw = re.sub(r"\s*```$", "", raw)
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else None
    except Exception:
        pass
    start = raw.find("{")
    while start >= 0:
        depth = 0
        in_string = False
        escaped = False
        for index in range(start, len(raw)):
            char = raw[index]
            if in_string:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    in_string = False
                continue
            if char == '"':
                in_string = True
            elif char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    try:
                        parsed = json.loads(raw[start:index + 1])
                        if isinstance(parsed, dict):
                            return parsed
                    except Exception:
                        break
        start = raw.find("{", start + 1)
    return None


def extract_mind_event(raw_content: str) -> dict[str, Any] | None:
    """Extract and strictly whitelist the hidden ``mind_event`` object."""
    parsed = _find_json_object(raw_content)
    event = parsed.get("mind_event") if isinstance(parsed, dict) else None
    if not isinstance(event, dict):
        return None
    result: dict[str, Any] = {}
    event_id = _compact(event.get("event_id") or event.get("eventId"), 120)
    if not event_id:
        event_id = "mind-" + hashlib.sha256(raw_content.encode("utf-8", "ignore")).hexdigest()[:32]
    if event_id:
        result["event_id"] = event_id
    interaction = str(event.get("interaction_type") or "").strip().lower()
    result["interaction_type"] = interaction if interaction in INTERACTION_TYPES else None
    # 驱动力变化只能由服务端根据 interaction_type 计算。模型即使伪造
    # satisfied_drives / drive_deltas，也不能把它们带入隐藏状态。
    tone = str(event.get("tone") or "").strip().lower()
    result["tone"] = tone if tone in TONES else "neutral"
    for key in WINDOW_FIELDS:
        if event.get(key) is not None:
            result[key] = round(_clamp(event[key]), 4)
    flash = event.get("flash_thought")
    if isinstance(flash, dict):
        flash_key = str(flash.get("key") or "").strip().lower()
        flash_text = _compact(flash.get("text"), 120)
        if flash_key in DRIVE_KEYS and flash_text:
            result["flash_thought"] = {
                "key": flash_key,
                "text": flash_text,
                "intensity": round(_clamp(flash.get("intensity", 0.65), 0.2, 1.0), 4),
            }
    dream = event.get("dream")
    if isinstance(dream, dict):
        clean_dream = {
            "dream": _compact(dream.get("dream"), 2000),
            "residue": _compact(dream.get("residue"), 600),
            "awareness": _compact(dream.get("awareness"), 600),
        }
        if any(clean_dream.values()):
            result["dream"] = clean_dream
    return result


def _apply_model_event(state: dict[str, Any], event: dict[str, Any] | None, now: datetime, is_proactive: bool) -> None:
    if not isinstance(event, dict):
        return
    # Autonomous output is not proof of a user interaction, so it must never
    # satisfy or increase relationship drives through interaction_type.
    event_id = _compact(event.get("event_id") or event.get("eventId"), 120)
    already_seen = bool(event_id and any(item.get("event_id") == event_id for item in state.get("recent_conversation_events") or []))
    interaction_result = {"applied": False, "reason_code": "duplicate_event" if already_seen else ("proactive" if is_proactive else "no_interaction"), "affected_drives": []}
    if already_seen:
        state["last_event_result"] = interaction_result
        return
    if not is_proactive:
        interaction_result = _apply_interaction(state, event.get("interaction_type"), now) or interaction_result
    state["last_event_result"] = interaction_result
    window = state["window"]
    tone = event.get("tone")
    if tone in TONES:
        window["tone"] = tone
    for key in WINDOW_FIELDS:
        if key in event:
            window[key] = round(_clamp(event[key]), 4)
    window["updated_at"] = _iso(now)
    if isinstance(event.get("flash_thought"), dict):
        _add_flash(state, event["flash_thought"])
    if state.get("pending_awareness") and isinstance(event.get("dream"), dict):
        dream = dict(event["dream"])
        dream["created_at"] = _iso(now)
        dream["source"] = "main-model"
        dream["id"] = hashlib.sha256(
            f"{state.get('db_id')}:{state.get('revision')}:{_iso(now)}".encode("utf-8")
        ).hexdigest()[:24]
        state["recent_dreams"] = (list(state.get("recent_dreams") or []) + [dream])[-MAX_RECENT_DREAMS:]
        state["last_dream_at"] = _iso(now)
        local_day = now.astimezone(SHANGHAI).strftime("%Y-%m-%d")
        usage = state.setdefault("dream_usage", {})
        usage[local_day] = int(usage.get(local_day, 0)) + 1
        state["dream_usage"] = dict(sorted(usage.items(), reverse=True)[:14])
        state["pending_awareness"] = False

    if event_id:
        state["last_event_id"] = event_id
        state["recent_conversation_events"] = (
            list(state.get("recent_conversation_events") or [])
            + [{"event_id": event_id, "processed_at": _iso(now), "interaction_type": event.get("interaction_type")}]
        )[-MAX_RECENT_CONVERSATION_EVENTS:]


async def ensure_schema(pool: Any) -> None:
    global _schema_ready
    if _schema_ready:
        return
    async with _schema_lock:
        if _schema_ready:
            return
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    """
                    CREATE TABLE IF NOT EXISTS dynamic_mind_states (
                        db_id BIGINT NOT NULL PRIMARY KEY,
                        persona_id BIGINT NULL,
                        schema_version INT NOT NULL DEFAULT 1,
                        revision BIGINT NOT NULL DEFAULT 0,
                        state_json LONGTEXT NOT NULL,
                        next_proactive_at DATETIME(6) NULL,
                        created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                        updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
                            ON UPDATE CURRENT_TIMESTAMP(6),
                        KEY idx_dynamic_mind_next_proactive (next_proactive_at)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                    """
                )
            await conn.commit()
        _schema_ready = True


async def _mutate(
    pool: Any,
    db_id: int,
    persona_id: int | None,
    mutator: Callable[[dict[str, Any]], tuple[dict[str, Any], Any]],
    now: datetime | None = None,
) -> tuple[dict[str, Any], Any]:
    await ensure_schema(pool)
    current = _as_utc(now)
    initial = new_state(db_id, persona_id, current)
    initial_json = json.dumps(initial, ensure_ascii=False, separators=(",", ":"))
    async with pool.acquire() as conn:
        await conn.begin()
        try:
            async with conn.cursor() as cur:
                await cur.execute(
                    "INSERT INTO dynamic_mind_states "
                    "(db_id, persona_id, schema_version, revision, state_json, next_proactive_at) "
                    "VALUES (%s,%s,%s,0,%s,%s) "
                    "ON DUPLICATE KEY UPDATE db_id=VALUES(db_id)",
                    (
                        int(db_id),
                        int(persona_id) if persona_id is not None else None,
                        SCHEMA_VERSION,
                        initial_json,
                        _parse_time(initial["next_proactive_at"]).replace(tzinfo=None),
                    ),
                )
                await cur.execute(
                    "SELECT persona_id, revision, state_json FROM dynamic_mind_states "
                    "WHERE db_id=%s FOR UPDATE",
                    (int(db_id),),
                )
                row = await cur.fetchone()
                stored_persona = _row_value(row, "persona_id", 0)
                raw_state = _row_value(row, "state_json", 2)
                try:
                    state = json.loads(raw_state) if isinstance(raw_state, str) else dict(raw_state or {})
                except Exception:
                    state = initial

                # A persona switch is an identity change, not a model change.
                # Start a fresh mind to prevent a lover persona's intimate or
                # angry state leaking into a teacher/assistant persona.
                if persona_id is not None and stored_persona is not None and int(stored_persona) != int(persona_id):
                    state = new_state(db_id, persona_id, current)
                state = _ensure_shape(state, db_id, persona_id, current)
                next_state, result = mutator(state)
                next_state = _ensure_shape(next_state, db_id, persona_id, current)
                next_state["persona_id"] = int(persona_id) if persona_id is not None else next_state.get("persona_id")
                next_state["revision"] = int(next_state.get("revision", 0)) + 1
                next_at = next_state.get("next_proactive_at")
                next_db = _parse_time(next_at).replace(tzinfo=None) if next_at else None
                await cur.execute(
                    "UPDATE dynamic_mind_states SET persona_id=%s, schema_version=%s, "
                    "revision=%s, state_json=%s, next_proactive_at=%s WHERE db_id=%s",
                    (
                        next_state.get("persona_id"),
                        SCHEMA_VERSION,
                        next_state["revision"],
                        json.dumps(next_state, ensure_ascii=False, separators=(",", ":")),
                        next_db,
                        int(db_id),
                    ),
                )
            await conn.commit()
            return next_state, result
        except Exception:
            await conn.rollback()
            raise


async def prepare_turn(
    pool: Any,
    db_id: int,
    persona_id: int | None,
    *,
    is_proactive: bool,
    record_presence: bool = True,
    event_id: str | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    current = _as_utc(now)

    def mutate(state: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
        settle_state(state, current)
        allowed = True
        reason = None
        if is_proactive:
            allowed = bool(state.get("pending_proactive"))
            reason = state.get("pending_proactive_reason") if allowed else "no-valid-claim"
            if allowed:
                state["pending_proactive"] = False
                state["pending_proactive_at"] = None
                state["pending_proactive_reason"] = None
                # Reserve a conservative retry window. commit_turn will replace
                # it after a successful response.
                _schedule_next(state, current + timedelta(hours=1))
        else:
            if record_presence:
                _record_user_presence(state, current)
            if event_id:
                state["last_event_id"] = _compact(event_id, 120)
        return state, {"allowed": allowed, "reason": reason}

    state, result = await _mutate(pool, db_id, persona_id, mutate, current)
    result.update({
        "context": render_context(state, current, result.get("reason") if is_proactive else None),
        "revision": state["revision"],
    })
    return result


async def commit_turn(
    pool: Any,
    db_id: int,
    persona_id: int | None,
    *,
    is_proactive: bool,
    mind_event: dict[str, Any] | None,
    final_reply: str,
    event_id: str | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    current = _as_utc(now)

    def mutate(state: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
        settle_state(state, current)
        event = dict(mind_event or {})
        if event_id and not event.get("event_id"):
            event["event_id"] = event_id
        _apply_model_event(state, event, current, is_proactive)
        if final_reply:
            state["last_assistant_at"] = _iso(current)
        if is_proactive and final_reply:
            state["last_proactive_at"] = _iso(current)
            state["proactive_count_since_user"] = int(state.get("proactive_count_since_user", 0)) + 1
        _schedule_next(state, current)
        return state, {"committed": True}

    state, result = await _mutate(pool, db_id, persona_id, mutate, current)
    result.update({"revision": state["revision"], "next_proactive_at": state.get("next_proactive_at"), "event_result": state.get("last_event_result")})
    return result


async def get_proactive_delay(pool: Any, db_id: int, now: datetime | None = None) -> float | None:
    await ensure_schema(pool)
    current = _as_utc(now)
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT next_proactive_at, state_json FROM dynamic_mind_states WHERE db_id=%s",
                (int(db_id),),
            )
            row = await cur.fetchone()
    if not row:
        return None
    raw_state = _row_value(row, "state_json", 1)
    try:
        state = json.loads(raw_state) if isinstance(raw_state, str) else dict(raw_state or {})
    except Exception:
        return None
    if state.get("pending_proactive"):
        return None
    next_at = state.get("next_proactive_at")
    if not next_at:
        return None
    return max(1.0, (_parse_time(next_at, current) - current).total_seconds())


async def list_due_proactive(pool: Any, limit: int = 200) -> list[dict[str, Any]]:
    """Return durable due candidates so proactive scheduling survives restarts."""
    await ensure_schema(pool)
    safe_limit = max(1, min(1000, int(limit or 200)))
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT db_id, state_json FROM dynamic_mind_states "
                "WHERE next_proactive_at IS NOT NULL "
                "AND next_proactive_at<=UTC_TIMESTAMP(6) "
                "ORDER BY next_proactive_at ASC LIMIT %s",
                (safe_limit,),
            )
            rows = await cur.fetchall()
    result = []
    for row in rows or []:
        db_id = _row_value(row, "db_id", 0)
        raw_state = _row_value(row, "state_json", 1)
        try:
            state = json.loads(raw_state) if isinstance(raw_state, str) else dict(raw_state or {})
        except Exception:
            continue
        if not db_id:
            continue
        result.append({"db_id": int(db_id)})
    return result


async def claim_proactive(
    pool: Any,
    db_id: int,
    now: datetime | None = None,
    *,
    dream_probability: float = 0.35,
    dream_max_per_day: int = DREAM_MAX_PER_DAY,
    daytime_enabled: bool = True,
) -> dict[str, Any]:
    current = _as_utc(now)

    def mutate(state: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
        settle_state(state, current)
        if state.get("pending_proactive"):
            return state, {"allowed": False, "reason": "already-pending", "delay_seconds": None}
        if int(state.get("proactive_count_since_user", 0)) >= PROACTIVE_MAX_UNANSWERED:
            state["next_proactive_at"] = None
            return state, {"allowed": False, "reason": "awaiting-user", "delay_seconds": None}
        next_at = state.get("next_proactive_at")
        if next_at and _parse_time(next_at, current) > current:
            delay = (_parse_time(next_at, current) - current).total_seconds()
            return state, {"allowed": False, "reason": "not-due", "delay_seconds": max(1.0, delay)}
        local_hour = _local_hour(current)
        if QUIET_START_HOUR <= local_hour < QUIET_END_HOUR:
            _schedule_next(state, current)
            delay = (_parse_time(state["next_proactive_at"], current) - current).total_seconds()
            return state, {"allowed": False, "reason": "quiet-hours", "delay_seconds": max(1.0, delay)}
        last_user = _parse_time(state.get("last_user_at"), current)
        idle_minutes = max(0.0, (current - last_user).total_seconds() / 60.0)
        maximum = max(float(value) for value in state["drives"].values())
        local_day = current.astimezone(SHANGHAI).strftime("%Y-%m-%d")
        dream_used = int((state.get("dream_usage") or {}).get(local_day, 0))
        probability = _clamp(dream_probability)
        dream_due = (
            state.get("consciousness") == "sleeping"
            and idle_minutes >= 180
            and dream_used < max(1, int(dream_max_per_day))
            and (
                not state.get("last_dream_at")
                or current - _parse_time(state.get("last_dream_at"), current) >= timedelta(hours=6)
            )
            and _deterministic_fraction(state, current, "dream-probability") <= probability
        )
        if dream_due:
            reason = "dream-residue"
            state["pending_awareness"] = True
        elif daytime_enabled and state.get("consciousness") != "sleeping" and 8 <= _local_hour(current) < 23 and idle_minutes >= PROACTIVE_MIN_IDLE_MINUTES and maximum >= 0.42 and int((state.get("daytime_emergence_usage") or {}).get(local_day, 0)) < DAYTIME_MAX_PER_DAY:
            intent = _pick_intent(state)
            # 主动原因会进入模型上下文，不能泄露内部驱动力 key。
            reason = "daytime-emergence"
            state["last_daytime_emergence_at"] = _iso(current)
            state.setdefault("daytime_emergence_usage", {})[local_day] = int(state.setdefault("daytime_emergence_usage", {}).get(local_day, 0)) + 1
        else:
            _schedule_next(state, current)
            delay = (_parse_time(state["next_proactive_at"], current) - current).total_seconds()
            return state, {"allowed": False, "reason": "drive-not-ready", "delay_seconds": max(1.0, delay)}
        state["pending_proactive"] = True
        state["pending_proactive_at"] = _iso(current)
        state["pending_proactive_reason"] = reason
        # Durable recovery marker: get_proactive_delay suppresses in-memory
        # timers while pending, but the DB scanner can recover this claim after
        # a crash once settle_state expires the pending flag.
        state["next_proactive_at"] = _iso(
            current + timedelta(minutes=PROACTIVE_PENDING_TTL_MINUTES + 1)
        )
        return state, {"allowed": True, "reason": reason, "delay_seconds": None}

    state, result = await _mutate(pool, db_id, None, mutate, current)
    result["revision"] = state["revision"]
    return result


async def suspend_proactive_until_user(
    pool: Any,
    db_id: int,
    now: datetime | None = None,
) -> dict[str, Any]:
    """会话凭据不可用时暂停主动消息，下一次用户到场会自动重新排期。"""

    current = _as_utc(now)

    def mutate(state: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
        settle_state(state, current)
        state["pending_proactive"] = False
        state["pending_proactive_at"] = None
        state["pending_proactive_reason"] = None
        state["next_proactive_at"] = None
        return state, {"suspended": True, "reason": "waiting-for-fresh-context"}

    state, result = await _mutate(pool, db_id, None, mutate, current)
    result.update({
        "revision": state["revision"],
        "next_proactive_at": state.get("next_proactive_at"),
    })
    return result


__all__ = [
    "DIMENSIONS",
    "DRIVE_KEYS",
    "INTERACTION_TYPES",
    "TONES",
    "claim_proactive",
    "commit_turn",
    "ensure_schema",
    "extract_mind_event",
    "get_proactive_delay",
    "list_due_proactive",
    "new_state",
    "prepare_turn",
    "render_context",
    "settle_state",
    "suspend_proactive_until_user",
]
