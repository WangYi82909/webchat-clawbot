import base64
import json
import unittest
from unittest.mock import AsyncMock, patch

import httpx

import qqbot_worker
import utils
from skills import send_emoji


class _Cursor:
    def __init__(self, row):
        self.row = row

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_args):
        return False

    async def execute(self, *_args, **_kwargs):
        return 1

    async def fetchone(self):
        return self.row


class _Connection:
    def __init__(self, row):
        self.row = row

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_args):
        return False

    def cursor(self):
        return _Cursor(self.row)


class _Acquire:
    def __init__(self, row):
        self.row = row

    def __await__(self):
        async def resolve():
            return _Connection(self.row)
        return resolve().__await__()

    async def __aenter__(self):
        return _Connection(self.row)

    async def __aexit__(self, *_args):
        return False


class _Pool:
    def __init__(self, row):
        self.row = row

    def acquire(self):
        return _Acquire(self.row)


class QQMediaProtocolTests(unittest.IsolatedAsyncioTestCase):
    async def test_c2c_image_uses_official_upload_then_send_protocol(self):
        requests = []

        async def handler(request: httpx.Request) -> httpx.Response:
            requests.append(request)
            if request.url.path.endswith("/files"):
                return httpx.Response(
                    200,
                    json={"file_uuid": "uuid-1", "file_info": "file-1", "ttl": 60},
                )
            return httpx.Response(200, json={"id": "message-1"})

        worker = qqbot_worker.QQBotWorker(
            app_id="app", client_secret="secret", account_label="test"
        )
        worker.http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        worker._get_access_token = AsyncMock(return_value="access-token")
        try:
            image = b"\x89PNG\r\n\x1a\n" + b"pixels" * 20
            result = await worker.send_c2c_image("user/a", "incoming-1", image)
        finally:
            await worker.http.aclose()

        self.assertEqual(len(requests), 2)
        self.assertEqual(requests[0].url.raw_path, b"/v2/users/user%2Fa/files")
        upload = json.loads(requests[0].content)
        self.assertEqual(upload["file_type"], 1)
        self.assertIs(upload["srv_send_msg"], False)
        self.assertEqual(base64.b64decode(upload["file_data"]), image)

        self.assertEqual(requests[1].url.raw_path, b"/v2/users/user%2Fa/messages")
        sent = json.loads(requests[1].content)
        self.assertEqual(sent["msg_type"], 7)
        self.assertEqual(sent["media"], {"file_info": "file-1"})
        self.assertEqual(sent["msg_id"], "incoming-1")
        self.assertIsInstance(sent["msg_seq"], int)
        self.assertEqual(result["message_id"], "message-1")
        self.assertEqual(result["raw_size"], len(image))

    async def test_qq_adapter_keeps_current_passive_reply_context(self):
        worker = AsyncMock()
        worker.http = object()
        worker.send_c2c_image.return_value = {"message_id": "m1"}
        adapter = qqbot_worker.QQBotInstanceAdapter(
            12, object(), worker, "openid-1", "incoming-1", 7
        )
        result = await adapter.send_image(b"image")
        self.assertEqual(adapter.tool_channel, "qq")
        self.assertEqual(adapter.qq_account_id, 7)
        self.assertEqual(result, {"message_id": "m1"})
        worker.send_c2c_image.assert_awaited_once_with(
            "openid-1", "incoming-1", b"image"
        )


class QQToolExposureTests(unittest.IsolatedAsyncioTestCase):
    async def test_qq_receives_same_media_and_note_tools_as_wechat(self):
        specs = await utils.load_skill_specs_for_openai(None, tool_channel="qq")
        names = {(item.get("function") or {}).get("name") for item in specs}
        self.assertTrue({"generate_image", "send_emoji", "write_couple_note"} <= names)

    async def test_qq_emoji_sends_through_adapter_without_wechat_token(self):
        image = b"GIF89a" + b"payload" * 20
        stored = [{
            "id": "7",
            "tag": "开心",
            "base64_data": "data:image/gif;base64," + base64.b64encode(image).decode(),
        }]
        pool = _Pool({"emojis_json": json.dumps(stored), "wx_token": ""})
        adapter = AsyncMock()
        adapter.tool_channel = "qq"
        adapter.send_image.return_value = {
            "message_id": "qq-message-1",
            "raw_size": len(image),
        }
        with (
            patch(
                "skills.send_emoji._select_emoji_via_qe",
                new=AsyncMock(return_value="7"),
            ),
            patch("skills.send_emoji.utils.add_temp_log", new=AsyncMock()),
            patch(
                "skills.send_emoji.utils.decrypt_data",
                side_effect=AssertionError("QQ 不应读取微信 Token"),
            ),
        ):
            result = await send_emoji.run(
                {
                    "_conversation_context": [
                        {"role": "user", "content": "今天好开心"},
                        {"role": "assistant", "content": "那就一起开心"},
                    ],
                },
                pool,
                12,
                "qq:7:openid-1",
                adapter,
            )

        self.assertTrue(result["success"])
        adapter.send_image.assert_awaited_once_with(image)


if __name__ == "__main__":
    unittest.main()
