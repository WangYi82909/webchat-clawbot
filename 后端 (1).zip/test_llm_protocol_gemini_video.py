import base64
import unittest

import llm_protocol_gemini as gemini


class GeminiNativeVideoProtocolTests(unittest.TestCase):
    def test_routed_media_models_are_registered_for_media(self):
        routed_models = (
            "[hm]u|gemini-3.5-flash-anti",
            "[ba]q|假流式/gemini-3.5-flash",
        )
        for model in routed_models:
            with self.subTest(model=model):
                self.assertTrue(gemini.is_explicit_native_media_model(model))
                endpoint = gemini.resolve_endpoint(model=model)
                self.assertTrue(endpoint.startswith(
                    "https://mixed.strai.life/v1beta/models/"
                ))
                self.assertTrue(endpoint.endswith(":generateContent"))

        self.assertTrue(gemini.is_explicit_native_media_model(
            "[other]gemini-3.5-flash"
        ))
        self.assertFalse(gemini.is_explicit_native_media_model(
            "[other]text-only-model"
        ))

    def test_database_endpoint_template_has_priority(self):
        self.assertEqual(
            gemini.resolve_endpoint(
                "https://relay.example/v1beta/models/{model}:generateContent",
                "https://global.example/v1",
                model="[ais]gemini-3.5-flash",
            ),
            "https://relay.example/v1beta/models/"
            "%5Bais%5Dgemini-3.5-flash:generateContent",
        )

    def test_database_v1beta_base_is_completed(self):
        self.assertEqual(
            gemini.resolve_endpoint(
                "https://relay.example/v1beta",
                "https://global.example/v1",
                model="gemini-2.5-pro",
            ),
            "https://relay.example/v1beta/models/gemini-2.5-pro:generateContent",
        )

    def test_default_endpoint_is_used_only_without_model_endpoint(self):
        self.assertEqual(
            gemini.resolve_endpoint(
                None,
                "https://global.example/v1",
                model="gemini-3.1-pro",
            ),
            "https://mixed.strai.life/v1beta/models/gemini-3.1-pro:generateContent",
        )

    def test_endpoint_uses_any_selected_model_id(self):
        self.assertEqual(
            gemini.resolve_endpoint(model="custom-gemini-video-model"),
            "https://mixed.strai.life/v1beta/models/"
            "custom-gemini-video-model:generateContent",
        )
        self.assertEqual(
            gemini.resolve_endpoint(model="models/gemini-next-preview"),
            "https://mixed.strai.life/v1beta/models/"
            "gemini-next-preview:generateContent",
        )

    def test_video_becomes_native_inline_data_before_text(self):
        raw_video = b"small-mp4-payload"
        encoded = base64.b64encode(raw_video).decode("ascii")
        payload = gemini.build_payload(
            model="backend-selected-model",
            messages=[
                {"role": "system", "content": "system"},
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "video",
                            "data": encoded,
                            "mime_type": "video/mp4",
                        },
                        {"type": "text", "text": "请理解这个视频"},
                    ],
                },
            ],
        )

        parts = payload["contents"][0]["parts"]
        self.assertEqual(
            parts[0],
            {"inlineData": {"mimeType": "video/mp4", "data": encoded}},
        )
        self.assertEqual(parts[1], {"text": "请理解这个视频"})
        self.assertNotIn("messages", payload)

    def test_mixed_payload_omits_unsupported_penalty_fields(self):
        payload = gemini.build_payload(
            model="[ais]gemini-3.5-flash",
            messages=[{"role": "user", "content": "只回复 OK"}],
            presence_penalty=0.15,
            frequency_penalty=0.25,
        )
        config = payload["generationConfig"]
        self.assertNotIn("presencePenalty", config)
        self.assertNotIn("frequencyPenalty", config)
        self.assertEqual(config["temperature"], 1.1)
        self.assertEqual(config["thinkingConfig"], {"includeThoughts": True})

    def test_routed_model_image_becomes_native_inline_data(self):
        encoded = base64.b64encode(b"small-jpeg").decode("ascii")
        payload = gemini.build_payload(
            model="[hm]u|gemini-3.5-flash-anti",
            messages=[{
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{encoded}"
                        },
                    },
                    {"type": "text", "text": "请看图回复"},
                ],
            }],
        )
        self.assertEqual(
            payload["contents"][0]["parts"][0],
            {"inlineData": {"mimeType": "image/jpeg", "data": encoded}},
        )

    def test_video_data_uri_is_supported_but_remote_url_is_not_faked(self):
        encoded = base64.b64encode(b"video").decode("ascii")
        native = gemini._openai_block_to_gemini(
            {
                "type": "video_url",
                "video_url": {"url": f"data:video/webm;base64,{encoded}"},
            }
        )
        self.assertEqual(
            native,
            {"inlineData": {"mimeType": "video/webm", "data": encoded}},
        )
        self.assertIsNone(
            gemini._openai_block_to_gemini(
                {
                    "type": "video_url",
                    "video_url": {"url": "https://example.com/video.mp4"},
                }
            )
        )

    def test_unsupported_video_mime_is_rejected(self):
        self.assertIsNone(
            gemini._openai_block_to_gemini(
                {
                    "type": "video",
                    "data": "AAAA",
                    "mime_type": "application/octet-stream",
                }
            )
        )

    def test_native_sync_function_roundtrip_preserves_signature_and_response(self):
        native_response = {
            "candidates": [{
                "content": {
                    "role": "model",
                    "parts": [
                        {"text": "internal summary", "thought": True},
                        {
                            "functionCall": {
                                "name": "get_weather",
                                "args": {"city": "北京"},
                                "id": "call-1",
                            },
                            "thoughtSignature": "signed-value",
                        },
                    ],
                },
                "finishReason": "STOP",
            }],
            "usageMetadata": {},
        }
        parsed = gemini.parse_response(native_response)
        message = parsed["choices"][0]["message"]

        self.assertEqual(message["content"], "")
        self.assertEqual(message["tool_calls"][0]["function"]["name"], "get_weather")
        self.assertEqual(message["reasoning_content"], "internal summary")

        tool_result = gemini.tool_result_message(
            message["tool_calls"][0],
            "记录成功",
            success=True,
            instruction="请生成最终回复",
        )
        payload = gemini.build_payload(
            model="gemini-3.5-flash",
            messages=[
                {"role": "user", "content": "北京天气怎么样"},
                gemini.assistant_message_for_replay(message),
                tool_result,
            ],
            tools=[{
                "type": "function",
                "function": {
                    "name": "get_weather",
                    "parameters": {"type": "object"},
                },
            }],
            tool_choice="none",
        )

        self.assertEqual(payload["contents"][1], native_response["candidates"][0]["content"])
        function_response = payload["contents"][2]["parts"][0]["functionResponse"]
        self.assertEqual(function_response["name"], "get_weather")
        self.assertEqual(function_response["id"], "call-1")
        self.assertEqual(function_response["response"]["result"], "记录成功")
        self.assertEqual(payload["contents"][2]["parts"][1]["text"], "请生成最终回复")
        self.assertEqual(
            payload["toolConfig"]["functionCallingConfig"]["mode"],
            "NONE",
        )

    def test_native_async_function_can_share_candidate_with_nonempty_text(self):
        native_response = {
            "candidates": [{
                "content": {
                    "role": "model",
                    "parts": [
                        {"text": '{"reply":"给你发个表情。","tools":[]}'},
                        {
                            "functionCall": {
                                "name": "send_emoji",
                                "args": {"emoji_id": 3},
                            }
                        },
                    ],
                },
                "finishReason": "STOP",
            }],
            "usageMetadata": {},
        }

        message = gemini.parse_response(native_response)["choices"][0]["message"]
        self.assertIn("给你发个表情", message["content"])
        self.assertEqual(
            message["tool_calls"][0]["function"]["name"],
            "send_emoji",
        )


if __name__ == "__main__":
    unittest.main()
