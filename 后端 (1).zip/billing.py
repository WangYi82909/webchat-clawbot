# =============================================================================
# billing.py — 计费、配额校验、订阅包/周额度路由（v2 · 2026-05-06）
# =============================================================================
#
# 设计核心：
#   每次请求基于"三个桶"路由，bucket 互斥，绝不双扣。
#
#   ┌───────────────────────────────────────────────────────────────────┐
#   │  bucket    │ 命中条件                              │ 扣什么          │
#   ├────────────┼───────────────────────────────────────┼─────────────────┤
#   │  balance   │ billing_mode=balance_first AND bal>0  │ 按 token 算 ¥   │
#   │  pack      │ 持有有效订阅包                          │ pro_pack_used   │
#   │  weekly    │ 无包                                   │ weekly_used     │
#   └───────────────────────────────────────────────────────────────────┘
#
#   降级链：
#     pack 桶用尽   → 自动降到 weekly 桶（同时写 downgrade_msg 提示用户）
#     weekly 桶用尽 → 自动降到 balance 桶（如果余额>0；否则拦截）
#     pack/weekly 命中时，模型必须在数据库白名单或 free_model_id 内
#
#   模型权限矩阵：
#     bucket=balance → 全模型放行
#     bucket=pack    → 模型必须在 model_pricing.is_pack_allowed 或为免费模型
#     bucket=weekly  → 模型必须等于 system_config.free_model_id
#
#   余额计费精度：
#     最小颗粒 0.0001 元（4 位小数 = 0.01 分）
#     避免 0.000090082 之类的极小数字撑爆前端展示
#
#   日志策略（统一通过 utils.add_temp_log 写到 instances.temp_log）：
#     - bucket=balance → 写 2 条（"按量计费 ¥X" + "明细 In/Out/模型"）
#     - bucket=pack    → 写 1 条（"订阅包扣减 X token，剩余 Y"）
#     - bucket=weekly  → 写 1 条（"本周额度扣减 X token，剩余 Y"）
#     - 降级时（pack→weekly / weekly→balance）→ 额外写 1 条 [扣费·切换计费桶]
# =============================================================================
import time
import logging
from datetime import datetime, timezone, timedelta

import utils


# ─────────────────────────────────────────────────────────────────────
# 次数包桶 · 反滥用临时限制（内存级，不落库）
# ─────────────────────────────────────────────────────────────────────
# 规则：
#   走「次数包」计费时，每一次请求拿到输入/输出 token 后检查 —— 注意是
#   【单次请求】的 token，不是一轮对话累计。
#   只要单次请求的输入 token 或 输出 token 任意一方 > 30000，
#   立即把该用户封禁 1 小时（仅内存，进程重启自动清空）。
#   封禁期间该用户再来消息，直接回固定提示语，不再走模型。
#   只有走「次数包」桶的请求受此限制；余额 / token 包计费不受限。
#   提示语每次封禁只发一次（发过就标记，避免重复刷屏）。

COUNT_PACK_ABUSE_TOKEN_LIMIT = 70000      # 单次请求输入或输出 token 上限
COUNT_PACK_ABUSE_BAN_SECONDS = 3600       # 触发后封禁时长（秒）= 1 小时

# user_id -> {"until": 解封时间戳, "notified": 是否已发过提示}
_count_pack_ban: dict = {}

COUNT_PACK_ABUSE_MSG = (
    "次数包防恶意临时限制：您的输入/输出异常，人设不要过多。"
    "一小时后恢复正常，或改用余额 / token 包计费（不受此限制）。"
)


def count_pack_ban_check(user_id: int):
    """
    检查用户是否处于次数包反滥用封禁中。
    返回:
      - None                    → 未封禁，正常放行
      - {"msg": 提示语}          → 仍在封禁，且本次需要把提示语发给用户
      - {"msg": None}            → 仍在封禁，但提示语已发过，本次静默拦截
    """
    rec = _count_pack_ban.get(user_id)
    if not rec:
        return None
    now = time.time()
    if now >= rec["until"]:
        # 封禁到期，清掉
        _count_pack_ban.pop(user_id, None)
        return None
    # 仍在封禁期内
    if not rec.get("notified"):
        rec["notified"] = True          # 标记已发，后续静默
        return {"msg": COUNT_PACK_ABUSE_MSG}
    return {"msg": None}


def count_pack_ban_trigger(user_id: int) -> bool:
    """
    触发一次次数包反滥用封禁（封 1 小时）。
    返回 True 表示这是本次新触发的封禁（调用方应把提示语发给用户），
         False 表示该用户已在封禁中（不重复触发）。
    """
    now = time.time()
    rec = _count_pack_ban.get(user_id)
    if rec and now < rec["until"]:
        return False                    # 已在封禁中，不重复
    # 新封禁：提示语在本次触发时就发出去，notified 直接置 True
    _count_pack_ban[user_id] = {
        "until":    now + COUNT_PACK_ABUSE_BAN_SECONDS,
        "notified": True,
    }
    return True


logger = logging.getLogger(__name__)

# ── 免费模型配置（与 PHP 控制台接口完全对齐） ─────────────────────────────────
# 线上值读取 system_config.free_model_id；这里只保留数据库尚未迁移或暂时不可用时
# 的安全兜底。模型协议、端点、Key 和价格始终由 model_pricing 中同 ID 的行提供。
DEFAULT_FREE_MODEL_ID = "gemini-3.1-flash-lite"

# ── 订阅包(pack)桶白名单(v6 改造 · 2026-05-07) ──────────────────────────────
# 从硬编码常量改为【动态查 model_pricing.is_pack_allowed 字段】,在 admin 后台
# 可视化勾选模型即可加入/移出订阅包。本常量作为【兜底】保留:
#   - 数据库不可达时
#   - is_pack_allowed 字段不存在(老库未跑 migrate_v6)时
# 都会回退到这份硬编码列表,保证服务降级也能跑。
#
# 修改本常量【不会】立即影响线上行为(因为 check_quota 优先查 DB);只有 DB 路径
# 失败时才作为安全网生效。要调整生产白名单,请在 admin 后台「模型定价」勾选
# is_pack_allowed,而不是改这里。
PRO_PACK_MODELS_FALLBACK = frozenset({
    "gemini-3.1-flash-lite-preview",
    "gemini-3.1-flash",
    "gemini-3-flash-preview",
    "gemini-3.1-flash-lite",
    "deepseek-v4-flash",
    "grok-4.1-fast",
})

# 老代码兼容别名:其它模块若 import 了 PRO_PACK_MODELS,仍能拿到 fallback 名单
PRO_PACK_MODELS = PRO_PACK_MODELS_FALLBACK

# 弃用,仅为与历史日志/admin 文案兼容保留;不要在新代码里引用
PRO_PACK_PREFIX = "gemini-3.1-flash"

# ── 计费常量 ─────────────────────────────────────────────────────────────────
MIN_BALANCE_DEDUCT = 0.0001     # 余额扣费最小颗粒（4 位小数 = 0.01 分）
ROUND_DECIMALS     = 4          # 余额扣费保留小数位

# 七夕延期专场：仅 2026-08-20（北京时间）有效；全站当日真实流水
# 达到 2000 元后，所有聊天模型免扣。8 月 21 日 00:00 立即恢复原计费。
QIXI_EVENT_TARGET = 2000.0
QIXI_EVENT_START = datetime(2026, 8, 20, 0, 0, 0, tzinfo=timezone(timedelta(hours=8)))
QIXI_EVENT_END = datetime(2026, 8, 21, 0, 0, 0, tzinfo=timezone(timedelta(hours=8)))
_qixi_free_models_cache = {"expires_at": 0.0, "unlocked": False, "revenue": 0.0}


async def qixi_all_models_free(pool) -> bool:
    """仅在活动当天流水达到 2K 后返回 True。"""
    bj_now = datetime.now(timezone(timedelta(hours=8)))
    # 时间判断必须在缓存之前：即使 23:59:59 缓存为 True，次日第一条请求
    # 也会立即恢复计费，不会多免费一个缓存周期。
    if bj_now < QIXI_EVENT_START or bj_now >= QIXI_EVENT_END:
        return False

    now_mono = time.monotonic()
    if now_mono < float(_qixi_free_models_cache.get("expires_at") or 0):
        return bool(_qixi_free_models_cache.get("unlocked"))

    day_start = int(QIXI_EVENT_START.timestamp())
    day_end = int(QIXI_EVENT_END.timestamp())
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute("SHOW COLUMNS FROM payment_orders LIKE 'paid_amount'")
                has_paid_amount = bool(await cur.fetchone())
                revenue_expr = (
                    "COALESCE(SUM(COALESCE(paid_amount, amount)), 0)"
                    if has_paid_amount else "COALESCE(SUM(amount), 0)"
                )
                await cur.execute(
                    f"SELECT {revenue_expr} AS revenue FROM payment_orders "
                    "WHERE status='success' AND created_at >= %s AND created_at < %s",
                    (day_start, day_end),
                )
                row = await cur.fetchone()
        revenue = max(0.0, float((row or {}).get("revenue") or 0))
        unlocked = revenue >= QIXI_EVENT_TARGET
        _qixi_free_models_cache.update({
            # 未达标仅缓存 1 秒，确保跨过 2K 后实际计费层几乎同步放开；
            # 达标后可缓存 30 秒，活动边界仍会在缓存前被硬拦截。
            "expires_at": now_mono + (30.0 if unlocked else 1.0),
            "unlocked": unlocked,
            "revenue": revenue,
        })
        return unlocked
    except Exception as exc:
        # 统计失败时坚持正常计费，不能误将全站模型放开。
        logger.warning(f"[七夕2K免费] 今日流水查询失败，沿用正常计费: {exc}")
        _qixi_free_models_cache.update({
            "expires_at": now_mono + 10.0,
            "unlocked": False,
            "revenue": 0.0,
        })
        return False


# =============================================================================
# 工具：周字符串 / 桶判定
# =============================================================================
def current_iso_week() -> str:
    """
    返回当前 ISO 周字符串，例如 '2026-W18'（按北京时间 UTC+8 算周边界）。
    显式 +8，不依赖服务器/容器系统时区；跨年时按 ISO 8601。
    格式与原来一致(%Y-W%V = 公历年 + ISO 周号)，与 PHP me 接口同 key。
    （注:容器若跑在 UTC，旧的 time.strftime 会把周一 00:00–08:00 这段算到上一周，
      导致每周免费额度重置点偏移、且与 PHP 侧周 key 错位；改成显式 +8 后对齐。）
    """
    return datetime.now(timezone(timedelta(hours=8))).strftime("%Y-W%V")


def _has_active_pack(user: dict) -> bool:
    """
    持有有效订阅包：pro_pack_total > 0 且未过期。
    plan_expired_at = 0 视为永久（兼容 admin 手动赠送场景）。
    """
    total = int(user.get("pro_pack_total") or 0)
    if total <= 0:
        return False
    expire = int(user.get("plan_expired_at") or 0)
    if expire == 0:
        return True
    return expire > int(time.time())


# ─────────────────────────────────────────────────────────────────────
# 次数包（count pack） · 多包分桶改造（方案 A）
# ─────────────────────────────────────────────────────────────────────
# 每个用户有 0..N 个独立次数包（user_count_packs 表，一行一个包）。
# 选包规则（计费时）：
#   1. 用户在控制台手动选了 active_count_pack_id → 优先用它（前提：该包
#      未过期、有剩余次数、且当前模型在它的 models 白名单内）。
#   2. 没选 / 选的包对当前模型无效 / 选的包过期 → 自动回退到「最早过期的、
#      对当前模型有效的包」（先到期先消耗，避免浪费）。
#   3. 都没有 → 返回 None，由上层降级到订阅包/周额度/余额。
# ─────────────────────────────────────────────────────────────────────

def _pack_model_match(model: str, models_json) -> bool:
    """模型是否在某个次数包的 models 白名单内。"""
    if not models_json:
        return False
    try:
        import json as _json
        arr = _json.loads(models_json)
        if not isinstance(arr, list):
            return False
        m = (model or "").lower().strip()
        return any(m == str(x).lower().strip() for x in arr if x)
    except Exception:
        return False


async def _pick_count_pack(pool, user_id: int, active_pack_id, model: str):
    """
    为本次调用挑一个可用的次数包。
    返回 dict（user_count_packs 的一行）或 None。

    回退机制：
      - active_pack_id 指定的包若有效且模型匹配 → 用它。
      - 否则在用户所有「未过期 + 有剩余次数 + 模型匹配」的包里，
        取 expired_at 最小（最早过期）的那个。
    """
    now_ts = int(time.time())
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT id, pack_name, counts_total, counts_used, "
                    "       models, created_at, expired_at "
                    "FROM user_count_packs "
                    "WHERE user_id = %s AND is_active = 1 "
                    "  AND created_at <= %s "
                    "  AND expired_at > %s "
                    "  AND counts_total - counts_used > 0 "
                    "ORDER BY expired_at ASC",
                    (user_id, now_ts, now_ts),
                )
                rows = await cur.fetchall()
    except Exception as e:
        # 表不存在（未跑迁移）等 → 视作无次数包，让上层走其它桶
        logger.warning(f"[_pick_count_pack] user_count_packs 不可用: {e}")
        return None

    if not rows:
        return None

    # 只保留「当前模型匹配」的包
    usable = [r for r in rows if _pack_model_match(model, r.get("models"))]
    if not usable:
        return None

    # ① 用户手动指定的包，若在 usable 里 → 优先用
    if active_pack_id:
        for r in usable:
            if int(r["id"]) == int(active_pack_id):
                return r
        # 指定的包不在 usable（过期 / 用尽 / 模型不匹配）→ 走回退

    # ② 回退：最早过期的可用包（rows 已按 expired_at ASC 排序，usable 同序）
    return usable[0]


async def commit_count_pack(pool, pack_id: int, n: int = 1) -> dict:
    """对指定次数包扣 n 次（默认 1）。counts_used 封顶不超过 counts_total。
    返回 {remain, expired_at} 供日志用。"""
    n = max(1, int(n or 1))
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "UPDATE user_count_packs "
                "SET counts_used = LEAST(counts_total, counts_used + %s) "
                "WHERE id = %s",
                (n, pack_id),
            )
            await cur.execute(
                "SELECT counts_total, counts_used, expired_at "
                "FROM user_count_packs WHERE id = %s",
                (pack_id,),
            )
            row = await cur.fetchone()
        await conn.commit()
    if row:
        remain = max(0, int(row["counts_total"] or 0) - int(row["counts_used"] or 0))
        return {"remain": remain, "expired_at": int(row["expired_at"] or 0)}
    return {"remain": -1, "expired_at": 0}


# ── 旧·单桶次数包 helper（保留：老库 / 老用户老包仍可能用到，向后兼容） ──
def _has_active_count_pack(user: dict) -> bool:
    """
    [旧逻辑] 持有有效次数包：count_pack_total - count_pack_used > 0 且未过期。
    多包分桶改造后，新购买一律走 user_count_packs 表；此函数仅用于老库兜底。
    """
    total = int(user.get("count_pack_total") or 0)
    used  = int(user.get("count_pack_used")  or 0)
    if total - used <= 0:
        return False
    expire = int(user.get("count_pack_expired_at") or 0)
    if expire <= 0:
        return False
    return expire > int(time.time())


def _model_match_count(model: str, user_count_models_json) -> bool:
    """
    [旧逻辑] 模型是否在用户的次数包白名单内（users.count_pack_models）。
    多包分桶改造后仅用于老库兜底。
    """
    if not user_count_models_json:
        return False
    try:
        import json as _json
        arr = _json.loads(user_count_models_json)
        if not isinstance(arr, list):
            return False
        m = (model or "").lower().strip()
        return any(m == str(x).lower().strip() for x in arr if x)
    except Exception:
        return False


async def _load_pack_whitelist(pool):
    """
    查 model_pricing.is_pack_allowed=1 的所有模型,返回 (set_of_lowercase_names, source).

    返回值的 source:
      - 'db'       : 成功从 DB 读取,长度由 admin 勾选决定
      - 'fallback' : DB 不可达 / 字段不存在 / 查询为空,退回 PRO_PACK_MODELS_FALLBACK

    任何 DB 异常都会被静默吞掉,确保支付/扣费链路在 schema 不一致时也能继续跑。
    """
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT model_name FROM model_pricing "
                    "WHERE is_pack_allowed=1 AND is_active=1"
                )
                rows = await cur.fetchall()
        names = set()
        for r in rows:
            mn = r.get("model_name") if isinstance(r, dict) else r[0]
            if mn:
                names.add(mn.lower().strip())
        if names:
            return names, "db"
    except Exception as e:
        logger.warning(f"[_load_pack_whitelist] DB 路径失败,fallback 兜底: {e}")
    return set(m.lower() for m in PRO_PACK_MODELS_FALLBACK), "fallback"


async def _load_free_model_id(pool) -> str:
    """每次额度判定读取当前免费模型，使 SQL 修改无需重启 Python 服务。"""
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT config_value FROM system_config "
                    "WHERE config_key='free_model_id' LIMIT 1"
                )
                row = await cur.fetchone()
        if row:
            value = row.get("config_value") if isinstance(row, dict) else row[0]
            value = str(value or "").strip()
            if value:
                return value
    except Exception as exc:
        logger.warning(f"[free_model] 读取配置失败，使用旧值兜底: {exc}")
    return DEFAULT_FREE_MODEL_ID


def _model_match_lite(model: str, free_model_id: str) -> bool:
    m = (model or "").lower().strip()
    return m == (free_model_id or DEFAULT_FREE_MODEL_ID).lower().strip()


# =============================================================================
# 跨周懒重置
# =============================================================================
async def _maybe_reset_week(pool, user_id: int, user: dict) -> dict:
    """
    跨周懒重置：last_reset_week != 当前周 → weekly_used_tokens=0，刷新 last_reset_week。
    返回更新后的 user dict（已就地改写）。
    """
    cur_week = current_iso_week()
    last_week = (user.get("last_reset_week") or "").strip()
    if last_week == cur_week:
        return user

    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "UPDATE users SET weekly_used_tokens = 0, last_reset_week = %s WHERE id = %s",
                (cur_week, user_id),
            )
        await conn.commit()

    user["weekly_used_tokens"] = 0
    user["last_reset_week"]    = cur_week
    print(
        f"[{time.strftime('%H:%M:%S')}][WeeklyReset] user_id={user_id} "
        f"{last_week or '(none)'} -> {cur_week}",
        flush=True,
    )
    return user


# =============================================================================
# 计费换算：网关 usage → 美元/人民币 cost
# =============================================================================
def calc_cost_from_usage(
    usage: dict,
    in_price: float,
    out_price: float,
    cached_input_price: float | None = None,
):
    """
    模型计费明细换算成本。
    in_price / out_price 单位为"每 100 万 token 的人民币价格"(与 model_pricing 表一致)。

    OpenAI 协议关于 reasoning 计费的两种实现(yunwu 等聚合层不一致):
      A派(标准 OpenAI o1/o3): completion_tokens 已包含 reasoning_tokens,
          completion_tokens_details.reasoning_tokens 只是子项明细。
      B派(部分聚合实现):     completion_tokens 不含 reasoning,
          reasoning 在外层 reasoning_tokens 或 completion_tokens_details 单独记。

    判断逻辑:
      - 看 completion_tokens_details.reasoning_tokens 是否存在
      - 如果该字段存在 且 reasoning <= completion_tokens 则视为A派(已含),不再加
      - 如果该字段存在 且 reasoning > completion_tokens 则视为B派(未含),按 reasoning 主导
      - 如果只有外层 usage.reasoning_tokens 字段(B派变种),累加到 c_tok 上

    返回 (cost, prompt_tok, billed_completion_tok, breakdown_dict),
    breakdown_dict 用于日志,记录拆分明细。
    """
    p_tok          = int(usage.get("prompt_tokens", 0) or 0)
    cached_tok = int(
        usage.get("cached_tokens")
        or usage.get("cache_read_input_tokens")
        or (usage.get("prompt_tokens_details") or {}).get("cached_tokens")
        or 0
    )
    cached_tok = max(0, min(p_tok, cached_tok))
    uncached_tok = max(0, p_tok - cached_tok)
    cache_price = in_price if cached_input_price is None else float(cached_input_price)
    raw_completion = int(usage.get("completion_tokens", 0) or 0)
    details        = usage.get("completion_tokens_details", {}) or {}
    reasoning_in_details = int(details.get("reasoning_tokens", 0) or 0)
    reasoning_outer      = int(usage.get("reasoning_tokens", 0) or 0)

    # 计费用的 completion token 总数
    if reasoning_in_details > 0:
        # A派(标准):completion_tokens 已含 reasoning;但若 reasoning 反而比 completion 大,
        # 说明聚合层数据混乱,按较大值兜底(避免少算)
        billed_completion = max(raw_completion, reasoning_in_details)
        scheme = "A派(details含)" if reasoning_in_details <= raw_completion else "A派异常(reasoning>completion,取大)"
    elif reasoning_outer > 0:
        # B派:reasoning 在外层,与 completion 是两笔;相加才是真实输出量
        billed_completion = raw_completion + reasoning_outer
        scheme = "B派(外层reasoning,累加)"
    else:
        # 无思维链 / 普通模型
        billed_completion = raw_completion
        scheme = "普通(无reasoning)"

    cost = (
        uncached_tok * in_price
        + cached_tok * cache_price
        + billed_completion * out_price
    ) / 1_000_000

    breakdown = {
        "scheme":               scheme,
        "raw_completion":       raw_completion,
        "reasoning_in_details": reasoning_in_details,
        "reasoning_outer":      reasoning_outer,
        "billed_completion":    billed_completion,
        "uncached_prompt":      uncached_tok,
        "cached_prompt":        cached_tok,
        "cached_input_price":   cache_price,
    }
    return cost, p_tok, billed_completion, breakdown


# =============================================================================
# check_quota：决定本次请求扣哪个桶 + 模型权限校验 + 降级
# =============================================================================
async def _has_active_platinum(pool, user_id: int) -> bool:
    """白金会员有效期校验。迁移未执行或字段不存在时安全返回 False。"""
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT platinum_expires_at FROM users WHERE id=%s LIMIT 1",
                    (int(user_id),),
                )
                row = await cur.fetchone()
        if not row:
            return False
        value = row.get("platinum_expires_at") if hasattr(row, "get") else row[0]
        return int(value or 0) > int(time.time())
    except Exception:
        return False


async def check_quota(pool, user_id: int, db_id: int, model: str) -> dict:
    """
    返回结构（与 chat.py v2 契约严格对齐）：
        {
          "ok": True/False,
          "bucket": "pack" | "weekly" | "balance",
          "downgrade_msg": str | None,
          "deny_reason": str | None,
        }

    ok=False 时表示请求被拦截（chat.py 会写日志告知用户并静默丢弃本轮）。
    ok=True 时 chat.py 进入 LLM 调用流程，最终用同一个 bucket 调 commit_usage。

    关键设计：
      - 单次请求 bucket 在这里"锁定"，即使 LLM 多轮循环消耗也用同一个桶结算
      - 余额检查：balance_first + 余额=0 时退化为 quota_first 路径
      - 降级链：pack 用尽 → weekly；weekly 用尽 → balance（仅当余额>0）
    """
    # SQL 修改 free_model_id 后下一次请求立即生效，不依赖进程重启或内存缓存。
    free_model_id = await _load_free_model_id(pool)

    # ── 拉用户当前快照 ──────────────────────────────────────────────────────
    # 优先用 v7 schema(含 count_*字段);未跑 migrate_v7 的老库报字段不存在 →
    # 自动 fallback 到 v6 schema(不含次数包),后续逻辑 _has_active_count_pack
    # 看到字段缺失会判定无次数包,自然走 pack/weekly/balance 三桶链路。
    user = None
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT id, balance, plan_expired_at, "
                    "       pro_pack_total, pro_pack_used, "
                    "       base_weekly_tokens, bonus_weekly_tokens, "
                    "       weekly_used_tokens, last_reset_week, "
                    "       billing_mode, "
                    "       count_pack_total, count_pack_used, "
                    "       count_pack_expired_at, count_pack_models, "
                    "       active_count_pack_id "
                    "FROM users WHERE id = %s",
                    (user_id,)
                )
                user = await cur.fetchone()
    except Exception as _v7_err:
        logger.warning(f"[check_quota] v7 schema 不可用,回退 v6: {_v7_err}")
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT id, balance, plan_expired_at, "
                    "       pro_pack_total, pro_pack_used, "
                    "       base_weekly_tokens, bonus_weekly_tokens, "
                    "       weekly_used_tokens, last_reset_week, "
                    "       billing_mode "
                    "FROM users WHERE id = %s",
                    (user_id,)
                )
                user = await cur.fetchone()

    if not user:
        return {
            "ok": False,
            "bucket": None,
            "downgrade_msg": None,
            "deny_reason": "账户不存在",
        }

    # 跨周懒重置（与 PHP me 接口同 key 同 SQL，避免重复刷新）
    user = await _maybe_reset_week(pool, user_id, user)

    # 白金会员是独立权益：不受当前计费策略、模型白名单、余额和额度影响。
    # 仍返回独立 bucket，commit_usage 只累计消息统计，不扣任何用户资产。
    if await _has_active_platinum(pool, user_id):
        return {
            "ok": True,
            "bucket": "platinum_free",
            "count_pack_id": None,
            "downgrade_msg": None,
            "deny_reason": None,
        }

    # 七夕专场当天流水达到 2K 后，所有模型进入活动免费桶。此判断放在用户存在性
    # 校验之后、所有策略白名单之前，确保“所有模型免费”不是只免扣却仍被拦截。
    if await qixi_all_models_free(pool):
        return {
            "ok": True,
            "bucket": "event_free",
            "count_pack_id": None,
            "downgrade_msg": None,
            "deny_reason": None,
        }

    billing_mode  = (user.get("billing_mode") or "quota_first").strip()
    balance       = float(user.get("balance") or 0)
    has_pack      = _has_active_pack(user)
    pack_total    = int(user.get("pro_pack_total") or 0)
    pack_used     = int(user.get("pro_pack_used")  or 0)
    pack_remain   = max(0, pack_total - pack_used)
    weekly_total  = int(user.get("base_weekly_tokens")  or 0) + int(user.get("bonus_weekly_tokens") or 0)
    weekly_used   = int(user.get("weekly_used_tokens")  or 0)
    weekly_remain = max(0, weekly_total - weekly_used)

    # ── v7 次数包字段（老库无字段时下面所有 _has_active_count_pack 都返回 False）─
    # ── v8 多次数包：从 user_count_packs 表挑当前可用的包 ──────────────────
    active_pack_id = user.get("active_count_pack_id")
    picked_pack    = await _pick_count_pack(pool, user_id, active_pack_id, model)

    # 该用户名下是否有「任何」有效次数包（不限模型）—— 用于区分
    # 「没买过包」和「买了包但模型不匹配」两种情况，给出不同提示。
    has_any_count_pack = False
    try:
        _now = int(time.time())
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT COUNT(*) AS c FROM user_count_packs "
                    "WHERE user_id = %s AND is_active = 1 "
                    "  AND created_at <= %s AND expired_at > %s "
                    "  AND counts_total - counts_used > 0",
                    (user_id, _now, _now),
                )
                _r = await cur.fetchone()
                has_any_count_pack = bool(_r and int(_r.get("c") or 0) > 0)
    except Exception:
        has_any_count_pack = False

    # ── ① count_first 优先：走次数包桶 ─────────────────────────────────────
    # 命中 → 用挑到的包；count_pack_id 一并返回，commit 时精确扣这个包。
    if billing_mode == "count_first":
        if picked_pack:
            return {
                "ok": True,
                "bucket": "count",
                "count_pack_id": int(picked_pack["id"]),
                "downgrade_msg": None,
                "deny_reason": None,
            }
        # —— 关键修复：count_first 但没挑到包 ——
        # 旧 bug：这里会静默降级，最后扣余额（用户切了次数包却被扣钱）。
        # 新逻辑：用户有有效次数包、只是当前实例模型和包不匹配 → 明确拦截，
        #         提示去把实例模型改成次数包支持的模型，绝不静默扣余额。
        if has_any_count_pack:
            return {
                "ok": False,
                "bucket": None,
                "count_pack_id": None,
                "downgrade_msg": None,
                "deny_reason": (
                    f"当前实例使用的模型 {model} 不在你所选次数包的支持范围内，"
                    f"因此无法走次数计费。请在控制台把实例模型改成次数包对应的"
                    f"模型后再对话；或在「次数包」里切换到包含该模型的次数包。"
                ),
            }
        # 真的没有任何有效次数包 → 继续往下走 quota/weekly/balance 链路

    # ── ② balance_first 优先：余额>0 直接走 balance 桶 ──────────────────────
    if billing_mode == "balance_first":
        if balance > 0:
            return {
                "ok": True,
                "bucket": "balance",
                "count_pack_id": None,
                "downgrade_msg": None,
                "deny_reason": None,
            }
        # 余额=0：退化到 quota_first 路径继续判断

    # ── ③ count_first 但次数包用尽/模型不匹配,顺手尝试 count 桶兜底 ────────
    # 让 quota_first / balance_first 用户也能在模型匹配时享用次数包
    # （比如 admin 手动赠送的次数包,用户没切 billing_mode 也能用）
    # 多包分桶：picked_pack 已按「指定包优先 / 否则最早过期」挑好。
    if billing_mode != "count_first" and picked_pack:
        return {
            "ok": True,
            "bucket": "count",
            "count_pack_id": int(picked_pack["id"]),
            "downgrade_msg": None,
            "deny_reason": None,
        }

    # ── ④ 持有订阅包：尝试 pack 桶 ─────────────────────────────────────────
    if has_pack:
        if pack_remain > 0:
            # 模型必须在 pack 白名单内(v6:从 model_pricing.is_pack_allowed 读取,
            # DB 不可达 / 字段不存在时 fallback 到 PRO_PACK_MODELS_FALLBACK 常量)
            allowed_set, allowed_source = await _load_pack_whitelist(pool)
            # 免费模型不要求额外勾选 is_pack_allowed；订阅用户也始终可以选择它。
            allowed_set.add(free_model_id.lower().strip())
            m_lower = (model or "").lower().strip()
            if m_lower not in allowed_set:
                allowed_list = ", ".join(sorted(allowed_set))
                return {
                    "ok": False,
                    "bucket": None,
                    "downgrade_msg": None,
                    "deny_reason": (
                        f"订阅包当前支持以下模型: {allowed_list}。"
                        f"实例模型 {model} 不在白名单,请切换为余额优先扣费以使用其它模型。"
                    ),
                }
            return {
                "ok": True,
                "bucket": "pack",
                "downgrade_msg": None,
                "deny_reason": None,
            }
        # pack 已耗尽 → 降级到 weekly（pack_total>0 但 pack_used 已撑满）
        downgrade_msg = "订阅包额度已用完，本次起按本周免费额度计费"
        # 走到下面 weekly 分支
    else:
        downgrade_msg = None

    # ── ⑤ weekly 桶 ────────────────────────────────────────────────────────
    if weekly_remain > 0:
        # 模型必须等于数据库当前配置的免费模型 ID。
        if not _model_match_lite(model, free_model_id):
            return {
                "ok": False,
                "bucket": None,
                "downgrade_msg": None,
                "deny_reason": (
                    f"当前没有有效订阅包，免费版仅支持 {free_model_id}，"
                    f"实例模型 {model} 不在白名单。请购买订阅包或切换为余额优先扣费。"
                ),
            }
        return {
            "ok": True,
            "bucket": "weekly",
            "downgrade_msg": downgrade_msg,
            "deny_reason": None,
        }

    # ── ⑥ weekly 也耗尽 → 最后兜底转 balance ───────────────────────────────
    if balance > 0:
        # 即便 billing_mode=quota_first，没免费额度的情况下也只能扣余额
        # 写明降级原因，让用户看到链路
        if has_pack:
            chained_msg = "订阅包与本周额度均已用完，本次起按余额计费"
        else:
            chained_msg = "本周免费额度已用完，本次起按余额计费"
        return {
            "ok": True,
            "bucket": "balance",
            "downgrade_msg": chained_msg,
            "deny_reason": None,
        }

    # ── ⑦ 全部桶都不可用 → 拦截 ────────────────────────────────────────────
    if has_pack:
        deny = "订阅包已用完，本周免费额度也已用完，且账户余额为 0，请充值后继续使用。"
    else:
        deny = "本周免费额度已用完，且账户余额为 0，请充值或购买订阅包后继续使用。"

    return {
        "ok": False,
        "bucket": None,
        "downgrade_msg": None,
        "deny_reason": deny,
    }


# =============================================================================
# commit_usage：按 bucket 分桶扣费 + 写日志
# =============================================================================
async def commit_usage(
    pool,
    user_id: int,
    db_id: int,
    bucket: str,
    total_cost: float,
    total_prompt_tokens: int,
    total_completion_tokens: int,
    model: str = "",
    count_pack_id: int = None,
    count_units: int = 1,
) -> None:
    """
    按 bucket 提交本次调用消耗。

    bucket="pack"    → pro_pack_used += (in + out)         | 1 条日志
    bucket="weekly"  → weekly_used_tokens += (in + out)    | 1 条日志
    bucket="balance" → balance -= max(0.0001, round(cost, 4)) | 2 条日志
    bucket="count"   → 扣 count_units 次（= 本轮实际 LLM 请求数，一个请求计一次）
    bucket="event_free" → 七夕专场 2K 达标免费，不扣任何额度，仅累计消息统计
    bucket="platinum_free" → 白金会员不扣任何额度，仅累计消息统计

    count_units：次数包桶专用。一轮对话里工具循环可能发起多次 LLM 请求，
                 按"一个请求计一次"扣 count_units 次（其它桶按 token 累计，不受影响）。
    """
    in_tok  = int(total_prompt_tokens or 0)
    out_tok = int(total_completion_tokens or 0)
    token_increment = in_tok + out_tok
    _units = max(1, int(count_units or 1))
    ts = time.strftime("%H:%M:%S")

    # ── bucket = event_free（七夕专场 2K 达标，不消耗任何用户额度）─────
    if bucket == "event_free":
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "UPDATE users SET total_ai_messages = total_ai_messages + 1 WHERE id = %s",
                    (user_id,),
                )
            await conn.commit()
        print(
            f"[{ts}][CommitUsage] user_id={user_id} db_id={db_id} bucket=event_free "
            f"免费 (in={in_tok} out={out_tok} model={model})",
            flush=True,
        )
        await utils.add_temp_log(
            pool, db_id,
            f"[七夕活动] 今日全站流水已达 2K，模型 {model} 本轮不扣费"
        )
        return

    # ── bucket = platinum_free（白金会员全模型不计费）───────────────
    if bucket == "platinum_free":
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "UPDATE users SET total_ai_messages = total_ai_messages + 1 WHERE id = %s",
                    (user_id,),
                )
            await conn.commit()
        print(
            f"[{ts}][CommitUsage] user_id={user_id} db_id={db_id} bucket=platinum_free "
            f"白金会员不扣费 (in={in_tok} out={out_tok} model={model})",
            flush=True,
        )
        await utils.add_temp_log(pool, db_id, f"[白金会员] 模型 {model} 本轮不扣费")
        return

    # ─────────────────────────────────────────────────────────────────────
    # bucket = count（多包分桶 · 扣指定的那一个次数包，不扣余额、不扣 token）
    # ─────────────────────────────────────────────────────────────────────
    if bucket == "count":
        if count_pack_id:
            # 精确扣 check_quota 挑中的那个包（user_count_packs 一行）；
            # 一个请求计一次 → 扣 _units 次（本轮 LLM 请求数）。
            info = await commit_count_pack(pool, int(count_pack_id), _units)
            # total_ai_messages 仍然累加（统计"回复条数"，一轮一条，与其它桶一致）
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "UPDATE users SET total_ai_messages = total_ai_messages + 1 "
                        "WHERE id = %s",
                        (user_id,),
                    )
                await conn.commit()
            remain  = info["remain"]
            exp_ts  = info["expired_at"]
            exp_str = time.strftime('%Y-%m-%d', time.localtime(exp_ts)) if exp_ts > 0 else '无到期'
        else:
            # 兜底：没传 count_pack_id（理论上不会发生）→ 退回老·单桶字段扣减 _units 次
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "UPDATE users SET "
                        "  count_pack_used   = LEAST(count_pack_total, count_pack_used + %s), "
                        "  total_ai_messages = total_ai_messages + 1 "
                        "WHERE id = %s",
                        (_units, user_id),
                    )
                    await cur.execute(
                        "SELECT count_pack_total, count_pack_used, count_pack_expired_at "
                        "FROM users WHERE id = %s",
                        (user_id,),
                    )
                    row = await cur.fetchone()
                await conn.commit()
            if row:
                remain = max(0, int(row["count_pack_total"] or 0) - int(row["count_pack_used"] or 0))
                exp_ts = int(row["count_pack_expired_at"] or 0)
                exp_str = time.strftime('%Y-%m-%d', time.localtime(exp_ts)) if exp_ts > 0 else '无到期'
            else:
                remain, exp_str = -1, '?'

        print(
            f"[{ts}][CommitUsage] user_id={user_id} db_id={db_id} bucket=count "
            f"pack_id={count_pack_id} +{_units} 次 (in={in_tok} out={out_tok} model={model}) "
            f"余 {remain} 次 截止 {exp_str}",
            flush=True,
        )
        await utils.add_temp_log(
            pool, db_id,
            f"[扣费] 次数包扣减 {_units} 次（模型 {model}，本轮 {_units} 次请求），剩余 {remain} 次（{exp_str} 到期）"
        )
        return

    # ─────────────────────────────────────────────────────────────────────
    # bucket = pack
    # ─────────────────────────────────────────────────────────────────────
    if bucket == "pack":
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                # 同时把 token_increment 写入 pro_pack_used；并维持 total_ai_messages
                await cur.execute(
                    "UPDATE users SET "
                    "  pro_pack_used     = pro_pack_used + %s, "
                    "  total_ai_messages = total_ai_messages + 1 "
                    "WHERE id = %s",
                    (token_increment, user_id),
                )
                # 取一下扣完后的剩余量，方便日志写得自然
                await cur.execute(
                    "SELECT pro_pack_total, pro_pack_used FROM users WHERE id = %s",
                    (user_id,),
                )
                row = await cur.fetchone()
            await conn.commit()

        if row:
            remain = max(0, int(row["pro_pack_total"] or 0) - int(row["pro_pack_used"] or 0))
        else:
            remain = -1

        print(
            f"[{ts}][CommitUsage] user_id={user_id} db_id={db_id} bucket=pack "
            f"+{token_increment} tokens (in={in_tok} out={out_tok}) 余 {remain}",
            flush=True,
        )
        await utils.add_temp_log(
            pool, db_id,
            f"[扣费] 订阅包扣减 {token_increment} token（输入 {in_tok} / 输出 {out_tok}），剩余 {remain:,} token"
        )
        return

    # ─────────────────────────────────────────────────────────────────────
    # bucket = weekly
    # ─────────────────────────────────────────────────────────────────────
    if bucket == "weekly":
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "UPDATE users SET "
                    "  weekly_used_tokens = weekly_used_tokens + %s, "
                    "  total_ai_messages  = total_ai_messages + 1 "
                    "WHERE id = %s",
                    (token_increment, user_id),
                )
                await cur.execute(
                    "SELECT base_weekly_tokens, bonus_weekly_tokens, weekly_used_tokens "
                    "FROM users WHERE id = %s",
                    (user_id,),
                )
                row = await cur.fetchone()
            await conn.commit()

        if row:
            wt = int(row["base_weekly_tokens"] or 0) + int(row["bonus_weekly_tokens"] or 0)
            wu = int(row["weekly_used_tokens"] or 0)
            remain = max(0, wt - wu)
        else:
            remain = -1

        print(
            f"[{ts}][CommitUsage] user_id={user_id} db_id={db_id} bucket=weekly "
            f"+{token_increment} tokens (in={in_tok} out={out_tok}) 余 {remain}",
            flush=True,
        )
        await utils.add_temp_log(
            pool, db_id,
            f"[扣费] 本周免费额度扣减 {token_increment} token（输入 {in_tok} / 输出 {out_tok}），"
            f"本周剩余 {remain:,} token"
        )
        return

    # ─────────────────────────────────────────────────────────────────────
    # bucket = balance
    # ─────────────────────────────────────────────────────────────────────
    if bucket == "balance":
        # 4 位精度 + 最小颗粒兜底
        cost_rounded = round(float(total_cost or 0), ROUND_DECIMALS)
        if cost_rounded > 0 and cost_rounded < MIN_BALANCE_DEDUCT:
            cost_rounded = MIN_BALANCE_DEDUCT
        # 极端情况：cost 为 0（免费模型）→ 不扣，但仍写日志告知用户

        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                if cost_rounded > 0:
                    await cur.execute(
                        "UPDATE users SET "
                        "  balance           = GREATEST(0, balance - %s), "
                        "  total_ai_messages = total_ai_messages + 1 "
                        "WHERE id = %s",
                        (cost_rounded, user_id),
                    )
                else:
                    await cur.execute(
                        "UPDATE users SET total_ai_messages = total_ai_messages + 1 WHERE id = %s",
                        (user_id,),
                    )
                await cur.execute(
                    "SELECT balance FROM users WHERE id = %s", (user_id,)
                )
                row = await cur.fetchone()
            await conn.commit()

        new_balance = float(row["balance"]) if row else -1.0

        print(
            f"[{ts}][CommitUsage] user_id={user_id} db_id={db_id} bucket=balance "
            f"扣 ¥{cost_rounded:.4f} (in={in_tok} out={out_tok} model={model}) 余 ¥{new_balance:.4f}",
            flush=True,
        )
        # 两条日志：先扣费动作，再明细
        await utils.add_temp_log(
            pool, db_id,
            f"[扣费] 余额计费：本轮扣 ¥{cost_rounded:.4f}，余额剩余 ¥{new_balance:.4f}"
        )
        await utils.add_temp_log(
            pool, db_id,
            f"[扣费·明细] 模型 {model}：输入 {in_tok} / 输出 {out_tok} token"
        )
        return

    # ─────────────────────────────────────────────────────────────────────
    # 未知 bucket：保护性日志，不动数据
    # ─────────────────────────────────────────────────────────────────────
    print(
        f"[{ts}][CommitUsage][严重] user_id={user_id} db_id={db_id} 收到未知 bucket={bucket}，"
        f"已跳过扣费（in={in_tok} out={out_tok}）",
        flush=True,
    )
    await utils.add_temp_log(
        pool, db_id,
        f"[扣费·出错] 未知扣费桶 {bucket}，本轮未扣费（请联系管理员）"
    )
