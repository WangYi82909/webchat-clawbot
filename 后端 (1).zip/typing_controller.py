"""
typing_controller.py — v12.1 (2026-05-12) 正在输入指示控制器

严格按 openclaw-weixin@2.4.2 spec:
  - keepaliveIntervalMs = 5000 (每 5s 续一次 status:1)
  - markDispatchIdle() 模式:AI 生成完成后 finally 显式 stop()
  - 用 bot 共享的 httpx client(已 warm),不每次 new client(老版本的 50-100ms 浪费)

用法:
  typing = TypingController(client, base_url, token, uid, context_token, db_id, pool)
  await typing.start()
  try:
      reply = await chat.generate_reply(...)
  finally:
      await typing.stop()
  # 然后才 send_wx_text

stop() 是 idempotent 的,多次调用安全。
start() 失败(getconfig 拿不到 ticket)时 stop() 是 no-op。
"""
import asyncio
import httpx
import time
import utils


# 与 wechat_poller.py 对齐
CHANNEL_VERSION         = "2.4.2"
KEEPALIVE_INTERVAL_S    = 5.0      # 官方 keepaliveIntervalMs=5000
TYPING_STATUS_ON        = 1
TYPING_STATUS_OFF       = 2
DEFAULT_API_TIMEOUT_S   = 10.0


class TypingController:
    """单个用户单次回复周期内的"正在输入"控制器。"""

    def __init__(
        self,
        *,
        client: httpx.AsyncClient,
        base_url: str,
        wx_token: str,
        uid: str,
        context_token: str | None,
        db_id: int,
    ):
        self.client        = client
        self.base_url      = base_url.rstrip('/')
        self.token         = wx_token
        self.uid           = uid
        self.context_token = context_token or ""
        self.db_id         = db_id

        self.ticket: str | None     = None
        self._task: asyncio.Task | None = None
        self._stopped               = False

    # ── 内部辅助 ──
    def _headers(self) -> dict:
        return {
            "Content-Type":      "application/json",
            "AuthorizationType": "ilink_bot_token",
            "X-WECHAT-UIN":      utils.generate_x_wechat_uin(),
            "Authorization":     f"Bearer {self.token}",
        }

    def _base_info(self) -> dict:
        return {"channel_version": CHANNEL_VERSION}

    async def _post_status(self, status: int) -> bool:
        """单次 POST /sendtyping。成功 True,失败 False(静默)。"""
        if not self.ticket:
            return False
        try:
            r = await self.client.post(
                f"{self.base_url}/sendtyping",
                json={
                    "ilink_user_id": self.uid,
                    "typing_ticket": self.ticket,
                    "status":        status,
                    "base_info":     self._base_info(),
                },
                headers=self._headers(),
                timeout=DEFAULT_API_TIMEOUT_S,
            )
            return r.status_code == 200
        except Exception:
            return False

    async def _keepalive_loop(self) -> None:
        """每 5s 续 status:1,直到 _stopped。"""
        try:
            while not self._stopped:
                await asyncio.sleep(KEEPALIVE_INTERVAL_S)
                if self._stopped:
                    return
                await self._post_status(TYPING_STATUS_ON)
        except asyncio.CancelledError:
            return
        except Exception:
            return

    # ── 公共 API ──
    async def start(self) -> bool:
        """
        启动:fetch typing_ticket → POST status:1 → 起 keepalive 任务。
        返回 True 表示成功启动;False 表示拿不到 ticket(stop 时也是 no-op)。
        """
        # 1. getconfig 拿 ticket
        body = {"ilink_user_id": self.uid, "base_info": self._base_info()}
        if self.context_token:
            body["context_token"] = self.context_token
        try:
            r = await self.client.post(
                f"{self.base_url}/getconfig",
                json=body,
                headers=self._headers(),
                timeout=DEFAULT_API_TIMEOUT_S,
            )
            data = r.json()
            self.ticket = data.get("typing_ticket")
        except Exception as e:
            print(
                f"[typing] db_id={self.db_id} getconfig 失败: {type(e).__name__}: {e}",
                flush=True,
            )
            return False

        if not self.ticket:
            return False

        # 2. 立刻发一条 status:1
        ok = await self._post_status(TYPING_STATUS_ON)
        if not ok:
            return False

        # 3. 启动 keepalive
        self._task = asyncio.create_task(self._keepalive_loop())
        return True

    async def stop(self) -> None:
        """
        显式停止 typing。Idempotent。

        操作顺序:
          1. set _stopped (防止 keepalive 再发 status:1)
          2. cancel keepalive task
          3. POST status:2 (用 warm client,~5-30ms)

        本方法 await 第 3 步完成,确保 typing 指示器在用户看到回复前就消失。
        """
        if self._stopped:
            return
        self._stopped = True

        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass

        # 必须显式发 status:2 — 不能依赖任何隐式机制
        await self._post_status(TYPING_STATUS_OFF)
