import unittest

import chat


class _Cursor:
    def __init__(self, row=None, error=None):
        self.row = row
        self.error = error
        self.executed = None

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def execute(self, sql, params):
        if self.error:
            raise self.error
        self.executed = (sql, params)

    async def fetchone(self):
        return self.row


class _Connection:
    def __init__(self, cursor):
        self._cursor = cursor

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    def cursor(self):
        return self._cursor


class _Pool:
    def __init__(self, row=None, error=None):
        self.cursor_obj = _Cursor(row=row, error=error)

    def acquire(self):
        return _Connection(self.cursor_obj)


class SpecialModeTests(unittest.IsolatedAsyncioTestCase):
    async def test_database_one_enables_mode(self):
        pool = _Pool({"special_mode": 1})
        self.assertTrue(await chat._load_special_mode_enabled(pool, 12))
        sql, params = pool.cursor_obj.executed
        self.assertIn("SELECT special_mode FROM instances", sql)
        self.assertEqual(params, (12,))

    async def test_all_other_values_default_to_off(self):
        for row in (None, {"special_mode": None}, {"special_mode": 0}, ("0",)):
            with self.subTest(row=row):
                self.assertFalse(
                    await chat._load_special_mode_enabled(_Pool(row), 13)
                )

    async def test_database_error_defaults_to_off(self):
        self.assertFalse(
            await chat._load_special_mode_enabled(
                _Pool(error=RuntimeError("missing column")), 14
            )
        )

    async def test_system_block_only_exists_when_enabled(self):
        self.assertEqual(chat._build_special_mode_system_block(False), "")
        enabled = chat._build_special_mode_system_block(True)
        self.assertIn("【特殊模式】", enabled)
        self.assertIn("我们是成年人", enabled)
        self.assertIn("在涉及性方面", enabled)
        self.assertIn("禁止输出：", enabled)


if __name__ == "__main__":
    unittest.main()
