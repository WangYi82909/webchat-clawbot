<?php
date_default_timezone_set('Asia/Shanghai');
/**
 * Cloud Love · 管理后台 (Admin Console)
 *
 * 鉴权策略：必须是 session 中已登录、且 username == 'admin' 的用户。
 *           任何其他用户访问 → 403。未登录 → 跳 index.php。
 *
 * 架构：单文件 SPA。
 *   - GET   admin.php           → 渲染管理页面 (HTML)
 *   - POST  admin.php?action=*  → 返回 JSON（CRUD 接口）
 *
 * 覆盖模块：dashboard / users / instances / orders / models / config /
 *          tools / market / emails
 */
require_once __DIR__ . '/api/common.php';

// ── 鉴权 ──────────────────────────────────────────────────────────────────
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
$user = require_auth();
if (($user['username'] ?? '') !== 'admin') {
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><meta charset="utf-8"><title>403</title>';
    echo '<style>body{font-family:sans-serif;text-align:center;padding:60px;color:#444}</style>';
    echo '<h1>403 Forbidden</h1><p>仅 admin 用户可访问此页面。</p>';
    echo '<p><a href="console.php">返回控制台</a></p>';
    exit;
}

$db = get_db();

// =====================================================================
// AJAX Action 路由（所有 POST 请求走这里，返回 JSON 后 exit）
// =====================================================================
$action = $_GET['action'] ?? $_POST['action'] ?? '';
if ($action !== '') {
    header('Content-Type: application/json; charset=utf-8');

    function p($k, $d = null) { return $_POST[$k] ?? $_GET[$k] ?? $d; }
    function ok($data = null, $msg = 'ok') {
        echo json_encode(['code'=>200,'message'=>$msg,'data'=>$data], JSON_UNESCAPED_UNICODE);
        exit;
    }
    function err($msg, $code = 400) {
        echo json_encode(['code'=>$code,'message'=>$msg,'data'=>null], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ── DashScope 声音复刻: 列出 / 删除音色 (后台批量清理配额用) ──
    function _vc_ds_post($input) {
        $ch = curl_init('https://dashscope.aliyuncs.com/api/v1/services/audio/tts/customization');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
            CURLOPT_POSTFIELDS     => json_encode(['model' => 'voice-enrollment', 'input' => $input], JSON_UNESCAPED_UNICODE),
            CURLOPT_HTTPHEADER     => ['Authorization: Bearer sk-REMOVED-ROTATE-THIS-KEY', 'Content-Type: application/json'],
            CURLOPT_TIMEOUT        => 40, CURLOPT_CONNECTTIMEOUT => 15, CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $resp = curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return [$http, json_decode((string)$resp, true), (string)$resp];
    }
    function _vc_ds_list($pageIndex, $pageSize) {
        [$http, $j, $raw] = _vc_ds_post(['action' => 'list_voice', 'page_index' => $pageIndex, 'page_size' => $pageSize]);
        $out = [];
        if (is_array($j) && isset($j['output']['voice_list']) && is_array($j['output']['voice_list'])) {
            foreach ($j['output']['voice_list'] as $v) {
                $vid = (string)($v['voice_id'] ?? $v['voice'] ?? '');
                if ($vid !== '') {
                    $out[] = ['voice_id' => $vid, 'status' => (string)($v['status'] ?? ''), 'gmt_create' => (string)($v['gmt_create'] ?? '')];
                }
            }
        }
        return $out;
    }
    function _vc_ds_delete($vid) {
        if ($vid === '') return true;
        [$http, $j, $raw] = _vc_ds_post(['action' => 'delete_voice', 'voice_id' => $vid]);
        if ($http !== 200) error_log('[admin vc] dashscope delete HTTP ' . $http . ' ' . $vid . ' ' . substr($raw, 0, 120));
        return $http === 200;
    }

    // 兑换码表自愈建表(与 api/api_redeem.php 完全一致)。
    function redeem_ensure_table($db) {
        try {
            $db->exec(
                "CREATE TABLE IF NOT EXISTS `redeem_codes` (
                  `id`            INT AUTO_INCREMENT PRIMARY KEY,
                  `code`          VARCHAR(16) NOT NULL,
                  `reward_type`   VARCHAR(16) NOT NULL DEFAULT 'balance',
                  `reward_value`  DECIMAL(14,2) NOT NULL DEFAULT 0,
                  `reward_days`   INT NOT NULL DEFAULT 30,
                  `reward_models` TEXT DEFAULT NULL,
                  `batch_id`      VARCHAR(32) DEFAULT NULL,
                  `note`          VARCHAR(128) DEFAULT NULL,
                  `status`        VARCHAR(8) NOT NULL DEFAULT 'unused',
                  `used_by`       INT DEFAULT NULL,
                  `used_by_name`  VARCHAR(64) DEFAULT NULL,
                  `used_at`       INT DEFAULT NULL,
                  `created_at`    INT NOT NULL DEFAULT 0,
                  UNIQUE KEY `uniq_code` (`code`),
                  KEY `idx_status` (`status`),
                  KEY `idx_batch`  (`batch_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
        } catch (Exception $e) {
            error_log('[admin] ensure redeem_codes failed: ' . $e->getMessage());
        }
    }

    // 用户封禁表自愈建表(与 console.php / main.py 的判定字段完全一致)。
    // 语义:某用户「正在封禁中」⇔ is_banned=1 且 (banned_until=0 永久 或 banned_until>now 未到期)。
    function ban_ensure_table($db) {
        try {
            $db->exec(
                "CREATE TABLE IF NOT EXISTS `user_bans` (
                  `user_id`      INT NOT NULL PRIMARY KEY,
                  `is_banned`    TINYINT NOT NULL DEFAULT 0,
                  `reason`       VARCHAR(500) NOT NULL DEFAULT '',
                  `banned_until` BIGINT NOT NULL DEFAULT 0,
                  `banned_at`    BIGINT NOT NULL DEFAULT 0,
                  `banned_by`    VARCHAR(64) NOT NULL DEFAULT '',
                  `updated_at`   BIGINT NOT NULL DEFAULT 0,
                  KEY `idx_is_banned` (`is_banned`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
        } catch (Exception $e) {
            error_log('[admin] ensure user_bans failed: ' . $e->getMessage());
        }
    }

    // 手机号黑名单自愈建表 (2026-07-07 新增)。
    // 已注销用户的手机号加入此表后,注册流程(login.php send_phone_code / register)
    // 会拦截并提示「已注销用户不得再次注册」。
    function phone_blacklist_ensure_table($db) {
        try {
            $db->exec(
                "CREATE TABLE IF NOT EXISTS `phone_blacklist` (
                  `id`         INT AUTO_INCREMENT PRIMARY KEY,
                  `phone`      VARCHAR(20)  NOT NULL,
                  `reason`     VARCHAR(200) NOT NULL DEFAULT '',
                  `created_by` VARCHAR(64)  NOT NULL DEFAULT '',
                  `created_at` BIGINT       NOT NULL DEFAULT 0,
                  UNIQUE KEY `uk_phone` (`phone`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
        } catch (Exception $e) {
            error_log('[admin] ensure phone_blacklist failed: ' . $e->getMessage());
        }
    }

    // 支付回调日志表自愈建表(与 api/notify.php 的 notifylog_ensure 完全一致)。
    // 每次易支付回调都会往这里写一行;admin 据此做掉单监控 + 循环告警。
    function notifylog_ensure_table($db) {
        try {
            $db->exec(
                "CREATE TABLE IF NOT EXISTS `notify_log` (
                  `id`           INT AUTO_INCREMENT PRIMARY KEY,
                  `out_trade_no` VARCHAR(64)  DEFAULT NULL,
                  `trade_no`     VARCHAR(64)  DEFAULT NULL,
                  `attempt_no`   INT NOT NULL DEFAULT 1,
                  `sign_ok`      TINYINT NOT NULL DEFAULT 0,
                  `trade_status` VARCHAR(32)  DEFAULT NULL,
                  `result`       VARCHAR(16) NOT NULL DEFAULT 'fail',
                  `stage`        VARCHAR(32)  DEFAULT NULL,
                  `reason`       VARCHAR(255) DEFAULT NULL,
                  `username`     VARCHAR(64)  DEFAULT NULL,
                  `order_type`   VARCHAR(32)  DEFAULT NULL,
                  `amount`       VARCHAR(32)  DEFAULT NULL,
                  `raw`          TEXT         DEFAULT NULL,
                  `ip`           VARCHAR(64)  DEFAULT NULL,
                  `handled`      TINYINT NOT NULL DEFAULT 0,
                  `handled_at`   INT          DEFAULT NULL,
                  `created_at`   INT NOT NULL DEFAULT 0,
                  KEY `idx_oid`      (`out_trade_no`),
                  KEY `idx_res_hand` (`result`,`handled`),
                  KEY `idx_created`  (`created_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
        } catch (Exception $e) {
            error_log('[admin] ensure notify_log failed: ' . $e->getMessage());
        }
    }

    try {
        switch ($action) {

        // ── Dashboard 总览 ────────────────────────────────────────────────
        case 'stats': {
            $today_start = strtotime(date('Y-m-d 00:00:00'));
            $stats = [];
            $stats['user_total']   = (int)$db->query("SELECT COUNT(*) FROM users")->fetchColumn();
            $s = $db->prepare("SELECT COUNT(*) FROM users WHERE created_at >= ?");
            $s->execute([$today_start]);
            $stats['user_today']   = (int)$s->fetchColumn();
            $stats['user_pro']     = (int)$db->query("SELECT COUNT(*) FROM users WHERE plan_type='pro'")->fetchColumn();
            $stats['user_with_pack'] = (int)$db->query(
                "SELECT COUNT(*) FROM users WHERE pro_pack_total > 0
                 AND (plan_expired_at = 0 OR plan_expired_at > UNIX_TIMESTAMP())"
            )->fetchColumn();
            $stats['instance_total']  = (int)$db->query("SELECT COUNT(*) FROM instances")->fetchColumn();
            $stats['instance_active'] = (int)$db->query("SELECT COUNT(*) FROM instances WHERE status='启动'")->fetchColumn();
            // 9 折(2026-07-01):营收按"实收"统计 = round(orig_amount*0.90,2)。
            //   老订单(无 orig_amount)回退 amount(那时无折扣, amount 即实收)。
            //   ⚠ 单一倍率重算:历史按 98 折成交的订单会以 90% 口径估算;要逐单精确需把实付落库。
            //   orig_amount 列不存在时(未跑 migration)整体回退 SUM(amount), 不报错。
            $hasOrigCol = false;
            try { $hasOrigCol = (bool)$db->query("SHOW COLUMNS FROM payment_orders LIKE 'orig_amount'")->fetch(); } catch (Exception $e) {}
            $revExpr = $hasOrigCol
                ? "COALESCE(SUM(CASE WHEN orig_amount IS NOT NULL THEN ROUND(orig_amount*0.90,2) ELSE amount END),0)"
                : "COALESCE(SUM(amount),0)";

            $stats['order_total']  = (int)$db->query("SELECT COUNT(*) FROM payment_orders WHERE status='success'")->fetchColumn();
            $stats['order_amount'] = (float)$db->query("SELECT $revExpr FROM payment_orders WHERE status='success'")->fetchColumn();
            $s = $db->prepare("SELECT COUNT(*) FROM payment_orders WHERE status='success' AND created_at >= ?");
            $s->execute([$today_start]);
            $stats['order_today']  = (int)$s->fetchColumn();
            $s = $db->prepare("SELECT $revExpr FROM payment_orders WHERE status='success' AND created_at >= ?");
            $s->execute([$today_start]);
            $stats['order_today_amount'] = (float)$s->fetchColumn();
            $stats['msg_total']    = (int)$db->query("SELECT COALESCE(SUM(ai_message_count),0) FROM instances")->fetchColumn();

            // v12.9 (2026-05-12) 7 天趋势数据(用户注册 / 订单收入)
            // 一次性把 7 天每天的数字算出来,前端拿去画 line chart
            $trend = ['labels' => [], 'users' => [], 'orders' => [], 'revenue' => []];
            for ($i = 6; $i >= 0; $i--) {
                $day_start = strtotime(date('Y-m-d 00:00:00', strtotime("-{$i} days")));
                $day_end   = $day_start + 86400;
                $trend['labels'][] = date('m-d', $day_start);

                $s = $db->prepare("SELECT COUNT(*) FROM users WHERE created_at >= ? AND created_at < ?");
                $s->execute([$day_start, $day_end]);
                $trend['users'][] = (int)$s->fetchColumn();

                $s = $db->prepare("SELECT COUNT(*), $revExpr FROM payment_orders WHERE status='success' AND created_at >= ? AND created_at < ?");
                $s->execute([$day_start, $day_end]);
                $row = $s->fetch(PDO::FETCH_NUM);
                $trend['orders'][]  = (int)($row[0] ?? 0);
                $trend['revenue'][] = (float)($row[1] ?? 0);
            }
            $stats['trend'] = $trend;
            ok($stats);
        }

        // ── 系统状态(v13.12 · 2026-05-14)─────────────────────────────────
        //    在仪表盘小卡里显示:worker / mysql 连接 / 系统负载 / 内存
        case 'system.status': {
            $sys = [];

            // 1. Worker 进程数(pgrep) — 失败/禁用 shell_exec 时显示 null
            $sys['workers'] = null;
            $sys['workers_err'] = null;
            try {
                if (function_exists('shell_exec') && !in_array('shell_exec', array_map('trim', explode(',', (string)ini_get('disable_functions'))), true)) {
                    $out = @shell_exec("pgrep -fc 'python.*main\\.py' 2>/dev/null");
                    if ($out !== null && $out !== false) {
                        $sys['workers'] = max(0, (int)trim($out));
                    }
                } else {
                    $sys['workers_err'] = 'shell_exec 被禁用';
                }
            } catch (Throwable $e) {
                $sys['workers_err'] = $e->getMessage();
            }

            // 2. MySQL 连接数 + 运行线程
            try {
                $row = $db->query("SHOW STATUS WHERE Variable_name IN ('Threads_connected','Threads_running','Uptime','Questions')")->fetchAll(PDO::FETCH_KEY_PAIR);
                $sys['mysql_connections'] = isset($row['Threads_connected']) ? (int)$row['Threads_connected'] : null;
                $sys['mysql_running']     = isset($row['Threads_running'])   ? (int)$row['Threads_running']   : null;
                $sys['mysql_uptime']      = isset($row['Uptime'])            ? (int)$row['Uptime']            : null;
                $sys['mysql_questions']   = isset($row['Questions'])         ? (int)$row['Questions']         : null;
            } catch (Throwable $e) {
                $sys['mysql_err'] = $e->getMessage();
            }

            // 3. 系统负载(Linux only)
            $sys['load1']  = null;
            $sys['load5']  = null;
            $sys['load15'] = null;
            if (function_exists('sys_getloadavg')) {
                $la = @sys_getloadavg();
                if (is_array($la) && count($la) >= 3) {
                    $sys['load1']  = round((float)$la[0], 2);
                    $sys['load5']  = round((float)$la[1], 2);
                    $sys['load15'] = round((float)$la[2], 2);
                }
            }

            // 4. 内存(读 /proc/meminfo)
            $sys['mem_total_mb']  = null;
            $sys['mem_avail_mb']  = null;
            $sys['mem_used_pct']  = null;
            if (is_readable('/proc/meminfo')) {
                $mem = @file_get_contents('/proc/meminfo');
                if ($mem) {
                    $get = function($key) use ($mem) {
                        if (preg_match('/^' . preg_quote($key, '/') . ':\s+(\d+)/m', $mem, $m)) return (int)$m[1];
                        return null;
                    };
                    $total = $get('MemTotal');
                    $avail = $get('MemAvailable');
                    if ($total && $avail !== null) {
                        $sys['mem_total_mb'] = (int)round($total / 1024);
                        $sys['mem_avail_mb'] = (int)round($avail / 1024);
                        $sys['mem_used_pct'] = (int)round(($total - $avail) * 100 / $total);
                    }
                }
            }

            // 5. 当前活跃实例(快速 SQL)
            $sys['instances_active'] = (int)$db->query("SELECT COUNT(*) FROM instances WHERE status='启动'")->fetchColumn();

            // 6. 服务器时间
            $sys['server_time'] = date('Y-m-d H:i:s');
            $sys['server_tz']   = date_default_timezone_get();

            ok($sys);
        }

        // ── 版本日志(v13.12 · 2026-05-14)─────────────────────────────────
        case 'versions.list': {
            $rows = $db->query(
                "SELECT id, version, released_at, title, content, is_published, sort_order, created_at, updated_at
                 FROM version_logs
                 ORDER BY released_at DESC, sort_order DESC, id DESC"
            )->fetchAll();
            ok(['items' => $rows]);
        }

        case 'versions.save': {
            $id           = (int)p('id', 0);
            $version      = trim((string)p('version', ''));
            $released_at  = trim((string)p('released_at', date('Y-m-d')));
            $title        = trim((string)p('title', ''));
            $content      = (string)p('content', '');
            $is_published = ((int)p('is_published', 1)) ? 1 : 0;
            $sort_order   = (int)p('sort_order', 0);

            if ($version === '')              fail('版本号不能为空');
            if (mb_strlen($version) > 30)     fail('版本号最多 30 字');
            if ($title === '')                fail('标题不能为空');
            if (mb_strlen($title) > 120)      fail('标题最多 120 字');
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $released_at)) fail('日期格式应为 YYYY-MM-DD');

            if ($id > 0) {
                $s = $db->prepare(
                    "UPDATE version_logs
                       SET version=?, released_at=?, title=?, content=?,
                           is_published=?, sort_order=?
                     WHERE id=?"
                );
                $s->execute([$version, $released_at, $title, $content, $is_published, $sort_order, $id]);
                ok(['id' => $id, 'updated' => true]);
            } else {
                $s = $db->prepare(
                    "INSERT INTO version_logs (version, released_at, title, content, is_published, sort_order)
                     VALUES (?, ?, ?, ?, ?, ?)"
                );
                $s->execute([$version, $released_at, $title, $content, $is_published, $sort_order]);
                ok(['id' => (int)$db->lastInsertId(), 'created' => true]);
            }
        }

        case 'versions.delete': {
            $id = (int)p('id', 0);
            if ($id <= 0) fail('参数错误');
            $s = $db->prepare("DELETE FROM version_logs WHERE id = ?");
            $s->execute([$id]);
            ok();
        }

        // ── 用户管理 ──────────────────────────────────────────────────────
        case 'users.list': {
            $kw = trim((string)p('keyword', ''));
            $plan = (string)p('plan', '');
            $page = max(1, (int)p('page', 1));
            $size = 20;
            $offset = ($page - 1) * $size;

            $where = [];
            $bind = [];
            if ($kw !== '') {
                // v12.9 (2026-05-12) 新增手机号搜索 — 老库没 phone 列会回退
                try {
                    $db->query("SELECT phone FROM users LIMIT 1");
                    $has_phone = true;
                } catch (PDOException $e) {
                    $has_phone = false;
                }
                if ($has_phone) {
                    $where[] = "(username LIKE ? OR email LIKE ? OR invite_code LIKE ? OR phone LIKE ?)";
                    $bind[] = "%{$kw}%"; $bind[] = "%{$kw}%"; $bind[] = "%{$kw}%"; $bind[] = "%{$kw}%";
                } else {
                    $where[] = "(username LIKE ? OR email LIKE ? OR invite_code LIKE ?)";
                    $bind[] = "%{$kw}%"; $bind[] = "%{$kw}%"; $bind[] = "%{$kw}%";
                }
            }
            if (in_array($plan, ['free','pro'], true)) {
                $where[] = "plan_type = ?";
                $bind[] = $plan;
            }
            $w = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

            $cstmt = $db->prepare("SELECT COUNT(*) FROM users $w");
            $cstmt->execute($bind);
            $total = (int)$cstmt->fetchColumn();

            // v12.9 SELECT phone + 次数包字段(老库降级)
            try {
                $sql = "SELECT id, username, email, phone, plan_type, plan_expired_at, billing_mode,
                               balance,
                               base_weekly_tokens, bonus_weekly_tokens, weekly_used_tokens, last_reset_week,
                               pro_pack_total, pro_pack_used,
                               count_pack_total, count_pack_used, count_pack_expired_at, count_pack_models,
                               total_ai_messages, invite_code, invite_count,
                               title, title_color,
                               created_at
                        FROM users $w
                        ORDER BY id DESC
                        LIMIT $size OFFSET $offset";
                $stmt = $db->prepare($sql);
                $stmt->execute($bind);
                $rows = $stmt->fetchAll();
            } catch (PDOException $e) {
                $err_msg = $e->getMessage();
                // 老库可能缺 phone / count_pack_* / title 等列,依次降级
                if (strpos($err_msg, 'phone') !== false ||
                    strpos($err_msg, 'count_pack') !== false ||
                    strpos($err_msg, 'title') !== false) {
                    $sql = "SELECT id, username, email, plan_type, plan_expired_at, billing_mode,
                                   balance,
                                   base_weekly_tokens, bonus_weekly_tokens, weekly_used_tokens, last_reset_week,
                                   pro_pack_total, pro_pack_used,
                                   total_ai_messages, invite_code, invite_count,
                                   created_at
                            FROM users $w
                            ORDER BY id DESC
                            LIMIT $size OFFSET $offset";
                    $stmt = $db->prepare($sql);
                    $stmt->execute($bind);
                    $rows = $stmt->fetchAll();
                    foreach ($rows as &$r) {
                        if (!isset($r['phone']))                  $r['phone'] = '';
                        if (!isset($r['count_pack_total']))       $r['count_pack_total'] = 0;
                        if (!isset($r['count_pack_used']))        $r['count_pack_used'] = 0;
                        if (!isset($r['count_pack_expired_at']))  $r['count_pack_expired_at'] = 0;
                        if (!isset($r['count_pack_models']))      $r['count_pack_models'] = '[]';
                        if (!isset($r['title']))                  $r['title'] = '';
                        if (!isset($r['title_color']))            $r['title_color'] = '#b04e5c';
                    }
                    unset($r);
                } else {
                    throw $e;
                }
            }

            // ── 合并封禁状态（user_bans）─────────────────────────────────────
            // 表不存在 / 查询异常 → 全部按未封禁处理,不影响用户列表正常返回。
            ban_ensure_table($db);
            if (!empty($rows)) {
                $uids = array_map(function ($r) { return (int)$r['id']; }, $rows);
                $banMap = [];
                try {
                    $in = implode(',', array_fill(0, count($uids), '?'));
                    $bs = $db->prepare(
                        "SELECT user_id, is_banned, reason, banned_until, banned_at, banned_by
                         FROM user_bans WHERE user_id IN ($in)"
                    );
                    $bs->execute($uids);
                    foreach ($bs->fetchAll() as $b) { $banMap[(int)$b['user_id']] = $b; }
                } catch (Exception $e) { $banMap = []; }
                $now = time();
                foreach ($rows as &$r) {
                    $b = $banMap[(int)$r['id']] ?? null;
                    // 「当前是否生效」= is_banned=1 且 (永久 或 未到期)
                    $effective = $b
                        && (int)$b['is_banned'] === 1
                        && ((int)$b['banned_until'] === 0 || (int)$b['banned_until'] > $now);
                    $r['ban'] = [
                        'is_banned'    => $effective ? 1 : 0,
                        'reason'       => $b['reason'] ?? '',
                        'banned_until' => $b ? (int)$b['banned_until'] : 0,
                        'banned_at'    => $b ? (int)$b['banned_at'] : 0,
                        'banned_by'    => $b['banned_by'] ?? '',
                    ];
                }
                unset($r);
            }

            // ── 合并人工客服身份（is_support / support_email）─────────────────
            // 列不存在（未跑迁移）/ 查询异常 → 全部按「非客服」处理，不影响列表返回。
            if (!empty($rows)) {
                try {
                    $__sids = array_map(function ($r) { return (int)$r['id']; }, $rows);
                    $__in   = implode(',', array_fill(0, count($__sids), '?'));
                    $__ss   = $db->prepare("SELECT id, is_support, support_email FROM users WHERE id IN ($__in)");
                    $__ss->execute($__sids);
                    $__sm = [];
                    foreach ($__ss->fetchAll() as $__s) { $__sm[(int)$__s['id']] = $__s; }
                    foreach ($rows as &$r) {
                        $__s = $__sm[(int)$r['id']] ?? null;
                        $r['is_support']    = $__s ? (int)$__s['is_support'] : 0;
                        $r['support_email'] = $__s['support_email'] ?? '';
                    }
                    unset($r);
                } catch (Throwable $e) {
                    foreach ($rows as &$r) { $r['is_support'] = 0; $r['support_email'] = ''; }
                    unset($r);
                }
            }

            ok(['total'=>$total, 'page'=>$page, 'size'=>$size, 'rows'=>$rows]);
        }

        // ── 新增用户（2026-06-27）：用户名 + 手机号 + 密码即可创建 ──────────────
        // 用 SHOW COLUMNS 读取真实表结构动态构造 INSERT，兼容不同库版本、
        // 自动为「NOT NULL 且无默认值」的其它列补零值，避免缺列报错。
        case 'users.create': {
            $username = trim((string)p('username', ''));
            $phone    = trim((string)p('phone', ''));
            $password = (string)p('password', '');

            if ($username === '')                    err('请输入用户名');
            if (mb_strlen($username) < 2)            err('用户名至少 2 个字符');
            if (mb_strlen($username) > 32)           err('用户名最多 32 个字符');
            if ($phone === '')                       err('请输入手机号');
            if (!preg_match('/^\d{6,20}$/', $phone)) err('手机号格式不正确（6-20 位数字）');
            if (strlen($password) < 6)               err('密码至少 6 位');

            // 用户名唯一
            $chk = $db->prepare("SELECT id FROM users WHERE username=? LIMIT 1");
            $chk->execute([$username]);
            if ($chk->fetchColumn()) err('用户名已存在');
            // 手机号唯一（老库无 phone 列则跳过）
            try {
                $cp = $db->prepare("SELECT id FROM users WHERE phone=? LIMIT 1");
                $cp->execute([$phone]);
                if ($cp->fetchColumn()) err('该手机号已被注册');
            } catch (PDOException $e) { /* 无 phone 列 */ }

            $hash = password_hash($password, PASSWORD_DEFAULT);

            try {
                $cols = $db->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) { err('读取 users 表结构失败'); }

            // created_at 可能是 int 时间戳或 datetime；invite_code 取列宽避免超长
            $createdIsDatetime = false;
            $inviteLen = 8;
            foreach ($cols as $c) {
                if ($c['Field'] === 'created_at' && preg_match('/datetime|timestamp/i', $c['Type'])) {
                    $createdIsDatetime = true;
                }
                if ($c['Field'] === 'invite_code' && preg_match('/\((\d+)\)/', $c['Type'], $mm)) {
                    $inviteLen = max(4, min(16, (int)$mm[1]));
                }
            }
            // 生成唯一邀请码
            $genInvite = function () use ($db, $inviteLen) {
                for ($i = 0; $i < 8; $i++) {
                    $code = strtoupper(substr(bin2hex(random_bytes(16)), 0, $inviteLen));
                    try {
                        $q = $db->prepare("SELECT 1 FROM users WHERE invite_code=? LIMIT 1");
                        $q->execute([$code]);
                        if (!$q->fetchColumn()) return $code;
                    } catch (PDOException $e) { return $code; }
                }
                return strtoupper(substr(bin2hex(random_bytes(16)), 0, $inviteLen));
            };

            $now = time();
            // 已知字段预设值（仅当该列存在时写入）
            $preset = [
                'username'     => $username,
                'password'     => $hash,
                'phone'        => $phone,
                'email'        => '',
                'plan_type'    => 'free',
                'billing_mode' => 'quota_first',
                'balance'      => 0,
                'invite_code'  => $genInvite(),
                'invite_count' => 0,
                'created_at'   => $createdIsDatetime ? date('Y-m-d H:i:s') : $now,
            ];

            $insCols = []; $place = []; $insVals = [];
            foreach ($cols as $c) {
                $name = $c['Field'];
                if (stripos((string)$c['Extra'], 'auto_increment') !== false) continue;   // 跳过自增主键
                if (array_key_exists($name, $preset)) {
                    $insCols[] = "`$name`"; $place[] = '?'; $insVals[] = $preset[$name];
                    continue;
                }
                // 其余列：只有「NOT NULL 且无默认值」才必须补零值，否则交给 DB 默认/NULL
                $notNull    = (strtoupper((string)$c['Null']) === 'NO');
                $hasDefault = ($c['Default'] !== null);
                if ($notNull && !$hasDefault) {
                    $isNum = (bool)preg_match('/int|decimal|float|double|bit|year/i', $c['Type']);
                    $insCols[] = "`$name`"; $place[] = '?'; $insVals[] = $isNum ? 0 : '';
                }
            }

            try {
                $db->prepare("INSERT INTO users (" . implode(',', $insCols) . ") VALUES (" . implode(',', $place) . ")")
                   ->execute($insVals);
            } catch (PDOException $e) {
                if (stripos($e->getMessage(), 'Duplicate') !== false) err('用户名或手机号已存在');
                err('创建失败：' . $e->getMessage());
            }
            $newId = (int)$db->lastInsertId();
            error_log(sprintf("[%s][Admin] users.create id=%d username=%s phone=%s",
                date('Y-m-d H:i:s'), $newId, $username, $phone));
            ok(['id' => $newId, 'username' => $username], '用户创建成功');
        }

        case 'users.update': {
            $id = (int)p('id');
            if (!$id) err('缺少 id');

            $allowed = [
                'plan_type','plan_expired_at','billing_mode','balance',
                'base_weekly_tokens','bonus_weekly_tokens','weekly_used_tokens',
                'pro_pack_total','pro_pack_used',
                'count_pack_total','count_pack_used','count_pack_expired_at','count_pack_models',
                'invite_count','email',
                'title','title_color',
            ];
            // 数值字段:允许传 0(尤其 plan_expired_at=0 表示永久)
            $int_fields = [
                'plan_expired_at',
                'base_weekly_tokens','bonus_weekly_tokens','weekly_used_tokens',
                'pro_pack_total','pro_pack_used',
                'count_pack_total','count_pack_used','count_pack_expired_at',
                'invite_count',
            ];
            $float_fields = ['balance'];
            // 字符串字段:允许传 ''(email 清空,count_pack_models JSON 字符串)
            $str_fields = ['plan_type','billing_mode','email','count_pack_models','title','title_color'];

            $sets = []; $bind = [];
            foreach ($allowed as $k) {
                // 关键修复:只检测前端是否真的传了这个 key,而非用空值判断
                // 之前 if ($v !== null && $v !== '') 会过滤掉:
                //   - plan_expired_at='' 的"清空设为永久"语义
                //   - 任何用户主动清空的字段
                // 现在用 array_key_exists 精确判断"前端是否传了这个字段"
                if (!array_key_exists($k, $_POST) && !array_key_exists($k, $_GET)) {
                    continue;
                }
                $v = p($k);
                $sets[] = "`$k` = ?";
                if (in_array($k, $int_fields, true)) {
                    // 整数字段:空字符串视为 0(plan_expired_at='' → 0 = 永久)
                    $bind[] = ($v === '' || $v === null) ? 0 : (int)$v;
                } elseif (in_array($k, $float_fields, true)) {
                    $bind[] = ($v === '' || $v === null) ? 0.0 : (float)$v;
                } else {
                    // 字符串字段:trim 后原样保留(允许空串)
                    $bind[] = (string)($v ?? '');
                }
            }
            if (!$sets) err('没有要更新的字段');
            $bind[] = $id;
            $stmt = $db->prepare("UPDATE users SET " . implode(',', $sets) . " WHERE id=?");
            $stmt->execute($bind);
            $affected = $stmt->rowCount();
            error_log(sprintf("[%s][Admin] users.update id=%d sets=[%s] affected=%d",
                date('Y-m-d H:i:s'), $id,
                implode(',', array_keys(array_intersect_key($_POST, array_flip($allowed)))),
                $affected));

            // 写后立即重读一次,确保前端 loadUsers 能拿到最新值
            // 防御:某些 MySQL 实例隔离级别下,UPDATE 后立即 SELECT 偶尔拿到旧值
            $verify = $db->prepare("SELECT plan_type, plan_expired_at, billing_mode, balance,
                                          base_weekly_tokens, bonus_weekly_tokens, weekly_used_tokens,
                                          pro_pack_total, pro_pack_used, invite_count, email
                                    FROM users WHERE id=?");
            $verify->execute([$id]);
            $after = $verify->fetch();
            ok([
                'affected'    => $affected,
                'sets_count'  => count($sets),
                'after'       => $after,  // 当前 DB 值,供前端校验是否真改了
            ], '用户信息已更新');
            break;
        }

        // ── 设为 / 取消「人工客服」（2026-07 新增）─────────────────────────────
        //   is_support=1 时必须给一个合法邮箱（客服接收新工单通知的邮箱）；
        //   is_support=0 时清空 support_email。
        case 'users.set_support': {
            $id = (int)p('id');
            if (!$id) err('缺少 id');
            $is   = ((int)p('is_support', 0) === 1) ? 1 : 0;
            $mail = trim((string)p('support_email', ''));
            if ($is === 1) {
                if ($mail === '')                                err('请填写人工客服的邮箱');
                if (!filter_var($mail, FILTER_VALIDATE_EMAIL))   err('客服邮箱格式不正确');
                if (mb_strlen($mail) > 200)                       err('客服邮箱过长');
            } else {
                $mail = '';   // 取消客服身份时清空邮箱
            }
            try {
                $db->prepare("UPDATE users SET is_support = ?, support_email = ? WHERE id = ?")
                   ->execute([$is, $mail, $id]);
            } catch (PDOException $e) {
                // 老库还没跑迁移（无 is_support / support_email 列）
                err('数据库缺少客服字段，请先执行 migration_support_tickets.sql');
            }
            error_log(sprintf("[%s][Admin] users.set_support id=%d is_support=%d email=%s",
                date('Y-m-d H:i:s'), $id, $is, $mail));
            ok(['is_support'=>$is, 'support_email'=>$mail],
               $is ? '已设为人工客服' : '已取消人工客服');
        }

        case 'users.reset_password': {
            $id = (int)p('id');
            $new = (string)p('new_password', '');
            if (!$id || strlen($new) < 6) err('参数错误，密码至少 6 位');
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $db->prepare("UPDATE users SET password=? WHERE id=?")->execute([$hash, $id]);
            error_log("[Admin] reset password id=$id");
            ok(null, '密码已重置');
        }

        case 'users.delete': {
            $id = (int)p('id');
            if (!$id) err('缺少 id');
            if ($id == $user['id']) err('不能删除当前 admin 用户');
            // 删用户级联：instances / personas / orders（保留订单方便审计）
            $db->beginTransaction();
            try {
                $db->prepare("DELETE FROM instances WHERE user_id=?")->execute([$id]);
                $db->prepare("DELETE FROM user_personas WHERE user_id=?")->execute([$id]);
                $db->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
                $db->commit();
            } catch (Exception $e) {
                $db->rollBack();
                err('删除失败：' . $e->getMessage(), 500);
            }
            error_log("[Admin] user.delete id=$id");
            ok(null, '用户已删除（订单记录保留）');
        }

        // ── 用户封禁 / 解封（2026 新增） ─────────────────────────────────────
        // 封禁后:该用户名下所有微信实例收到消息时,main.py 不再调大模型,直接用
        //         封禁原因回复;该用户登录 console.php 只能看到红色封禁提示页。
        // banned_until: 0 = 永久;>0 = 绝对 UNIX 秒,到期自动解封(读时判定)。
        case 'users.ban': {
            ban_ensure_table($db);
            $id     = (int)p('id');
            $reason = trim((string)p('reason', ''));
            // until: 前端按「时长预设 / 自定义到期」算好的绝对 UNIX 秒;0 表示永久
            $until  = (int)p('until', 0);
            if (!$id) err('缺少 id');

            $chk = $db->prepare("SELECT id, username FROM users WHERE id=?");
            $chk->execute([$id]);
            $target = $chk->fetch();
            if (!$target) err('用户不存在');
            if ($id == ($user['id'] ?? 0)) err('不能封禁当前登录的 admin 账号');
            if ($reason === '') err('请填写封禁原因（将展示给被封禁用户）');
            if (mb_strlen($reason) > 500) $reason = mb_substr($reason, 0, 500);

            $now = time();
            if ($until < 0) err('封禁时长参数非法');
            if ($until !== 0 && $until <= $now) err('解封时间必须晚于当前时间');

            $by = (string)($user['username'] ?? 'admin');
            // upsert:显式重复传值,避开 MySQL 8.0.20+ 已弃用的 VALUES() 写法
            $stmt = $db->prepare(
                "INSERT INTO user_bans
                    (user_id, is_banned, reason, banned_until, banned_at, banned_by, updated_at)
                 VALUES (?, 1, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                    is_banned=1, reason=?, banned_until=?, banned_at=?, banned_by=?, updated_at=?"
            );
            $stmt->execute([
                $id, $reason, $until, $now, $by, $now,
                $reason, $until, $now, $by, $now,
            ]);
            error_log(sprintf("[%s][Admin] users.ban id=%d until=%d by=%s",
                date('Y-m-d H:i:s'), $id, $until, $by));
            ok([
                'user_id'      => $id,
                'is_banned'    => 1,
                'reason'       => $reason,
                'banned_until' => $until,
                'banned_at'    => $now,
                'banned_by'    => $by,
            ], $until === 0 ? '用户已永久封禁' : '用户已封禁');
        }

        case 'users.unban': {
            ban_ensure_table($db);
            $id = (int)p('id');
            if (!$id) err('缺少 id');
            // 保留封禁记录(审计),仅把 is_banned 置 0 → 立即解封
            $db->prepare("UPDATE user_bans SET is_banned=0, updated_at=? WHERE user_id=?")
               ->execute([time(), $id]);
            error_log("[Admin] users.unban id=$id");
            ok(['user_id'=>$id, 'is_banned'=>0], '已解除封禁');
        }

        // ── 手机号黑名单 (2026-07-07 新增) ────────────────────────────────
        // 已注销用户手机号加入黑名单后,注册时(发验证码前)即被拦截,
        // 提示「已注销用户不得再次注册」。校验逻辑见 login.php。
        case 'phone_blacklist.list': {
            phone_blacklist_ensure_table($db);
            $kw = trim((string)p('keyword', ''));
            if ($kw !== '') {
                $s = $db->prepare(
                    "SELECT id, phone, reason, created_by, created_at
                     FROM phone_blacklist
                     WHERE phone LIKE ? OR reason LIKE ?
                     ORDER BY id DESC LIMIT 500"
                );
                $like = '%' . $kw . '%';
                $s->execute([$like, $like]);
                ok($s->fetchAll());
            }
            $rows = $db->query(
                "SELECT id, phone, reason, created_by, created_at
                 FROM phone_blacklist ORDER BY id DESC LIMIT 500"
            )->fetchAll();
            ok($rows);
        }

        case 'phone_blacklist.add': {
            phone_blacklist_ensure_table($db);
            // 支持批量:phones 传多行文本,每行一个手机号;reason 共用
            $raw    = (string)p('phones', '');
            $reason = trim((string)p('reason', ''));
            if (mb_strlen($reason) > 200) $reason = mb_substr($reason, 0, 200);

            $lines = preg_split('/[\s,;，；]+/u', $raw, -1, PREG_SPLIT_NO_EMPTY);
            if (!$lines) err('请输入手机号');

            $valid = [];
            $bad   = [];
            foreach ($lines as $ln) {
                $ph = trim($ln);
                if (preg_match('/^1[3-9]\d{9}$/', $ph)) {
                    $valid[$ph] = true;   // 去重
                } else {
                    $bad[] = $ph;
                }
            }
            if ($bad)  err('以下不是有效的 11 位手机号: ' . implode('、', array_slice($bad, 0, 5)) . (count($bad) > 5 ? ' 等' : ''));
            if (!$valid) err('请输入手机号');
            if (count($valid) > 200) err('单次最多添加 200 个手机号');

            $by  = (string)($user['username'] ?? 'admin');
            $now = time();
            $ins = $db->prepare(
                "INSERT IGNORE INTO phone_blacklist (phone, reason, created_by, created_at)
                 VALUES (?, ?, ?, ?)"
            );
            $added = 0; $skipped = 0;
            foreach (array_keys($valid) as $ph) {
                $ins->execute([$ph, $reason, $by, $now]);
                $ins->rowCount() > 0 ? $added++ : $skipped++;
            }
            error_log(sprintf("[Admin] phone_blacklist.add by=%s added=%d skipped=%d", $by, $added, $skipped));
            $msg = "已添加 {$added} 个";
            if ($skipped > 0) $msg .= ",{$skipped} 个已存在(跳过)";
            ok(['added' => $added, 'skipped' => $skipped], $msg);
        }

        case 'phone_blacklist.delete': {
            phone_blacklist_ensure_table($db);
            $id = (int)p('id', 0);
            if (!$id) err('缺少 id');
            $s = $db->prepare("SELECT phone FROM phone_blacklist WHERE id=?");
            $s->execute([$id]);
            $row = $s->fetch();
            if (!$row) err('记录不存在');
            $db->prepare("DELETE FROM phone_blacklist WHERE id=?")->execute([$id]);
            error_log("[Admin] phone_blacklist.delete id=$id phone=" . $row['phone']);
            ok(null, '已移出黑名单');
        }

        // ── 用户次数包·多桶管理（v19 · 2026-05-26 新增） ─────────────────────
        // notify.php 自 v?? 起,次数包改为「每买一包 = user_count_packs 一行」的
        // 多桶模型(物理隔离、永不互串)。但 admin 用户编辑一直只操作老的
        // users.count_pack_* 共享单桶字段,看不到也改不了这些独立包。
        // 这一组 action 把多桶接进后台:列出 / 新增 / 编辑 / 删除任意包。
        //
        // 表结构(与 notify.php 的 CREATE TABLE IF NOT EXISTS 完全一致):
        //   id user_id pack_name source_price counts_total counts_used
        //   models(JSON字符串) expired_at(秒级时间戳,0=永久) is_active created_at
        //
        // 设计要点:
        //   - 与老单桶字段并存,互不干扰。老字段仍可在弹窗上半区编辑。
        //   - models 存 JSON 字符串数组;空数组 [] = 不限模型。
        //   - counts_used 不允许超过 counts_total(后端兜底 clamp)。
        //   - 老库未跑迁移时,list 容错返回空数组,save 时按 notify.php 同款建表。
        case 'user_count_packs.list': {
            $uid = (int)p('user_id', 0);
            if (!$uid) err('缺少 user_id');
            try {
                $st = $db->prepare(
                    "SELECT id, user_id, pack_name, source_price, counts_total, counts_used, "
                    . "       models, expired_at, is_active, created_at "
                    . "FROM user_count_packs WHERE user_id=? ORDER BY id DESC"
                );
                $st->execute([$uid]);
                $rows = $st->fetchAll();
            } catch (PDOException $e) {
                // 表不存在(老库未跑迁移)→ 返回空,前端显示「暂无独立次数包」
                if (stripos($e->getMessage(), 'user_count_packs') !== false ||
                    stripos($e->getMessage(), "doesn't exist") !== false) {
                    $rows = [];
                } else {
                    throw $e;
                }
            }
            ok(['rows' => $rows]);
        }

        case 'user_count_packs.save': {
            // 新增(无 pack_id)或编辑(有 pack_id)一个独立次数包。
            $uid     = (int)p('user_id', 0);
            $pack_id = (int)p('pack_id', 0);   // 0 = 新增
            if (!$uid) err('缺少 user_id');

            // 确认用户存在(避免给不存在的 user_id 挂包)
            $uchk = $db->prepare("SELECT id FROM users WHERE id=?");
            $uchk->execute([$uid]);
            if (!$uchk->fetchColumn()) err('用户不存在');

            $pack_name    = trim((string)p('pack_name', ''));
            $source_price = (float)p('source_price', 0);
            $counts_total = max(0, (int)p('counts_total', 0));
            $counts_used  = max(0, (int)p('counts_used', 0));
            if ($counts_used > $counts_total) $counts_used = $counts_total; // clamp
            $is_active    = ((int)p('is_active', 1)) ? 1 : 0;

            // expired_at:前端传秒级时间戳;0/空 = 永久
            $expired_at   = (int)p('expired_at', 0);

            // models:前端传 JSON 字符串;校验必须是数组,空串归一成 []
            $models_raw = trim((string)p('models', ''));
            if ($models_raw === '') {
                $models_json = '[]';
            } else {
                $decoded = json_decode($models_raw, true);
                if (!is_array($decoded)) err('「允许的模型」必须是 JSON 数组,例如 ["m1","m2"]');
                $models_json = json_encode(array_values($decoded), JSON_UNESCAPED_UNICODE);
            }

            if ($pack_name === '') {
                // 没填名字就按模型/价格自动生成,跟 notify.php 同款命名
                $marr = json_decode($models_json, true);
                $pack_name = (is_array($marr) && $marr)
                    ? (implode('/', $marr) . ' 次数包')
                    : ('次数包 ¥' . number_format($source_price, 2, '.', ''));
            }

            // 幂等建表(与 notify.php 完全一致,老库未迁移时自愈)
            try {
                $db->exec(
                    "CREATE TABLE IF NOT EXISTS `user_count_packs` (
                      `id`           INT AUTO_INCREMENT PRIMARY KEY,
                      `user_id`      INT NOT NULL,
                      `pack_name`    VARCHAR(64) DEFAULT NULL,
                      `source_price` DECIMAL(10,2) DEFAULT NULL,
                      `counts_total` INT NOT NULL DEFAULT 0,
                      `counts_used`  INT NOT NULL DEFAULT 0,
                      `models`       TEXT DEFAULT NULL,
                      `expired_at`   INT NOT NULL DEFAULT 0,
                      `is_active`    TINYINT NOT NULL DEFAULT 1,
                      `created_at`   INT NOT NULL DEFAULT 0,
                      KEY `idx_user` (`user_id`),
                      KEY `idx_user_expire` (`user_id`,`expired_at`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
                );
            } catch (Exception $ce) {
                error_log('[admin] 建 user_count_packs 表失败: ' . $ce->getMessage());
            }

            if ($pack_id > 0) {
                // 编辑:确认这包属于该用户,防越权改别人的包
                $own = $db->prepare("SELECT id FROM user_count_packs WHERE id=? AND user_id=?");
                $own->execute([$pack_id, $uid]);
                if (!$own->fetchColumn()) err('次数包不存在或不属于该用户');

                $db->prepare(
                    "UPDATE user_count_packs SET "
                    . "pack_name=?, source_price=?, counts_total=?, counts_used=?, "
                    . "models=?, expired_at=?, is_active=? "
                    . "WHERE id=? AND user_id=?"
                )->execute([
                    $pack_name, $source_price, $counts_total, $counts_used,
                    $models_json, $expired_at, $is_active, $pack_id, $uid
                ]);
                error_log(sprintf("[%s][Admin] user_count_packs.save EDIT pack=%d user=%d total=%d used=%d",
                    date('Y-m-d H:i:s'), $pack_id, $uid, $counts_total, $counts_used));
                ok(['pack_id' => $pack_id], '次数包已更新');
            } else {
                // 新增
                $db->prepare(
                    "INSERT INTO user_count_packs "
                    . "(user_id, pack_name, source_price, counts_total, counts_used, "
                    . " models, expired_at, is_active, created_at) "
                    . "VALUES (?,?,?,?,?,?,?,?,?)"
                )->execute([
                    $uid, $pack_name, $source_price, $counts_total, $counts_used,
                    $models_json, $expired_at, $is_active, time()
                ]);
                $new_id = (int)$db->lastInsertId();
                error_log(sprintf("[%s][Admin] user_count_packs.save NEW pack=%d user=%d total=%d",
                    date('Y-m-d H:i:s'), $new_id, $uid, $counts_total));
                ok(['pack_id' => $new_id], '次数包已新增');
            }
        }

        case 'user_count_packs.delete': {
            $uid     = (int)p('user_id', 0);
            $pack_id = (int)p('pack_id', 0);
            if (!$uid || !$pack_id) err('缺少 user_id 或 pack_id');
            // 带 user_id 条件,防越权删别人的包
            $st = $db->prepare("DELETE FROM user_count_packs WHERE id=? AND user_id=?");
            $st->execute([$pack_id, $uid]);
            if ($st->rowCount() === 0) err('次数包不存在或不属于该用户');
            error_log(sprintf("[%s][Admin] user_count_packs.delete pack=%d user=%d",
                date('Y-m-d H:i:s'), $pack_id, $uid));
            ok(null, '次数包已删除');
        }

        // ── 用户临时日志(2026-05-07 新增) ──────────────────────────────
        // 拉取指定用户所有实例的 temp_log,管理员排查用
        case 'users.logs': {
            $uid = (int)p('id', 0);
            if (!$uid) err('缺少 id');

            // 先确认用户存在(顺便取用户名,弹窗标题用)
            $uStmt = $db->prepare("SELECT id, username, email FROM users WHERE id = ?");
            $uStmt->execute([$uid]);
            $user = $uStmt->fetch();
            if (!$user) err('用户不存在', 404);

            // 拉这个用户所有实例 + 临时日志
            $iStmt = $db->prepare(
                "SELECT i.id, i.instance_id, i.model, i.status, i.last_heartbeat,
                        i.ai_message_count, i.user_message_count, i.temp_log,
                        p.name AS persona_name
                 FROM instances i
                 LEFT JOIN user_personas p ON i.persona_id = p.id
                 WHERE i.user_id = ?
                 ORDER BY i.id DESC"
            );
            $iStmt->execute([$uid]);
            $instances = $iStmt->fetchAll();

            // log 字段可能很大,这里直接全量返回(后端已有 200 行截断 by _append_log)
            ok([
                'user'      => $user,
                'instances' => $instances,
            ]);
        }

        // ── 实例管理 ──────────────────────────────────────────────────────
        case 'instances.list': {
            $kw = trim((string)p('keyword', ''));
            $page = max(1, (int)p('page', 1));
            $size = 20;
            $offset = ($page - 1) * $size;

            $where = []; $bind = [];
            if ($kw !== '') {
                $where[] = "(i.instance_id LIKE ? OR u.username LIKE ? OR i.model LIKE ?)";
                $bind[] = "%{$kw}%"; $bind[] = "%{$kw}%"; $bind[] = "%{$kw}%";
            }
            $w = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

            $cstmt = $db->prepare("SELECT COUNT(*) FROM instances i LEFT JOIN users u ON i.user_id=u.id $w");
            $cstmt->execute($bind);
            $total = (int)$cstmt->fetchColumn();

            $sql = "SELECT i.id, i.instance_id, i.user_id, u.username, i.model,
                           i.persona_id, p.name AS persona_name,
                           i.status, i.ai_message_count, i.user_message_count,
                           i.last_heartbeat, i.created_at,
                           i.temperature, i.presence_penalty, i.frequency_penalty
                    FROM instances i
                    LEFT JOIN users u ON i.user_id = u.id
                    LEFT JOIN user_personas p ON i.persona_id = p.id
                    $w
                    ORDER BY i.id DESC
                    LIMIT $size OFFSET $offset";
            $stmt = $db->prepare($sql);
            $stmt->execute($bind);
            $rows = $stmt->fetchAll();
            ok(['total'=>$total,'page'=>$page,'size'=>$size,'rows'=>$rows]);
        }

        case 'instances.force_stop': {
            $id = (int)p('id');
            if (!$id) err('缺少 id');
            $db->prepare("UPDATE instances SET status='停止' WHERE id=?")->execute([$id]);
            ok(null, '实例已强制停止');
        }

        case 'instances.delete': {
            $id = (int)p('id');
            if (!$id) err('缺少 id');
            $db->prepare("DELETE FROM instances WHERE id=?")->execute([$id]);
            ok(null, '实例已删除');
        }

        // ── 语音通话 (语音会员/音色管理) ───────────────────────────────
        case 'voice_call.list': {
            $now = time(); $memberCount = 0; $voiceCount = 0; $rows = [];
            try {
                $memberCount = (int)$db->query("SELECT COUNT(*) FROM voice_members WHERE voice_expired_at > " . $now)->fetchColumn();
                $voiceCount  = (int)$db->query("SELECT COUNT(*) FROM voice_members WHERE voice_id <> ''")->fetchColumn();
                $st = $db->query(
                    "SELECT vm.user_id, u.username, vm.voice_id, vm.voice_name, vm.voice_expired_at, vm.wechat_enabled
                     FROM voice_members vm LEFT JOIN users u ON u.id = vm.user_id
                     ORDER BY vm.updated_at DESC LIMIT 500"
                );
                $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
            } catch (Throwable $e) { /* 表不存在 → 空 */ }
            ok(['member_count' => $memberCount, 'voice_count' => $voiceCount, 'now' => $now, 'list' => $rows]);
        }

        case 'voice_call.delete_voice': {
            $target = (int)p('user_id');
            if (!$target) err('缺少 user_id');
            // 取该用户音色 id → 删阿里云(释放配额) → 清库
            $vid = '';
            try {
                $q = $db->prepare("SELECT voice_id FROM voice_members WHERE user_id=? LIMIT 1");
                $q->execute([$target]);
                $vid = trim((string)($q->fetchColumn() ?: ''));
            } catch (Throwable $e) {}
            if ($vid !== '') {
                $ch = curl_init('https://dashscope.aliyuncs.com/api/v1/services/audio/tts/customization');
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS     => json_encode(['model' => 'voice-enrollment', 'input' => ['action' => 'delete_voice', 'voice_id' => $vid]]),
                    CURLOPT_HTTPHEADER     => ['Authorization: Bearer sk-REMOVED-ROTATE-THIS-KEY', 'Content-Type: application/json'],
                    CURLOPT_TIMEOUT        => 30, CURLOPT_SSL_VERIFYPEER => true,
                ]);
                curl_exec($ch);
                $dhttp = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                if ($dhttp !== 200) error_log('[admin voice_call] dashscope delete HTTP ' . $dhttp . ' voice=' . $vid);
            }
            try {
                $db->prepare("UPDATE voice_members SET voice_id='', voice_name='', sample_url='', wechat_enabled=0, updated_at=? WHERE user_id=?")
                   ->execute([time(), $target]);
            } catch (Throwable $e) { err('清库失败: ' . $e->getMessage(), 500); }
            ok(null, '已删除该用户音色(阿里云+数据库)，用户需重新克隆');
        }

        // 拉取阿里云账号下【全部】音色 ID (分页), 标注库内归属
        case 'voice_call.list_dashscope': {
            $all = []; $pi = 0; $ps = 50; $guard = 0;
            while ($guard++ < 60) {   // 60 页 * 50 = 3000, 覆盖 1000 配额上限
                $page = _vc_ds_list($pi, $ps);
                if (!$page) break;
                $all = array_merge($all, $page);
                if (count($page) < $ps) break;
                $pi++;
            }
            $inUse = [];
            try {
                $st = $db->query("SELECT voice_id, user_id FROM voice_members WHERE voice_id <> ''");
                foreach ($st as $r) { $inUse[(string)$r['voice_id']] = (int)$r['user_id']; }
            } catch (Throwable $e) {}
            ok(['total' => count($all), 'list' => $all, 'in_use' => $inUse]);
        }

        // 删除单个阿里云音色 (顺带清库)
        case 'voice_call.delete_dashscope': {
            $vid = trim((string)p('voice_id'));
            if ($vid === '') err('缺少 voice_id');
            $okDel = _vc_ds_delete($vid);
            try { $db->prepare("UPDATE voice_members SET voice_id='', voice_name='', wechat_enabled=0, updated_at=? WHERE voice_id=?")->execute([time(), $vid]); } catch (Throwable $e) {}
            ok(['deleted' => $okDel], $okDel ? '已删除' : '删除失败(见日志)');
        }

        // 批量删除: 每次删一批(前 N 个), 前端循环调用直到 batch=0
        case 'voice_call.purge_dashscope': {
            $ps = 30;
            $page = _vc_ds_list(0, $ps);
            $deleted = 0; $failed = 0; $vids = [];
            foreach ($page as $v) {
                if (_vc_ds_delete($v['voice_id'])) { $deleted++; $vids[] = $v['voice_id']; }
                else { $failed++; }
            }
            if ($vids) {
                try {
                    $ph = implode(',', array_fill(0, count($vids), '?'));
                    $db->prepare("UPDATE voice_members SET voice_id='', voice_name='', wechat_enabled=0, updated_at=" . time() . " WHERE voice_id IN ($ph)")->execute($vids);
                } catch (Throwable $e) {}
            }
            ok(['batch' => count($page), 'deleted' => $deleted, 'failed' => $failed]);
        }

        // ── 音色广场 (精选可导入音色) ──
        case 'square.list': {
            try { $db->exec("CREATE TABLE IF NOT EXISTS `voice_square` (`id` INT AUTO_INCREMENT PRIMARY KEY, `name` VARCHAR(64) NOT NULL DEFAULT '', `voice_id` VARCHAR(160) NOT NULL DEFAULT '', `note` VARCHAR(255) NOT NULL DEFAULT '', `created_at` INT NOT NULL DEFAULT 0, KEY `idx_voice`(`voice_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch (Throwable $e) {}
            $rows = [];
            try { $rows = $db->query("SELECT id, name, voice_id, note, created_at FROM `voice_square` ORDER BY id DESC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC) ?: []; } catch (Throwable $e) {}
            ok(['list' => $rows]);
        }
        case 'square.add': {
            try { $db->exec("CREATE TABLE IF NOT EXISTS `voice_square` (`id` INT AUTO_INCREMENT PRIMARY KEY, `name` VARCHAR(64) NOT NULL DEFAULT '', `voice_id` VARCHAR(160) NOT NULL DEFAULT '', `note` VARCHAR(255) NOT NULL DEFAULT '', `created_at` INT NOT NULL DEFAULT 0, KEY `idx_voice`(`voice_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); } catch (Throwable $e) {}
            $name = trim((string)p('name'));
            $vid  = trim((string)p('voice_id'));
            $note = trim((string)p('note'));
            if ($name === '' || $vid === '') err('名称和音色 ID 不能为空');
            if (mb_strlen($name) > 64) $name = mb_substr($name, 0, 64);
            try {
                $db->prepare("INSERT INTO `voice_square` (name, voice_id, note, created_at) VALUES (?, ?, ?, ?)")->execute([$name, $vid, $note, time()]);
            } catch (Throwable $e) { err('添加失败: ' . $e->getMessage(), 500); }
            ok(null, '已添加到音色广场');
        }
        case 'square.delete': {
            $id = (int)p('id');
            if (!$id) err('缺少 id');
            try { $db->prepare("DELETE FROM `voice_square` WHERE id=?")->execute([$id]); } catch (Throwable $e) { err('删除失败: ' . $e->getMessage(), 500); }
            ok(null, '已删除');
        }

        // ── 订单查询（只读） ──────────────────────────────────────────────
        case 'orders.list': {
            $kw = trim((string)p('keyword', ''));
            $status = (string)p('status', '');
            $type = (string)p('type', '');
            $page = max(1, (int)p('page', 1));
            $size = 20;
            $offset = ($page - 1) * $size;

            $where = []; $bind = [];
            if ($kw !== '') { $where[] = "(out_trade_no LIKE ? OR username LIKE ?)"; $bind[]="%$kw%"; $bind[]="%$kw%"; }
            if ($status !== '') { $where[] = "status = ?"; $bind[] = $status; }
            if ($type !== '')   { $where[] = "type = ?";   $bind[] = $type; }
            $w = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

            $cstmt = $db->prepare("SELECT COUNT(*) FROM payment_orders $w");
            $cstmt->execute($bind);
            $total = (int)$cstmt->fetchColumn();

            $sql = "SELECT * FROM payment_orders $w ORDER BY id DESC LIMIT $size OFFSET $offset";
            $stmt = $db->prepare($sql);
            $stmt->execute($bind);
            $rows = $stmt->fetchAll();
            ok(['total'=>$total,'page'=>$page,'size'=>$size,'rows'=>$rows]);
        }

        // ── 支付回调掉单监控（2026-07 新增） ────────────────────────────────
        // notify_log 每条 = 易支付一次回调。掉单 = 已收款(验签通过的
        // TRADE_SUCCESS)却从未成功发货、且管理员未标记处理的订单。
        case 'notify_log.anomalies': {
            notifylog_ensure_table($db);
            $g = [];
            try {
                $g = $db->query(
                    "SELECT out_trade_no,
                            COUNT(*)          AS callbacks,
                            MAX(attempt_no)   AS attempts,
                            MAX(created_at)   AS last_ts,
                            MAX(id)           AS last_id
                       FROM notify_log
                      WHERE handled = 0
                      GROUP BY out_trade_no
                     HAVING SUM(result='success') = 0
                        AND SUM(result='fail' AND sign_ok=1) > 0
                      ORDER BY last_ts DESC
                      LIMIT 100"
                )->fetchAll();
            } catch (Exception $e) { $g = []; }

            $rows = [];
            foreach ($g as $row) {
                $det = [];
                try {
                    $d = $db->prepare(
                        "SELECT trade_no, reason, stage, username, order_type, amount, raw
                           FROM notify_log WHERE id = ?"
                    );
                    $d->execute([(int)$row['last_id']]);
                    $det = $d->fetch() ?: [];
                } catch (Exception $e) {}

                $os = '';
                try {
                    $o = $db->prepare("SELECT status FROM payment_orders WHERE out_trade_no = ? LIMIT 1");
                    $o->execute([$row['out_trade_no']]);
                    $os = (string)($o->fetchColumn() ?: '');
                } catch (Exception $e) {}

                $rows[] = [
                    'out_trade_no' => $row['out_trade_no'],
                    'callbacks'    => (int)$row['callbacks'],
                    'attempts'     => (int)$row['attempts'],
                    'last_ts'      => (int)$row['last_ts'],
                    'last_reason'  => (string)($det['reason'] ?? ''),
                    'stage'        => (string)($det['stage'] ?? ''),
                    'username'     => (string)($det['username'] ?? ''),
                    'order_type'   => (string)($det['order_type'] ?? ''),
                    'amount'       => (string)($det['amount'] ?? ''),
                    'order_status' => $os,
                    'raw'          => (string)($det['raw'] ?? ''),
                ];
            }
            ok(['count' => count($rows), 'rows' => $rows]);
        }

        // 全部回调流水浏览(success/fail/duplicate),用于查"某单被回调了几次"。
        case 'notify_log.recent': {
            notifylog_ensure_table($db);
            $filter = (string)p('filter', 'all');
            $kw     = trim((string)p('keyword', ''));
            $page   = max(1, (int)p('page', 1));
            $size   = (int)p('size', 10);
            if ($size < 1)   $size = 10;
            if ($size > 100) $size = 100;
            $offset = ($page - 1) * $size;

            $where = []; $bind = [];
            if ($filter === 'fail')        { $where[] = "result='fail'"; }
            elseif ($filter === 'success') { $where[] = "result='success'"; }
            elseif ($filter === 'duplicate'){ $where[] = "result='duplicate'"; }
            if ($kw !== '') { $where[] = "(out_trade_no LIKE ? OR username LIKE ?)"; $bind[]="%$kw%"; $bind[]="%$kw%"; }
            $w = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

            $total = 0; $rows = [];
            try {
                $c = $db->prepare("SELECT COUNT(*) FROM notify_log $w");
                $c->execute($bind);
                $total = (int)$c->fetchColumn();

                $st = $db->prepare(
                    "SELECT id, out_trade_no, trade_no, attempt_no, sign_ok, trade_status,
                            result, stage, reason, username, order_type, amount, raw, ip, handled, created_at
                       FROM notify_log $w ORDER BY id DESC LIMIT $size OFFSET $offset"
                );
                $st->execute($bind);
                $rows = $st->fetchAll();
            } catch (Exception $e) {}
            ok(['rows' => $rows, 'total' => $total, 'page' => $page, 'size' => $size]);
        }

        // 标记某订单的回调记录为「已处理」→ 该单从告警中移除。
        case 'notify_log.resolve': {
            notifylog_ensure_table($db);
            $oid = trim((string)p('out_trade_no', ''));
            if ($oid === '') err('缺少 out_trade_no');
            $st = $db->prepare("UPDATE notify_log SET handled=1, handled_at=? WHERE out_trade_no=? AND handled=0");
            $st->execute([time(), $oid]);
            ok(['updated' => $st->rowCount()]);
        }

        // 一键把当前所有未处理异常标记为已处理(停止循环告警)。
        case 'notify_log.resolve_all': {
            notifylog_ensure_table($db);
            $st = $db->prepare("UPDATE notify_log SET handled=1, handled_at=? WHERE handled=0 AND result <> 'success'");
            $st->execute([time()]);
            ok(['updated' => $st->rowCount()]);
        }

        // ── 用户统计（只读 · 2026-06-16 新增） ──────────────────────────────
        // 纯查询 / 排序 / 聚合，绝不写库（仅 SELECT + SHOW COLUMNS）。用途：
        //   ① 找出充值最高 / 邀请最高 / 余额最高的用户；
        //   ② 看清「订阅包(users.pro_pack_*)」与「次数包(user_count_packs 多桶)」
        //      的存量与到期分布，便于在大量包临近过期时决定是否退出优惠活动。
        //
        // 口径（与 dashboard stats / orders.list 完全一致，见 pay.php 注释）：
        //   · 实收营收：orig_amount 非空(pro/次数单) → ROUND(orig_amount*0.90,2)；
        //     否则(balance 单) → amount。orig_amount 列不存在时整体回退 SUM(amount)。
        //   · 订单与用户经 username 关联（payment_orders 无 user_id 列）。
        //   · 次数包「可用」= is_active=1 且 counts_used<counts_total 且
        //     (expired_at=0 永久 或 expired_at>now)。
        //   · 订阅包「可用」= pro_pack_total>0 且 (plan_expired_at=0 或 >now)。
        // 三个子接口：summary（聚合卡+到期分布）/ rank（排行榜）/ expiring（到期明细）。
        case 'user_stats.summary': {
            $now = time();
            $D   = 86400;

            // orig_amount 列探测 → 实收表达式（payment_orders 上下文，裸列名）
            $hasOrig = false;
            try { $hasOrig = (bool)$db->query("SHOW COLUMNS FROM payment_orders LIKE 'orig_amount'")->fetch(); } catch (Exception $e) {}
            $rev = $hasOrig
                ? "COALESCE(SUM(CASE WHEN orig_amount IS NOT NULL THEN ROUND(orig_amount*0.90,2) ELSE amount END),0)"
                : "COALESCE(SUM(amount),0)";

            $out = [];
            // —— 用户 / 余额 / 充值 ——
            $out['user_total']   = (int)$db->query("SELECT COUNT(*) FROM users")->fetchColumn();
            $out['user_pro']     = (int)$db->query("SELECT COUNT(*) FROM users WHERE plan_type='pro'")->fetchColumn();
            $out['balance_sum']  = (float)$db->query("SELECT COALESCE(SUM(balance),0) FROM users")->fetchColumn();
            $out['paying_users'] = (int)$db->query("SELECT COUNT(DISTINCT username) FROM payment_orders WHERE status='success'")->fetchColumn();
            $out['revenue_all']  = (float)$db->query("SELECT $rev FROM payment_orders WHERE status='success'")->fetchColumn();
            $monthStart = strtotime(date('Y-m-01 00:00:00'));
            $st = $db->prepare("SELECT $rev FROM payment_orders WHERE status='success' AND created_at >= ?");
            $st->execute([$monthStart]);
            $out['revenue_month'] = (float)$st->fetchColumn();

            // —— 订阅包(pro_pack, users 列) ——
            $pro = [];
            $pro['active_users']     = (int)$db->query("SELECT COUNT(*) FROM users WHERE pro_pack_total>0 AND (plan_expired_at=0 OR plan_expired_at>$now)")->fetchColumn();
            $pro['remaining_tokens'] = (float)$db->query("SELECT COALESCE(SUM(GREATEST(CAST(pro_pack_total AS SIGNED)-CAST(pro_pack_used AS SIGNED),0)),0) FROM users WHERE pro_pack_total>0 AND (plan_expired_at=0 OR plan_expired_at>$now)")->fetchColumn();
            $pro['permanent']        = (int)$db->query("SELECT COUNT(*) FROM users WHERE pro_pack_total>0 AND plan_expired_at=0")->fetchColumn();
            foreach ([['exp_1d',1],['exp_7d',7],['exp_30d',30]] as $w) {
                $lim = $now + $w[1]*$D;
                $pro[$w[0]] = (int)$db->query("SELECT COUNT(*) FROM users WHERE pro_pack_total>0 AND plan_expired_at>$now AND plan_expired_at<=$lim")->fetchColumn();
            }
            $pro['expired_with_remain'] = (int)$db->query("SELECT COUNT(*) FROM users WHERE pro_pack_total>pro_pack_used AND plan_expired_at>0 AND plan_expired_at<=$now")->fetchColumn();
            $out['pro'] = $pro;

            // —— 次数包(user_count_packs 多桶) ——
            $cp = ['table_missing' => false];
            try {
                $usable = "is_active=1 AND counts_total>counts_used AND (expired_at=0 OR expired_at>$now)";
                $cp['active_packs']     = (int)$db->query("SELECT COUNT(*) FROM user_count_packs WHERE $usable")->fetchColumn();
                $cp['active_users']     = (int)$db->query("SELECT COUNT(DISTINCT user_id) FROM user_count_packs WHERE $usable")->fetchColumn();
                $cp['remaining_counts'] = (int)$db->query("SELECT COALESCE(SUM(counts_total-counts_used),0) FROM user_count_packs WHERE $usable")->fetchColumn();
                $cp['permanent_packs']  = (int)$db->query("SELECT COUNT(*) FROM user_count_packs WHERE is_active=1 AND counts_total>counts_used AND expired_at=0")->fetchColumn();
                foreach ([['exp_1d',1],['exp_7d',7],['exp_30d',30]] as $w) {
                    $lim  = $now + $w[1]*$D;
                    $cond = "is_active=1 AND counts_total>counts_used AND expired_at>$now AND expired_at<=$lim";
                    $cp[$w[0].'_packs']  = (int)$db->query("SELECT COUNT(*) FROM user_count_packs WHERE $cond")->fetchColumn();
                    $cp[$w[0].'_counts'] = (int)$db->query("SELECT COALESCE(SUM(counts_total-counts_used),0) FROM user_count_packs WHERE $cond")->fetchColumn();
                }
                $expCond = "is_active=1 AND counts_total>counts_used AND expired_at>0 AND expired_at<=$now";
                $cp['expired_packs']  = (int)$db->query("SELECT COUNT(*) FROM user_count_packs WHERE $expCond")->fetchColumn();
                $cp['expired_counts'] = (int)$db->query("SELECT COALESCE(SUM(counts_total-counts_used),0) FROM user_count_packs WHERE $expCond")->fetchColumn();
            } catch (PDOException $e) {
                if (stripos($e->getMessage(),'user_count_packs')!==false || stripos($e->getMessage(),"doesn't exist")!==false) {
                    $cp['table_missing'] = true;
                } else { throw $e; }
            }
            $out['count_pack'] = $cp;

            ok($out);
        }

        case 'user_stats.rank': {
            // 排行榜（只读，分页）。metric 白名单决定排序维度，绝不把 metric 拼进 SQL。
            $metric = (string)p('metric', 'recharge');
            $page   = max(1, (int)p('page', 1));
            $size   = 20;
            $offset = ($page-1)*$size;
            $now    = time();

            $rows = []; $total = 0;

            if ($metric === 'recharge') {
                $hasOrig = false;
                try { $hasOrig = (bool)$db->query("SHOW COLUMNS FROM payment_orders LIKE 'orig_amount'")->fetch(); } catch (Exception $e) {}
                $rev = $hasOrig
                    ? "COALESCE(SUM(CASE WHEN po.orig_amount IS NOT NULL THEN ROUND(po.orig_amount*0.90,2) ELSE po.amount END),0)"
                    : "COALESCE(SUM(po.amount),0)";
                $total = (int)$db->query("SELECT COUNT(DISTINCT username) FROM payment_orders WHERE status='success'")->fetchColumn();
                $st = $db->query(
                    "SELECT po.username AS username, $rev AS metric_val, COUNT(*) AS order_count,
                            MAX(po.created_at) AS last_at, MAX(u.id) AS user_id,
                            MAX(u.plan_type) AS plan_type, MAX(u.balance) AS balance
                     FROM payment_orders po LEFT JOIN users u ON u.username = po.username
                     WHERE po.status='success'
                     GROUP BY po.username
                     ORDER BY metric_val DESC, order_count DESC
                     LIMIT $size OFFSET $offset"
                );
                $rows = $st->fetchAll();
            } elseif ($metric === 'invite') {
                $total = (int)$db->query("SELECT COUNT(*) FROM users WHERE invite_count>0")->fetchColumn();
                $st = $db->query(
                    "SELECT id AS user_id, username, plan_type, invite_code, balance,
                            invite_count AS metric_val
                     FROM users WHERE invite_count>0
                     ORDER BY invite_count DESC LIMIT $size OFFSET $offset"
                );
                $rows = $st->fetchAll();
            } elseif ($metric === 'balance') {
                $total = (int)$db->query("SELECT COUNT(*) FROM users WHERE balance>0")->fetchColumn();
                $st = $db->query(
                    "SELECT id AS user_id, username, plan_type, balance AS metric_val
                     FROM users WHERE balance>0
                     ORDER BY balance DESC LIMIT $size OFFSET $offset"
                );
                $rows = $st->fetchAll();
            } elseif ($metric === 'pro_remaining') {
                $total = (int)$db->query("SELECT COUNT(*) FROM users WHERE pro_pack_total>pro_pack_used AND (plan_expired_at=0 OR plan_expired_at>$now)")->fetchColumn();
                $st = $db->query(
                    "SELECT id AS user_id, username, plan_type, pro_pack_total, pro_pack_used, plan_expired_at,
                            GREATEST(CAST(pro_pack_total AS SIGNED)-CAST(pro_pack_used AS SIGNED),0) AS metric_val
                     FROM users WHERE pro_pack_total>pro_pack_used AND (plan_expired_at=0 OR plan_expired_at>$now)
                     ORDER BY metric_val DESC LIMIT $size OFFSET $offset"
                );
                $rows = $st->fetchAll();
            } elseif ($metric === 'messages') {
                $total = (int)$db->query("SELECT COUNT(*) FROM users WHERE total_ai_messages>0")->fetchColumn();
                $st = $db->query(
                    "SELECT id AS user_id, username, plan_type, total_ai_messages AS metric_val
                     FROM users WHERE total_ai_messages>0
                     ORDER BY total_ai_messages DESC LIMIT $size OFFSET $offset"
                );
                $rows = $st->fetchAll();
            } elseif ($metric === 'count_remaining') {
                try {
                    $usable = "cp.is_active=1 AND cp.counts_total>cp.counts_used AND (cp.expired_at=0 OR cp.expired_at>$now)";
                    $total = (int)$db->query("SELECT COUNT(DISTINCT cp.user_id) FROM user_count_packs cp WHERE $usable")->fetchColumn();
                    $st = $db->query(
                        "SELECT cp.user_id, MAX(u.username) AS username, MAX(u.plan_type) AS plan_type,
                                SUM(cp.counts_total-cp.counts_used) AS metric_val,
                                SUM(cp.counts_total) AS counts_total, COUNT(*) AS pack_count
                         FROM user_count_packs cp LEFT JOIN users u ON u.id = cp.user_id
                         WHERE $usable
                         GROUP BY cp.user_id
                         ORDER BY metric_val DESC LIMIT $size OFFSET $offset"
                    );
                    $rows = $st->fetchAll();
                } catch (PDOException $e) {
                    if (stripos($e->getMessage(),'user_count_packs')!==false || stripos($e->getMessage(),"doesn't exist")!==false) {
                        $rows = []; $total = 0;
                    } else { throw $e; }
                }
            } else {
                err('未知排序指标');
            }

            ok(['metric'=>$metric, 'total'=>$total, 'page'=>$page, 'size'=>$size, 'rows'=>$rows]);
        }

        case 'user_stats.expiring': {
            // 即将到期明细（只读）。kind=count_pack|pro，days=未来天数(默认7)。
            $kind = (string)p('kind', 'count_pack');
            $days = (int)p('days', 7);
            if ($days <= 0)   $days = 7;
            if ($days > 365)  $days = 365;
            $now = time();
            $lim = $now + $days*86400;

            $rows = [];
            if ($kind === 'pro') {
                $st = $db->prepare(
                    "SELECT id AS user_id, username, plan_type, pro_pack_total, pro_pack_used,
                            GREATEST(CAST(pro_pack_total AS SIGNED)-CAST(pro_pack_used AS SIGNED),0) AS remaining,
                            plan_expired_at AS expired_at
                     FROM users
                     WHERE pro_pack_total>0 AND plan_expired_at>0 AND plan_expired_at<=?
                     ORDER BY plan_expired_at ASC
                     LIMIT 500"
                );
                $st->execute([$lim]);
                $rows = $st->fetchAll();
            } else {
                try {
                    $st = $db->prepare(
                        "SELECT cp.id, cp.user_id, u.username, u.plan_type, cp.pack_name,
                                cp.counts_total, cp.counts_used,
                                (cp.counts_total-cp.counts_used) AS remaining,
                                cp.expired_at, cp.models, cp.source_price
                         FROM user_count_packs cp LEFT JOIN users u ON u.id = cp.user_id
                         WHERE cp.is_active=1 AND cp.counts_total>cp.counts_used
                           AND cp.expired_at>0 AND cp.expired_at<=?
                         ORDER BY cp.expired_at ASC
                         LIMIT 500"
                    );
                    $st->execute([$lim]);
                    $rows = $st->fetchAll();
                } catch (PDOException $e) {
                    if (stripos($e->getMessage(),'user_count_packs')!==false || stripos($e->getMessage(),"doesn't exist")!==false) {
                        $rows = [];
                    } else { throw $e; }
                }
            }
            ok(['kind'=>$kind, 'days'=>$days, 'now'=>$now, 'rows'=>$rows]);
        }

        // ── 模型定价 ──────────────────────────────────────────────────────
        case 'models.list': {
            $rows = $db->query("SELECT * FROM model_pricing ORDER BY id DESC")->fetchAll();
            ok($rows);
        }

        case 'models.save': {
            $id = (int)p('id', 0);
            $name = trim((string)p('model_name', ''));
            $disp = trim((string)p('display_name', ''));
            $in   = (float)p('input_price', 0);
            $out  = (float)p('output_price', 0);
            $act  = (int)p('is_active', 1) ? 1 : 0;
            $pack = (int)p('is_pack_allowed', 0) ? 1 : 0;
            // v7 新增:模型自有端点 / API Key / 协议 / 思维链
            $endpoint = trim((string)p('endpoint', ''));
            $apikey   = trim((string)p('api_key', ''));
            $proto    = strtolower(trim((string)p('protocol', 'openai'))) ?: 'openai';
            if (!in_array($proto, ['openai', 'anthropic', 'gemini'], true)) {
                err('请求协议无效');
            }
            $supTh    = (int)p('supports_thinking', 0) ? 1 : 0;
            // Gemini 原生协议按产品规则始终请求并返回思考摘要，后台不能关闭。
            if ($proto === 'gemini') $supTh = 1;
            // 端点 / Key 留空时存 NULL,这样后端能区分"未配置(用全局)"vs"明确空字符串"
            $endpoint_db = $endpoint === '' ? null : $endpoint;
            $apikey_db   = $apikey   === '' ? null : $apikey;

            // v8 新增:能力标签(展示用)
            // 接收逗号分隔字符串,白名单过滤,去重,小写化,再拼回去
            $tags_raw = (string)p('tags', '');
            $tags_allowed = ['chat', 'vision', 'thinking', 'tools'];
            $tags_in = array_filter(array_map('trim', explode(',', strtolower($tags_raw))));
            $tags_clean = array_values(array_unique(array_filter(
                $tags_in, fn($t) => in_array($t, $tags_allowed, true)
            )));
            $tags_db = empty($tags_clean) ? null : implode(',', $tags_clean);

            // v12.11 新增:icon(base64) + category(分组)
            // 用户没传 → 不动现有值;传空串 → 清空
            $icon_raw = p('icon', null);     // null = 未传(保留)、''/字符串 = 设值
            $cat_raw  = p('category', null);
            $set_icon = $icon_raw !== null;
            $set_cat  = $cat_raw  !== null;

            if ($name === '') err('模型名不能为空');
            // display_name 为空 → 兜底用 model_name，避免前端下拉显示空白
            if ($disp === '') $disp = $name;

            // v8 全字段 → v7 → v6 → v5(最老)四级 fallback
            try {
                if ($id > 0) {
                    $db->prepare(
                        "UPDATE model_pricing SET model_name=?, display_name=?, "
                        . "input_price=?, output_price=?, is_active=?, is_pack_allowed=?, "
                        . "endpoint=?, api_key=?, protocol=?, supports_thinking=?, tags=? WHERE id=?"
                    )->execute([$name, $disp, $in, $out, $act, $pack,
                                $endpoint_db, $apikey_db, $proto, $supTh, $tags_db, $id]);
                } else {
                    $db->prepare(
                        "INSERT INTO model_pricing (model_name, display_name, "
                        . "input_price, output_price, is_active, is_pack_allowed, "
                        . "endpoint, api_key, protocol, supports_thinking, tags) "
                        . "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                    )->execute([$name, $disp, $in, $out, $act, $pack,
                                $endpoint_db, $apikey_db, $proto, $supTh, $tags_db]);
                }
            } catch (PDOException $e) {
                $msg = $e->getMessage();
                $missing_v8 = (strpos($msg, 'Unknown column') !== false) &&
                              (strpos($msg, 'tags') !== false);
                $missing_v7 = (strpos($msg, 'Unknown column') !== false) &&
                              (strpos($msg, 'endpoint') !== false ||
                               strpos($msg, 'api_key') !== false ||
                               strpos($msg, 'protocol') !== false ||
                               strpos($msg, 'supports_thinking') !== false);
                $missing_v6 = (strpos($msg, 'Unknown column') !== false) &&
                              (strpos($msg, 'is_pack_allowed') !== false);

                if ($missing_v8 && !$missing_v7 && !$missing_v6) {
                    // v8 字段未跑迁移 → 退回 v7 写法(保留所有 v7 字段,丢弃 tags)
                    if ($id > 0) {
                        $db->prepare(
                            "UPDATE model_pricing SET model_name=?, display_name=?, "
                            . "input_price=?, output_price=?, is_active=?, is_pack_allowed=?, "
                            . "endpoint=?, api_key=?, protocol=?, supports_thinking=? WHERE id=?"
                        )->execute([$name, $disp, $in, $out, $act, $pack,
                                    $endpoint_db, $apikey_db, $proto, $supTh, $id]);
                    } else {
                        $db->prepare(
                            "INSERT INTO model_pricing (model_name, display_name, "
                            . "input_price, output_price, is_active, is_pack_allowed, "
                            . "endpoint, api_key, protocol, supports_thinking) "
                            . "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                        )->execute([$name, $disp, $in, $out, $act, $pack,
                                    $endpoint_db, $apikey_db, $proto, $supTh]);
                    }
                    ok(['warning' => '注:数据库尚未启用 v8 字段(能力标签),请跑 migrate_v8_model_tags.sql 后再设置标签'],
                       '保存成功(标签未生效)');
                } elseif ($missing_v7 && !$missing_v6) {
                    // v7 字段未跑迁移 → 退回 v6 写法(保留 is_pack_allowed)
                    if ($id > 0) {
                        $db->prepare(
                            "UPDATE model_pricing SET model_name=?, display_name=?, "
                            . "input_price=?, output_price=?, is_active=?, is_pack_allowed=? WHERE id=?"
                        )->execute([$name, $disp, $in, $out, $act, $pack, $id]);
                    } else {
                        $db->prepare(
                            "INSERT INTO model_pricing (model_name, display_name, "
                            . "input_price, output_price, is_active, is_pack_allowed) "
                            . "VALUES (?, ?, ?, ?, ?, ?)"
                        )->execute([$name, $disp, $in, $out, $act, $pack]);
                    }
                    ok(['warning' => '注:数据库尚未启用 v7/v8 字段(端点/API Key/协议/思维链/标签),请按顺序跑 migrate_v7_model_endpoint.py 与 migrate_v8_model_tags.sql'],
                       '保存成功(端点/Key/协议/思维链/标签未生效)');
                } elseif ($missing_v6) {
                    // 连 v6 字段也没 → 最老 schema
                    if ($id > 0) {
                        $db->prepare("UPDATE model_pricing SET model_name=?, display_name=?, input_price=?, output_price=?, is_active=? WHERE id=?")
                           ->execute([$name, $disp, $in, $out, $act, $id]);
                    } else {
                        $db->prepare("INSERT INTO model_pricing (model_name, display_name, input_price, output_price, is_active) VALUES (?, ?, ?, ?, ?)")
                           ->execute([$name, $disp, $in, $out, $act]);
                    }
                    ok(['warning' => '注:数据库尚未启用 v6/v7/v8 字段,请按顺序跑 migrate_v6.py、migrate_v7_model_endpoint.py、migrate_v8_model_tags.sql'],
                       '保存成功(订阅包/端点/思维链/标签均未生效)');
                } elseif (strpos($msg, 'Duplicate') !== false) {
                    err('模型名已存在');
                } else {
                    throw $e;
                }
            }

            // v12.11 (2026-05-12) 单独 UPDATE icon / category
            // 用 INSERT 路径时 $id 还是 0,这里要拿到 last_insert_id
            if ($id <= 0) {
                $id = (int)$db->lastInsertId();
            }
            if ($id > 0 && ($set_icon || $set_cat)) {
                try {
                    $sets = []; $bind = [];
                    if ($set_icon) { $sets[] = '`icon`=?';     $bind[] = $icon_raw === '' ? null : $icon_raw; }
                    if ($set_cat)  { $sets[] = '`category`=?'; $bind[] = (string)$cat_raw; }
                    $bind[] = $id;
                    $db->prepare("UPDATE model_pricing SET " . implode(',', $sets) . " WHERE id=?")
                       ->execute($bind);
                } catch (PDOException $e3) {
                    if (strpos($e3->getMessage(), 'Unknown column') !== false) {
                        ok(['warning' => '注:数据库尚未启用 v12.11 字段(icon/category),请跑 migration_v12_11_model_icon.sql'],
                           '保存成功(图标/分组未生效)');
                    }
                    // 其它错就静默(主体保存已成功)
                }
            }
            ok(null, '保存成功');
        }

        case 'models.delete': {
            $id = (int)p('id');
            if (!$id) err('缺少 id');
            $db->prepare("DELETE FROM model_pricing WHERE id=?")->execute([$id]);
            ok(null, '已删除');
        }

        // ── 批量回填 display_name(v5 · 2026-05-07) ──────────────────────
        // 与 migrate_v5.py 的 SUGGESTED_DISPLAY_NAMES 完全对齐。
        // 仅修复"display_name 为空 / NULL"的行,已填的不动(尊重 admin 已做的命名)。
        case 'models.autofill_display_names': {
            $suggested = [
                'gemini-3.1-flash-lite-preview' => 'Gemini 3.1 Flash Lite',
                'gemini-3.1-flash'              => 'Gemini 3.1 Flash',
                'gemini-3-flash-preview'        => 'Gemini 3 Flash Preview',
                'gemini-3.1-flash-lite'              => 'Gemini 2.5 Flash',
                'gemini-2.5-pro'                => 'Gemini 2.5 Pro',
                'deepseek-v4-flash'             => 'DeepSeek V4 Flash',
                'deepseek-chat'                 => 'DeepSeek Chat',
                'grok-4.1-fast'                 => 'Grok 4.1 Fast',
                'claude-sonnet-4-6'             => 'Claude Sonnet 4.6',
                'claude-opus-4-6'               => 'Claude Opus 4.6',
                'claude-haiku-4-5'              => 'Claude Haiku 4.5',
                'gpt-4o'                        => 'GPT-4o',
                'gpt-4o-mini'                   => 'GPT-4o mini',
                'qwen-turbo'                    => 'Qwen Turbo',
                'qwen-max'                      => 'Qwen Max',
                'glm-4-flash'                   => 'GLM-4 Flash',
            ];
            $rows = $db->query(
                "SELECT id, model_name, display_name FROM model_pricing"
            )->fetchAll();
            $fixed = 0;
            $st = $db->prepare("UPDATE model_pricing SET display_name=? WHERE id=?");
            foreach ($rows as $r) {
                if (trim((string)($r['display_name'] ?? '')) !== '') continue;
                $name = $suggested[$r['model_name']] ?? $r['model_name'];
                $st->execute([$name, $r['id']]);
                $fixed++;
            }
            ok(['fixed' => $fixed], "已回填 {$fixed} 个模型的显示名");
        }

        // ── 一键激活订阅包白名单(v6 · 2026-05-07 改造) ──────────────────
        // 把订阅包(pack)桶允许的 6 个模型的 is_pack_allowed=1 + is_active=1;
        // 若某模型不存在则 INSERT 一条默认价 0 的(admin 后续可手动填真实价格)。
        // is_pack_allowed 字段不存在(老库未跑 migrate_v6)时,只激活 is_active=1。
        case 'models.activate_pack_whitelist': {
            $whitelist = [
                'gemini-3.1-flash-lite-preview' => 'Gemini 3.1 Flash Lite',
                'gemini-3.1-flash'              => 'Gemini 3.1 Flash',
                'gemini-3-flash-preview'        => 'Gemini 3 Flash Preview',
                'gemini-3.1-flash-lite'              => 'Gemini 2.5 Flash',
                'deepseek-v4-flash'             => 'DeepSeek V4 Flash',
                'grok-4.1-fast'                 => 'Grok 4.1 Fast',
            ];
            // 探测 is_pack_allowed 是否存在
            $has_pack_field = false;
            try {
                $db->query("SELECT is_pack_allowed FROM model_pricing LIMIT 0");
                $has_pack_field = true;
            } catch (Exception $e) { /* 字段不存在 */ }

            $activated = 0;
            $inserted  = 0;
            foreach ($whitelist as $model_name => $display_name) {
                $st = $db->prepare(
                    "SELECT id, is_active FROM model_pricing "
                    . "WHERE LOWER(model_name) = LOWER(?)"
                );
                $st->execute([$model_name]);
                $row = $st->fetch();
                if ($row) {
                    if ($has_pack_field) {
                        $db->prepare("UPDATE model_pricing SET is_active=1, is_pack_allowed=1 WHERE id=?")
                           ->execute([$row['id']]);
                    } else {
                        $db->prepare("UPDATE model_pricing SET is_active=1 WHERE id=?")
                           ->execute([$row['id']]);
                    }
                    $activated++;
                } else {
                    if ($has_pack_field) {
                        $db->prepare(
                            "INSERT INTO model_pricing "
                            . "(model_name, display_name, input_price, output_price, is_active, is_pack_allowed) "
                            . "VALUES (?, ?, 0, 0, 1, 1)"
                        )->execute([$model_name, $display_name]);
                    } else {
                        $db->prepare(
                            "INSERT INTO model_pricing "
                            . "(model_name, display_name, input_price, output_price, is_active) "
                            . "VALUES (?, ?, 0, 0, 1)"
                        )->execute([$model_name, $display_name]);
                    }
                    $inserted++;
                }
            }
            $note = $has_pack_field ? '' : ' ⚠ 数据库未启用 is_pack_allowed 字段,本次只激活了 is_active,请跑 migrate_v6.py 后重做。';
            ok(
                ['activated' => $activated, 'inserted' => $inserted, 'has_pack_field' => $has_pack_field],
                "已激活 {$activated} 个,新增 {$inserted} 个" . $note
            );
        }

        // ── 订阅包档位 CRUD(v5 · 2026-05-07) ────────────────────────────
        case 'packs.list': {
            try {
                $rows = $db->query(
                    "SELECT * FROM pack_tiers ORDER BY sort_order, price"
                )->fetchAll();
                ok($rows);
            } catch (Exception $e) {
                err('pack_tiers 表不存在,请先跑 migrate_v5.py');
            }
        }

        case 'packs.save': {
            $id           = (int)p('id', 0);
            $price        = (float)p('price', 0);
            $tokens       = (int)p('tokens', 0);
            $gift_balance = (float)p('gift_balance', 0);
            $days         = (int)p('days', 30);
            $label        = trim((string)p('label', ''));
            $sort_order   = (int)p('sort_order', 0);
            $is_active    = (int)p('is_active', 1) ? 1 : 0;

            if ($price < 0.01)  err('价格不能小于 0.01 元');
            if ($tokens < 0)    err('Token 数不能为负');
            if ($days < 1)      err('有效期至少 1 天');
            if (mb_strlen($label) > 32) err('标签过长(32 字以内)');

            $now = time();
            try {
                if ($id > 0) {
                    $db->prepare(
                        "UPDATE pack_tiers SET price=?, tokens=?, gift_balance=?, "
                        . "days=?, label=?, sort_order=?, is_active=?, updated_at=? WHERE id=?"
                    )->execute([$price, $tokens, $gift_balance, $days,
                                $label === '' ? null : $label,
                                $sort_order, $is_active, $now, $id]);
                } else {
                    $db->prepare(
                        "INSERT INTO pack_tiers (price, tokens, gift_balance, days, "
                        . "label, sort_order, is_active, created_at, updated_at) "
                        . "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
                    )->execute([$price, $tokens, $gift_balance, $days,
                                $label === '' ? null : $label,
                                $sort_order, $is_active, $now, $now]);
                }
            } catch (PDOException $e) {
                if (strpos($e->getMessage(), 'Duplicate') !== false) {
                    err('该价格已存在,请改用另一个价格或编辑现有档位');
                }
                if (strpos($e->getMessage(), "doesn't exist") !== false) {
                    err('pack_tiers 表不存在,请先跑 migrate_v5.py');
                }
                throw $e;
            }
            ok(null, '保存成功');
        }

        case 'packs.delete': {
            $id = (int)p('id');
            if (!$id) err('缺少 id');
            $db->prepare("DELETE FROM pack_tiers WHERE id=?")->execute([$id]);
            ok(null, '已删除');
        }

        // ── 次数包套餐（count_pack_tiers） v7 新增 ───────────────────────────
        case 'count_packs.list': {
            try {
                $rows = $db->query(
                    "SELECT * FROM count_pack_tiers ORDER BY sort_order, price"
                )->fetchAll();
                // 顺手返回所有可勾选的模型，便于前端表单画 checkbox
                $models = $db->query(
                    "SELECT model_name, display_name FROM model_pricing "
                    . "WHERE is_active=1 ORDER BY model_name"
                )->fetchAll();
                ok(['rows' => $rows, 'models' => $models]);
            } catch (Exception $e) {
                err('count_pack_tiers 表不存在，请先跑 migrate_v7.sql');
            }
        }

        case 'count_packs.save': {
            $id         = (int)p('id', 0);
            $price      = (float)p('price', 0);
            $counts     = (int)p('counts', 0);
            $days       = (int)p('days', 30);
            $label      = trim((string)p('label', ''));
            $sort_order = (int)p('sort_order', 0);
            $is_active  = (int)p('is_active', 1) ? 1 : 0;

            // allowed_models 接收：可以是数组 或 JSON 字符串
            $am_raw = $_POST['allowed_models'] ?? '';
            if (is_array($am_raw)) {
                $allowed_arr = $am_raw;
            } else {
                $decoded = json_decode((string)$am_raw, true);
                $allowed_arr = is_array($decoded) ? $decoded : [];
            }
            // 清洗：去空、去重、限制数量
            $allowed_arr = array_values(array_unique(array_filter(
                array_map(function($x){ return trim((string)$x); }, $allowed_arr),
                function($x){ return $x !== ''; }
            )));
            if (count($allowed_arr) === 0) {
                err('请为该次数包选择 1 个模型');
            }
            if (count($allowed_arr) > 1) {
                // v10：每个次数包只绑定一个模型（前端单选；这里兜底，只取首个）
                $allowed_arr = [reset($allowed_arr)];
            }
            $allowed_json = json_encode($allowed_arr, JSON_UNESCAPED_UNICODE);

            if ($price < 0.01)  err('价格不能小于 0.01 元');
            if ($counts < 1)    err('次数不能少于 1');
            if ($days < 1)      err('有效期至少 1 天');
            if (mb_strlen($label) > 32) err('标签过长（32 字以内）');

            $now = time();
            try {
                if ($id > 0) {
                    $db->prepare(
                        "UPDATE count_pack_tiers SET price=?, counts=?, days=?, "
                        . "label=?, allowed_models=?, sort_order=?, is_active=?, "
                        . "updated_at=? WHERE id=?"
                    )->execute([
                        $price, $counts, $days,
                        $label === '' ? null : $label,
                        $allowed_json, $sort_order, $is_active, $now, $id
                    ]);
                } else {
                    $db->prepare(
                        "INSERT INTO count_pack_tiers (price, counts, days, label, "
                        . "allowed_models, sort_order, is_active, created_at, updated_at) "
                        . "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
                    )->execute([
                        $price, $counts, $days,
                        $label === '' ? null : $label,
                        $allowed_json, $sort_order, $is_active, $now, $now
                    ]);
                }
            } catch (PDOException $e) {
                if (strpos($e->getMessage(), 'Duplicate') !== false) {
                    err('该价格已存在，请改用另一个价格或编辑现有档位');
                }
                if (strpos($e->getMessage(), "doesn't exist") !== false) {
                    err('count_pack_tiers 表不存在，请先跑 migrate_v7.sql');
                }
                throw $e;
            }
            ok(null, '保存成功');
        }

        case 'count_packs.delete': {
            $id = (int)p('id');
            if (!$id) err('缺少 id');
            $db->prepare("DELETE FROM count_pack_tiers WHERE id=?")->execute([$id]);
            ok(null, '已删除');
        }

        // ── 次数包「可用模型」一键同步（2026-06-24 新增）─────────────────────
        // 背景：count_pack_tiers 是次数包的「档位/SKU」，allowed_models 是该档位
        //       授权的模型清单；用户购买后会在 user_count_packs 里存一份 models
        //       快照。管理员事后在档位里增减模型时，老买家的 models 不会跟着变，
        //       于是出现「买过次数包的用户拿不到新模型 / 仍留着已删模型」的问题
        //       （正好对应页面说明里「可用模型清单以最新购买的套餐为准（覆盖）」）。
        // 本接口：把每个档位「当前」的 allowed_models 覆盖同步到所有「买过对应价位」
        //       的 user_count_packs.models，并返回受影响的用户 / 次数包数量。
        //       匹配键：user_count_packs.source_price == count_pack_tiers.price
        //       （price 在档位表里唯一，是稳定的 1:1 映射；只动 models，其余不变）。
        case 'count_packs.sync_user_models': {
            // 1) 读出所有档位，建「价格 -> 规整后的模型数组」映射
            try {
                $tiers = $db->query(
                    "SELECT price, allowed_models FROM count_pack_tiers"
                )->fetchAll();
            } catch (Exception $e) {
                err('count_pack_tiers 表不存在，请先跑 migrate_v7.sql');
            }
            if (!$tiers) err('还没有任何次数包档位，无需同步');

            // 把 JSON 模型清单规整成「去空 + 去重 + 排序」的数组，便于做集合比较
            $norm = function ($raw) {
                $arr = json_decode((string)$raw, true);
                if (!is_array($arr)) $arr = [];
                $arr = array_values(array_unique(array_filter(
                    array_map(function ($x) { return trim((string)$x); }, $arr),
                    function ($x) { return $x !== ''; }
                )));
                sort($arr, SORT_STRING);
                return $arr;
            };

            $priceMap = [];   // '9.90' => ['grok-4.1-fast', ...]（已规整）
            foreach ($tiers as $t) {
                $key = number_format((float)$t['price'], 2, '.', '');
                $priceMap[$key] = $norm($t['allowed_models']);
            }

            // 2) 拉出所有用户次数包（老库可能没这张表）
            try {
                $packs = $db->query(
                    "SELECT id, user_id, source_price, models FROM user_count_packs"
                )->fetchAll();
            } catch (PDOException $e) {
                if (stripos($e->getMessage(), 'user_count_packs') !== false ||
                    stripos($e->getMessage(), "doesn't exist") !== false) {
                    ok([
                        'affected_users' => 0, 'affected_packs' => 0,
                        'scanned' => 0, 'unmatched' => 0, 'already' => 0,
                    ], '还没有任何用户次数包，无需同步');
                }
                throw $e;
            }

            $upd = $db->prepare("UPDATE user_count_packs SET models=? WHERE id=?");

            $affectedPacks = 0;   // 实际改动的次数包行数
            $unmatched     = 0;   // 价格对不上任何档位（含管理员手挂的自定义包）→ 跳过
            $already       = 0;   // 已经是最新，无需改
            $affectedUsers = [];  // 去重用户集合：user_id => true

            $useTx = false;
            try { $db->beginTransaction(); $useTx = true; } catch (Exception $e) { $useTx = false; }

            try {
                foreach ($packs as $row) {
                    // source_price 为空 → 没法对应档位，跳过（典型为管理员手动挂的包）
                    if ($row['source_price'] === null || $row['source_price'] === '') {
                        $unmatched++; continue;
                    }
                    $key = number_format((float)$row['source_price'], 2, '.', '');
                    if (!array_key_exists($key, $priceMap)) { $unmatched++; continue; }

                    $target  = $priceMap[$key];         // 目标（档位最新）
                    $current = $norm($row['models']);   // 现状（用户快照）
                    if ($current === $target) { $already++; continue; }

                    $upd->execute([
                        json_encode($target, JSON_UNESCAPED_UNICODE),
                        (int)$row['id'],
                    ]);
                    $affectedPacks++;
                    $affectedUsers[(int)$row['user_id']] = true;
                }
                if ($useTx) $db->commit();
            } catch (Exception $e) {
                if ($useTx && $db->inTransaction()) $db->rollBack();
                throw $e;   // 交给外层 try/catch 统一回 500
            }

            $affectedUserCount = count($affectedUsers);
            error_log(sprintf(
                "[%s][Admin] count_packs.sync_user_models users=%d packs=%d unmatched=%d already=%d scanned=%d",
                date('Y-m-d H:i:s'), $affectedUserCount, $affectedPacks,
                $unmatched, $already, count($packs)
            ));

            ok([
                'affected_users' => $affectedUserCount,
                'affected_packs' => $affectedPacks,
                'scanned'        => count($packs),
                'unmatched'      => $unmatched,
                'already'        => $already,
            ], "同步完成，影响了 {$affectedUserCount} 位用户");
        }

        // ── 兑换码管理(2026-06-19)────────────────────────────────────────
        // 表 redeem_codes 与 api/api_redeem.php 自愈建表完全一致。
        case 'redeem.list': {
            redeem_ensure_table($db);

            $status = (string)p('status', '');     // '' / unused / used
            $kw     = trim((string)p('kw', ''));    // 按 code / 批次 / 备注 模糊
            $limit  = min(1000, max(1, (int)p('limit', 300)));

            $where = [];
            $args  = [];
            if ($status === 'unused' || $status === 'used') { $where[] = 'status = ?'; $args[] = $status; }
            if ($kw !== '') {
                $where[] = '(code LIKE ? OR batch_id LIKE ? OR note LIKE ? OR used_by_name LIKE ?)';
                $like = '%' . $kw . '%';
                array_push($args, $like, $like, $like, $like);
            }
            $sql = "SELECT * FROM redeem_codes";
            if ($where) $sql .= " WHERE " . implode(' AND ', $where);
            $sql .= " ORDER BY id DESC LIMIT " . $limit;

            $st = $db->prepare($sql);
            $st->execute($args);
            $rows = $st->fetchAll(PDO::FETCH_ASSOC);

            // 汇总
            $total  = (int)$db->query("SELECT COUNT(*) FROM redeem_codes")->fetchColumn();
            $unused = (int)$db->query("SELECT COUNT(*) FROM redeem_codes WHERE status='unused'")->fetchColumn();
            $used   = $total - $unused;

            // 顺手返回可勾选模型(次数类型用)
            $models = [];
            try {
                $models = $db->query(
                    "SELECT model_name, display_name FROM model_pricing WHERE is_active=1 ORDER BY model_name"
                )->fetchAll(PDO::FETCH_ASSOC);
            } catch (Exception $e) { /* 忽略 */ }

            ok([
                'rows'    => $rows,
                'models'  => $models,
                'summary' => ['total' => $total, 'unused' => $unused, 'used' => $used],
            ]);
        }

        case 'redeem.create': {
            redeem_ensure_table($db);

            $type  = (string)p('reward_type', 'balance');
            if (!in_array($type, ['balance', 'token', 'count'], true)) err('reward_type 非法');

            $value = (float)p('reward_value', 0);
            $days  = max(0, (int)p('reward_days', 30));
            $count = min(2000, max(1, (int)p('count', 1)));   // 批量张数,单次上限 2000
            $note  = trim((string)p('note', ''));

            if ($value <= 0) err('奖励数值必须大于 0（余额=元 / token=数量 / 次数=次数）');

            // 次数类型必须带模型
            $models_json = '[]';
            if ($type === 'count') {
                $models_raw = trim((string)p('reward_models', ''));
                $decoded = $models_raw === '' ? [] : json_decode($models_raw, true);
                if (!is_array($decoded) || count($decoded) === 0) err('次数类型必须至少选择 1 个模型');
                $models_json = json_encode(array_values($decoded), JSON_UNESCAPED_UNICODE);
            }

            $batch_id = 'B' . date('ymdHis') . substr(bin2hex(random_bytes(2)), 0, 4);
            $now      = time();

            // 生成不重复的 16 位码(数字+大写字母)。预查已存在码做内存去重 + 唯一索引兜底。
            $exist = [];
            foreach ($db->query("SELECT code FROM redeem_codes")->fetchAll(PDO::FETCH_COLUMN) as $c) {
                $exist[$c] = true;
            }
            $gen = function () {
                $alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                $s = '';
                for ($i = 0; $i < 16; $i++) $s .= $alphabet[random_int(0, 35)];
                return $s;
            };

            $ins = $db->prepare(
                "INSERT INTO redeem_codes
                   (code, reward_type, reward_value, reward_days, reward_models, batch_id, note, status, created_at)
                 VALUES (?,?,?,?,?,?,?, 'unused', ?)"
            );

            $created = [];
            $attempts = 0;
            $maxAttempts = $count * 12 + 50;   // 给足重试空间
            while (count($created) < $count && $attempts < $maxAttempts) {
                $attempts++;
                $code = $gen();
                if (isset($exist[$code])) continue;
                try {
                    $ins->execute([$code, $type, $value, $days, $models_json, $batch_id, $note, $now]);
                    $exist[$code] = true;
                    $created[] = $code;
                } catch (Exception $e) {
                    // 撞唯一索引(并发) → 换一个继续
                    continue;
                }
            }

            if (count($created) === 0) err('生成失败,请重试');

            error_log(sprintf("[%s][Admin][redeem.create] batch=%s type=%s value=%s days=%d n=%d/%d",
                date('Y-m-d H:i:s'), $batch_id, $type, (string)$value, $days, count($created), $count));

            ok([
                'batch_id' => $batch_id,
                'count'    => count($created),
                'codes'    => $created,
            ], '已生成 ' . count($created) . ' 个兑换码');
        }

        case 'redeem.delete': {
            // 支持单个 id、逗号分隔的 ids、整批 batch_id
            $id    = (int)p('id', 0);
            $ids   = trim((string)p('ids', ''));
            $batch = trim((string)p('batch_id', ''));

            if ($batch !== '') {
                $st = $db->prepare("DELETE FROM redeem_codes WHERE batch_id = ?");
                $st->execute([$batch]);
                ok(['deleted' => $st->rowCount()], '已删除整批 ' . $st->rowCount() . ' 个');
            }

            $idList = [];
            if ($ids !== '') {
                foreach (explode(',', $ids) as $v) {
                    $v = (int)trim($v);
                    if ($v > 0) $idList[] = $v;
                }
            }
            if ($id > 0) $idList[] = $id;
            $idList = array_values(array_unique($idList));
            if (!$idList) err('缺少 id / ids / batch_id');

            $ph = implode(',', array_fill(0, count($idList), '?'));
            $st = $db->prepare("DELETE FROM redeem_codes WHERE id IN ($ph)");
            $st->execute($idList);
            ok(['deleted' => $st->rowCount()], '已删除 ' . $st->rowCount() . ' 个');
        }

        // ── v8.4.2 (2026-05-10) 限时抽奖 admin 查询 + 开奖 ──────────────
        // 奖品配置(必须与 api/api_lottery.php / console.php 三处保持一致)
        // 改奖品时三个文件一起改。
        case 'lottery.list_entries':
        case 'lottery.draw':
        {
            // v13.13 (2026-05-14) 新一期:gemini-flash-lite ×20 + grok-fast ×20 + gemini-pro ×5
            // v13.13.2 (2026-05-14) 截止时间改为 2026-05-15 12:00:00 +08:00
            $LOTTERY_ID          = 'lucky_2026_05_14';
            $LOTTERY_DEADLINE_TS = 1778817600;
            $LOTTERY_PRIZES = [
                ['id' => 'gemini_flash_100', 'name' => 'Gemini 3.1 Flash-Lite', 'detail' => '100 次调用', 'winners' => 20, 'type' => 'count_pack', 'icon' => 'bolt',     'color' => '#0ea5e9'],
                ['id' => 'grok_fast_100',    'name' => 'Grok 4.1 Fast',          'detail' => '100 次调用', 'winners' => 20, 'type' => 'count_pack', 'icon' => 'flash_on', 'color' => '#7c3aed'],
                ['id' => 'gemini_pro_100',   'name' => 'Gemini 3.1 Pro Preview', 'detail' => '100 次调用', 'winners' => 5,  'type' => 'count_pack', 'icon' => 'diamond',  'color' => '#2563eb'],
            ];

            // ─── 开奖 action ────────────────────────────────────────────
            if ($action === 'lottery.draw') {
                // 校验 1:必须已过截止时间(防止 admin 提前开奖)
                $force = (int)p('force', 0) === 1;
                if (!$force && time() < $LOTTERY_DEADLINE_TS) {
                    err('未到截止时间,不能开奖。如需测试,前端传 force=1 强制开奖');
                }

                // 校验 2:不能重复开奖(已经有 is_winner=1 的记录就拒绝,除非 force)
                try {
                    $stmt = $db->prepare(
                        "SELECT COUNT(*) FROM lottery_entries WHERE lottery_id=? AND is_winner=1"
                    );
                    $stmt->execute([$LOTTERY_ID]);
                    $already = (int)$stmt->fetchColumn();
                } catch (PDOException $e) {
                    if (strpos($e->getMessage(), "doesn't exist") !== false) {
                        err('lottery_entries 表不存在,请先跑 migration/migrate_v8_4_lottery.sql');
                    }
                    throw $e;
                }
                if ($already > 0 && !$force) {
                    err("本期已开奖({$already} 人中奖)。如需重新开奖,前端传 force=1");
                }

                // 拉所有报名用户
                try {
                    $stmt = $db->prepare(
                        "SELECT id, user_id FROM lottery_entries WHERE lottery_id=?"
                    );
                    $stmt->execute([$LOTTERY_ID]);
                    $entries = $stmt->fetchAll();
                } catch (PDOException $e) {
                    if (strpos($e->getMessage(), 'prize_id') !== false ||
                        strpos($e->getMessage(), 'is_winner') !== false) {
                        err('lottery_entries 缺少 prize_id 字段,请先跑 migration/migrate_v8_4_2_lottery_prize.sql');
                    }
                    throw $e;
                }
                if (empty($entries)) {
                    err('本期无人报名,无法开奖');
                }

                $total_winners_needed = array_sum(array_column($LOTTERY_PRIZES, 'winners'));
                $entry_count = count($entries);

                // shuffle 报名名单
                shuffle($entries);

                // force=1 时先清空现有 is_winner / prize_id(重新开奖)
                if ($force) {
                    $db->prepare(
                        "UPDATE lottery_entries SET is_winner=0, prize_id=NULL "
                        . "WHERE lottery_id=?"
                    )->execute([$LOTTERY_ID]);
                }

                $db->beginTransaction();
                try {
                    $cursor = 0;  // shuffle 名单的游标
                    $assigned_per_prize = [];  // 实际分配人数(可能少于 winners,因为报名人数不够)

                    foreach ($LOTTERY_PRIZES as $p) {
                        $assigned_per_prize[$p['id']] = 0;
                        for ($i = 0; $i < $p['winners']; $i++) {
                            if ($cursor >= $entry_count) break 2;  // 报名人数不够,停止
                            $entry = $entries[$cursor++];
                            $db->prepare(
                                "UPDATE lottery_entries SET is_winner=1, prize_id=? WHERE id=?"
                            )->execute([$p['id'], $entry['id']]);
                            $assigned_per_prize[$p['id']]++;
                        }
                    }

                    $db->commit();
                } catch (Exception $e) {
                    $db->rollBack();
                    err('开奖失败: ' . $e->getMessage(), 500);
                }

                ok([
                    'lottery_id'           => $LOTTERY_ID,
                    'entry_count'          => $entry_count,
                    'total_winners_needed' => $total_winners_needed,
                    'total_winners_actual' => array_sum($assigned_per_prize),
                    'per_prize'            => $assigned_per_prize,
                    'force'                => $force,
                ], '开奖成功');
            }

            // ─── list_entries action(强化:返回 prize_id + 按奖项分组) ──
            try {
                // 报名总数 / 中奖数 / 已发奖数
                $stmt = $db->prepare("SELECT COUNT(*) FROM lottery_entries WHERE lottery_id=?");
                $stmt->execute([$LOTTERY_ID]);
                $entry_count = (int)$stmt->fetchColumn();

                $stmt = $db->prepare("SELECT COUNT(*) FROM lottery_entries WHERE lottery_id=? AND is_winner=1");
                $stmt->execute([$LOTTERY_ID]);
                $winner_count = (int)$stmt->fetchColumn();

                $stmt = $db->prepare(
                    "SELECT COUNT(*) FROM lottery_entries WHERE lottery_id=? AND awarded_at IS NOT NULL"
                );
                $stmt->execute([$LOTTERY_ID]);
                $awarded_count = (int)$stmt->fetchColumn();

                // 名单(JOIN 用户表拿用户名)— 兼容老库无 prize_id
                try {
                    $stmt = $db->prepare(
                        "SELECT e.id, e.user_id, u.username, e.balance_at, e.invites_at, "
                        . "e.ip, e.created_at, e.is_winner, e.prize_id, e.awarded_at "
                        . "FROM lottery_entries e LEFT JOIN users u ON u.id = e.user_id "
                        . "WHERE e.lottery_id = ? "
                        . "ORDER BY e.is_winner DESC, e.id DESC LIMIT 1000"
                    );
                    $stmt->execute([$LOTTERY_ID]);
                    $rows = $stmt->fetchAll();
                } catch (PDOException $e) {
                    if (strpos($e->getMessage(), 'prize_id') !== false) {
                        // 老库无 prize_id,fallback
                        $stmt = $db->prepare(
                            "SELECT e.id, e.user_id, u.username, e.balance_at, e.invites_at, "
                            . "e.ip, e.created_at, e.is_winner, e.awarded_at "
                            . "FROM lottery_entries e LEFT JOIN users u ON u.id = e.user_id "
                            . "WHERE e.lottery_id = ? "
                            . "ORDER BY e.is_winner DESC, e.id DESC LIMIT 1000"
                        );
                        $stmt->execute([$LOTTERY_ID]);
                        $rows = $stmt->fetchAll();
                        // 补 prize_id=null 字段,前端无需判断
                        foreach ($rows as &$r) { $r['prize_id'] = null; }
                        unset($r);
                    } else {
                        throw $e;
                    }
                }

                // 按奖项分组中奖名单(给 admin 展示)
                $winners_by_prize = [];
                foreach ($LOTTERY_PRIZES as $p) {
                    $winners_by_prize[$p['id']] = [];
                }
                foreach ($rows as $r) {
                    if ((int)$r['is_winner'] === 1 && !empty($r['prize_id']) && isset($winners_by_prize[$r['prize_id']])) {
                        $winners_by_prize[$r['prize_id']][] = [
                            'user_id'  => (int)$r['user_id'],
                            'username' => $r['username'] ?? '',
                            'awarded'  => !empty($r['awarded_at']),
                        ];
                    }
                }

                ok([
                    'lottery_id'        => $LOTTERY_ID,
                    'deadline_ts'       => $LOTTERY_DEADLINE_TS,
                    'prizes'            => $LOTTERY_PRIZES,
                    'entry_count'       => $entry_count,
                    'winner_count'      => $winner_count,
                    'awarded_count'     => $awarded_count,
                    'rows'              => $rows,
                    'winners_by_prize'  => $winners_by_prize,
                    'is_drawn'          => $winner_count > 0,
                ]);
            } catch (PDOException $e) {
                if (strpos($e->getMessage(), "doesn't exist") !== false) {
                    err('lottery_entries 表不存在,请先跑 migration/migrate_v8_4_lottery.sql');
                }
                throw $e;
            }
        }


        // ── 系统配置（system_config） ────────────────────────────────────
        case 'config.list': {
            $rows = $db->query("SELECT id, config_key, config_value, remark FROM system_config ORDER BY config_key")->fetchAll();
            // 按前缀分组
            $groups = [];
            foreach ($rows as $r) {
                $key = $r['config_key'];
                $prefix = strtok($key, '_');
                $groups[$prefix][] = $r;
            }
            ok(['rows'=>$rows, 'groups'=>$groups]);
        }

        case 'config.save': {
            // 接收 configs JSON 数组：[{key, value, remark}]
            $raw = file_get_contents('php://input');
            $data = json_decode($raw, true);
            if (!is_array($data) || empty($data['configs'])) err('参数错误');
            $now = time();
            $stmt = $db->prepare(
                "INSERT INTO system_config (config_key, config_value, remark, updated_at)
                 VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE config_value=VALUES(config_value), remark=VALUES(remark), updated_at=VALUES(updated_at)"
            );
            foreach ($data['configs'] as $c) {
                $k = trim((string)($c['key'] ?? ''));
                if ($k === '') continue;
                $v = (string)($c['value'] ?? '');
                $r = (string)($c['remark'] ?? '');
                $stmt->execute([$k, $v, $r, $now]);
            }
            ok(null, '配置已保存');
        }

        case 'config.delete': {
            $key = trim((string)p('config_key', ''));
            if ($key === '') err('缺少 config_key');
            $db->prepare("DELETE FROM system_config WHERE config_key=?")->execute([$key]);
            ok(null, '已删除');
        }

        // ══════════════════════════════════════════════════════════════════
        // 论坛管理 (forum.*) —— 分区维护 + 帖子审核
        //   依赖 forum_migration.sql 已执行(forum_sections / forum_posts 等)。
        // ══════════════════════════════════════════════════════════════════

        // 分区列表(含每区帖子总数)
        case 'forum.sections': {
            $rows = $db->query(
                "SELECT id, name, intro, sort_order, created_at FROM forum_sections ORDER BY sort_order ASC, id ASC"
            )->fetchAll();
            $counts = [];
            foreach ($db->query("SELECT section_id, COUNT(*) c FROM forum_posts GROUP BY section_id")->fetchAll() as $c) {
                $counts[(int)$c['section_id']] = (int)$c['c'];
            }
            foreach ($rows as &$r) {
                $r['id']         = (int)$r['id'];
                $r['sort_order'] = (int)$r['sort_order'];
                $r['post_count'] = $counts[$r['id']] ?? 0;
            }
            unset($r);
            ok(['rows' => $rows]);
        }

        // 新增 / 编辑分区
        case 'forum.section_save': {
            $id    = (int)p('id', 0);
            $name  = trim((string)p('name', ''));
            $intro = trim((string)p('intro', ''));
            $sort  = (int)p('sort_order', 0);
            if ($name === '')            err('分区名称不能为空');
            if (mb_strlen($name) > 40)   err('分区名称最长 40 字');
            if (mb_strlen($intro) > 160) err('简介最长 160 字');
            if ($id > 0) {
                $db->prepare("UPDATE forum_sections SET name=?, intro=?, sort_order=? WHERE id=?")
                   ->execute([$name, $intro, $sort, $id]);
                ok(['id' => $id], '分区已更新');
            } else {
                $db->prepare("INSERT INTO forum_sections (name, intro, sort_order, created_at) VALUES (?,?,?,?)")
                   ->execute([$name, $intro, $sort, time()]);
                ok(['id' => (int)$db->lastInsertId()], '分区已创建');
            }
        }

        // 删除分区(该区下的帖子 section_id 归 0,不连带删帖)
        case 'forum.section_delete': {
            $id = (int)p('id', 0);
            if (!$id) err('缺少分区 ID');
            $db->prepare("UPDATE forum_posts SET section_id=0 WHERE section_id=?")->execute([$id]);
            $db->prepare("DELETE FROM forum_sections WHERE id=?")->execute([$id]);
            ok(null, '分区已删除（原帖子已移出该分区）');
        }

        // 帖子列表(可按 status 过滤 + 关键字 + 分页)
        case 'forum.posts': {
            $status  = trim((string)p('status', ''));   // ''=全部 / pending / approved / rejected
            $keyword = trim((string)p('keyword', ''));
            $page    = max(1, (int)p('page', 1));
            $size    = 15;
            $offset  = ($page - 1) * $size;

            $where = []; $bind = [];
            if (in_array($status, ['pending','approved','rejected'], true)) { $where[] = 'p.status=?'; $bind[] = $status; }
            if ($keyword !== '') { $where[] = '(p.title LIKE ? OR p.content LIKE ?)'; $kw='%'.$keyword.'%'; $bind[]=$kw; $bind[]=$kw; }
            $w = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

            $cnt = $db->prepare("SELECT COUNT(*) FROM forum_posts p $w");
            $cnt->execute($bind);
            $total = (int)$cnt->fetchColumn();

            $sql = "SELECT p.id, p.user_id, p.section_id, p.title, p.content, p.images,
                           p.like_count, p.comment_count, p.status, p.reject_reason, p.created_at,
                           u.username, s.name AS section_name
                    FROM forum_posts p
                    LEFT JOIN users u ON u.id = p.user_id
                    LEFT JOIN forum_sections s ON s.id = p.section_id
                    $w
                    ORDER BY p.id DESC
                    LIMIT $size OFFSET $offset";
            $stmt = $db->prepare($sql);
            $stmt->execute($bind);
            $rows = $stmt->fetchAll();
            foreach ($rows as &$r) {
                $imgs = $r['images'] ? json_decode($r['images'], true) : [];
                $r['image_count'] = is_array($imgs) ? count($imgs) : 0;
                // 列表里不回传巨大的图片 DataURL,只给数量;详情按需另取
                unset($r['images']);
                $r['id']            = (int)$r['id'];
                $r['like_count']    = (int)$r['like_count'];
                $r['comment_count'] = (int)$r['comment_count'];
                $r['created_at']    = (int)$r['created_at'];
            }
            unset($r);

            // 顺带返回 pending 计数(给导航小红点用)
            $pending = (int)$db->query("SELECT COUNT(*) FROM forum_posts WHERE status='pending'")->fetchColumn();
            ok(['rows'=>$rows, 'total'=>$total, 'page'=>$page, 'size'=>$size, 'pending'=>$pending]);
        }

        // 单帖详情(含图片,审核时点开看)
        case 'forum.post_detail': {
            $id = (int)p('id', 0);
            if (!$id) err('缺少帖子 ID');
            $stmt = $db->prepare(
                "SELECT p.*, u.username FROM forum_posts p LEFT JOIN users u ON u.id=p.user_id WHERE p.id=?"
            );
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            if (!$row) err('帖子不存在', 404);
            $imgs = $row['images'] ? json_decode($row['images'], true) : [];
            $row['images'] = is_array($imgs) ? array_values($imgs) : [];
            ok($row);
        }

        // 审核:通过 / 驳回
        case 'forum.post_review': {
            $id     = (int)p('id', 0);
            $decide = trim((string)p('decision', ''));   // approve | reject
            $reason = trim((string)p('reason', ''));
            if (!$id) err('缺少帖子 ID');
            if (!in_array($decide, ['approve','reject'], true)) err('审核动作不合法');
            $status = $decide === 'approve' ? 'approved' : 'rejected';
            $db->prepare("UPDATE forum_posts SET status=?, reject_reason=?, reviewed_at=? WHERE id=?")
               ->execute([$status, $decide === 'reject' ? $reason : '', time(), $id]);
            ok(null, $decide === 'approve' ? '已通过' : '已驳回');
        }

        // 管理员删帖(连带点赞/评论)
        case 'forum.post_delete': {
            $id = (int)p('id', 0);
            if (!$id) err('缺少帖子 ID');
            $db->prepare("DELETE FROM forum_likes    WHERE post_id=?")->execute([$id]);
            $db->prepare("DELETE FROM forum_comments WHERE post_id=?")->execute([$id]);
            $db->prepare("DELETE FROM forum_posts    WHERE id=?")->execute([$id]);
            ok(null, '帖子已删除');
        }


        // ── v11 (2026-05-12) 提示词预设 prompt_presets ─────────────────────
        // 4 个 prompt 字段 + 元信息.老库未跑 migration_v11 时返 "请先跑迁移".
        case 'prompt_presets.list': {
            try {
                $rows = $db->query(
                    "SELECT id, name, description, system_prompt, passive_reply_prompt,
                            proactive_message_prompt, active_reply_prompt,
                            is_active, sort_order, created_at, updated_at
                       FROM prompt_presets
                      ORDER BY sort_order ASC, id ASC"
                )->fetchAll();
                ok($rows);
            } catch (PDOException $e) {
                if (strpos($e->getMessage(), 'prompt_presets') !== false) {
                    err('请先执行 migration/migration_v11_prompt_presets.sql', 500);
                }
                throw $e;
            }
        }

        case 'prompt_presets.save': {
            $id   = (int)p('id', 0);
            $name = trim((string)p('name', ''));
            $desc = trim((string)p('description', ''));
            // 三个核心 + 一个附加
            $sys  = (string)p('system_prompt', '');
            $pas  = (string)p('passive_reply_prompt', '');
            $pro  = (string)p('proactive_message_prompt', '');
            $act  = (string)p('active_reply_prompt', '');
            $is_active = (int)p('is_active', 1) ? 1 : 0;
            $sort = (int)p('sort_order', 0);

            if ($name === '')   err('预设名不能为空');
            if ($sys === '')    err('系统提示词不能为空');
            if ($pas === '')    err('被动回复提示词不能为空');
            if ($pro === '')    err('主动消息提示词不能为空');
            // active_reply_prompt 可空

            // 长度兜底 — 防止误粘超大文本撑爆 mediumtext
            $MAX_PROMPT = 65000;
            foreach (['system'=>$sys, 'passive'=>$pas, 'proactive'=>$pro, 'active'=>$act] as $k=>$v) {
                if (strlen($v) > $MAX_PROMPT) {
                    err("『{$k}」提示词过长 (>" . $MAX_PROMPT . " 字节),请精简");
                }
            }

            $now = time();
            try {
                if ($id > 0) {
                    $stmt = $db->prepare(
                        "UPDATE prompt_presets
                            SET name=?, description=?, system_prompt=?, passive_reply_prompt=?,
                                proactive_message_prompt=?, active_reply_prompt=?,
                                is_active=?, sort_order=?, updated_at=?
                          WHERE id=?"
                    );
                    $stmt->execute([$name, $desc, $sys, $pas, $pro, $act, $is_active, $sort, $now, $id]);
                    ok(['id'=>$id], '已更新');
                } else {
                    $stmt = $db->prepare(
                        "INSERT INTO prompt_presets
                            (name, description, system_prompt, passive_reply_prompt,
                             proactive_message_prompt, active_reply_prompt,
                             is_active, sort_order, created_at, updated_at)
                         VALUES (?,?,?,?,?,?,?,?,?,?)"
                    );
                    $stmt->execute([$name, $desc, $sys, $pas, $pro, $act, $is_active, $sort, $now, $now]);
                    ok(['id'=>(int)$db->lastInsertId()], '已新建');
                }
            } catch (PDOException $e) {
                if (strpos($e->getMessage(), 'prompt_presets') !== false &&
                    strpos($e->getMessage(), "doesn't exist") !== false) {
                    err('请先执行 migration/migration_v11_prompt_presets.sql', 500);
                }
                throw $e;
            }
            break;
        }

        case 'prompt_presets.delete': {
            $id = (int)p('id');
            if (!$id) err('缺少 id');
            // 把引用该预设的实例 preset_id 设回 NULL(回退到内置默认),不让用户实例报错
            try {
                $db->prepare("UPDATE instances SET preset_id=NULL WHERE preset_id=?")->execute([$id]);
            } catch (PDOException $e) {
                // instances.preset_id 字段不存在(老库) → 跳过
                if (strpos($e->getMessage(), 'preset_id') === false) throw $e;
            }
            $db->prepare("DELETE FROM prompt_presets WHERE id=?")->execute([$id]);
            ok(null, '已删除(引用此预设的实例已回退为内置默认)');
        }

        // ── 工具注册 ──────────────────────────────────────────────────────
        case 'tools.list': {
            $rows = $db->query("SELECT * FROM tools_registry ORDER BY sort_order ASC, id ASC")->fetchAll();
            ok($rows);
        }

        case 'tools.save': {
            $id = (int)p('id', 0);
            $name = trim((string)p('tool_name', ''));
            $disp = trim((string)p('display_name', ''));
            $desc = (string)p('description', '');
            $icon = trim((string)p('icon', 'extension'));
            $act  = (int)p('is_active', 1);
            $core = (int)p('is_core', 0);
            $sort = (int)p('sort_order', 0);
            if ($name === '' || $disp === '') err('工具名和展示名不能为空');

            if ($id > 0) {
                $db->prepare("UPDATE tools_registry SET tool_name=?, display_name=?, description=?, icon=?, is_active=?, is_core=?, sort_order=? WHERE id=?")
                   ->execute([$name, $disp, $desc, $icon, $act, $core, $sort, $id]);
            } else {
                try {
                    $db->prepare("INSERT INTO tools_registry (tool_name, display_name, description, icon, is_active, is_core, sort_order, created_at) VALUES (?,?,?,?,?,?,?,?)")
                       ->execute([$name, $disp, $desc, $icon, $act, $core, $sort, time()]);
                } catch (PDOException $e) {
                    err('工具名已存在');
                }
            }
            ok(null, '保存成功');
        }

        case 'tools.delete': {
            $id = (int)p('id');
            if (!$id) err('缺少 id');
            // 同时清理黑名单残留
            $tn = $db->prepare("SELECT tool_name FROM tools_registry WHERE id=?");
            $tn->execute([$id]);
            $row = $tn->fetch();
            if ($row) {
                $db->prepare("DELETE FROM instance_tool_blacklist WHERE tool_name=?")->execute([$row['tool_name']]);
            }
            $db->prepare("DELETE FROM tools_registry WHERE id=?")->execute([$id]);
            ok(null, '已删除（黑名单同步清理）');
        }

        // ── 人格市场 ──────────────────────────────────────────────────────
        case 'market.list': {
            $rows = $db->query("SELECT * FROM market_personas ORDER BY id DESC")->fetchAll();
            ok($rows);
        }

        case 'market.save': {
            $id = (int)p('id', 0);
            $name = trim((string)p('name', ''));
            $desc = (string)p('description', '');
            $prompt = (string)p('system_prompt', '');
            $avatar = (string)p('avatar', 'image/logo.png');
            $act  = (int)p('is_active', 1);
            if ($name === '' || $prompt === '') err('名称与 system_prompt 不能为空');

            if ($id > 0) {
                $db->prepare("UPDATE market_personas SET name=?, description=?, system_prompt=?, avatar=?, is_active=? WHERE id=?")
                   ->execute([$name, $desc, $prompt, $avatar, $act, $id]);
            } else {
                $db->prepare("INSERT INTO market_personas (name, description, system_prompt, avatar, is_active, created_at) VALUES (?,?,?,?,?,?)")
                   ->execute([$name, $desc, $prompt, $avatar, $act, time()]);
            }
            ok(null, '保存成功');
        }

        case 'market.delete': {
            $id = (int)p('id');
            if (!$id) err('缺少 id');
            $db->prepare("DELETE FROM market_personas WHERE id=?")->execute([$id]);
            ok(null, '已删除');
        }

        // ── 邮件队列（只读） ──────────────────────────────────────────────
        case 'emails.list': {
            $rows = $db->query("SELECT * FROM email_queue ORDER BY id DESC LIMIT 100")->fetchAll();
            ok($rows);
        }

        case 'emails.purge': {
            $db->exec("DELETE FROM email_queue WHERE status=1 AND created_at < " . (time() - 86400 * 7));
            ok(null, '已清理 7 天前的成功记录');
        }

        // ── v9.2 (2026-05-11) 鸣谢滑动头像(testimonials) ──────────────
        case 'testimonials.list': {
            try {
                $rows = $db->query(
                    "SELECT id, avatar_url, name, content, row_index, sort_order, is_active, created_at
                     FROM testimonials ORDER BY row_index ASC, sort_order ASC"
                )->fetchAll();
                ok($rows);
            } catch (PDOException $e) {
                if (strpos($e->getMessage(), "doesn't exist") !== false)
                    err('testimonials 表不存在,请先跑 migration/migrate_v9_2_testimonials.sql');
                throw $e;
            }
        }

        case 'testimonials.save': {
            $id         = (int)p('id', 0);
            $avatar_url = trim(p('avatar_url', ''));
            $name       = trim(p('name', ''));
            $content    = trim(p('content', ''));
            $row_index  = (int)p('row_index', 0);
            $sort_order = (int)p('sort_order', 0);
            $is_active  = (int)p('is_active', 1);
            if (!$name)    err('名字不能为空');
            if (!$content) err('内容不能为空');
            if (mb_strlen($content) > 200) err('内容最多 200 字');
            // 头像兜底:JS 已压缩到 ~30KB,这里防止绕过前端直接发超大数据
            if (strlen($avatar_url) > 800_000) err('头像图片太大,请选择更小的图片');
            try {
                if ($id > 0) {
                    $db->prepare(
                        "UPDATE testimonials SET avatar_url=?,name=?,content=?,row_index=?,sort_order=?,is_active=? WHERE id=?"
                    )->execute([$avatar_url, $name, $content, $row_index, $sort_order, $is_active, $id]);
                    ok(['id' => $id], '已更新');
                } else {
                    $db->prepare(
                        "INSERT INTO testimonials (avatar_url,name,content,row_index,sort_order,is_active,created_at)
                         VALUES (?,?,?,?,?,?,?)"
                    )->execute([$avatar_url, $name, $content, $row_index, $sort_order, $is_active, time()]);
                    ok(['id' => $db->lastInsertId()], '已添加');
                }
            } catch (PDOException $e) {
                $em = $e->getMessage();
                if (strpos($em, "doesn't exist") !== false)
                    err('testimonials 表不存在,请先跑 migration/migrate_v9_2_testimonials.sql');
                if (strpos($em, 'Data too long') !== false)
                    err('头像数据太大,请执行 ALTER TABLE: ALTER TABLE testimonials MODIFY COLUMN avatar_url LONGTEXT NOT NULL;');
                throw $e;
            }
        }

        case 'testimonials.delete': {
            $id = (int)p('id', 0);
            if (!$id) err('缺少 id');
            $db->prepare("DELETE FROM testimonials WHERE id=?")->execute([$id]);
            ok(null, '已删除');
        }

        // ── v9.3 预设音色管理 (存 system_config.preset_voice_ids JSON 数组) ─
        case 'preset_voices.list': {
            $stmt = $db->prepare("SELECT config_value FROM system_config WHERE config_key=''");
            $stmt->execute();
            $r = $stmt->fetch();
            $list = [];
            if ($r && !empty($r['config_value'])) {
                $arr = json_decode($r['config_value'], true);
                if (is_array($arr)) {
                    foreach ($arr as $i => $v) {
                        $list[] = [
                            'idx'       => $i,
                            'voice_id'  => $v['voice_id'] ?? '',
                            'name'      => $v['name']     ?? '未命名',
                            'is_active' => isset($v['is_active']) ? (int)$v['is_active'] : 1,
                        ];
                    }
                }
            }
            ok($list);
        }

        case 'preset_voices.save': {
            $idx       = (int)p('idx', -1);   // -1 = 新增
            $voice_id  = trim(p('voice_id', ''));
            $name      = trim(p('name', '') ?: p('display_name', ''));
            $is_active = (int)p('is_active', 1) ? 1 : 0;
            if (!$voice_id) err('voice_id 不能为空');
            if (!$name)     err('显示名称不能为空');

            $stmt = $db->prepare("SELECT config_value FROM system_config WHERE config_key=''");
            $stmt->execute();
            $r = $stmt->fetch();
            $arr = [];
            if ($r && !empty($r['config_value'])) {
                $tmp = json_decode($r['config_value'], true);
                if (is_array($tmp)) $arr = $tmp;
            }
            // voice_id 唯一性检查
            foreach ($arr as $i => $v) {
                if (($v['voice_id'] ?? '') === $voice_id && $i !== $idx) {
                    err('该 voice_id 已存在,不能重复添加');
                }
            }
            $item = ['voice_id' => $voice_id, 'name' => $name, 'is_active' => $is_active];
            if ($idx >= 0 && isset($arr[$idx])) {
                $arr[$idx] = $item;
            } else {
                $arr[] = $item;
            }
            $up = $db->prepare(
                "INSERT INTO system_config (config_key, config_value, remark, updated_at) "
                . "VALUES ('preset_voice_ids', ?, '预设音色 ID 列表 (admin 维护)', ?) "
                . "ON DUPLICATE KEY UPDATE config_value=VALUES(config_value), updated_at=VALUES(updated_at)"
            );
            $up->execute([json_encode($arr, JSON_UNESCAPED_UNICODE), time()]);
            ok(['count' => count($arr)], '已保存');
        }

        case 'preset_voices.delete': {
            $idx = (int)p('idx', -1);
            if ($idx < 0) err('缺少 idx');
            $stmt = $db->prepare("SELECT config_value FROM system_config WHERE config_key=''");
            $stmt->execute();
            $r = $stmt->fetch();
            $arr = [];
            if ($r && !empty($r['config_value'])) {
                $tmp = json_decode($r['config_value'], true);
                if (is_array($tmp)) $arr = $tmp;
            }
            if (!isset($arr[$idx])) err('索引越界');
            array_splice($arr, $idx, 1);
            $up = $db->prepare(
                "INSERT INTO system_config (config_key, config_value, remark, updated_at) "
                . "VALUES ('preset_voice_ids', ?, '预设音色 ID 列表 (admin 维护)', ?) "
                . "ON DUPLICATE KEY UPDATE config_value=VALUES(config_value), updated_at=VALUES(updated_at)"
            );
            $up->execute([json_encode($arr, JSON_UNESCAPED_UNICODE), time()]);
            ok(null, '已删除');
        }

        // ── 用户留言管理（精简） ──
        case 'messages.list': {
            $page   = max(1, (int)p('page', 1));
            $size   = 20;
            $offset = ($page - 1) * $size;

            $total = (int)$db->query("SELECT COUNT(*) FROM user_messages")->fetchColumn();
            $stmt = $db->prepare(
                "SELECT m.*, u.username, u.email
                 FROM user_messages m
                 LEFT JOIN users u ON m.user_id = u.id
                 ORDER BY
                     CASE WHEN m.replied_at = 0 THEN 0 ELSE 1 END ASC,
                     m.id DESC
                 LIMIT $size OFFSET $offset"
            );
            $stmt->execute();
            $rows = $stmt->fetchAll();

            $pending = (int)$db->query("SELECT COUNT(*) FROM user_messages WHERE replied_at = 0")->fetchColumn();

            ok([
                'total'   => $total,
                'page'    => $page,
                'size'    => $size,
                'rows'    => $rows,
                'pending' => $pending,
            ]);
        }

        case 'messages.reply': {
            $id    = (int)p('id', 0);
            $reply = trim((string)p('reply', ''));
            if ($id <= 0)      err('缺少 id');
            if ($reply === '') err('回复内容不能为空');
            if (mb_strlen($reply) > 2000) err('回复长度不能超过 2000 字');

            // 拉留言原文与用户邮箱(用于邮件回执)
            $msg_stmt = $db->prepare(
                "SELECT m.id, m.user_id, m.content, u.email, u.username
                 FROM user_messages m
                 LEFT JOIN users u ON u.id = m.user_id
                 WHERE m.id = ?"
            );
            $msg_stmt->execute([$id]);
            $msg_row = $msg_stmt->fetch();
            if (!$msg_row) err('留言不存在');

            $admin_username = $user['username'] ?? 'admin';
            $stmt = $db->prepare(
                "UPDATE user_messages
                 SET reply = ?, replied_at = ?, replied_by = ?, read_at = 0
                 WHERE id = ?"
            );
            $stmt->execute([$reply, time(), $admin_username, $id]);
            if ($stmt->rowCount() === 0) err('留言不存在');

            // 通过 email_queue 发邮件通知用户(emoji.py 后台进程会取出处理)
            // 仅在用户填了合法邮箱时入队
            $user_email = trim((string)($msg_row['email'] ?? ''));
            $email_queued = false;
            if ($user_email !== '' && filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
                $original = $msg_row['content'];
                $username = $msg_row['username'] ?? 'user';
                $safe_reply = htmlspecialchars($reply, ENT_QUOTES, 'UTF-8');
                $safe_orig  = htmlspecialchars($original, ENT_QUOTES, 'UTF-8');
                $safe_user  = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
                $body_html = "
<div style='font-family:-apple-system,BlinkMacSystemFont,sans-serif;max-width:600px;margin:auto;'>
  <h2 style='color:#111;border-bottom:2px solid #111;padding-bottom:10px;'>💬 您的留言已收到回复</h2>
  <p>$safe_user 您好,管理员已回复您的留言 #$id。</p>
  <h3 style='color:#666;font-size:14px;margin-top:24px;margin-bottom:8px;'>您的留言:</h3>
  <div style='background:#fafafa;border-left:3px solid #ddd;padding:12px 14px;border-radius:6px;line-height:1.7;white-space:pre-wrap;color:#666;font-size:13px;'>$safe_orig</div>
  <h3 style='color:#111;font-size:14px;margin-top:24px;margin-bottom:8px;'>管理员回复:</h3>
  <div style='background:#f5f3fe;border-left:3px solid #7367f0;padding:14px 16px;border-radius:6px;line-height:1.7;white-space:pre-wrap;font-size:14px;'>$safe_reply</div>
  <p style='margin-top:28px;color:#999;font-size:12px;'>此邮件由系统自动发出。如需进一步沟通,请直接登录 Cloud Love 控制台再次留言。</p>
</div>";
                $subject = "[Cloud Love] 您的留言 #$id 已回复";
                try {
                    $db->prepare(
                        "INSERT INTO email_queue (email, subject, body, is_html, status, created_at)
                         VALUES (?, ?, ?, 1, 0, ?)"
                    )->execute([$user_email, $subject, $body_html, time()]);
                    $email_queued = true;
                } catch (Throwable $e) {
                    error_log("[messages.reply] email_queue 入队异常,回复已落库: " . $e->getMessage());
                }
            }

            ok([
                'email_queued' => $email_queued,
                'user_email'   => $user_email,
            ], '回复已发送');
        }

        // ── 公告管理（v2 新增） ──────────────────────────────────────────
        case 'announcement.get': {
            // 读 system_config 中的 announcement_content 与 announcement_version
            $stmt = $db->prepare(
                "SELECT config_key, config_value, updated_at FROM system_config
                 WHERE config_key IN ('announcement_content', 'announcement_version')"
            );
            $stmt->execute();
            $rows = $stmt->fetchAll();
            $out = ['content' => '', 'version' => '0', 'updated_at' => 0];
            foreach ($rows as $r) {
                if ($r['config_key'] === 'announcement_content') {
                    $out['content']    = (string)$r['config_value'];
                    $out['updated_at'] = (int)($r['updated_at'] ?? 0);
                }
                if ($r['config_key'] === 'announcement_version') {
                    $out['version'] = (string)$r['config_value'];
                }
            }
            ok($out);
        }

        case 'announcement.update': {
            // 保存公告内容；版本号自动 bump 为当前时间戳，前端 sessionStorage 据此
            // 检测变化触发再次弹出。允许 content 为空字符串（清空公告）。
            $content = (string)p('content', '');
            $now     = time();
            // 简易长度限制：8000 字（公告不该比一篇博客还长）
            if (mb_strlen($content) > 8000) {
                err('公告内容过长（上限 8000 字）');
            }

            $upsert = $db->prepare(
                "INSERT INTO system_config (config_key, config_value, remark, updated_at)
                 VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE config_value = VALUES(config_value), updated_at = VALUES(updated_at)"
            );
            $upsert->execute(['announcement_content', $content, '前端登录后的弹窗公告（admin 编辑）', $now]);
            $upsert->execute(['announcement_version', (string)$now, '公告版本号（修改后自动 bump）', $now]);

            error_log(sprintf(
                "[%s][Admin] announcement.update version=%d length=%d",
                date('Y-m-d H:i:s'), $now, mb_strlen($content)
            ));
            ok(['version' => (string)$now, 'updated_at' => $now], '公告已发布，所有用户下次进入将看到');
        }

        // ── 推广视频审核（v2.1 新增） ────────────────────────────────────
        // 列表 / 通过 / 拒绝 / 送订阅包
        case 'videos.list': {
            $status = trim((string)p('status', ''));
            $kw     = trim((string)p('username', ''));
            $page   = max(1, (int)p('page', 1));
            $size   = min(100, max(10, (int)p('size', 20)));
            $offset = ($page - 1) * $size;

            $where = []; $bind = [];
            if (in_array($status, ['pending','approved','rejected','rewarded'], true)) {
                $where[] = "v.status = ?"; $bind[] = $status;
            }
            if ($kw !== '') {
                $where[] = "u.username LIKE ?"; $bind[] = "%{$kw}%";
            }
            $w = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

            $cstmt = $db->prepare("SELECT COUNT(*) FROM referral_videos v LEFT JOIN users u ON u.id=v.user_id $w");
            $cstmt->execute($bind);
            $total = (int)$cstmt->fetchColumn();

            $sql = "SELECT v.id, v.user_id, v.video_url, v.description, v.platform,
                           v.status, v.reject_reason, v.gift_pack_amt,
                           v.created_at, v.reviewed_at, v.reviewed_by,
                           u.username, u.balance,
                           u.bonus_weekly_tokens, u.pro_pack_total, u.plan_expired_at
                    FROM referral_videos v
                    LEFT JOIN users u ON u.id = v.user_id
                    $w
                    ORDER BY v.id DESC
                    LIMIT $size OFFSET $offset";
            $st = $db->prepare($sql);
            $st->execute($bind);
            $rows = $st->fetchAll();

            // 同时返回 pending 总数，前端导航红点要用
            $pcnt = (int)$db->query("SELECT COUNT(*) FROM referral_videos WHERE status='pending'")->fetchColumn();

            ok([
                'videos'         => $rows,
                'total'          => $total,
                'page'           => $page,
                'size'           => $size,
                'pending_count'  => $pcnt,
            ]);
        }

        case 'videos.review': {
            // 接收：id, action ∈ {approve, reject}, reject_reason?
            // 通过 → bonus_weekly_tokens += 200000，status=approved
            // 拒绝 → status=rejected, reject_reason=...
            // 重复操作幂等：仅当当前 status='pending' 时才生效
            $vid    = (int)p('id', 0);
            $act    = trim((string)p('review_action', ''));
            $reason = trim((string)p('reject_reason', ''));
            if (!$vid)                         err('缺少 id');
            if (!in_array($act, ['approve','reject'], true)) err('action 错误');
            if ($act === 'reject' && !$reason) err('请填写拒绝原因');
            if (mb_strlen($reason) > 500)      err('拒绝原因过长（500 字以内）');

            $admin_uid = (int)($_SESSION['admin_uid'] ?? $_SESSION['user_id'] ?? 0);

            $db->beginTransaction();
            try {
                $st = $db->prepare("SELECT * FROM referral_videos WHERE id=? FOR UPDATE");
                $st->execute([$vid]);
                $v = $st->fetch();
                if (!$v) throw new Exception('视频不存在');
                if ($v['status'] !== 'pending') throw new Exception('该视频已被处理过，状态：' . $v['status']);

                $now = time();
                if ($act === 'approve') {
                    // ① 标记审核通过
                    $db->prepare(
                        "UPDATE referral_videos SET status='approved', reviewed_at=?, reviewed_by=? WHERE id=?"
                    )->execute([$now, $admin_uid, $vid]);
                    // ② 给用户 +20 万/周永久
                    $db->prepare(
                        "UPDATE users SET bonus_weekly_tokens = bonus_weekly_tokens + 200000 WHERE id=?"
                    )->execute([$v['user_id']]);
                    error_log(sprintf(
                        "[%s][Admin][videos.approve] vid=%d user_id=%d +200000 weekly token by admin=%d",
                        date('Y-m-d H:i:s'), $vid, $v['user_id'], $admin_uid
                    ));
                } else {
                    $db->prepare(
                        "UPDATE referral_videos SET status='rejected', reject_reason=?, reviewed_at=?, reviewed_by=? WHERE id=?"
                    )->execute([$reason, $now, $admin_uid, $vid]);
                    error_log(sprintf(
                        "[%s][Admin][videos.reject] vid=%d user_id=%d reason=%s by admin=%d",
                        date('Y-m-d H:i:s'), $vid, $v['user_id'], $reason, $admin_uid
                    ));
                }
                $db->commit();
                ok(null, $act === 'approve' ? '已通过，用户 +20 万 Token / 周永久' : '已拒绝');
            } catch (Exception $e) {
                $db->rollBack();
                err($e->getMessage());
            }
        }

        case 'videos.gift_pack': {
            // 单独的"送订阅包"操作：可在 approved 之后再点（升级为 rewarded）
            // 也可以一步到位（pending → rewarded，同时 +20 万/周）
            $vid     = (int)p('id', 0);
            $pack    = (string)p('pack_amt', '0');
            if (!$vid) err('缺少 id');

            // v5 改造:档位优先从 pack_tiers 读;表不存在则走硬编码兜底
            $valid_packs = [];
            try {
                $stP = $db->query(
                    "SELECT price, tokens, gift_balance, days FROM pack_tiers WHERE is_active=1"
                );
                foreach ($stP->fetchAll(PDO::FETCH_ASSOC) as $row) {
                    $key = number_format((float)$row['price'], 1, '.', '');
                    $valid_packs[$key] = [
                        'tokens' => (int)$row['tokens'],
                        'gift'   => (float)$row['gift_balance'],
                        'days'   => (int)$row['days'],
                    ];
                }
            } catch (Exception $e) { /* 走兜底 */ }
            if (empty($valid_packs)) {
                $valid_packs = [
                    '9.9'  => ['tokens' => 1500000,  'gift' => 0.0,   'days' => 30],
                    '15.9' => ['tokens' => 2500000,  'gift' => 3.9,   'days' => 30],
                    '29.9' => ['tokens' => 5000000,  'gift' => 6.66,  'days' => 30],
                    '39.9' => ['tokens' => 8000000,  'gift' => 8.88,  'days' => 30],
                    '49.9' => ['tokens' => 12000000, 'gift' => 12.99, 'days' => 30],
                ];
            }
            $pack_str = number_format((float)$pack, 1, '.', '');
            if (!isset($valid_packs[$pack_str])) {
                err('档位非法,可选: ' . implode(' / ', array_keys($valid_packs)));
            }

            $admin_uid = (int)($_SESSION['admin_uid'] ?? $_SESSION['user_id'] ?? 0);
            $cfg       = $valid_packs[$pack_str];

            $db->beginTransaction();
            try {
                $st = $db->prepare("SELECT * FROM referral_videos WHERE id=? FOR UPDATE");
                $st->execute([$vid]);
                $v = $st->fetch();
                if (!$v) throw new Exception('视频不存在');
                if (in_array($v['status'], ['rejected','rewarded'], true)) {
                    throw new Exception('当前状态为 ' . $v['status'] . '，无法再赠送订阅包');
                }

                // 取用户行
                $stU = $db->prepare("SELECT plan_expired_at FROM users WHERE id=? FOR UPDATE");
                $stU->execute([$v['user_id']]);
                $u = $stU->fetch();
                if (!$u) throw new Exception('用户已不存在');

                $now           = time();
                $currentExpire = (int)($u['plan_expired_at'] ?? 0);
                $baseExpire    = ($currentExpire > $now) ? $currentExpire : $now;
                $newExpire     = $baseExpire + ($cfg['days'] * 86400);

                // 累加 token + 叠期 + 赠送余额（不动 used）
                $db->prepare("
                    UPDATE users SET
                        plan_type       = 'pro',
                        plan_expired_at = ?,
                        pro_pack_total  = pro_pack_total + ?,
                        balance         = balance + ?
                    WHERE id = ?
                ")->execute([$newExpire, $cfg['tokens'], $cfg['gift'], $v['user_id']]);

                // 如果当前还是 pending，升级到 approved 同时给周 token；否则只更新 gift_pack_amt
                if ($v['status'] === 'pending') {
                    $db->prepare(
                        "UPDATE users SET bonus_weekly_tokens = bonus_weekly_tokens + 200000 WHERE id=?"
                    )->execute([$v['user_id']]);
                }
                $db->prepare(
                    "UPDATE referral_videos SET
                        status        = 'rewarded',
                        gift_pack_amt = ?,
                        reviewed_at   = ?,
                        reviewed_by   = ?
                     WHERE id = ?"
                )->execute([(float)$pack_str, $now, $admin_uid, $vid]);

                error_log(sprintf(
                    "[%s][Admin][videos.gift_pack] vid=%d user_id=%d pack=¥%s tokens=%d gift=¥%.2f by admin=%d",
                    date('Y-m-d H:i:s'), $vid, $v['user_id'], $pack_str, $cfg['tokens'], $cfg['gift'], $admin_uid
                ));
                $db->commit();
                ok(null, "已赠送 ¥{$pack_str} 档订阅包（{$cfg['tokens']} token + 30 天）");
            } catch (Exception $e) {
                $db->rollBack();
                err($e->getMessage());
            }
        }

        case 'users.quick_adjust': {
            // "小的用户管理"——不进 users tab 直接给某用户加额度/送包
            $key       = trim((string)p('user_key', ''));
            $add_bonus = (int)p('add_bonus_weekly', 0);
            $gift_pack = (string)p('gift_pack_amt', '0');

            if ($key === '') err('请填写用户名 / ID');

            // user_key 支持纯数字 ID 或精确用户名
            if (ctype_digit($key)) {
                $stU = $db->prepare("SELECT id, username, bonus_weekly_tokens, pro_pack_total, plan_expired_at FROM users WHERE id=?");
                $stU->execute([(int)$key]);
            } else {
                $stU = $db->prepare("SELECT id, username, bonus_weekly_tokens, pro_pack_total, plan_expired_at FROM users WHERE username=?");
                $stU->execute([$key]);
            }
            $u = $stU->fetch();
            if (!$u) err('用户不存在');

            $messages   = [];
            $admin_uid  = (int)($_SESSION['admin_uid'] ?? $_SESSION['user_id'] ?? 0);

            // 加周额度
            if ($add_bonus > 0) {
                $db->prepare("UPDATE users SET bonus_weekly_tokens = bonus_weekly_tokens + ? WHERE id=?")
                   ->execute([$add_bonus, $u['id']]);
                $messages[] = "+{$add_bonus} weekly token";
            }

            // 送包(v5 改造:从 pack_tiers 读;表不存在则走硬编码兜底)
            $valid_packs = [];
            try {
                $stP = $db->query(
                    "SELECT price, tokens, gift_balance, days FROM pack_tiers WHERE is_active=1"
                );
                foreach ($stP->fetchAll(PDO::FETCH_ASSOC) as $row) {
                    $key = number_format((float)$row['price'], 1, '.', '');
                    $valid_packs[$key] = [
                        'tokens' => (int)$row['tokens'],
                        'gift'   => (float)$row['gift_balance'],
                        'days'   => (int)$row['days'],
                    ];
                }
            } catch (Exception $e) { /* 走兜底 */ }
            if (empty($valid_packs)) {
                $valid_packs = [
                    '9.9'  => ['tokens' => 1500000,  'gift' => 0.0,   'days' => 30],
                    '15.9' => ['tokens' => 2500000,  'gift' => 3.9,   'days' => 30],
                    '29.9' => ['tokens' => 5000000,  'gift' => 6.66,  'days' => 30],
                    '39.9' => ['tokens' => 8000000,  'gift' => 8.88,  'days' => 30],
                    '49.9' => ['tokens' => 12000000, 'gift' => 12.99, 'days' => 30],
                ];
            }
            $pack_str = number_format((float)$gift_pack, 1, '.', '');
            if (isset($valid_packs[$pack_str])) {
                $cfg           = $valid_packs[$pack_str];
                $now           = time();
                $currentExpire = (int)($u['plan_expired_at'] ?? 0);
                $baseExpire    = ($currentExpire > $now) ? $currentExpire : $now;
                $newExpire     = $baseExpire + ($cfg['days'] * 86400);
                $db->prepare("
                    UPDATE users SET
                        plan_type       = 'pro',
                        plan_expired_at = ?,
                        pro_pack_total  = pro_pack_total + ?,
                        balance         = balance + ?
                    WHERE id = ?
                ")->execute([$newExpire, $cfg['tokens'], $cfg['gift'], $u['id']]);
                $messages[] = "+订阅包 ¥{$pack_str}（{$cfg['tokens']} token + 30 天）";
            }

            if (empty($messages)) err('未填写任何调整项');

            error_log(sprintf(
                "[%s][Admin][users.quick_adjust] user=%s(%d) by=%d %s",
                date('Y-m-d H:i:s'), $u['username'], $u['id'], $admin_uid, implode(' / ', $messages)
            ));

            ok([
                'user_id'  => $u['id'],
                'username' => $u['username'],
                'applied'  => $messages,
            ], '已应用：' . implode(' / ', $messages));
        }

        // ── 实时监控（多进程分片:读全部 runtime_snapshot_N 行并合并） ──────
        case 'monitor.snapshot': {
            // 多进程改造:每个分片进程各写一行 runtime_snapshot_{N}。
            // 这里把全部分片行读出来,既给出「合并视图」(所有进程汇总),
            // 也给出「分片明细」(每个进程单独一块,看 worker 分配/回复速度)。
            // 注:LIKE 里 '_' 是单字符通配符,要匹配字面下划线需转义。
            //     用 ESCAPE 指定 '!' 作转义符,'runtime!_snapshot!_%' 才是
            //     精确匹配 "runtime_snapshot_" 开头。
            $rows = $db->query(
                "SELECT config_key, config_value, updated_at FROM system_config "
                . "WHERE config_key LIKE 'runtime!_snapshot!_%' ESCAPE '!'"
            )->fetchAll();

            // MySQL 全局连接状态（一次性 SHOW，开销极低）
            $mysql = ['max' => 0, 'now' => 0, 'max_used' => 0];
            try {
                $r = $db->query("SHOW VARIABLES LIKE 'max_connections'")->fetch();
                if ($r) $mysql['max'] = (int)$r['Value'];
                $r = $db->query("SHOW STATUS LIKE 'Threads_connected'")->fetch();
                if ($r) $mysql['now'] = (int)$r['Value'];
                $r = $db->query("SHOW STATUS LIKE 'Max_used_connections'")->fetch();
                if ($r) $mysql['max_used'] = (int)$r['Value'];
            } catch (Exception $e) { /* 静默：监控页面不应影响主功能 */ }

            // 解析每个分片的快照
            $shards = [];
            foreach ($rows as $row) {
                if (empty($row['config_value'])) continue;
                $snap = json_decode($row['config_value'], true);
                if (!is_array($snap)) continue;
                // 从 key 末尾取分片号(runtime_snapshot_7 → 7);快照内也有 shard_index 兜底
                $idx = $snap['shard_index'] ?? null;
                if ($idx === null && preg_match('/_(\d+)$/', $row['config_key'], $m)) {
                    $idx = (int)$m[1];
                }
                $snap['shard_index']  = (int)$idx;
                $snap['snapshot_age'] = max(0, time() - (int)($snap['ts'] ?? 0));
                $shards[] = $snap;
            }
            // 按分片号排序,保证前端 0..12 顺序稳定
            usort($shards, function ($a, $b) {
                return ($a['shard_index'] ?? 0) <=> ($b['shard_index'] ?? 0);
            });

            // 没有任何分片写过快照
            if (empty($shards)) {
                ok([
                    'available' => false,
                    'reason'    => 'main.py 未写入快照（服务未启动 / 升级后首次未到 1 秒 / 写库失败）',
                    'mysql'     => $mysql,
                    'shards'    => [],
                ]);
            }

            // ── 合并视图:所有分片汇总 ────────────────────────────────────
            $allWorkers = [];
            $allLogs    = [];
            $sumQueue   = 0;
            $sumActive  = 0;
            $sumTotal   = 0;
            $sumFailed  = 0;
            $sumPoolUsed = 0;
            $sumPoolSize = 0;
            $maxAge     = 0;
            foreach ($shards as $s) {
                $sidx = $s['shard_index'];
                // worker / log 都打上分片号前缀,合并后仍能区分来源
                foreach (($s['workers'] ?? []) as $w) {
                    $w['shard'] = $sidx;
                    $allWorkers[] = $w;
                }
                foreach (($s['logs'] ?? []) as $lg) {
                    // 单进程时代 logs 是 [{ts,msg}] 对象数组,前端按对象渲染。
                    // 多进程合并必须保留对象结构 —— 把「分片N」前缀加进 msg,
                    // ts 原样保留,否则前端 _renderRtLog 按 l.ts 过滤会全空。
                    if (is_array($lg)) {
                        $allLogs[] = [
                            'ts'  => $lg['ts'] ?? time(),
                            'msg' => "[分片{$sidx}] " . (string)($lg['msg'] ?? ''),
                        ];
                    } else {
                        // 兜底:万一某分片写的是纯字符串日志
                        $allLogs[] = [
                            'ts'  => time(),
                            'msg' => "[分片{$sidx}] " . (string)$lg,
                        ];
                    }
                }
                $sumQueue    += (int)($s['queue_size'] ?? 0);
                $sumActive   += (int)($s['active_workers'] ?? 0);
                $sumTotal    += (int)($s['total_workers'] ?? 0);
                $sumFailed   += (int)($s['pending_failed'] ?? 0);
                $sumPoolUsed += (int)($s['pool_used'] ?? 0);
                $sumPoolSize += (int)($s['pool_size'] ?? 0);
                $maxAge       = max($maxAge, (int)($s['snapshot_age'] ?? 0));
            }

            // 13 个分片的日志按时间戳升序排,前端 _renderRtLog 靠 ts 增量渲染,
            // 不排序会因各分片 ts 交错而漏渲染。
            usort($allLogs, function ($a, $b) {
                return ($a['ts'] ?? 0) <=> ($b['ts'] ?? 0);
            });
            // 日志总量控制:13 进程合起来可能很多,只留最近 800 条
            if (count($allLogs) > 800) {
                $allLogs = array_slice($allLogs, -800);
            }

            ok([
                'available'      => true,
                'multi_shard'    => true,
                'shard_count'    => count($shards),
                'snapshot_age'   => $maxAge,           // 取最旧的一片
                'queue_size'     => $sumQueue,
                'active_workers' => $sumActive,
                'total_workers'  => $sumTotal,
                'pending_failed' => $sumFailed,
                'pool_used'      => $sumPoolUsed,
                'pool_size'      => $sumPoolSize,
                'workers'        => $allWorkers,       // 全部分片的 worker(带 shard 字段)
                'logs'           => $allLogs,          // 全部分片的日志(带[分片N]前缀)
                'mysql'          => $mysql,
                'shards'         => $shards,           // 每个分片的完整明细
            ]);
        }

        // ── 紧急公告广播：触发 announce_broadcast.py ──────────────────────
        case 'announce.broadcast': {
            $text = trim((string)p('text', ''));
            if ($text === '') err('公告文本不能为空');
            if (mb_strlen($text) > 1000) err('公告过长（>1000 字），微信单次推送不建议这么长');

            // 防重复触发：如已有 running 任务，拒绝再发
            $rowP = $db->query(
                "SELECT config_value FROM system_config WHERE config_key='' LIMIT 1"
            )->fetch();
            if ($rowP && !empty($rowP['config_value'])) {
                $prog = json_decode($rowP['config_value'], true);
                if (is_array($prog) && in_array(($prog['status'] ?? ''), ['loading', 'running'], true)) {
                    $age = time() - (int)($prog['updated_at'] ?? 0);
                    // 进度 30s 内更新过，视为还在跑
                    if ($age < 30) {
                        err('已有广播任务正在运行，请等其完成或超时（30s 无更新视为僵死）');
                    }
                }
            }

            // 1) 写任务到 DB（脚本通过 --from-db 读取）
            $job_id = 'job-' . date('YmdHis') . '-' . substr(md5(uniqid('', true)), 0, 6);
            $job_payload = json_encode([
                'job_id'     => $job_id,
                'text'       => $text,
                'created_at' => time(),
                'created_by' => $user['username'] ?? 'admin',
            ], JSON_UNESCAPED_UNICODE);

            $stmt = $db->prepare(
                "INSERT INTO system_config (config_key, config_value, remark) " .
                "VALUES ('announce_broadcast_job', ?, '紧急广播任务·admin 写入·脚本读取') " .
                "ON DUPLICATE KEY UPDATE config_value=VALUES(config_value)"
            );
            $stmt->execute([$job_payload]);

            // 2) 进度初始化（避免脚本启动延迟期间前端转空圈）
            $init_progress = json_encode([
                'job_id'     => $job_id,
                'status'     => 'pending',
                'text'       => mb_substr($text, 0, 200),
                'total'      => 0,
                'done'       => 0,
                'ok'         => 0,
                'fail'       => 0,
                'errors'     => [],
                'started_at' => time(),
                'updated_at' => time(),
            ], JSON_UNESCAPED_UNICODE);
            $stmt = $db->prepare(
                "INSERT INTO system_config (config_key, config_value, remark) " .
                "VALUES ('announce_broadcast_progress', ?, '紧急广播进度·初始化') " .
                "ON DUPLICATE KEY UPDATE config_value=VALUES(config_value)"
            );
            $stmt->execute([$init_progress]);

            // 3) 启动子进程（fire-and-forget；任何方式失败都把原因报给 admin）
            $script   = realpath(__DIR__ . '/data/announce_broadcast.py') ?: (__DIR__ . '/data/announce_broadcast.py');
            $py_bin   = 'python3';
            $log_file = __DIR__ . '/data/broadcast_' . date('Ymd_His') . '.log';  // 写日志,便于排查
            $launched = false;
            $launch_msg = '';

            // 优先 popen + nohup（PHP-FPM 下最稳定的 fire-and-forget）
            if (function_exists('popen')) {
                $cmd = sprintf(
                    'nohup %s %s --from-db --job-id %s >> %s 2>&1 &',
                    escapeshellcmd($py_bin),
                    escapeshellarg($script),
                    escapeshellarg($job_id),
                    escapeshellarg($log_file)
                );
                $h = @popen($cmd, 'r');
                if (is_resource($h)) {
                    pclose($h);
                    $launched = true;
                } else {
                    $launch_msg = 'popen 失败';
                }
            }
            // 退路 1：proc_open
            if (!$launched && function_exists('proc_open')) {
                $cmd = sprintf(
                    '%s %s --from-db --job-id %s',
                    escapeshellcmd($py_bin),
                    escapeshellarg($script),
                    escapeshellarg($job_id)
                );
                $desc = [
                    0 => ['file', '/dev/null', 'r'],
                    1 => ['file', $log_file, 'a'],
                    2 => ['file', $log_file, 'a'],
                ];
                $proc = @proc_open($cmd . ' &', $desc, $pipes);
                if (is_resource($proc)) {
                    proc_close($proc);
                    $launched = true;
                } else {
                    $launch_msg .= ' / proc_open 失败';
                }
            }

            error_log(sprintf(
                "[%s][Admin][announce.broadcast] job=%s by=%s launched=%d text_len=%d",
                date('Y-m-d H:i:s'), $job_id,
                ($user['username'] ?? '?'), $launched ? 1 : 0, mb_strlen($text)
            ));

            ok([
                'job_id'     => $job_id,
                'launched'   => $launched,
                'log_file'   => $log_file,
                'launch_msg' => $launched
                    ? '子进程已派发，前端会自动跟进度。日志: ' . basename($log_file)
                    : ('PHP 无法启动子进程（' . trim($launch_msg, ' /') . '），'
                        . '请在服务器上手动执行：python3 ' . $script . ' --from-db --job-id ' . $job_id),
            ], $launched ? '已派发' : '任务已写入但需手动启动脚本');
        }

        case 'announce.progress': {
            $row = $db->query(
                "SELECT config_value FROM system_config WHERE config_key='' LIMIT 1"
            )->fetch();
            if (!$row || empty($row['config_value'])) {
                ok(['available' => false]);
            }
            $p = json_decode($row['config_value'], true);
            if (!is_array($p)) ok(['available' => false]);
            $p['available']  = true;
            $p['stale_secs'] = time() - (int)($p['updated_at'] ?? 0);
            ok($p);
        }

        // ════════════════════════════════════════════════════════════════
        // 520 抽奖管理 (v14.0 · 2026-05-19)
        // ════════════════════════════════════════════════════════════════
        case 'lottery_520_list': {
            // tab: balance(余额奖)/ cash(现金)/ milktea(奶茶);默认 balance
            $tab = p('tab', 'balance');
            $typeWhere = "''";
            if ($tab === 'balance') $typeWhere = "'balance_520','balance_188'";
            else if ($tab === 'cash')    $typeWhere = "'cash'";
            else if ($tab === 'milktea') $typeWhere = "'milktea'";
            else err('无效 tab');

            $rows = $db->query(
                "SELECT l.id, l.user_id, l.prize_type, l.prize_amount,
                        l.phone, l.realname, l.status, l.created_at, l.paid_at,
                        u.username
                   FROM lottery_520 l
                   LEFT JOIN users u ON u.id = l.user_id
                  WHERE l.prize_type IN ($typeWhere)
                  ORDER BY l.status ASC, l.created_at DESC
                  LIMIT 500"
            )->fetchAll();

            // 统计
            $stats = ['balance'=>['pending'=>0,'paid'=>0],'cash'=>['pending'=>0,'paid'=>0],
                      'milktea'=>['pending'=>0,'paid'=>0],'thanks'=>['pending'=>0,'paid'=>0]];
            $countRows = $db->query("SELECT prize_type, status, COUNT(*) AS c
                                       FROM lottery_520 GROUP BY prize_type, status")->fetchAll();
            foreach ($countRows as $r) {
                $grp = in_array($r['prize_type'], ['balance_520','balance_188'], true) ? 'balance'
                     : ($r['prize_type'] === 'thanks' ? 'thanks'
                     : $r['prize_type']);
                if (isset($stats[$grp])) $stats[$grp][$r['status']] += (int)$r['c'];
            }

            ok(['rows' => $rows, 'stats' => $stats]);
        }

        case 'lottery_520_mark_paid': {
            $id = (int)p('id', 0);
            if (!$id) err('缺少 id');

            $r = $db->prepare("SELECT user_id, prize_type, prize_amount, status FROM lottery_520 WHERE id = ?");
            $r->execute([$id]);
            $row = $r->fetch();
            if (!$row)                       err('记录不存在');
            if ($row['status'] === 'paid')   err('已是 paid 状态');
            if ($row['prize_type'] === 'cash' && !$db->prepare("SELECT phone FROM lottery_520 WHERE id=?")) err('cash 必须有 phone');

            // cash 必须填了手机号
            $cashChk = $db->prepare("SELECT phone, realname FROM lottery_520 WHERE id=?");
            $cashChk->execute([$id]);
            $cashRow = $cashChk->fetch();
            if ($row['prize_type'] === 'cash' && (empty($cashRow['phone']) || empty($cashRow['realname']))) {
                err('该用户还没填手机号 / 实名,不能标记');
            }

            $db->beginTransaction();
            try {
                // 余额奖:实际加用户余额
                if (in_array($row['prize_type'], ['balance_520','balance_188'], true)) {
                    $upd = $db->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                    $upd->execute([$row['prize_amount'], $row['user_id']]);
                }
                // 标记 paid
                $upd2 = $db->prepare("UPDATE lottery_520 SET status='paid', paid_at=NOW() WHERE id = ?");
                $upd2->execute([$id]);
                $db->commit();
            } catch (Exception $e) {
                $db->rollBack();
                err('标记失败: ' . $e->getMessage());
            }
            ok(['ok' => true]);
        }

        case 'lottery_520_mark_unpaid': {
            $id = (int)p('id', 0);
            if (!$id) err('缺少 id');

            $r = $db->prepare("SELECT user_id, prize_type, prize_amount, status FROM lottery_520 WHERE id = ?");
            $r->execute([$id]);
            $row = $r->fetch();
            if (!$row)                            err('记录不存在');
            if ($row['status'] !== 'paid')        err('当前状态不是 paid');

            $db->beginTransaction();
            try {
                if (in_array($row['prize_type'], ['balance_520','balance_188'], true)) {
                    $upd = $db->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
                    $upd->execute([$row['prize_amount'], $row['user_id']]);
                }
                $upd2 = $db->prepare("UPDATE lottery_520 SET status='pending', paid_at=NULL WHERE id = ?");
                $upd2->execute([$id]);
                $db->commit();
            } catch (Exception $e) {
                $db->rollBack();
                err('撤回失败: ' . $e->getMessage());
            }
            ok(['ok' => true]);
        }

        default:
            err('未知 action: ' . $action);
        }
    } catch (Exception $e) {
        err('服务器异常：' . $e->getMessage(), 500);
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台 · Cloud Love</title>
    <link rel="icon" href="image/logo-3.png" type="image/png">
    <link rel="stylesheet" href="icons/material-symbols.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body { background: #f6f7f9; }
        .admin-layout { display: flex; min-height: 100vh; }

        /* 侧栏 */
        .admin-sidebar {
            width: 220px; background: #1a1a1a; color: #ddd;
            padding: 20px 12px; flex-shrink: 0;
            position: fixed; top: 0; bottom: 0; left: 0;
        }
        .admin-brand { display: flex; align-items: center; gap: 10px; padding: 0 12px 20px; border-bottom: 1px solid rgba(255,255,255,0.08); margin-bottom: 16px; }
        .admin-brand img { width: 32px; height: 32px; border-radius: 8px; }
        .admin-brand strong { color: #fff; font-size: 1rem; }
        .admin-brand span { font-size: 0.75rem; color: #888; display: block; }

        .admin-nav-item {
            display: flex; align-items: center; gap: 10px;
            padding: 10px 12px; border-radius: 8px; cursor: pointer;
            color: #bbb; font-size: 0.92rem; transition: 0.2s; user-select: none;
            margin-bottom: 2px;
        }
        .admin-nav-item:hover { background: rgba(255,255,255,0.05); color: #fff; }
        .admin-nav-item.active { background: #7367f0; color: #fff; }
        .admin-nav-item .material-symbols-rounded { font-size: 18px; }

        .admin-sidebar-footer {
            position: absolute; bottom: 16px; left: 12px; right: 12px;
            padding: 12px; border-top: 1px solid rgba(255,255,255,0.08);
            display: flex; align-items: center; gap: 10px; font-size: 0.85rem; color: #888;
        }
        .admin-sidebar-footer a { color: #8b7fff; text-decoration: none; }

        /* 主体 */
        .admin-main {
            margin-left: 220px; flex: 1; padding: 24px 32px;
        }
        .admin-tab { display: none; }
        .admin-tab.active { display: block; animation: fadeIn 0.3s; }

        .tab-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 20px;
        }
        .tab-header h2 { font-size: 1.5rem; font-weight: 700; color: #111; }
        .tab-header .tab-actions { display: flex; gap: 8px; align-items: center; }

        /* 表格 */
        .data-table-wrap {
            background: #fff; border-radius: 12px; overflow: hidden;
            border: 1px solid rgba(0,0,0,0.05);
            box-shadow: 0 4px 16px rgba(0,0,0,0.02);
        }
        .data-table { width: 100%; border-collapse: collapse; font-size: 0.88rem; }
        .data-table thead { background: #fafafa; }
        .data-table th {
            text-align: left; padding: 12px 16px; font-weight: 600;
            color: #555; border-bottom: 1px solid rgba(0,0,0,0.05);
            font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.5px;
        }
        .data-table td {
            padding: 12px 16px; border-bottom: 1px solid rgba(0,0,0,0.04);
            color: #333; vertical-align: middle;
        }
        .data-table tr:last-child td { border-bottom: 0; }
        .data-table tr:hover { background: #fafbfc; }
        .data-table .row-actions { display: flex; gap: 6px; }

        /* 标签 */
        .tag {
            display: inline-block; padding: 2px 8px; border-radius: 6px;
            font-size: 0.72rem; font-weight: 600; line-height: 1.4;
        }
        .tag-free  { background: #e8f5e9; color: #2e7d32; }
        .tag-pro   { background: #fff8e1; color: #f57f17; }
        .tag-running { background: #e8f5e9; color: #2e7d32; }
        .tag-stopped { background: #ffebee; color: #c62828; }
        .tag-success { background: #e8f5e9; color: #2e7d32; }
        .tag-pending { background: #fff8e1; color: #f57f17; }
        .tag-danger  { background: #ffebee; color: #c62828; }
        .tag-failed  { background: #ffebee; color: #c62828; }

        .btn-mini {
            padding: 4px 10px; font-size: 0.78rem; border-radius: 6px;
            border: 1px solid #ddd; background: #fff; color: #333;
            cursor: pointer; font-family: inherit; transition: 0.15s;
        }
        .btn-mini:hover { background: #f0f0f0; border-color: #bbb; }
        .btn-mini.danger { color: #c62828; border-color: #ffcdd2; }
        .btn-mini.danger:hover { background: #ffebee; }
        .btn-mini.primary { background: #7367f0; color: #fff; border-color: #7367f0; }
        .btn-mini.primary:hover { background: #5e52d6; }

        /* 搜索栏 */
        .search-box {
            display: flex; gap: 8px; align-items: center;
            background: #fff; border: 1px solid #e5e7eb; border-radius: 8px;
            padding: 4px 12px; height: 36px;
        }
        .search-box input {
            border: 0; outline: 0; font-size: 0.88rem;
            min-width: 200px; font-family: inherit;
        }
        .search-box select {
            border: 0; outline: 0; background: transparent;
            font-size: 0.85rem; font-family: inherit; cursor: pointer;
        }

        /* 概览卡片 */
        .stat-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }
        .stat-card {
            background: #fff; border-radius: 12px; padding: 20px;
            border: 1px solid rgba(0,0,0,0.05);
            box-shadow: 0 4px 16px rgba(0,0,0,0.02);
        }
        .stat-card .label { font-size: 0.85rem; color: #777; margin-bottom: 8px; }
        .stat-card .value { font-size: 2rem; font-weight: 800; color: #111; }
        .stat-card .delta { font-size: 0.78rem; color: #888; margin-top: 6px; }
        .stat-card .delta strong { color: #28a745; }

        /* 弹窗 */
        .admin-modal-overlay {
            position: fixed; inset: 0; background: rgba(0,0,0,0.4);
            z-index: 9000; display: none; justify-content: center; align-items: center;
        }
        .admin-modal-overlay.active { display: flex; }
        .admin-modal {
            background: #fff; border-radius: 16px; width: 90%; max-width: 600px;
            max-height: 88vh; overflow-y: auto; padding: 24px 28px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
        }
        .admin-modal-large { max-width: 800px; }
        .admin-modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid rgba(0,0,0,0.06); }
        .admin-modal-title { font-size: 1.15rem; font-weight: 700; color: #111; }
        .admin-modal-close { font-size: 22px; color: #999; cursor: pointer; }
        .admin-modal-close:hover { color: #000; }

        .form-row { display: flex; gap: 12px; margin-bottom: 12px; }
        .form-row .form-group { flex: 1; margin-bottom: 0; }

        .form-group label { display: block; font-size: 0.85rem; font-weight: 600; color: #444; margin-bottom: 6px; }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 8px 12px; font-size: 0.88rem;
            border: 1px solid #d1d5db; border-radius: 6px; outline: 0;
            font-family: inherit; transition: 0.15s; box-sizing: border-box;
        }
        .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
            border-color: #7367f0; box-shadow: 0 0 0 3px rgba(115,103,240,0.1);
        }
        .form-group .hint { font-size: 0.75rem; color: #888; margin-top: 4px; }

        .modal-footer { display: flex; justify-content: flex-end; gap: 8px; margin-top: 20px; padding-top: 16px; border-top: 1px solid rgba(0,0,0,0.06); }

        /* 配置分组 */
        .config-group { margin-bottom: 24px; background: #fff; padding: 20px; border-radius: 12px; border: 1px solid rgba(0,0,0,0.05); }
        .config-group h3 { font-size: 1rem; font-weight: 700; color: #111; margin-bottom: 12px; padding-bottom: 8px; border-bottom: 1px solid rgba(0,0,0,0.06); }
        .config-row {
            display: grid; grid-template-columns: 220px 1fr 200px auto;
            gap: 12px; align-items: center; padding: 8px 0;
        }
        .config-row .config-key { font-family: ui-monospace, Menlo, monospace; font-size: 0.82rem; color: #555; }
        .config-row input { font-size: 0.85rem; padding: 6px 10px; }
        .config-row .config-remark { font-size: 0.75rem; color: #888; }

        /* 分页 */
        .pagination { display: flex; justify-content: center; gap: 8px; margin-top: 16px; align-items: center; font-size: 0.85rem; color: #666; }
        .pagination button { padding: 4px 10px; border: 1px solid #ddd; background: #fff; border-radius: 6px; cursor: pointer; font-family: inherit; }
        .pagination button:disabled { opacity: 0.4; cursor: not-allowed; }
        .pagination button:not(:disabled):hover { background: #f5f5f5; }

        .empty-state { padding: 60px 20px; text-align: center; color: #999; font-size: 0.9rem; }

        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

        /* Toast */
        #global-toast {
            position: fixed; top: 24px; right: 24px;
            padding: 12px 20px; border-radius: 8px; background: #1a1a1a; color: #fff;
            font-size: 0.88rem; box-shadow: 0 8px 24px rgba(0,0,0,0.18);
            opacity: 0; transform: translateX(20px); transition: all 0.25s; z-index: 99999;
            pointer-events: none;
        }
        #global-toast.show { opacity: 1; transform: translateX(0); }
        #global-toast.toast-error { background: #d32f2f; }
        #global-toast.toast-success { background: #2e7d32; }

        /* ==== 用户留言（精简） ==== */
        .nav-badge {
            background: #d32f2f; color: #fff;
            font-size: 0.68rem; font-weight: 700;
            padding: 0 6px; min-width: 18px; height: 18px;
            border-radius: 9px;
            display: inline-flex; align-items: center; justify-content: center;
            margin-left: auto;
        }
        .msg-cell-content { max-width: 480px; font-size: 0.85rem; line-height: 1.6; }
        .msg-cell-content .my-msg {
            background: #f3f4f6; padding: 8px 12px;
            border-radius: 8px 8px 8px 2px;
            display: inline-block; max-width: 100%;
            word-break: break-word; white-space: pre-wrap;
        }
        .msg-cell-content .reply-msg {
            background: #fff; border: 1px solid #d0d7de;
            padding: 8px 12px; border-radius: 8px 8px 2px 8px;
            display: block; margin-top: 6px; max-width: 100%;
            color: #444; font-size: 0.82rem;
            word-break: break-word; white-space: pre-wrap;
        }
        .msg-cell-content .reply-msg::before { content: '↳ '; color: #7367f0; font-weight: 700; }
        .msg-stats-bar .stat-item.pending strong { color: #e67700; }
        .msg-stats-bar .stat-item.replied strong { color: #2e7d32; }

        .msg-cell-content {
            max-width: 480px;
            font-size: 0.85rem;
            line-height: 1.6;
            color: #333;
        }
        .msg-cell-content .my-msg {
            background: #f3f4f6;
            padding: 8px 12px;
            border-radius: 8px 8px 8px 2px;
            display: inline-block;
            max-width: 100%;
            word-break: break-word;
            white-space: pre-wrap;
        }
        .msg-cell-content .reply-msg {
            background: #fff;
            border: 1px solid #d0d7de;
            padding: 8px 12px;
            border-radius: 8px 8px 2px 8px;
            display: block;
            margin-top: 6px;
            max-width: 100%;
            color: #444;
            font-size: 0.82rem;
            word-break: break-word;
            white-space: pre-wrap;
        }
        .msg-cell-content .reply-msg::before {
            content: '↳ ';
            color: #7367f0;
            font-weight: 700;
        }

        /* 移动端兜底 */
        @media (max-width: 900px) {
            .admin-sidebar { width: 60px; padding: 12px 6px; }
            .admin-nav-item span:not(.material-symbols-rounded) { display: none; }
            .admin-brand strong, .admin-brand span { display: none; }
            .admin-sidebar-footer { display: none; }
            .admin-main { margin-left: 60px; padding: 16px; }
            .stat-grid { grid-template-columns: repeat(2, 1fr); }
            .config-row { grid-template-columns: 1fr; gap: 4px; padding: 12px 0; border-bottom: 1px solid rgba(0,0,0,0.04); }
        }

        /* 移动端深度优化(v5 · 2026-05-07) ─────────────────────────── */
        @media (max-width: 768px) {
            /* 顶部 tab-header 横向超出 → 换行 + 间距收紧 */
            .tab-header {
                flex-direction: column; align-items: flex-start; gap: 10px;
            }
            .tab-actions {
                display: flex; flex-wrap: wrap; gap: 6px; width: 100%;
            }
            .tab-actions .btn-mini {
                flex: 1 1 auto; min-width: 0;   /* 允许按钮收缩,长文字会自动换行 */
                white-space: normal; line-height: 1.3;
                padding: 8px 10px;
            }

            /* 数据表格:横向滚动而不是挤变形 */
            .data-table-wrap { overflow-x: auto; -webkit-overflow-scrolling: touch; }
            .data-table { min-width: 600px; font-size: 0.78rem; }
            .data-table th, .data-table td { padding: 8px 6px; }

            /* 弹窗:上下贴边,form-row 改为单列堆叠,避免水平拥挤 */
            .admin-modal { width: 95vw; max-width: 95vw; max-height: 92vh; padding: 16px; }
            .admin-modal .form-row {
                flex-direction: column; gap: 10px;
            }
            .admin-modal .form-row .form-group {
                flex: 1 1 100%;
            }
            .admin-modal .form-group input,
            .admin-modal .form-group select,
            .admin-modal .form-group textarea {
                font-size: 16px;   /* iOS 防止聚焦时缩放 */
            }

            /* modal-footer 按钮换行 */
            .modal-footer {
                flex-wrap: wrap; gap: 8px;
            }
            .modal-footer .btn-mini {
                flex: 1 1 calc(50% - 4px); justify-content: center;
            }

            /* 主内容内边距收一点 */
            .admin-main { padding: 12px; }
            h2 { font-size: 1.1rem; margin: 0 0 8px; }

            /* 用户管理"快速调整"那种 form-row 在 768 也堆叠 */
            #tab-users .form-row { flex-direction: column; }
            #tab-users .form-row .form-group { flex: 1 1 100%; width: 100%; }

            /* 系统配置项的 secret 标记符号小一点 */
            .config-key { font-size: 0.82rem; word-break: break-all; }
        }

        /* 超小屏(380px,大多数 5.5 寸竖屏) */
        @media (max-width: 480px) {
            .stat-grid { grid-template-columns: 1fr; }
            .data-table { min-width: 540px; font-size: 0.76rem; }
            .admin-modal { padding: 14px; border-radius: 10px; }
            .admin-modal-title { font-size: 0.95rem; }
        }

        /* v8.6 (2026-05-10) toggle 开关 — 白色极简风 */
        .toggle-switch input[type="checkbox"] {
            display: none;
        }
        .toggle-slider {
            position: relative;
            width: 44px;
            height: 24px;
            background: #e5e7eb;
            border-radius: 12px;
            transition: background-color 0.18s ease;
        }
        .toggle-slider::after {
            content: "";
            position: absolute;
            top: 2px;
            left: 2px;
            width: 20px;
            height: 20px;
            background: #fff;
            border-radius: 50%;
            transition: transform 0.18s ease;
            box-shadow: 0 1px 2px rgba(0,0,0,0.18);
        }
        .toggle-switch input[type="checkbox"]:checked + .toggle-slider {
            background: #dc2626;
        }
        .toggle-switch input[type="checkbox"]:checked + .toggle-slider::after {
            transform: translateX(20px);
        }
        /* ===== v15.0 (2026-06-28) Dashboard 视觉重设计 ─ 无颜色条 · 数据导向 ===== */
        /* 全屏看板模式 ─ 隐藏侧栏,主体占满 */
        body.dashboard-fullscreen { overflow-x: hidden; }
        body.dashboard-fullscreen .admin-sidebar { display: none !important; }
        body.dashboard-fullscreen .admin-main { margin-left: 0; padding: 14px 22px; }
        body.dashboard-fullscreen #tab-dashboard .dash-charts canvas { max-height: 220px !important; }
        body.dashboard-fullscreen #tab-dashboard .rt-monitor { margin-top: 14px; }

        /* 全屏切换按钮 ─ v15.3:简化为图标 */
        .dash-fs-btn {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 7px 10px; border-radius: 8px;
            background: #0f172a; color: #fff; border: 1px solid #0f172a;
            cursor: pointer; font-family: inherit; font-size: 0.84rem;
            font-weight: 600; transition: all 0.15s ease;
            user-select: none;
        }
        .dash-fs-btn:hover { background: #1e293b; transform: translateY(-1px); }
        .dash-fs-btn .material-symbols-rounded { font-size: 18px; }
        body.dashboard-fullscreen .dash-fs-btn {
            background: #f1f5f9; color: #0f172a; border-color: #e2e8f0;
        }
        body.dashboard-fullscreen .dash-fs-btn:hover { background: #e2e8f0; }

        /* v15.2:提示音权限按钮 ─ v15.3 简化为图标(同时管订单 + 异常告警) */
        .audio-perm-btn {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 7px 10px; border-radius: 8px;
            cursor: pointer; font-family: inherit; font-size: 0.84rem;
            font-weight: 600; transition: all 0.15s ease;
            user-select: none; border: 1px solid transparent;
        }
        .audio-perm-btn .material-symbols-rounded { font-size: 18px; }
        .audio-perm-btn.pending {
            background: #fef3c7; color: #92400e;
            border-color: #fcd34d;
            animation: audioPermPulse 1.8s ease-in-out infinite;
        }
        .audio-perm-btn.pending:hover { background: #fde68a; transform: translateY(-1px); }
        @keyframes audioPermPulse {
            0%, 100% { box-shadow: 0 0 0 0 rgba(245, 158, 11, 0); }
            50%      { box-shadow: 0 0 0 8px rgba(245, 158, 11, 0.18); }
        }
        .audio-perm-btn.granted {
            background: #dcfce7; color: #15803d;
            border-color: #86efac;
            cursor: default;
            animation: none;
        }
        .audio-perm-btn.granted:hover { background: #dcfce7; transform: none; }
        .audio-perm-btn.warn {
            background: #fee2e2; color: #b91c1c;
            border-color: #fca5a5;
            animation: audioPermPulse 1.8s ease-in-out infinite;
        }
        .audio-perm-btn.warn:hover { background: #fecaca; transform: translateY(-1px); }

        /* v15.3:右上角按钮只显示图标(label 隐藏,tooltip 走 title 属性) */
        .audio-perm-btn .btn-label,
        .dash-fs-btn .btn-label { display: none; }

        /* 订单告警(绿色)─ v15.3:从红色改成绿色,与异常告警(红色)区分 */
        .order-alert-overlay {
            position: fixed; inset: 0;
            border: 6px solid #16a34a;
            pointer-events: none;
            z-index: 9997;  /* 比异常告警低一级 */
            display: none;
            box-shadow: inset 0 0 80px rgba(22, 163, 74, 0.4);
            animation: orderFlash 0.9s ease-in-out infinite;
        }
        .order-alert-overlay.active { display: block; }
        @keyframes orderFlash {
            0%, 100% { opacity: 0.35; }
            50%      { opacity: 1; }
        }
        .order-alert-banner {
            position: fixed;
            top: 22px; left: 50%; transform: translateX(-50%);
            display: none; align-items: center; gap: 16px;
            background: #fff;
            border: 2px solid #16a34a;
            border-radius: 14px;
            padding: 14px 22px;
            box-shadow: 0 14px 44px rgba(22, 163, 74, 0.3),
                        0 4px 12px rgba(0, 0, 0, 0.08);
            z-index: 9998;
            animation: orderBannerIn 0.3s ease;
            min-width: 320px;
        }
        .order-alert-banner.active { display: inline-flex; }
        @keyframes orderBannerIn {
            from { opacity: 0; transform: translate(-50%, -12px); }
            to   { opacity: 1; transform: translate(-50%, 0); }
        }
        .order-alert-banner .oab-icon {
            font-size: 30px; color: #16a34a;
            animation: oabBell 0.55s ease-in-out infinite;
            flex-shrink: 0;
        }
        @keyframes oabBell {
            0%, 100% { transform: rotate(0); }
            25%      { transform: rotate(-14deg); }
            75%      { transform: rotate(14deg); }
        }
        .order-alert-banner .oab-text {
            display: flex; flex-direction: column; gap: 3px; flex: 1;
        }
        .order-alert-banner .oab-title {
            font-size: 0.98rem; font-weight: 700; color: #0f172a;
            letter-spacing: -0.005em;
        }
        .order-alert-banner .oab-sub {
            font-size: 0.76rem; color: #64748b; font-variant-numeric: tabular-nums;
        }
        .order-alert-banner .oab-btn {
            background: #16a34a; color: #fff; border: 0;
            padding: 9px 20px; border-radius: 9px;
            font-family: inherit; font-weight: 700;
            cursor: pointer; transition: 0.15s;
            font-size: 0.86rem; letter-spacing: 0.02em;
            white-space: nowrap;
        }
        .order-alert-banner .oab-btn:hover {
            background: #15803d; transform: translateY(-1px);
        }
        .order-alert-banner .oab-btn:active { transform: translateY(0); }

        /* v15.3:异常告警(红色)─ HTTP 403/405/500 触发,1 分钟超 12 条循环 */
        .error-alert-overlay {
            position: fixed; inset: 0;
            border: 6px solid #dc2626;
            pointer-events: none;
            z-index: 9999;
            display: none;
            box-shadow: inset 0 0 80px rgba(220, 38, 38, 0.45);
            animation: errorFlash 0.9s ease-in-out infinite;
        }
        .error-alert-overlay.active { display: block; }
        .error-alert-overlay.loop {
            border-width: 8px;
            animation: errorFlash 0.5s ease-in-out infinite;
        }
        @keyframes errorFlash {
            0%, 100% { opacity: 0.3; }
            50%      { opacity: 1; }
        }
        .error-alert-banner {
            position: fixed;
            top: 22px; left: 50%; transform: translateX(-50%);
            display: none; align-items: center; gap: 16px;
            background: #fff;
            border: 2px solid #dc2626;
            border-radius: 14px;
            padding: 14px 22px;
            box-shadow: 0 14px 44px rgba(220, 38, 38, 0.35),
                        0 4px 12px rgba(0, 0, 0, 0.08);
            z-index: 10000;
            animation: orderBannerIn 0.3s ease;
            min-width: 360px;
        }
        .error-alert-banner.active { display: inline-flex; }
        .error-alert-banner .ebn-icon {
            font-size: 32px; color: #dc2626;
            animation: ebnSiren 0.4s ease-in-out infinite;
            flex-shrink: 0;
        }
        @keyframes ebnSiren {
            0%, 100% { opacity: 1; transform: scale(1); }
            50%      { opacity: 0.4; transform: scale(0.9); }
        }
        .error-alert-banner .ebn-text {
            display: flex; flex-direction: column; gap: 3px; flex: 1;
            min-width: 0;
        }
        .error-alert-banner .ebn-title {
            font-size: 0.98rem; font-weight: 700; color: #0f172a;
            letter-spacing: -0.005em;
        }
        .error-alert-banner.loop .ebn-title::after {
            content: ' · 循环告警中';
            color: #dc2626; font-weight: 700;
            margin-left: 4px;
        }
        .error-alert-banner .ebn-sub {
            font-size: 0.76rem; color: #64748b; font-variant-numeric: tabular-nums;
            overflow: hidden; text-overflow: ellipsis;
            font-family: 'JetBrains Mono', Consolas, monospace;
        }
        .error-alert-banner .ebn-btn {
            background: #dc2626; color: #fff; border: 0;
            padding: 9px 20px; border-radius: 9px;
            font-family: inherit; font-weight: 700;
            cursor: pointer; transition: 0.15s;
            font-size: 0.86rem; letter-spacing: 0.02em;
            white-space: nowrap;
        }
        .error-alert-banner .ebn-btn:hover {
            background: #b91c1c; transform: translateY(-1px);
        }

        /* v15.3:异常告警列表 ─ 日志中提取的 HTTP 错误码记录 */
        .exception-card {
            background: #fff;
            border: 1px solid #ecedf0;
            border-radius: 12px;
            overflow: hidden;
            margin-bottom: 6px;
        }
        .exception-card.has-recent { border-color: #fca5a5; }
        .exception-card.has-recent.loop { animation: excCardBreathe 1.2s ease-in-out infinite; }
        @keyframes excCardBreathe {
            0%, 100% { box-shadow: 0 0 0 0 rgba(220, 38, 38, 0); }
            50%      { box-shadow: 0 0 0 4px rgba(220, 38, 38, 0.15); }
        }
        .exception-list {
            max-height: 200px;
            overflow-y: auto;
        }
        .exception-item {
            display: grid;
            grid-template-columns: 78px 58px 1fr auto;
            align-items: center;
            gap: 12px;
            padding: 9px 14px;
            border-bottom: 1px solid #f1f5f9;
            font-size: 0.78rem;
        }
        .exception-item:last-child { border-bottom: 0; }
        .exception-item:hover { background: #fafbfc; }
        .exception-item .exc-time {
            color: #94a3b8;
            font-family: 'JetBrains Mono', Consolas, monospace;
            font-size: 0.72rem;
            font-variant-numeric: tabular-nums;
        }
        .exception-item .exc-code {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: #fef2f2;
            color: #b91c1c;
            font-weight: 700;
            border-radius: 5px;
            padding: 2px 0;
            font-family: 'JetBrains Mono', Consolas, monospace;
            font-size: 0.76rem;
            border: 1px solid #fecaca;
        }
        .exception-item.code-405 .exc-code { background: #fffbeb; color: #b45309; border-color: #fde68a; }
        .exception-item.code-403 .exc-code { background: #fef3c7; color: #a16207; border-color: #fcd34d; }
        .exception-item .exc-msg {
            color: #334155;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-family: 'JetBrains Mono', Consolas, monospace;
            font-size: 0.74rem;
            min-width: 0;
        }
        .exception-item .exc-shard {
            font-size: 0.68rem;
            color: #7367f0;
            background: #eeecfe;
            padding: 1px 6px;
            border-radius: 4px;
            font-weight: 600;
            white-space: nowrap;
        }
        .exception-empty {
            padding: 24px 16px;
            text-align: center;
            color: #94a3b8;
            font-size: 0.82rem;
            line-height: 1.6;
        }
        .exception-empty .hint { color: #cbd5e1; font-size: 0.74rem; margin-top: 3px; display: block; }
        .exception-footer {
            display: flex; align-items: center; justify-content: space-between;
            padding: 6px 12px;
            background: #fafbfc;
            border-top: 1px solid #f1f5f9;
            font-size: 0.72rem;
            color: #94a3b8;
        }
        .exc-clear-btn {
            display: inline-flex; align-items: center; gap: 4px;
            background: transparent;
            border: 1px solid #e2e8f0;
            color: #64748b;
            cursor: pointer;
            padding: 3px 10px;
            border-radius: 6px;
            font-family: inherit;
            font-size: 0.72rem;
            transition: 0.15s;
        }
        .exc-clear-btn:hover { color: #b91c1c; border-color: #fca5a5; background: #fef2f2; }
        .exc-clear-btn .material-symbols-rounded { font-size: 14px; }

        /* 异常告警 ─ 区块标题处的速率徽章 */
        .exc-rate-badge {
            display: inline-flex; align-items: center;
            background: #f1f5f9;
            color: #475569;
            padding: 2px 9px;
            border-radius: 999px;
            font-size: 0.7rem;
            font-weight: 600;
            font-variant-numeric: tabular-nums;
            letter-spacing: 0;
            text-transform: none;
        }
        .exc-rate-badge.warn { background: #fef3c7; color: #92400e; }
        .exc-rate-badge.crit {
            background: #fee2e2; color: #b91c1c;
            animation: excRatePulse 1s ease-in-out infinite;
        }
        @keyframes excRatePulse {
            0%, 100% { transform: scale(1); }
            50%      { transform: scale(1.08); }
        }

        /* 分区小标题:用作 stat-grid / sys-status-grid / charts 之间的语义分隔 */
        .dash-section-title {
            font-size: 0.7rem; font-weight: 600; color: #94a3b8;
            text-transform: uppercase; letter-spacing: 0.09em;
            margin: 18px 2px 10px; display: flex; align-items: center; gap: 10px;
        }
        .dash-section-title::after {
            content: ''; flex: 1; height: 1px;
            background: linear-gradient(90deg, #e8eaee 0%, transparent 80%);
        }
        .dash-section-title .sec-meta {
            font-size: 0.7rem; color: #cbd5e1; text-transform: none;
            letter-spacing: 0; font-weight: 500;
        }

        /* 主统计卡片 ─ 干净、可悬停、无装饰条 */
        .stat-grid.compact {
            gap: 12px; margin-bottom: 6px;
            grid-template-columns: repeat(6, 1fr);
        }
        .stat-grid.compact .stat-card {
            padding: 14px 16px;
            border-radius: 12px;
            box-shadow: none;
            border: 1px solid #ecedf0;
            background: #fff;
            transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease;
            position: relative;
        }
        .stat-grid.compact .stat-card:hover {
            transform: translateY(-1px);
            border-color: #d4d7de;
            box-shadow: 0 6px 20px rgba(15, 23, 42, 0.05);
        }
        .stat-grid.compact .stat-card .label {
            font-size: 0.72rem; color: #64748b;
            margin-bottom: 8px; font-weight: 500;
            display: flex; align-items: center; gap: 6px;
        }
        .stat-grid.compact .stat-card .label .material-symbols-rounded {
            font-size: 15px; color: #94a3b8;
        }
        .stat-grid.compact .stat-card .value {
            font-size: 1.6rem; font-weight: 700; color: #0f172a;
            line-height: 1.05; font-variant-numeric: tabular-nums;
            letter-spacing: -0.015em;
        }
        .stat-grid.compact .stat-card .delta {
            font-size: 0.72rem; color: #94a3b8;
            margin-top: 8px; display: flex; align-items: center; gap: 5px;
            flex-wrap: wrap;
        }
        .stat-grid.compact .stat-card .delta strong {
            color: #15803d; font-weight: 600;
            background: #ecfdf5;
            padding: 1px 7px;
            border-radius: 5px;
            font-size: 0.68rem;
            border: 1px solid #d1fae5;
        }
        .stat-grid.compact .stat-card .delta .neu {
            color: #475569; font-weight: 600;
            background: #f1f5f9;
            padding: 1px 7px; border-radius: 5px; font-size: 0.68rem;
            border: 1px solid #e2e8f0;
        }
        @media (max-width: 1100px) { .stat-grid.compact { grid-template-columns: repeat(3, 1fr); } }
        @media (max-width: 600px)  { .stat-grid.compact { grid-template-columns: repeat(2, 1fr); gap: 10px; }
                                     .stat-grid.compact .stat-card { padding: 12px 14px; }
                                     .stat-grid.compact .stat-card .value { font-size: 1.35rem; } }

        /* ───── 图表卡片 ─ 标题左侧带聚合数据,右侧带时间范围标签 ───── */
        .dash-charts {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
            margin-top: 6px;
        }
        .dash-chart-card {
            background: #fff;
            border: 1px solid #ecedf0;
            border-radius: 12px;
            padding: 16px 18px 12px;
            box-shadow: none;
        }
        .dash-chart-card .chart-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            margin-bottom: 12px;
            gap: 12px;
        }
        .dash-chart-card .chart-title-row {
            display: flex; flex-direction: column; gap: 0;
            min-width: 0;
        }
        .dash-chart-card .chart-title {
            font-size: 0.78rem;
            color: #64748b;
            font-weight: 500;
            margin: 0;
        }
        .dash-chart-card .chart-big {
            font-size: 1.55rem;
            font-weight: 700;
            color: #0f172a;
            line-height: 1.15;
            font-variant-numeric: tabular-nums;
            letter-spacing: -0.015em;
            margin-top: 4px;
        }
        .dash-chart-card .chart-sub {
            font-size: 0.72rem; color: #94a3b8;
            margin-top: 4px;
        }
        .dash-chart-card .chart-sub strong { color: #334155; font-weight: 600; }
        .dash-chart-card .chart-sub .up { color: #15803d; font-weight: 600; }
        .dash-chart-card .chart-sub .down { color: #b91c1c; font-weight: 600; }
        .dash-chart-card .chart-meta-tag {
            font-size: 0.66rem;
            color: #64748b;
            background: #f1f5f9;
            padding: 3px 9px;
            border-radius: 999px;
            white-space: nowrap;
            align-self: flex-start;
            font-weight: 500;
            letter-spacing: 0.02em;
        }
        .dash-chart-card canvas { max-width: 100%; max-height: 180px; display: block; }
        @media (max-width: 900px) {
            .dash-charts { grid-template-columns: 1fr; }
            .dash-chart-card canvas { max-height: 170px; }
        }

        /* ════════════════════════════════════════════════════════════
         * v13.12 (2026-05-14) 系统状态监控小卡 + 仪表盘紧凑化
         *   目标:仪表盘整页不滚动(尤其手机端)
         * ════════════════════════════════════════════════════════════ */
        .sys-status-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 8px;
            margin: 10px 0 14px;
        }
        .sys-card {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.06);
            border-radius: 8px;
            padding: 9px 11px;
            font-size: 0.74rem;
            color: #444;
            display: flex;
            flex-direction: column;
            gap: 2px;
            line-height: 1.4;
            min-width: 0;
        }
        .sys-card .sl { font-size: 0.66rem; color: #888; letter-spacing: 0.04em; text-transform: uppercase; }
        .sys-card .sv { font-size: 1.15rem; font-weight: 700; color: #0a0a0a; font-variant-numeric: tabular-nums; }
        .sys-card .sv.muted { color: #c0c0c0; font-weight: 500; }
        .sys-card .sh { font-size: 0.66rem; color: #999; }
        .sys-card .sh.err { color: #b91c1c; }
        .sys-card.err { background: #fef2f2; color: #b91c1c; }
        .sys-card.sys-loading { grid-column: 1/-1; text-align: center; color: #999; padding: 14px; }
        .sys-bar {
            height: 4px;
            background: rgba(0,0,0,0.08);
            border-radius: 999px;
            overflow: hidden;
            margin-top: 3px;
        }
        .sys-bar > span {
            display: block;
            height: 100%;
            background: linear-gradient(90deg, #10b981 0%, #d97706 70%, #dc2626 100%);
            border-radius: 999px;
            transition: width 0.4s ease;
        }
        /* 仪表盘紧凑:统计卡稍矮 + 图表 max-height 收 */
        /* ============ 实时运行 · 监控（白色 · 卡片网格 · 可折叠） ============ */
        .rt-monitor {
            margin: 16px 0;
            background: #ffffff;
            border: 1px solid #e8e8ee;
            border-radius: 14px;
            overflow: hidden;
        }
        .rt-head {
            display: flex; align-items: center; gap: 10px;
            padding: 13px 18px; cursor: pointer; user-select: none;
        }
        .rt-head:hover { background: #fafafc; }
        .rt-head h3 { margin: 0; font-size: 0.96rem; color: #1f2328; font-weight: 700; }
        .rt-pulse {
            width: 8px; height: 8px; border-radius: 50%;
            background: #22c55e; box-shadow: 0 0 0 0 rgba(34,197,94,.5);
            animation: rtPulse 2s infinite;
        }
        @keyframes rtPulse {
            0% { box-shadow: 0 0 0 0 rgba(34,197,94,.45); }
            70% { box-shadow: 0 0 0 6px rgba(34,197,94,0); }
            100% { box-shadow: 0 0 0 0 rgba(34,197,94,0); }
        }
        .rt-age {
            margin-left: auto; font-size: 0.76rem; color: #98a0ad; font-family: monospace;
        }
        .rt-toggle { font-size: 1.2rem; color: #b0b6c0; transition: transform .25s; }
        .rt-monitor.collapsed .rt-toggle { transform: rotate(-90deg); }
        .rt-body {
            padding: 4px 18px 18px;
            max-height: 2400px; overflow: hidden;
            transition: max-height .35s ease, padding .35s ease, opacity .25s;
        }
        .rt-monitor.collapsed .rt-body {
            max-height: 0; padding-top: 0; padding-bottom: 0; opacity: 0;
        }

        /* 核心指标：等宽卡片网格 */
        .rt-cover {
            display: grid; grid-template-columns: repeat(7, 1fr); gap: 10px;
            margin-bottom: 16px;
        }
        .rt-metric {
            background: #fafbfc; border: 1px solid #ecedf0;
            border-radius: 10px; padding: 12px 8px; text-align: center;
            transition: border-color .25s, background .25s;
        }
        .rt-metric-val {
            font-size: 1.32rem; font-weight: 800; color: #1f2328;
            font-family: 'DIN Alternate', monospace; line-height: 1.15;
        }
        .rt-metric-label { font-size: 0.7rem; color: #8a909c; margin-top: 5px; }
        .rt-metric.ok   { border-color: #b9e7c9; background: #f1faf4; }
        .rt-metric.ok   .rt-metric-val { color: #15a04a; }
        .rt-metric.warn { border-color: #f3d9a6; background: #fdf6e8; }
        .rt-metric.warn .rt-metric-val { color: #c47d10; }
        .rt-metric.crit { border-color: #efb4b4; background: #fdebeb; }
        .rt-metric.crit .rt-metric-val { color: #d63b3b; }
        .rt-metric.flash { animation: rtFlash .5s; }
        @keyframes rtFlash { 0% { background: #e3f0ff; } 100% {} }

        /* 区块小标题 */
        .rt-subhead {
            font-size: 0.8rem; font-weight: 700; color: #5b6372;
            margin: 4px 0 8px;
        }
        .rt-subhead .rt-count { color: #98a0ad; font-weight: 400; margin-left: 6px; }

        /* worker：整齐卡片网格 */
        .rt-workers {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr));
            gap: 10px; margin-bottom: 18px;
        }
        /* 分片进程明细 ─ v15.0:去掉左侧颜色条,改用顶部状态徽章 */
        .rt-shards {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 10px; margin-bottom: 18px;
        }
        .rt-shard-card {
            background: #fff;
            border: 1px solid #ecedf0;
            border-radius: 12px;
            padding: 12px 14px;
            transition: border-color 0.18s ease, transform 0.18s ease;
            position: relative;
        }
        .rt-shard-card:hover { border-color: #d4d7de; transform: translateY(-1px); }
        .rt-shard-card.off { opacity: 0.7; }

        .rt-shard-head {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 10px;
        }
        .rt-shard-name {
            font-size: 0.86rem; font-weight: 700; color: #0f172a;
            display: flex; align-items: center; gap: 6px;
        }
        .rt-shard-name .shard-tag {
            display: inline-flex; align-items: center; gap: 4px;
            font-size: 0.64rem; font-weight: 600;
            padding: 2px 7px; border-radius: 999px;
            background: #ecfdf5; color: #047857;
            letter-spacing: 0.04em;
        }
        .rt-shard-name .shard-tag::before {
            content: ''; width: 5px; height: 5px; border-radius: 50%;
            background: currentColor; box-shadow: 0 0 0 2px rgba(16,185,129,0.15);
        }
        .rt-shard-card.stale .shard-tag { background: #fffbeb; color: #b45309; }
        .rt-shard-card.stale .shard-tag::before { box-shadow: 0 0 0 2px rgba(217,119,6,0.15); }
        .rt-shard-card.off .shard-tag { background: #fef2f2; color: #b91c1c; }
        .rt-shard-card.off .shard-tag::before { box-shadow: 0 0 0 2px rgba(220,38,38,0.15); }

        .rt-shard-name .main-mark {
            font-size: 0.66rem; font-weight: 500;
            color: #7367f0; background: #eeecfe;
            padding: 1px 6px; border-radius: 4px;
        }

        .rt-shard-age { font-size: 0.7rem; color: #94a3b8; font-family: monospace; }
        .rt-shard-grid {
            display: grid; grid-template-columns: 1fr 1fr; gap: 5px 14px;
        }
        .rt-shard-kv {
            display: flex; justify-content: space-between; align-items: center;
            font-size: 0.74rem;
        }
        .rt-shard-kv .k { color: #94a3b8; }
        .rt-shard-kv .v {
            font-weight: 700; color: #0f172a;
            font-variant-numeric: tabular-nums;
        }
        .rt-shard-kv .v.busy { color: #d97706; }
        .rt-shard-kv .v.crit { color: #dc2626; }

        .rt-worker-empty {
            grid-column: 1/-1; text-align: center; color: #94a3b8;
            font-size: 0.84rem; padding: 22px 0;
            background: #fafbfc; border: 1px dashed #e2e3e9; border-radius: 12px;
        }
        /* v15.0:Worker 卡片 ─ 去掉左侧颜色条,仅靠圆点 + 阶段文字色区分状态 */
        .rt-wk {
            display: flex; align-items: center; gap: 10px;
            background: #fff;
            border: 1px solid #ecedf0;
            border-radius: 10px;
            padding: 9px 12px;
            animation: rtWkIn .3s ease;
            transition: border-color 0.18s ease, background 0.18s ease;
        }
        @keyframes rtWkIn {
            from { opacity: 0; transform: translateY(6px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        .rt-wk.leaving { animation: rtWkOut .4s ease forwards; }
        @keyframes rtWkOut { to { opacity: 0; transform: scale(.94); } }
        .rt-wk-dot {
            width: 9px; height: 9px; border-radius: 50%; flex-shrink: 0;
            background: #cbd5e1;
        }
        .rt-wk-main { min-width: 0; flex: 1; }
        .rt-wk-id {
            font-size: 0.82rem; font-weight: 700; color: #0f172a;
        }
        .rt-wk-stage {
            font-size: 0.7rem; margin-top: 2px;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
            color: #64748b;
        }
        .rt-wk-ms {
            font-size: 0.74rem; font-family: monospace; color: #94a3b8; flex-shrink: 0;
        }
        /* 状态配色(只通过圆点 + 文字色体现) */
        .rt-wk.s-think .rt-wk-dot { background: #f59e0b; box-shadow: 0 0 0 3px rgba(245,158,11,0.12); }
        .rt-wk.s-think .rt-wk-stage { color: #b8780c; font-weight: 600; }
        .rt-wk.s-tool  .rt-wk-dot { background: #8b5cf6; box-shadow: 0 0 0 3px rgba(139,92,246,0.12); }
        .rt-wk.s-tool  .rt-wk-stage { color: #6d3fd6; font-weight: 600; }
        .rt-wk.s-prep  .rt-wk-dot { background: #64748b; box-shadow: 0 0 0 3px rgba(100,116,139,0.10); }
        .rt-wk.s-prep  .rt-wk-stage { color: #5b6372; }
        .rt-wk.s-send  .rt-wk-dot { background: #22c55e; box-shadow: 0 0 0 3px rgba(34,197,94,0.12); }
        .rt-wk.s-send  .rt-wk-stage { color: #128a3e; font-weight: 600; }
        .rt-wk.s-done {
            background: #f0fdf4;
            border-color: #bbf7d0;
        }
        .rt-wk.s-done  .rt-wk-dot { background: #22c55e; box-shadow: 0 0 0 3px rgba(34,197,94,0.18); }
        .rt-wk.s-done  .rt-wk-stage { color: #128a3e; font-weight: 700; }
        /* 工作中的圆点轻微呼吸(完成态不呼吸) */
        .rt-wk:not(.s-done) .rt-wk-dot { animation: rtDot 1.6s ease-in-out infinite; }
        @keyframes rtDot { 0%,100% { opacity: 1; } 50% { opacity: .45; } }

        /* 命令行日志:白底 + 分片筛选条 */
        .rt-log-head {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 8px; flex-wrap: wrap; gap: 8px;
        }
        .rt-log-head h3 { margin: 0; font-size: 0.86rem; color: #334155; font-weight: 700; }
        .rt-log-sub { font-size: 0.72rem; color: #94a3b8; font-weight: 400; }
        .rt-log-meta { font-size: 0.74rem; color: #94a3b8; display: flex; gap: 12px; align-items: center; }
        .rt-follow { cursor: pointer; display: inline-flex; align-items: center; gap: 4px; color: #64748b; }
        .rt-follow input { accent-color: #1e293b; }

        /* v15.0:日志按分片筛选 chips */
        .rt-log-filter {
            display: flex; align-items: center; flex-wrap: wrap;
            gap: 6px; margin-bottom: 10px;
            padding: 8px 12px;
            background: #f8fafc;
            border: 1px solid #ecedf0;
            border-radius: 10px;
        }
        .rt-log-filter-label {
            font-size: 0.7rem; color: #64748b;
            font-weight: 600; margin-right: 4px;
            letter-spacing: 0.03em;
        }
        .rt-log-chip {
            font-size: 0.72rem;
            padding: 3px 11px;
            border-radius: 999px;
            background: #fff;
            border: 1px solid #e2e8f0;
            color: #475569;
            cursor: pointer;
            transition: all 0.15s ease;
            font-family: inherit;
            user-select: none;
            line-height: 1.6;
            display: inline-flex; align-items: center; gap: 4px;
        }
        .rt-log-chip:hover { background: #f1f5f9; border-color: #cbd5e1; }
        .rt-log-chip.active {
            background: #0f172a;
            border-color: #0f172a;
            color: #fff;
            font-weight: 600;
        }
        .rt-log-chip .chip-count {
            opacity: 0.65;
            font-size: 0.66rem;
            font-variant-numeric: tabular-nums;
        }
        .rt-log-chip.active .chip-count { opacity: 0.8; }

        .rt-log-box {
            background: #fafbfc; color: #475569;
            font-family: 'JetBrains Mono', 'SF Mono', Consolas, 'Liberation Mono', Menlo, monospace;
            font-size: 0.74rem; line-height: 1.7;
            border: 1px solid #ecedf0; border-radius: 10px;
            padding: 12px 14px; height: 280px; overflow-y: auto;
            white-space: pre-wrap; word-break: break-all;
        }
        .rt-log-box [data-shard].rt-log-hidden { display: none; }
        .rt-log-box .log-shard-tag {
            display: inline-block;
            font-size: 0.66rem;
            font-weight: 600;
            padding: 0 5px;
            border-radius: 3px;
            margin-right: 4px;
            background: #e6e2fd;
            color: #4a3fc0;
            font-family: inherit;
            letter-spacing: 0.02em;
        }
        @media (max-width: 900px) {
            .rt-cover { grid-template-columns: repeat(3, 1fr); }
        }
        @media (max-width: 600px) {
            .rt-cover { grid-template-columns: repeat(2, 1fr); }
        }


        /* v15.0:仪表盘移动端紧凑 */
        #tab-dashboard .dash-chart-card { padding: 14px; }
        #tab-dashboard .dash-chart-card .chart-big { font-size: 1.35rem; }
        #tab-dashboard .dash-chart-card canvas { max-height: 170px !important; }

        @media (max-width: 900px) {
            .sys-status-grid { grid-template-columns: repeat(3, 1fr); }
        }
        @media (max-width: 600px) {
            .sys-status-grid { grid-template-columns: repeat(2, 1fr); gap: 6px; }
            .sys-card { padding: 7px 9px; font-size: 0.7rem; }
            .sys-card .sv { font-size: 1rem; }
            #tab-dashboard .dash-chart-card canvas { max-height: 150px !important; }
            #tab-dashboard .dash-chart-card .chart-big { font-size: 1.2rem; }
        }
        /* ─── 论坛管理子标签 ─── */
        .forum-admin-subtabs { display: flex; gap: 8px; margin-bottom: 18px; border-bottom: 1px solid #eee; }
        .fa-subtab {
            border: 0; background: transparent; padding: 10px 4px; margin-right: 14px;
            font-size: 0.92rem; font-weight: 600; color: #888; cursor: pointer; font-family: inherit;
            border-bottom: 2px solid transparent; transition: .15s;
        }
        .fa-subtab:hover { color: #7367f0; }
        .fa-subtab.active { color: #7367f0; border-bottom-color: #7367f0; }
        .fa-sub { display: none; }
        .fa-sub.active { display: block; }
        .fa-detail-imgs { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; }
        .fa-detail-imgs img { width: 110px; height: 110px; object-fit: cover; border-radius: 8px; border: 1px solid #eee; }
        .fa-status-tag { font-size: 0.72rem; font-weight: 700; padding: 2px 9px; border-radius: 999px; white-space: nowrap; }
        .fa-status-tag.pending { background: #fff4e5; color: #b8860b; }
        .fa-status-tag.approved { background: #e7f6ec; color: #2e7d32; }
        .fa-status-tag.rejected { background: #fdecec; color: #d32f2f; }
        /* ─────────────────────────────────────────────────────────── */

        /* ===== 支付回调监控(简洁 · 收起式) ===== */
        .pay-monitor { background:#fff; border:1px solid #ececf0; border-radius:12px; margin-bottom:22px; overflow:hidden; transition:border-color .2s, background .2s; }
        .pay-monitor.has-alert { border-color:#f1c7c7; background:#fffafa; }
        .pm-bar { display:flex; align-items:center; justify-content:space-between; gap:12px; padding:13px 16px; }
        .pm-left { display:flex; align-items:center; gap:10px; min-width:0; }
        .pm-dot { width:8px; height:8px; border-radius:50%; background:#cbd5e1; flex-shrink:0; }
        .pm-dot.ok  { background:#16a34a; }
        .pm-dot.bad { background:#dc2626; animation:pmPing 1.6s ease-out infinite; }
        @keyframes pmPing { 0%{ box-shadow:0 0 0 0 rgba(220,38,38,0.45);} 70%{ box-shadow:0 0 0 7px rgba(220,38,38,0);} 100%{ box-shadow:0 0 0 0 rgba(220,38,38,0);} }
        .pm-name { font-weight:700; color:#111; font-size:0.96rem; }
        .pm-status { font-size:0.84rem; font-weight:600; color:#16a34a; }
        .pay-monitor.has-alert .pm-status { color:#dc2626; }
        .pm-ops { display:flex; gap:8px; align-items:center; flex-shrink:0; }
        .pm-btn { display:inline-flex; align-items:center; gap:4px; font-size:0.82rem; padding:6px 12px; border-radius:8px; border:1px solid #e5e7eb; background:#fff; color:#374151; cursor:pointer; transition:.15s; }
        .pm-btn:hover { background:#f7f8fa; }
        .pm-btn .material-symbols-rounded { font-size:16px; }
        .pm-btn.ghost.active { background:#eeecfe; border-color:#ded9fb; color:#5e52d6; }
        .pm-btn.danger { border-color:#fbcaca; color:#dc2626; }
        .pm-btn.danger:hover { background:#fef2f2; }

        .pm-anomaly { padding:2px 16px 14px; }
        .pm-recon { padding:14px 16px; border-top:1px solid #f0f0f3; background:#fbfbfc; }
        .pm-recon-head { display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap; margin-bottom:10px; }
        .pm-recon-title { font-weight:600; font-size:0.9rem; color:#374151; display:flex; align-items:center; gap:8px; }
        .pm-recon-ops { display:flex; gap:8px; align-items:center; }
        .pm-recon-ops select { font-size:0.82rem; padding:6px 10px; border-radius:8px; border:1px solid #e5e7eb; background:#fff; color:#374151; cursor:pointer; }

        /* 表格(异常 + 流水共用) */
        .na-table { width:100%; border-collapse:collapse; font-size:0.83rem; }
        .na-table th { text-align:left; color:#9aa1ac; font-weight:600; padding:7px 8px; border-bottom:1px solid #eef0f2; white-space:nowrap; }
        .na-table td { padding:9px 8px; border-bottom:1px solid #f4f4f6; vertical-align:top; }
        .na-table tbody tr:last-child td { border-bottom:0; }
        .na-oid { font-family:ui-monospace,Menlo,Consolas,monospace; font-size:0.76rem; color:#475569; word-break:break-all; max-width:190px; }
        .na-time { color:#6b7280; white-space:nowrap; font-size:0.78rem; }
        .na-badge { background:#fef2f2; color:#dc2626; border-radius:6px; padding:2px 8px; font-weight:700; font-size:0.76rem; white-space:nowrap; }
        .na-status { background:#f1f5f9; color:#475569; border-radius:6px; padding:2px 7px; font-size:0.75rem; }
        .na-reason { color:#374151; max-width:300px; }
        .na-reason.r-ok   { color:#15803d; }
        .na-reason.r-fail { color:#b91c1c; }
        .na-reason.r-dup  { color:#6b7280; }
        .na-stage { display:inline-block; margin-left:6px; font-size:0.68rem; color:#9ca3af; background:#f4f4f6; border:1px solid #eef0f2; border-radius:5px; padding:0 5px; }
        .na-ops { white-space:nowrap; }
        .na-ops button { font-size:0.74rem; padding:4px 9px; border-radius:6px; border:1px solid #e5e7eb; background:#fff; cursor:pointer; margin-right:4px; color:#374151; }
        .na-ops .na-resolve { border-color:#bbf7d0; color:#16a34a; }
        .na-ops .na-resolve:hover { background:#f0fdf4; }
        .na-rawrow pre { margin:0; background:#0f172a; color:#cbd5e1; border-radius:8px; padding:10px 12px; font-size:0.73rem; overflow:auto; max-height:220px; white-space:pre-wrap; word-break:break-all; }
        .na-empty { display:flex; align-items:center; gap:8px; color:#94a3b8; font-size:0.85rem; padding:12px 4px; }
        .na-empty .material-symbols-rounded { font-size:18px; }

        /* 结果标签 + 实时指示 */
        .ns-tag { font-size:0.73rem; font-weight:700; border-radius:6px; padding:2px 8px; white-space:nowrap; }
        .ns-tag.ns-ok   { color:#15803d; background:#ecfdf3; }
        .ns-tag.ns-fail { color:#dc2626; background:#fef2f2; }
        .ns-tag.ns-dup  { color:#6b7280; background:#f3f4f6; }
        .ns-nosign { font-size:0.68rem; color:#b45309; background:#fffbeb; border:1px solid #fde68a; border-radius:5px; padding:0 5px; margin-left:4px; }
        .ns-row.is-fail td { background:#fffafa; }
        .ns-live { font-size:0.72rem; font-weight:600; border-radius:999px; padding:1px 9px; }
        .ns-live.on  { color:#15803d; background:#ecfdf3; }
        .ns-live.off { color:#9ca3af; background:#f1f1f4; }

        /* 分页 */
        .ns-foot { display:flex; justify-content:space-between; align-items:center; gap:12px; margin-top:12px; flex-wrap:wrap; }
        .ns-pager { display:flex; gap:6px; align-items:center; }
        .ns-pg { font-size:0.77rem; padding:5px 10px; border-radius:7px; border:1px solid #e5e7eb; background:#fff; color:#374151; cursor:pointer; }
        .ns-pg:hover:not(:disabled) { background:#f4f4f6; }
        .ns-pg:disabled { opacity:0.4; cursor:default; }
        .ns-pgnum { font-size:0.78rem; color:#374151; padding:0 6px; white-space:nowrap; }
        .ns-meta { font-size:0.73rem; color:#9ca3af; }

        /* ===== 顶部循环告警条(仅异常时滑入) ===== */
        .pay-alert-overlay { position:fixed; inset:0; pointer-events:none; z-index:9998; display:none; }
        .pay-alert-overlay.active { display:block; animation: payFlash 1.4s ease-in-out infinite; }
        @keyframes payFlash {
            0%,100% { box-shadow: inset 0 0 0 3px rgba(220,38,38,0.0); }
            50%     { box-shadow: inset 0 0 0 3px rgba(220,38,38,0.45); }
        }
        .pay-alert-banner {
            position:fixed; top:0; left:50%; transform:translateX(-50%) translateY(-120%);
            z-index:9999; display:flex; align-items:center; gap:12px;
            background:#dc2626; color:#fff; padding:11px 18px; border-radius:0 0 14px 14px;
            box-shadow:0 10px 30px rgba(220,38,38,0.32); min-width:340px; max-width:92vw;
            transition: transform .35s cubic-bezier(.2,.8,.2,1);
        }
        .pay-alert-banner.active { transform:translateX(-50%) translateY(0); }
        .pay-alert-banner .pab-icon { font-size:24px; }
        .pay-alert-banner .pab-text { line-height:1.3; }
        .pay-alert-banner .pab-title { font-weight:800; font-size:0.94rem; }
        .pay-alert-banner .pab-sub { font-size:0.79rem; opacity:0.92; }
        .pay-alert-banner .pab-btn { background:#fff; color:#dc2626; border:0; border-radius:8px; padding:6px 13px; font-weight:700; font-size:0.83rem; cursor:pointer; }
        .pay-alert-banner .pab-btn.ghost { background:rgba(255,255,255,0.18); color:#fff; }
        .pay-alert-banner .pab-btn:hover { opacity:0.9; }
        @media (max-width:640px) {
            .pay-alert-banner { min-width:0; width:96vw; flex-wrap:wrap; }
            .na-oid { max-width:120px; }
        }

        /* ===== 运行日志异常(收起式,复用 pm-* 视觉) ===== */
        .exc-section { background:#fff; border:1px solid #ececf0; border-radius:12px; margin-bottom:22px; overflow:hidden; transition:border-color .2s; }
        .exc-section.has-alert { border-color:#f1c7c7; }
        .exc-bar { display:flex; align-items:center; justify-content:space-between; gap:12px; padding:13px 16px; cursor:pointer; user-select:none; }
        .exc-bar:hover { background:#fafbfc; }
        .exc-bar-left { display:flex; align-items:center; gap:10px; min-width:0; flex-wrap:wrap; }
        .exc-chevron { color:#9aa1ac; font-size:22px; flex-shrink:0; }
        .exc-section .exception-card { margin:0; border:0; border-top:1px solid #f0f0f3; border-radius:0; }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <!-- ============================================================
         UI THEME · Ovation 风格换肤层 (单一事实来源 / single source of truth)
         由 Claude 生成 · v1.0 · 2026-07-06 · Batch 1
         规矩：改样式一律用下面 :root 里的 CSS 变量；新页面专属类往这里追加。
         此块置于 </head> 前，最后加载 → 覆盖上方旧的内联样式。
    ============================================================ -->
    <style id="ui-theme">
/* =============================================================================
 *  Cloud Love · Admin Design System  (UI THEME · 单一事实来源)
 *  ---------------------------------------------------------------------------
 *  灵感：Ovation / Vuexy 风格 —— 白色侧栏、紫色主色、大圆角卡片、柔和阴影、
 *        胶囊标签、彩色圆角图标底。
 *  规矩：颜色 / 圆角 / 阴影 一律用下面 :root 的 CSS 变量，不要再写死 hex；
 *        新页面的专属类往本块对应分区追加，别散落回上面旧的内联样式。
 *  （详尽说明见随附的 admin-theme.css 文件头部。）
 *  版本：v1.0 · 2026-07-06 · Batch 1
 * ========================================================================== */

/* =============================================================================
 * 1. TOKENS  ——  设计变量（改主题只动这里）
 * ========================================================================== */
:root {
  /* ---- 品牌主色 (violet) ---------------------------------------------- */
  --primary:        #7367f0;
  --primary-600:    #5e52d6;   /* hover / pressed */
  --primary-700:    #4a3fc0;
  --primary-100:    #ded9fb;   /* soft border */
  --primary-50:     #eeecfe;   /* tint background */
  --primary-grad:   linear-gradient(118deg, #8b7fff 0%, #7367f0 100%);

  /* ---- 语义色 + 柔和底 (chip 三件套) --------------------------------- */
  --success:  #28c76f;  --success-bg: #e5f8ed;  --success-bd: #c3f0d5;
  --warning:  #ff9f43;  --warning-bg: #fff2e3;  --warning-bd: #ffdfbf;
  --danger:   #ea5455;  --danger-bg:  #fce9e9;  --danger-bd:  #f6cccc;
  --info:     #00bad1;  --info-bg:    #e0f7fb;  --info-bd:    #bcecf2;
  --violet:   #7367f0;  --violet-bg:  #eeecfe;  --violet-bd:  #ddd8fc;
  --pink:     #e879b9;  --pink-bg:    #fdeaf5;  --pink-bd:    #f8cfe6;

  /* ---- 中性 / 文字墨色 ----------------------------------------------- */
  --ink:        #2f2b3d;   /* 标题 headings          */
  --ink-2:      #4b465c;   /* 正文 body              */
  --muted:      #6f6b7d;   /* 次要 secondary         */
  --muted-2:    #a8a5b3;   /* 三级 / meta            */
  --line:       #ebe9f1;   /* 主分隔线 hairline      */
  --line-soft:  #f3f2f8;   /* 更淡分隔线             */

  /* ---- 表面 ---------------------------------------------------------- */
  --bg:         #f5f5fb;   /* 页面画布 (淡紫灰)      */
  --surface:    #ffffff;   /* 卡片 / 侧栏            */
  --surface-2:  #faf9fe;   /* 表头 / 轻填充          */
  --chip:       #f4f3fa;   /* 中性 chip             */
  --row-hover:  #faf9ff;   /* 表格行 hover          */

  /* ---- 圆角 ---------------------------------------------------------- */
  --r-xl:   22px;  /* 弹窗 / 大面板          */
  --r-lg:   16px;  /* 卡片                  */
  --r-md:   12px;  /* 按钮 / 输入 / 图表卡   */
  --r-chip: 14px;  /* 彩色圆角图标底         */
  --r-sm:    8px;
  --r-pill: 999px; /* 胶囊：标签 / 搜索      */

  /* ---- 阴影（冷/紫调，柔） ------------------------------------------- */
  --sh-xs:    0 1px 2px  rgba(47,43,61,0.06);
  --sh-card:  0 4px 18px rgba(47,43,61,0.06);
  --sh-hover: 0 8px 28px rgba(115,103,240,0.16);
  --sh-rail:  0 0 22px   rgba(47,43,61,0.05);
  --sh-modal: 0 24px 64px rgba(47,43,61,0.22);
  --sh-pop:   0 12px 40px rgba(47,43,61,0.14);
  --sh-primary: 0 5px 14px rgba(115,103,240,0.35);

  /* ---- 字体 ---------------------------------------------------------- */
  --font: 'Inter', 'PingFang SC', 'HarmonyOS Sans SC', 'Microsoft YaHei',
          system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif;

  /* ---- 动效 ---------------------------------------------------------- */
  --ease: cubic-bezier(.4,.2,.2,1);
}

/* =============================================================================
 * 2. BASE  ——  画布 / 滚动条 / 焦点
 * ========================================================================== */
body {
  background: var(--bg) !important;      /* 加载顺序安全锚点 */
  color: var(--ink-2);
  font-family: var(--font);
}

/* 细滚动条（侧栏、日志框、弹窗都受益） */
* { scrollbar-width: thin; scrollbar-color: #d9d6e6 transparent; }
*::-webkit-scrollbar { width: 9px; height: 9px; }
*::-webkit-scrollbar-thumb {
  background: #d9d6e6; border-radius: 999px;
  border: 2px solid transparent; background-clip: padding-box;
}
*::-webkit-scrollbar-thumb:hover { background: #c3bfd6; background-clip: padding-box; }
*::-webkit-scrollbar-track { background: transparent; }

/* 键盘可达性：统一焦点环 */
:where(button, a, input, select, textarea, [tabindex]):focus-visible {
  outline: 2px solid var(--primary);
  outline-offset: 2px;
  border-radius: var(--r-sm);
}

@media (prefers-reduced-motion: reduce) {
  * { animation-duration: .001ms !important; transition-duration: .001ms !important; }
}

/* =============================================================================
 * 3. SHELL  ——  侧栏 / 导航 / 主体 / 区块标题
 * ========================================================================== */
.admin-sidebar {
  background: var(--surface) !important;
  color: var(--muted);
  border-right: 1px solid var(--line);
  box-shadow: var(--sh-rail);
  padding: 18px 14px;
  overflow-y: auto;                      /* 长导航独立滚动 */
}
.admin-brand { border-bottom: 1px solid var(--line); }
.admin-brand img { border-radius: 10px; box-shadow: var(--sh-xs); }
.admin-brand strong { color: var(--ink); }
.admin-brand span { color: var(--muted-2); }

/* 导航分组小标题（新增，供后续把 27 项分组用） */
.admin-nav-group-label {
  font-size: .66rem; font-weight: 700; letter-spacing: .09em;
  text-transform: uppercase; color: var(--muted-2);
  padding: 14px 12px 6px;
}

.admin-nav-item {
  color: var(--muted);
  border-radius: var(--r-md);
  padding: 10px 12px;
  font-weight: 500;
  transition: background .16s var(--ease), color .16s var(--ease);
}
.admin-nav-item:hover { background: var(--primary-50); color: var(--primary); }
.admin-nav-item.active {
  background: var(--primary-grad) !important;   /* 安全锚点 */
  color: #fff !important;
  box-shadow: var(--sh-primary);
}
.admin-nav-item.active .material-symbols-rounded { color: #fff; }

.admin-sidebar-footer { border-top: 1px solid var(--line); color: var(--muted-2); }
.admin-sidebar-footer a { color: var(--primary); }
.nav-badge { background: var(--danger); box-shadow: 0 2px 6px rgba(234,84,85,.4); }

/* 主体 */
.admin-main { padding: 26px 34px; }
.tab-header h2 { color: var(--ink); font-weight: 700; letter-spacing: -.01em; }

/* 区块小标题 */
.dash-section-title { color: var(--muted-2); }
.dash-section-title::after {
  background: linear-gradient(90deg, var(--line) 0%, transparent 80%);
}
.dash-section-title .sec-meta { color: var(--muted-2); }

/* =============================================================================
 * 4. CARDS & STATS  ——  统计卡 / 图表卡 / 系统卡 / 配置组
 * ========================================================================== */
.stat-card,
.stat-grid.compact .stat-card {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--sh-card);
  transition: transform .18s var(--ease), border-color .18s var(--ease), box-shadow .18s var(--ease);
}
.stat-card:hover,
.stat-grid.compact .stat-card:hover {
  transform: translateY(-2px);
  border-color: var(--primary-100);
  box-shadow: var(--sh-hover);
}
.stat-card .label,
.stat-grid.compact .stat-card .label { color: var(--muted); }
.stat-card .value,
.stat-grid.compact .stat-card .value { color: var(--ink); }

/* delta 胶囊：涨=绿、跌=红、平=灰 */
.stat-grid.compact .stat-card .delta strong {
  color: var(--success); background: var(--success-bg);
  border: 1px solid var(--success-bd); border-radius: var(--r-pill);
}
.stat-grid.compact .stat-card .delta .neu {
  color: var(--muted); background: var(--chip);
  border: 1px solid var(--line); border-radius: var(--r-pill);
}
.stat-grid.compact .stat-card .delta .down {
  color: var(--danger); background: var(--danger-bg);
  border: 1px solid var(--danger-bd); border-radius: var(--r-pill);
  padding: 1px 7px; font-size: .68rem; font-weight: 600;
}

/* 图表卡 */
.dash-chart-card {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--sh-card);
}
.dash-chart-card .chart-title { color: var(--muted); }
.dash-chart-card .chart-big { color: var(--ink); }
.dash-chart-card .chart-sub strong { color: var(--ink-2); }
.dash-chart-card .chart-sub .up { color: var(--success); }
.dash-chart-card .chart-sub .down { color: var(--danger); }
.dash-chart-card .chart-meta-tag {
  background: var(--primary-50); color: var(--primary);
  border-radius: var(--r-pill); font-weight: 600;
}

/* 系统状态卡 */
.sys-card {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: var(--r-md);
  box-shadow: var(--sh-xs);
}
.sys-card .sl { color: var(--muted); }
.sys-card .sv { color: var(--ink); }
.sys-card .sv.muted { color: var(--muted-2); }
.sys-card.err { background: var(--danger-bg); color: var(--danger); border-color: var(--danger-bd); }

/* 配置分组 */
.config-group {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--sh-card);
}
.config-group h3 { color: var(--ink); border-bottom: 1px solid var(--line); }
.config-row .config-key { color: var(--muted); }
.config-row .config-remark { color: var(--muted-2); }

/* =============================================================================
 * 5. TABLES
 * ========================================================================== */
.data-table-wrap {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--sh-card);
}
.data-table thead { background: var(--surface-2); }
.data-table th {
  color: var(--muted);
  border-bottom: 1px solid var(--line);
  letter-spacing: .06em;
}
.data-table td { color: var(--ink-2); border-bottom: 1px solid var(--line-soft); }
.data-table tr:hover { background: var(--row-hover); }

/* =============================================================================
 * 6. CONTROLS  ——  按钮 / 标签 / 搜索 / 表单 / 分页 / 开关
 * ========================================================================== */

/* 胶囊标签 */
.tag {
  border-radius: var(--r-pill);
  padding: 3px 10px;
  font-weight: 600;
  font-size: .72rem;
}
.tag-free, .tag-running, .tag-success { background: var(--success-bg); color: var(--success); }
.tag-pro,  .tag-pending               { background: var(--warning-bg); color: var(--warning); }
.tag-stopped, .tag-danger, .tag-failed { background: var(--danger-bg);  color: var(--danger); }

/* 小按钮 */
.btn-mini {
  border-radius: var(--r-md);
  border: 1px solid var(--line);
  color: var(--ink-2);
  font-weight: 600;
  padding: 6px 14px;
  transition: all .16s var(--ease);
}
.btn-mini:hover { background: var(--primary-50); border-color: var(--primary-100); color: var(--primary); }
.btn-mini.primary {
  background: var(--primary) !important;      /* 安全锚点 */
  border-color: var(--primary);
  color: #fff;
  box-shadow: var(--sh-primary);
}
.btn-mini.primary:hover {
  background: var(--primary-600) !important;
  border-color: var(--primary-600);
  transform: translateY(-1px);
  box-shadow: 0 7px 18px rgba(115,103,240,.42);
}
.btn-mini.danger { color: var(--danger); border-color: var(--danger-bd); }
.btn-mini.danger:hover { background: var(--danger-bg); color: var(--danger); border-color: var(--danger-bd); }

/* 搜索框 → 胶囊 */
.search-box {
  border: 1px solid var(--line);
  border-radius: var(--r-pill);
  background: var(--surface);
  height: 40px;
  padding: 4px 16px;
  transition: border-color .16s var(--ease), box-shadow .16s var(--ease);
}
.search-box:focus-within { border-color: var(--primary-100); box-shadow: 0 0 0 4px var(--primary-50); }

/* 表单 */
.form-group label { color: var(--ink-2); }
.form-group input, .form-group select, .form-group textarea {
  border: 1px solid var(--line);
  border-radius: var(--r-md);
  color: var(--ink-2);
  padding: 9px 13px;
}
.form-group input:focus, .form-group select:focus, .form-group textarea:focus {
  border-color: var(--primary);
  box-shadow: 0 0 0 4px var(--primary-50);
}
.form-group .hint { color: var(--muted-2); }

/* 分页 */
.pagination { color: var(--muted); }
.pagination button { border-radius: var(--r-md); border: 1px solid var(--line); }
.pagination button:not(:disabled):hover {
  background: var(--primary-50); border-color: var(--primary-100); color: var(--primary);
}

/* 开关：开启=品牌紫（如需“危险=红”单独加 .toggle-danger 处理） */
.toggle-switch input[type="checkbox"]:checked + .toggle-slider { background: var(--primary); }
.toggle-switch.toggle-danger input[type="checkbox"]:checked + .toggle-slider { background: var(--danger); }

.empty-state { color: var(--muted-2); }

/* =============================================================================
 * 7. OVERLAYS  ——  弹窗 / Toast
 * ========================================================================== */
.admin-modal-overlay { background: rgba(47,43,61,.45); backdrop-filter: blur(2px); }
.admin-modal {
  border-radius: var(--r-xl);
  box-shadow: var(--sh-modal);
  padding: 26px 30px;
}
.admin-modal-header { border-bottom: 1px solid var(--line); }
.admin-modal-title { color: var(--ink); }
.admin-modal-close { color: var(--muted-2); }
.admin-modal-close:hover { color: var(--ink); }
.modal-footer { border-top: 1px solid var(--line); }

#global-toast { border-radius: var(--r-md); background: var(--ink); box-shadow: var(--sh-pop); }
#global-toast.toast-success { background: var(--success); }
#global-toast.toast-error   { background: var(--danger); }

/* =============================================================================
 * 8. UTILITIES  ——  可复用类（新页面直接用，别再造轮子）
 * ========================================================================== */

/* 通用卡片：任何新面板直接 class="card" 即可拿到一致外观 */
.card {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: var(--r-lg);
  box-shadow: var(--sh-card);
  padding: 20px 22px;
}

/* 彩色圆角图标底（Ovation 卡片左上那种） */
.icon-chip {
  width: 42px; height: 42px;
  display: inline-flex; align-items: center; justify-content: center;
  border-radius: var(--r-chip);
  font-size: 22px; flex-shrink: 0;
}
.icon-chip .material-symbols-rounded { font-size: 22px; }
.icon-chip--violet  { background: var(--violet-bg);  color: var(--violet); }
.icon-chip--success { background: var(--success-bg); color: var(--success); }
.icon-chip--warning { background: var(--warning-bg); color: var(--warning); }
.icon-chip--danger  { background: var(--danger-bg);  color: var(--danger); }
.icon-chip--info    { background: var(--info-bg);    color: var(--info); }
.icon-chip--pink    { background: var(--pink-bg);    color: var(--pink); }

/* 通用胶囊 */
.pill {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 3px 10px; border-radius: var(--r-pill);
  font-size: .72rem; font-weight: 600; line-height: 1.5;
}
.pill--up   { background: var(--success-bg); color: var(--success); }
.pill--down { background: var(--danger-bg);  color: var(--danger); }
.pill--neu  { background: var(--chip);       color: var(--muted); }

/* 紫色渐变 CTA 卡（对应参考里“升级至 PRO”那块，可用于侧栏/看板推广位） */
.cta-card {
  background: var(--primary-grad);
  border-radius: var(--r-lg);
  padding: 18px;
  color: #fff;
  box-shadow: 0 10px 26px rgba(115,103,240,.4);
}
.cta-card h4 { margin: 0 0 4px; font-size: .95rem; font-weight: 700; }
.cta-card p  { margin: 0 0 12px; font-size: .78rem; opacity: .88; line-height: 1.5; }
.cta-card .cta-btn {
  display: inline-block; background: #fff; color: var(--primary);
  border: 0; border-radius: var(--r-pill); padding: 7px 16px;
  font-size: .8rem; font-weight: 700; cursor: pointer; font-family: inherit;
}
.cta-card .cta-btn:hover { background: #f3f1ff; }

/* 头像圈 */
.avatar {
  width: 36px; height: 36px; border-radius: 50%; object-fit: cover;
  border: 2px solid var(--surface); box-shadow: var(--sh-xs);
}

/* 分隔线 */
.hr { height: 1px; background: var(--line); border: 0; margin: 16px 0; }


  /* ========================================================================
   * 9. DASHBOARD 专属协调层 (Batch 1)
   *    只处理概览页里“非通用组件”的少量冲突项，让落地页彻底统一。
   *    语义色（告警红/绿）与命令行深色终端保持不变 —— 那是对的。
   * ==================================================================== */

  /* 概览统计卡 → Ovation 风格：左上彩色圆角图标底，数字为主，标签在下 */
  #statGrid .stat-card .sc-top{
    display:flex; align-items:center; justify-content:space-between; margin-bottom:12px;
  }
  #statGrid .stat-card .label{ margin:5px 0 0; color:var(--muted); }
  #statGrid .stat-card .label .material-symbols-rounded{ display:none; }
  #statGrid .stat-card .value{ font-size:1.7rem; }

  /* 全屏看板按钮：深色 → 中性描边 + 紫色 hover（不与主按钮抢焦点） */
  .dash-fs-btn{
    background:var(--surface) !important; color:var(--ink-2) !important;
    border:1px solid var(--line) !important; border-radius:var(--r-md) !important;
  }
  .dash-fs-btn:hover{
    background:var(--primary-50) !important; color:var(--primary) !important;
    border-color:var(--primary-100) !important; transform:translateY(-1px);
  }
  body.dashboard-fullscreen .dash-fs-btn{ background:var(--primary-50) !important; color:var(--primary) !important; border-color:var(--primary-100) !important; }

  /* 支付回调监控条 / 异常区块：卡片化圆角 + 与主题一致的中性色 */
  .exception-card{ border:1px solid var(--line); border-radius:var(--r-md); box-shadow:var(--sh-xs); }
  .exception-item{ border-bottom-color:var(--line-soft); }
  .exception-item:hover{ background:var(--row-hover); }
  .exception-item .exc-shard{ color:var(--primary); background:var(--primary-50); border-radius:var(--r-sm); }
  .exception-footer{ background:var(--surface-2); border-top-color:var(--line-soft); color:var(--muted-2); }
  .exc-clear-btn{ border:1px solid var(--line); color:var(--muted); border-radius:var(--r-sm); }
  .exc-rate-badge{ background:var(--chip); color:var(--muted); }

  /* 实时监控卡片：统一圆角与柔和边框（深色日志框保持原样，不动） */
  .rt-monitor{ border:1px solid var(--line); border-radius:var(--r-lg); box-shadow:var(--sh-card); }
  .rt-head:hover{ background:var(--surface-2); }
  .rt-shard-card{ border:1px solid var(--line); border-radius:var(--r-md); }
  .rt-shard-card:hover{ border-color:var(--primary-100); }
  .rt-shard-name .shard-tag{ border-radius:var(--r-pill); }
  .rt-follow input{ accent-color:var(--primary); }
  .rt-log-chip{ border-radius:var(--r-pill); }
  .rt-log-chip.active{ background:var(--primary); color:#fff; border-color:var(--primary); }

  /* 音色权限按钮已是语义色（黄/绿/红），仅统一圆角 */
  .audio-perm-btn, .dash-fs-btn{ border-radius:var(--r-md); }

  /* ========================================================================
   * 10. 侧栏可滚动 (Batch 2)
   *    品牌固定顶部、导航区(.admin-nav-scroll)独立鼠标滚动、页脚固定底部。
   * ==================================================================== */
  .admin-sidebar{ display:flex; flex-direction:column; overflow:hidden; }
  .admin-sidebar .admin-brand{ flex:0 0 auto; }
  .admin-nav-scroll{
    flex:1 1 auto; min-height:0; overflow-y:auto; overscroll-behavior:contain;
    margin:0 -6px; padding:2px 6px;
  }
  .admin-sidebar .admin-sidebar-footer{
    position:static; left:auto; right:auto; bottom:auto;   /* 覆盖旧的 absolute 定位 */
    flex:0 0 auto; margin-top:6px;
  }
  .admin-nav-scroll::-webkit-scrollbar{ width:6px; }
  .admin-nav-scroll::-webkit-scrollbar-thumb{ background:#e2e0ee; }

  /* ========================================================================
   * 11. 系统健康 —— 白色小卡(风格对齐系统状态)· 仅用圆点表状态 (Batch 3)
   *    正常=绿点(不加文字), 异常=红点呼吸+红字计数。无灰底,保持简洁。
   *    复用旧 JS 的 IDs 与 .pm-dot .ok/.bad,监控逻辑零改动。
   * ==================================================================== */
  .health-card{ background:transparent; border:0; box-shadow:none; padding:0; margin-bottom:18px; overflow:visible; }
  .health-grid{ display:flex; align-items:stretch; gap:10px; flex-wrap:wrap; }

  .hcard{
    background:var(--surface); border:1px solid var(--line); border-radius:var(--r-md);
    box-shadow:var(--sh-xs); padding:11px 15px; min-width:184px; cursor:pointer;
    display:flex; flex-direction:column; gap:5px; justify-content:center;
    transition:border-color .15s var(--ease), box-shadow .15s var(--ease);
  }
  .hcard:hover{ border-color:var(--primary-100); box-shadow:var(--sh-card); }
  .hcard:focus-visible{ outline:2px solid var(--primary); outline-offset:2px; }
  .hcard-head{ display:flex; align-items:center; justify-content:space-between; gap:12px; }
  .hcard-name{ font-size:.8rem; font-weight:600; color:var(--ink-2); }
  .hcard-note{ font-size:.72rem; color:var(--muted); font-variant-numeric:tabular-nums; display:flex; align-items:center; gap:6px; }
  .hcard-note:empty{ display:none; }

  /* 状态圆点(绿=正常 / 红=异常呼吸) */
  .hcard .pm-dot{ width:10px; height:10px; border-radius:50%; flex-shrink:0; }
  .hcard .pm-dot.ok{ background:var(--success); box-shadow:0 0 0 3px rgba(40,199,111,.16); }
  .hcard .pm-dot.bad{ background:var(--danger); animation:pmPing 1.6s ease-out infinite; }

  /* 异常态:红描边 + 红字(不铺灰底,保持简洁) */
  .hcard.has-alert{ border-color:var(--danger-bd); }
  .hcard.has-alert .hcard-name, .hcard.has-alert .hcard-note{ color:var(--danger); font-weight:600; }
  .health-card.has-alert #payHealthItem{ border-color:var(--danger-bd); }
  .health-card.has-alert #payHealthItem .hcard-name,
  .health-card.has-alert #payHealthItem .hcard-note{ color:var(--danger); font-weight:600; }

  /* 速率徽章:仅在升高(warn/crit)时出现,正常隐藏 */
  .exc-rate-badge{ padding:1px 8px; font-size:.68rem; }
  .exc-rate-badge:not(.warn):not(.crit){ display:none; }

  .health-ops{ margin-left:auto; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }

  /* 明细面板:展开时作为独立白卡出现在下方 */
  .health-card > .pm-anomaly:empty{ display:none; }
  .health-card > .pm-anomaly:not(:empty){ margin-top:12px; padding:12px 16px; background:var(--surface); border:1px solid var(--danger-bd); border-radius:var(--r-lg); box-shadow:var(--sh-card); }
  .health-card > .pm-recon,
  .health-card > .exception-card{ margin-top:12px; background:var(--surface); border:1px solid var(--line); border-radius:var(--r-lg); box-shadow:var(--sh-card); }

  /* 小按钮统一(覆盖旧 pm-btn) */
  .pm-btn{ border-radius:var(--r-md); border:1px solid var(--line); background:var(--surface); color:var(--ink-2); font-weight:600; }
  .pm-btn:hover{ background:var(--primary-50); border-color:var(--primary-100); color:var(--primary); }
  .pm-btn.ghost.active{ background:var(--primary-50); border-color:var(--primary-100); color:var(--primary); }
  .pm-btn.danger{ background:var(--danger); border-color:var(--danger); color:#fff; }
  .pm-btn.danger:hover{ background:#d63e3f; border-color:#d63e3f; color:#fff; }

    </style>
</head>
<body>

<!-- 告警系统(v16 · 合成音改造):
       a.mp3 = 新订单 / 账单增加提示音(绿色边框 + 自动消)—— 保留
       接口异常 / 连接告警不再用音频文件,改为 Web Audio 实时合成 + 语音播报 -->
<audio id="orderAlertAudio" src="a.mp3" preload="auto" style="display:none;"></audio>

<!-- 订单告警(绿色) -->
<div class="order-alert-overlay" id="orderAlertOverlay"></div>
<div class="order-alert-banner" id="orderAlertBanner" role="alert">
    <span class="material-symbols-rounded oab-icon">notifications_active</span>
    <div class="oab-text">
        <div class="oab-title">检测到新订单</div>
        <div class="oab-sub" id="orderAlertSub">+1 单</div>
    </div>
    <button class="oab-btn" onclick="dismissOrderAlert()">确认</button>
</div>

<!-- 接口异常告警(红色):循环核弹音 + 语音「无法处理请求数据」,须点确定 -->
<div class="error-alert-overlay" id="errorAlertOverlay"></div>
<div class="error-alert-banner" id="errorAlertBanner" role="alert">
    <span class="material-symbols-rounded ebn-icon">error</span>
    <div class="ebn-text">
        <div class="ebn-title" id="errorAlertTitle">无法处理请求数据</div>
        <div class="ebn-sub" id="errorAlertSub">HTTP 500</div>
    </div>
    <button class="ebn-btn" onclick="dismissErrorAlert()">确定</button>
</div>

<!-- 连接断开告警(红色):循环急促音 + 语音「连接断开」,超 1 分钟升级为「断开危险，无法重连」,须点确定 -->
<div class="error-alert-overlay" id="connAlertOverlay"></div>
<div class="error-alert-banner" id="connAlertBanner" role="alert" style="top:96px;">
    <span class="material-symbols-rounded ebn-icon">wifi_off</span>
    <div class="ebn-text">
        <div class="ebn-title" id="connAlertTitle">连接断开</div>
        <div class="ebn-sub" id="connAlertSub">实时快照已停止更新</div>
    </div>
    <button class="ebn-btn" onclick="dismissConnAlert()">确定</button>
</div>

<!-- 连接建立提示(绿色):缓慢核弹音 ×3 + 语音「连接建立」×3,可提前点确定 -->
<div class="order-alert-banner" id="connOkBanner" role="alert" style="top:96px;">
    <span class="material-symbols-rounded oab-icon" style="color:#16a34a;">wifi</span>
    <div class="oab-text">
        <div class="oab-title">连接建立</div>
        <div class="oab-sub" id="connOkSub">实时快照已恢复更新</div>
    </div>
    <button class="oab-btn" onclick="dismissConnOk()">确定</button>
</div>

<!-- 支付回调掉单告警:红条提示(v16 起不再出声),处理清零后自动消失。 -->
<div class="pay-alert-overlay" id="payAlertOverlay"></div>
<div class="pay-alert-banner" id="payAlertBanner" role="alert">
    <span class="material-symbols-rounded pab-icon">crisis_alert</span>
    <div class="pab-text">
        <div class="pab-title">支付回调异常 · 可能掉单</div>
        <div class="pab-sub" id="payAlertSub">检测到已收款但未成功发货的订单</div>
    </div>
    <button class="pab-btn" onclick="switchTab('dashboard'); var c=document.getElementById('notifyAlertCard'); if(c) c.scrollIntoView({behavior:'smooth'});">查看</button>
    <button class="pab-btn ghost" onclick="snoozePayAlarm()">静音 5 分钟</button>
</div>

<div class="admin-layout">

    <!-- 侧栏 -->
    <aside class="admin-sidebar">
        <div class="admin-brand">
            <img src="image/logo-3.png" alt="Logo">
            <div>
                <strong>Cloud Love</strong>
                <span>管理后台</span>
            </div>
        </div>

        <div class="admin-nav-scroll">
        <div class="admin-nav-group-label">概览</div>
        <div class="admin-nav-item active" data-tab="dashboard" onclick="switchTab('dashboard')">
            <span class="material-symbols-rounded">dashboard</span><span>概览</span>
        </div>
        <div class="admin-nav-group-label">用户与订单</div>
        <div class="admin-nav-item" data-tab="users" onclick="switchTab('users')">
            <span class="material-symbols-rounded">group</span><span>用户管理</span>
        </div>
        <div class="admin-nav-item" data-tab="phone_blacklist" onclick="switchTab('phone_blacklist')">
            <span class="material-symbols-rounded">phone_disabled</span><span>手机号黑名单</span>
        </div>
        <div class="admin-nav-item" data-tab="instances" onclick="switchTab('instances')">
            <span class="material-symbols-rounded">smart_toy</span><span>实例管理</span>
        </div>
        <div class="admin-nav-item" data-tab="orders" onclick="switchTab('orders')">
            <span class="material-symbols-rounded">receipt_long</span><span>订单查询</span>
        </div>
        <div class="admin-nav-item" data-tab="user_stats" onclick="switchTab('user_stats')">
            <span class="material-symbols-rounded">leaderboard</span><span>用户统计</span>
        </div>
        <div class="admin-nav-group-label">计费变现</div>
        <div class="admin-nav-item" data-tab="models" onclick="switchTab('models')">
            <span class="material-symbols-rounded">payments</span><span>模型定价</span>
        </div>
        <div class="admin-nav-item" data-tab="packs" onclick="switchTab('packs')">
            <span class="material-symbols-rounded">card_membership</span><span>订阅包档位</span>
        </div>
        <div class="admin-nav-item" data-tab="count_packs" onclick="switchTab('count_packs')">
            <span class="material-symbols-rounded">confirmation_number</span><span>次数包档位</span>
        </div>
        <div class="admin-nav-item" data-tab="redeem" onclick="switchTab('redeem')">
            <span class="material-symbols-rounded">redeem</span><span>兑换码</span>
        </div>
        <div class="admin-nav-item" data-tab="lottery_520" onclick="switchTab('lottery_520')">
            <span class="material-symbols-rounded">redeem</span><span>520 抽奖</span>
        </div>
        <div class="admin-nav-item" data-tab="lottery" onclick="switchTab('lottery')">
            <span class="material-symbols-rounded">card_giftcard</span><span>限时抽奖</span>
        </div>
        <div class="admin-nav-group-label">内容运营</div>
        <div class="admin-nav-item" data-tab="prompt_presets" onclick="switchTab('prompt_presets')">
            <span class="material-symbols-rounded">edit_note</span><span>提示词预设</span>
        </div>
        <div class="admin-nav-item" data-tab="market" onclick="switchTab('market')">
            <span class="material-symbols-rounded">groups</span><span>人格市场</span>
        </div>
        <div class="admin-nav-item" data-tab="forum" onclick="switchTab('forum')">
            <span class="material-symbols-rounded">dashboard_customize</span><span>论坛管理</span>
            <span class="nav-badge" id="navForumBadge" style="display:none;">0</span>
        </div>
        <div class="admin-nav-item" data-tab="messages" onclick="switchTab('messages')">
            <span class="material-symbols-rounded">forum</span><span>用户留言</span>
            <span class="nav-badge" id="navMsgBadge" style="display:none;">0</span>
        </div>
        <div class="admin-nav-item" data-tab="testimonials" onclick="switchTab('testimonials')">
            <span class="material-symbols-rounded">volunteer_activism</span><span>鸣谢管理</span>
        </div>
        <div class="admin-nav-item" data-tab="announcement" onclick="switchTab('announcement')">
            <span class="material-symbols-rounded">campaign</span><span>公告管理</span>
        </div>
        <div class="admin-nav-item" data-tab="announce" onclick="switchTab('announce')">
            <span class="material-symbols-rounded">campaign</span><span>紧急公告</span>
        </div>
        <div class="admin-nav-item" data-tab="videos" onclick="switchTab('videos')">
            <span class="material-symbols-rounded">subscriptions</span><span>推广视频</span>
            <span class="nav-badge" id="navVidBadge" style="display:none;">0</span>
        </div>
        <div class="admin-nav-item" data-tab="broadcast" onclick="switchTab('broadcast')">
            <span class="material-symbols-rounded">campaign</span><span>节日推送</span>
        </div>
        <div class="admin-nav-group-label">语音</div>
        <div class="admin-nav-item" data-tab="preset_voices" onclick="switchTab('preset_voices')">
            <span class="material-symbols-rounded">graphic_eq</span><span>预设音色</span>
        </div>
        <div class="admin-nav-item" data-tab="voice_call" onclick="switchTab('voice_call')">
            <span class="material-symbols-rounded">call</span><span>语音通话</span>
        </div>
        <div class="admin-nav-group-label">系统</div>
        <div class="admin-nav-item" data-tab="config" onclick="switchTab('config')">
            <span class="material-symbols-rounded">settings</span><span>系统配置</span>
        </div>
        <div class="admin-nav-item" data-tab="tools" onclick="switchTab('tools')">
            <span class="material-symbols-rounded">extension</span><span>工具注册</span>
        </div>
        <div class="admin-nav-item" data-tab="emails" onclick="switchTab('emails')">
            <span class="material-symbols-rounded">mail</span><span>邮件队列</span>
        </div>
        <div class="admin-nav-item" data-tab="versions" onclick="switchTab('versions')">
            <span class="material-symbols-rounded">history</span><span>版本日志</span>
        </div>

        </div><!-- /admin-nav-scroll -->

        <div class="admin-sidebar-footer">
            <span class="material-symbols-rounded" style="font-size:18px;">person</span>
            <span><a href="console.php">控制台</a> · <a href="api/logout.php">退出</a></span>
        </div>
    </aside>

    <!-- 主体 -->
    <main class="admin-main">

        <!-- ============ 概览 ============ -->
        <section class="admin-tab active" id="tab-dashboard">
            <div class="tab-header">
                <h2>系统概览</h2>
                <div class="tab-actions">
                    <button class="audio-perm-btn pending" id="audioPermBtn" onclick="onAudioPermClick()" title="点击启用浏览器提示音(订单 + 异常告警共用,刷新页面需重新点击)">
                        <span class="material-symbols-rounded" id="audioPermIcon">notifications_off</span>
                        <span class="btn-label" id="audioPermLabel">申请提示音权限</span>
                    </button>
                    <button class="dash-fs-btn" id="dashFsBtn" onclick="toggleDashboardFullscreen()" title="全屏看板">
                        <span class="material-symbols-rounded">fullscreen</span>
                        <span class="btn-label" id="dashFsBtnLabel">全屏看板</span>
                    </button>
                </div>
            </div>

            <!-- 系统健康(合并:支付回调 + 运行日志)· 正常=绿点,异常=红点闪烁,点击展开查看 -->
            <div class="health-card" id="notifyAlertCard">
                <div class="health-grid">
                    <div class="hcard" id="payHealthItem" role="button" tabindex="0" onclick="_toggleRecon()" title="支付回调 · 点击查看对账流水 / 异常">
                        <div class="hcard-head">
                            <span class="hcard-name">支付回调</span>
                            <span class="pm-dot ok" id="pmDot"></span>
                        </div>
                        <div class="hcard-note" id="notifyAnomalyCount"></div>
                    </div>
                    <div class="hcard" id="excSection" role="button" tabindex="0" onclick="_toggleExcPanel()" title="运行日志 · 点击查看 HTTP 异常">
                        <div class="hcard-head">
                            <span class="hcard-name">运行日志</span>
                            <span class="pm-dot ok" id="excDot"></span>
                        </div>
                        <div class="hcard-note"><span id="excStatus"></span><span class="exc-rate-badge" id="excRateBadge"></span></div>
                    </div>
                    <div class="health-ops">
                        <button class="pm-btn danger" id="pmResolveAll" onclick="event.stopPropagation(); resolveAllNotify()" style="display:none;">
                            <span class="material-symbols-rounded">done_all</span> 全部标记已处理
                        </button>
                        <button class="pm-btn ghost" id="pmReconToggle" onclick="event.stopPropagation(); _toggleRecon()">
                            <span class="material-symbols-rounded">receipt_long</span> 对账
                        </button>
                    </div>
                </div>

                <!-- 支付:异常订单(有异常时自动展开) -->
                <div class="pm-anomaly" id="notifyAnomalyBody" style="display:none;"></div>

                <!-- 支付:对账流水(手动展开) -->
                <div class="pm-recon" id="notifyStreamWrap" style="display:none;">
                    <div class="pm-recon-head">
                        <div class="pm-recon-title">
                            回调流水 · 全部
                            <span class="ns-live off" id="nsLive">●</span>
                        </div>
                        <div class="pm-recon-ops">
                            <select id="nsFilter" onchange="_nsReload(1)">
                                <option value="all">全部</option>
                                <option value="success">仅成功</option>
                                <option value="fail">仅失败</option>
                                <option value="duplicate">仅重复</option>
                            </select>
                            <button class="pm-btn ghost" onclick="_nsReload(_nsPage)">
                                <span class="material-symbols-rounded">refresh</span> 刷新
                            </button>
                        </div>
                    </div>
                    <div class="ns-body" id="nsBody"></div>
                    <div class="ns-foot">
                        <div class="ns-pager" id="nsPager"></div>
                        <div class="ns-meta" id="nsMeta"></div>
                    </div>
                </div>

                <!-- 运行日志:HTTP 异常明细(有异常时自动展开) -->
                <div class="exception-card" id="exceptionCard" style="display:none;">
                    <div class="exception-list" id="exceptionList">
                        <div class="exception-empty">
                            无异常
                            <span class="hint">展开下方「实时运行」后开始监测日志中的 HTTP 403 / 405 / 500</span>
                        </div>
                    </div>
                    <div class="exception-footer">
                        <span id="exceptionCount">共 0 条记录</span>
                        <button class="exc-clear-btn" onclick="event.stopPropagation(); _clearExceptionList()">
                            <span class="material-symbols-rounded">delete_sweep</span> 清空
                        </button>
                    </div>
                </div>
            </div>

            <!-- 关键指标 -->
            <div class="dash-section-title">关键指标 <span class="sec-meta" id="dashUpdated"></span></div>
            <div class="stat-grid compact" id="statGrid">
                <div class="empty-state" style="grid-column:1/-1;">加载中...</div>
            </div>

            <!-- v13.12 (2026-05-14) 系统监控小卡 — worker / MySQL / 负载 / 内存 -->
            <div class="dash-section-title">系统状态</div>
            <div class="sys-status-grid" id="sysStatusGrid">
                <div class="sys-card sys-loading">加载系统状态…</div>
            </div>

            <!-- 运行日志异常已并入顶部「系统健康」卡(#notifyAlertCard) -->


            <!-- 双图:7 天注册趋势 + 收入趋势 -->
            <div class="dash-section-title">趋势 <span class="sec-meta">最近 7 天</span></div>
            <div class="dash-charts">
                <div class="dash-chart-card">
                    <div class="chart-header">
                        <div class="chart-title-row">
                            <div class="chart-title">用户增长</div>
                            <div class="chart-big" id="usersBig">--</div>
                            <div class="chart-sub" id="usersSub">&nbsp;</div>
                        </div>
                        <span class="chart-meta-tag">7 日新增</span>
                    </div>
                    <canvas id="chartUsers"></canvas>
                </div>
                <div class="dash-chart-card">
                    <div class="chart-header">
                        <div class="chart-title-row">
                            <div class="chart-title">每日收入</div>
                            <div class="chart-big" id="revBig">--</div>
                            <div class="chart-sub" id="revSub">&nbsp;</div>
                        </div>
                        <span class="chart-meta-tag">7 日合计</span>
                    </div>
                    <canvas id="chartRevenue"></canvas>
                </div>
            </div>

            <!-- ============ 实时运行 · 星空监控 ============ -->
            <div class="rt-monitor collapsed" id="rtMonitor">
                <div class="rt-head" onclick="toggleRtMonitor()">
                    <h3>实时运行</h3>
                    <span class="rt-pulse" id="rtPulse" title="实时连接中"></span>
                    <span class="rt-age" id="rtAge">点击展开</span>
                    <span class="rt-toggle material-symbols-rounded">expand_more</span>
                </div>

                <div class="rt-body">
                    <div class="rt-cover" id="rtCover">
                        <div class="rt-metric" id="rtmShard">
                            <div class="rt-metric-val">--</div>
                            <div class="rt-metric-label">分片进程</div>
                        </div>
                        <div class="rt-metric" id="rtmSnapshot">
                            <div class="rt-metric-val">--</div>
                            <div class="rt-metric-label">快照新鲜度</div>
                        </div>
                        <div class="rt-metric" id="rtmQueue">
                            <div class="rt-metric-val">--</div>
                            <div class="rt-metric-label">延迟队列</div>
                        </div>
                        <div class="rt-metric" id="rtmWorker">
                            <div class="rt-metric-val">--</div>
                            <div class="rt-metric-label">活跃 Worker</div>
                        </div>
                        <div class="rt-metric" id="rtmMysql">
                            <div class="rt-metric-val">--</div>
                            <div class="rt-metric-label">MySQL 连接</div>
                        </div>
                        <div class="rt-metric" id="rtmPool">
                            <div class="rt-metric-val">--</div>
                            <div class="rt-metric-label">连接池</div>
                        </div>
                        <div class="rt-metric" id="rtmFailed">
                            <div class="rt-metric-val">--</div>
                            <div class="rt-metric-label">失败重试</div>
                        </div>
                    </div>

                    <div class="rt-subhead">活跃 Worker<span class="rt-count" id="rtWkCount"></span></div>
                    <div class="rt-workers" id="rtWorkers">
                        <div class="rt-worker-empty" id="rtWkEmpty">当前没有运行中的 Worker</div>
                    </div>

                    <!-- 分片明细:每个 main.py 进程一行,看 worker 分配与回复速度 -->
                    <div class="rt-subhead">分片进程明细<span class="rt-count" id="rtShardCount"></span></div>
                    <div class="rt-shards" id="rtShards">
                        <div class="rt-worker-empty">等待分片数据…</div>
                    </div>

                    <div class="rt-log-head">
                        <h3>命令行日志 <span class="rt-log-sub">全部分片 main.py stdout</span></h3>
                        <span class="rt-log-meta">
                            <label class="rt-follow"><input type="checkbox" id="monAutoScroll" checked> 跟随最新</label>
                            <span id="monLogCount">0 行</span>
                        </span>
                    </div>
                    <!-- v15.0:日志按分片筛选 -->
                    <div class="rt-log-filter" id="rtLogFilter">
                        <span class="rt-log-filter-label">显示分片</span>
                        <button class="rt-log-chip active" data-shard="all" onclick="toggleLogShard('all')">全部</button>
                    </div>
                    <div id="monLogBox" class="rt-log-box"></div>
                </div>
            </div>
        </section>

        <!-- ============ 用户管理 ============ -->
        <section class="admin-tab" id="tab-users">
            <div class="tab-header">
                <h2>用户管理</h2>
                <div class="tab-actions">
                    <div class="search-box">
                        <span class="material-symbols-rounded" style="font-size:18px;color:#999;">search</span>
                        <input type="search" id="userKeyword" placeholder="用户名 / 邮箱 / 邀请码 / 手机号" oninput="debouncedLoadUsers()">
                        <select id="userPlanFilter" onchange="loadUsers()">
                            <option value="">全部套餐</option>
                            <option value="free">Free（无订阅包）</option>
                            <option value="pro">Pro（持有订阅包）</option>
                        </select>
                    </div>
                    <button class="btn-mini primary" onclick="openCreateUserModal()" style="white-space:nowrap;">+ 新增用户</button>
                </div>
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th>ID</th><th>用户名</th><th>手机号</th><th>邮箱</th><th>套餐</th><th>余额</th><th>到期</th>
                        <th>邀请码</th><th>消息数</th><th>操作</th>
                    </tr></thead>
                    <tbody id="userTableBody"><tr><td colspan="10" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
            <div class="pagination" id="userPagination"></div>
        </section>

        <!-- ============ 论坛管理 ============ -->
        <section class="admin-tab" id="tab-forum">
            <div class="tab-header"><h2>论坛管理</h2></div>

            <!-- 子标签:分区 / 帖子审核 -->
            <div class="forum-admin-subtabs">
                <button class="fa-subtab active" data-sub="sections" onclick="switchForumSub('sections')">分区设置</button>
                <button class="fa-subtab" data-sub="posts" onclick="switchForumSub('posts')">帖子管理</button>
            </div>

            <!-- 分区设置 -->
            <div id="faSubSections" class="fa-sub active">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
                    <p style="color:#666;font-size:0.86rem;margin:0;">分区会展示在论坛顶部，用户发帖必须选择一个分区。数字越小越靠前。</p>
                    <button class="btn-mini primary" onclick="openForumSectionEditor(0)">+ 新增分区</button>
                </div>
                <div class="data-table-wrap">
                    <table class="data-table">
                        <thead><tr><th>排序</th><th>名称</th><th>简介</th><th>帖子数</th><th>操作</th></tr></thead>
                        <tbody id="forumSectionBody"><tr><td colspan="5" class="empty-state">加载中...</td></tr></tbody>
                    </table>
                </div>
            </div>

            <!-- 帖子审核 -->
            <div id="faSubPosts" class="fa-sub">
                <div class="tab-actions" style="margin-bottom:14px;">
                    <div class="search-box">
                        <span class="material-symbols-rounded" style="font-size:18px;color:#999;">search</span>
                        <input type="search" id="forumPostKeyword" placeholder="标题 / 内容" oninput="debouncedLoadForumPosts()">
                        <select id="forumPostStatus" onchange="loadForumPosts()">
                            <option value="">全部帖子</option>
                            <option value="pending">待审核</option>
                            <option value="approved">已通过</option>
                            <option value="rejected">已驳回</option>
                        </select>
                    </div>
                </div>
                <div class="data-table-wrap">
                    <table class="data-table">
                        <thead><tr>
                            <th>ID</th><th>标题</th><th>作者</th><th>分区</th><th>图</th><th>赞/评</th><th>状态</th><th>时间</th><th>操作</th>
                        </tr></thead>
                        <tbody id="forumPostBody"><tr><td colspan="9" class="empty-state">加载中...</td></tr></tbody>
                    </table>
                </div>
                <div class="pagination" id="forumPostPagination"></div>
            </div>
        </section>

        <!-- ============ 实例管理 ============ -->
        <section class="admin-tab" id="tab-instances">
            <div class="tab-header">
                <h2>实例管理</h2>
                <div class="tab-actions">
                    <div class="search-box">
                        <span class="material-symbols-rounded" style="font-size:18px;color:#999;">search</span>
                        <input type="search" id="instKeyword" placeholder="实例 ID / 用户名 / 模型" oninput="debouncedLoadInstances()">
                    </div>
                </div>
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th>ID</th><th>实例 ID</th><th>用户</th><th>模型</th><th>人格</th>
                        <th>状态</th><th>消息数</th><th>采样</th><th>操作</th>
                    </tr></thead>
                    <tbody id="instTableBody"><tr><td colspan="9" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
            <div class="pagination" id="instPagination"></div>
        </section>

        <!-- ============ 订单查询 ============ -->
        <section class="admin-tab" id="tab-orders">
            <div class="tab-header">
                <h2>订单查询</h2>
                <div class="tab-actions">
                    <div class="search-box">
                        <input type="search" id="orderKeyword" placeholder="订单号 / 用户名" oninput="debouncedLoadOrders()">
                        <select id="orderTypeFilter" onchange="loadOrders()">
                            <option value="">全部类型</option>
                            <option value="balance">余额充值</option>
                            <option value="pro">订阅包</option>
                        </select>
                        <select id="orderStatusFilter" onchange="loadOrders()">
                            <option value="">全部状态</option>
                            <option value="pending">待支付</option>
                            <option value="success">成功</option>
                            <option value="failed">失败</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th>订单号</th><th>用户</th><th>类型</th><th>原价</th><th>实收</th><th>状态</th><th>创建时间</th><th>更新时间</th>
                    </tr></thead>
                    <tbody id="orderTableBody"><tr><td colspan="8" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
            <div class="pagination" id="orderPagination"></div>
        </section>

        <!-- ============ 用户统计（只读） ============ -->
        <section class="admin-tab" id="tab-user_stats">
            <div class="tab-header">
                <h2>用户统计
                    <span style="font-size:.68rem;font-weight:400;color:#16a34a;border:1px solid #bbf7d0;background:#f0fdf4;padding:2px 8px;border-radius:10px;vertical-align:middle;margin-left:6px;">只读 · 不修改任何数据</span>
                </h2>
                <div class="tab-actions">
                    <button class="btn-mini" onclick="loadUserStats()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:-3px;">refresh</span> 刷新
                    </button>
                </div>
            </div>

            <!-- 汇总卡 -->
            <div class="stat-grid compact" id="ustatGrid">
                <div class="empty-state" style="grid-column:1/-1;">加载中...</div>
            </div>

            <!-- 存量与到期分布 -->
            <div class="data-table-wrap" style="margin-top:16px;">
                <div style="padding:10px 14px;font-weight:600;border-bottom:1px solid #eee;">存量与到期分布 · 用于判断是否退出优惠活动</div>
                <div id="ustatExpiry" style="padding:12px 14px;color:#555;font-size:.85rem;line-height:1.9;">加载中...</div>
            </div>

            <!-- 排行榜 -->
            <div class="tab-header" style="margin-top:18px;">
                <h2 style="font-size:1.02rem;">排行榜</h2>
                <div class="tab-actions">
                    <div class="search-box">
                        <select id="ustatRankMetric" onchange="loadUserStatsRank(1)">
                            <option value="recharge">累计充值（实收，最高）</option>
                            <option value="invite">邀请人数（最高）</option>
                            <option value="balance">余额（最高）</option>
                            <option value="count_remaining">次数包 · 剩余次数</option>
                            <option value="pro_remaining">订阅包 · 剩余 token</option>
                            <option value="messages">AI 回复数</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr id="ustatRankHead"></tr></thead>
                    <tbody id="ustatRankBody"><tr><td class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
            <div class="pagination" id="ustatRankPagination"></div>

            <!-- 即将到期明细 -->
            <div class="tab-header" style="margin-top:18px;">
                <h2 style="font-size:1.02rem;">即将到期明细</h2>
                <div class="tab-actions">
                    <div class="search-box">
                        <select id="ustatExpKind" onchange="loadUserStatsExpiring()">
                            <option value="count_pack">次数包</option>
                            <option value="pro">订阅包</option>
                        </select>
                        <select id="ustatExpDays" onchange="loadUserStatsExpiring()">
                            <option value="1">未来 1 天</option>
                            <option value="3">未来 3 天</option>
                            <option value="7" selected>未来 7 天</option>
                            <option value="30">未来 30 天</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr id="ustatExpHead"></tr></thead>
                    <tbody id="ustatExpBody"><tr><td class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
        </section>

        <!-- ============ 模型定价 ============ -->
        <section class="admin-tab" id="tab-models">
            <div class="tab-header">
                <h2>模型定价</h2>
                <div class="tab-actions">
                    <button class="btn-mini" onclick="autoFillDisplayNames()" title="把所有 display_name 为空的模型,按预设建议表批量回填">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">auto_fix_high</span> 批量回填显示名
                    </button>
                    <button class="btn-mini" onclick="activatePackWhitelist()" title="把订阅包(pack)允许的 6 个模型一键设为上架,缺失的自动补齐">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">verified</span> 启用订阅包白名单
                    </button>
                    <button class="btn-mini primary" onclick="openModelModal()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">add</span> 新增模型
                    </button>
                </div>
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th>ID</th><th>模型名（API 调用）</th><th>显示名称</th><th>协议</th><th>输入价 (元/MTok)</th><th>输出价 (元/MTok)</th><th>订阅包</th><th>思维链</th><th>能力标签</th><th>状态</th><th>操作</th>
                    </tr></thead>
                    <tbody id="modelTableBody"><tr><td colspan="11" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
        </section>

        <!-- ============ 订阅包档位(v5 新增) ============ -->
        <section class="admin-tab" id="tab-packs">
            <div class="tab-header">
                <h2>订阅包档位</h2>
                <div class="tab-actions">
                    <button class="btn-mini primary" onclick="openPackTierModal()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">add</span> 新增档位
                    </button>
                </div>
            </div>
            <div class="callout-info" style="background:#e3f2fd;color:#0d47a1;padding:10px 14px;border-radius:8px;margin-bottom:14px;font-size:0.82rem;border:1px solid #bbdefb;">
                <strong>说明:</strong>这里增删改的档位,**前端充值卡片 / 支付校验 / 后端发包**全部联动生效,不需要改任何代码。<br>
                <strong>label</strong> 字段用于前端角标(例如填"最划算"会自动加金色徽章),留空则无角标。
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th>ID</th><th>价格(元)</th><th>Token 数</th><th>赠送余额</th><th>有效期(天)</th><th>标签</th><th>排序</th><th>状态</th><th>操作</th>
                    </tr></thead>
                    <tbody id="packTierTableBody"><tr><td colspan="9" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
        </section>

        <!-- ============ 次数包档位（v7 新增） ============ -->
        <section class="admin-tab" id="tab-count_packs">
            <div class="tab-header">
                <h2>次数包档位</h2>
                <div class="tab-actions">
                    <button class="btn-mini" onclick="syncCountPackUserModels(this)"
                            title="把每个档位“当前的可用模型”覆盖同步到所有买过对应价位次数包的用户（按购买价＝档位价匹配）。只动模型，不动次数/已用/有效期。">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">sync</span> 同步用户可用模型
                    </button>
                    <button class="btn-mini primary" onclick="openCountPackModal()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">add</span> 新增档位
                    </button>
                </div>
            </div>
            <div id="countPackSyncResult"
                 style="display:none;background:#eef6ff;border:1px solid #bcdcff;color:#0b4fa0;padding:8px 12px;border-radius:8px;margin-bottom:12px;font-size:0.82rem;line-height:1.6;"></div>
            <div class="callout-info" style="background:#e8f5e9;color:#1b5e20;padding:10px 14px;border-radius:8px;margin-bottom:14px;font-size:0.82rem;border:1px solid #c8e6c9;">
                <strong>次数包说明：</strong>
                <ul style="margin:6px 0 0;padding-left:20px;line-height:1.7;">
                    <li>每个套餐绑定<strong>一组指定模型</strong>，命中模型时<strong>每次调用扣 1 次（不扣余额、不扣 token）</strong>。</li>
                    <li>用户购买后：次数<strong>累加</strong>，过期时间<strong>顺延</strong>，但<strong>可用模型清单以最新购买的套餐为准（覆盖）</strong>。</li>
                    <li>用户在控制台切换"按次优先"时启用本桶；如未切换但模型命中也会自动用次数（兜底）。</li>
                    <li>用户没买过任何次数包时，本桶完全不参与计费，原 订阅包/余额/周额度 链路不变。</li>
                </ul>
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th>ID</th><th>价格(元)</th><th>次数</th><th>有效期(天)</th>
                        <th>绑定模型</th><th>标签</th><th>排序</th><th>状态</th><th>操作</th>
                    </tr></thead>
                    <tbody id="countPackTableBody"><tr><td colspan="9" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
        </section>

        <!-- ============ 兑换码 (2026-06-19) ============ -->
        <section class="admin-tab" id="tab-redeem">
            <div class="tab-header">
                <h2>兑换码</h2>
                <div class="tab-actions">
                    <button class="btn-mini" id="redeemBatchDelBtn" onclick="batchDeleteRedeem()" style="display:none;">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">delete</span> 删除所选
                    </button>
                    <button class="btn-mini primary" onclick="openRedeemModal()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">add</span> 批量生成
                    </button>
                </div>
            </div>

            <div class="callout-info" style="background:#eeecfe;color:#4a3fc0;padding:10px 14px;border-radius:8px;margin-bottom:14px;font-size:0.82rem;border:1px solid #ded9fb;">
                <strong>兑换码说明：</strong>
                <ul style="margin:6px 0 0;padding-left:20px;line-height:1.7;">
                    <li>兑换码为 16 位（数字 + 大写字母），用户在钱包页「使用兑换码」选项卡输入兑换。</li>
                    <li>可兑换：<strong>余额</strong>（元）/ <strong>Token 订阅包</strong>（自定义 token 数 + 有效期）/ <strong>次数包</strong>（选择模型 + 次数 + 有效期）。</li>
                    <li>每个码<strong>仅可使用一次</strong>，兑换后显示使用人与使用时间。可单个或整批删除。</li>
                </ul>
            </div>

            <!-- 汇总 + 筛选 -->
            <div style="display:flex;flex-wrap:wrap;gap:10px 18px;align-items:center;margin-bottom:14px;">
                <div id="redeemSummary" style="font-size:0.82rem;color:#374151;">总数 0 · 未使用 0 · 已使用 0</div>
                <div style="flex:1;"></div>
                <select id="redeemFilterStatus" onchange="loadRedeem()" style="padding:6px 10px;border:1px solid #e0e0e0;border-radius:8px;font-size:0.82rem;">
                    <option value="">全部状态</option>
                    <option value="unused">未使用</option>
                    <option value="used">已使用</option>
                </select>
                <input type="text" id="redeemFilterKw" placeholder="搜索 码 / 批次 / 备注 / 使用人"
                       oninput="onRedeemKwInput()"
                       style="padding:6px 10px;border:1px solid #e0e0e0;border-radius:8px;font-size:0.82rem;min-width:220px;">
            </div>

            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th style="width:34px;"><input type="checkbox" id="redeemCheckAll" onchange="toggleRedeemCheckAll(this)"></th>
                        <th>ID</th><th>兑换码</th><th>类型</th><th>奖励</th><th>有效期</th>
                        <th>状态</th><th>使用人</th><th>使用时间</th><th>批次</th><th>备注</th><th>操作</th>
                    </tr></thead>
                    <tbody id="redeemTableBody"><tr><td colspan="12" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
        </section>

        <!-- ============ 系统配置 ============ -->
        <section class="admin-tab" id="tab-config">
            <div class="tab-header">
                <h2>系统配置</h2>
                <div class="tab-actions">
                    <button class="btn-mini" onclick="addNewConfigKey()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">add</span> 新增配置项
                    </button>
                    <button class="btn-mini primary" onclick="saveAllConfigs()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">save</span> 保存全部
                    </button>
                </div>
            </div>

            <!-- v8.6 (2026-05-10) 免费通道关闭开关 ============================== -->
            <div class="dash-card" style="padding:18px 20px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;margin-bottom:16px;">
                <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:12px;">
                    <div style="flex:1;min-width:240px;">
                        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
                            <span class="material-symbols-rounded" style="font-size:20px;color:#dc2626;">block</span>
                            <strong style="font-size:0.95rem;color:#111;">关闭免费通道</strong>
                            <span id="freeBlockBadge" class="tag" style="display:none;background:#fef2f2;color:#dc2626;border:1px solid #fecaca;font-size:0.7rem;padding:2px 8px;">已关闭</span>
                        </div>
                        <div style="font-size:0.78rem;color:#6b7280;line-height:1.6;">
                            打开后,所有走<strong>本周免费额度</strong>的用户发消息时,服务器不会请求 AI,而是直接把下方提醒词原样回复给用户(不分段)。
                            <strong style="color:#16a34a;">订阅包用户、余额计费用户不受影响</strong>,正常请求。
                        </div>
                    </div>
                    <label class="toggle-switch" style="display:inline-flex;align-items:center;gap:10px;cursor:pointer;">
                        <input type="checkbox" id="freeBlockEnabled" onchange="onFreeBlockToggle(this.checked)">
                        <span class="toggle-slider"></span>
                    </label>
                </div>
                <div>
                    <label style="display:block;font-size:0.8rem;color:#374151;margin-bottom:6px;font-weight:500;">提醒词(关闭时给免费用户的回复内容)</label>
                    <textarea id="freeBlockMessage"
                        style="width:100%;min-height:72px;padding:10px 12px;border:1px solid #e5e7eb;border-radius:8px;font-family:inherit;font-size:0.85rem;line-height:1.5;resize:vertical;"
                        placeholder="例如:免费通道已临时关闭,请稍后再试或购买订阅包/充值后继续使用。"></textarea>
                    <div style="display:flex;justify-content:flex-end;margin-top:8px;">
                        <button class="btn-mini primary" onclick="saveFreeBlockConfig()">
                            <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">save</span> 保存免费通道配置
                        </button>
                    </div>
                </div>
            </div>

            <div id="configContent">
                <div class="empty-state">加载中...</div>
            </div>
        </section>

        <!-- ============ v11 (2026-05-12) 提示词预设 ============ -->
        <section class="admin-tab" id="tab-prompt_presets">
            <div class="tab-header">
                <h2>提示词预设</h2>
                <div class="tab-actions">
                    <button class="btn-mini primary" onclick="openPresetEditor()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">add</span> 新增预设
                    </button>
                </div>
            </div>
            <div class="callout-info" style="background:#e3f2fd;color:#0d47a1;padding:10px 14px;border-radius:8px;margin-bottom:14px;font-size:0.82rem;border:1px solid #bbdefb;line-height:1.7;">
                <strong>说明:</strong>预设由用户在实例「配置」里选择,每次收到消息时 chat.py 实时拉取构建提示词。<br>
                <strong>可用变量(必须用花括号,格式严格):</strong>
                <code style="background:#fff;padding:1px 6px;border-radius:4px;border:1px solid #bbdefb;">{persona}</code>
                <code style="background:#fff;padding:1px 6px;border-radius:4px;border:1px solid #bbdefb;">{user_persona}</code>
                <code style="background:#fff;padding:1px 6px;border-radius:4px;border:1px solid #bbdefb;">{emojis}</code>
                <code style="background:#fff;padding:1px 6px;border-radius:4px;border:1px solid #bbdefb;">{current_time}</code>
                <code style="background:#fff;padding:1px 6px;border-radius:4px;border:1px solid #bbdefb;">{user_text}</code>
                — 字段空时变量替换为空串。<br>
                <strong>时间感知开关:</strong>实例「实验性功能」里的"时间感知"关闭时,<code style="background:#fff;padding:1px 6px;border-radius:4px;border:1px solid #bbdefb;">{current_time}</code> 始终为空,防部分模型对时间格式敏感掉格式。<br>
                <strong>用户视角:</strong>下拉只显示 <code>name</code> 和 <code>description</code>,prompt 全文用户看不到。
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th>ID</th><th>名称</th><th>简介</th><th>状态</th><th>排序</th><th>更新时间</th><th>操作</th>
                    </tr></thead>
                    <tbody id="presetTableBody"><tr><td colspan="7" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
        </section>

        <!-- ============ 工具注册 ============ -->
        <section class="admin-tab" id="tab-tools">
            <div class="tab-header">
                <h2>工具注册</h2>
                <div class="tab-actions">
                    <button class="btn-mini primary" onclick="openToolModal()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">add</span> 新增工具
                    </button>
                </div>
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th>ID</th><th>tool_name</th><th>展示名</th><th>图标</th><th>核心</th><th>启用</th><th>排序</th><th>操作</th>
                    </tr></thead>
                    <tbody id="toolTableBody"><tr><td colspan="8" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
        </section>

        <!-- ============ 人格市场 ============ -->
        <section class="admin-tab" id="tab-market">
            <div class="tab-header">
                <h2>人格市场管理</h2>
                <div class="tab-actions">
                    <button class="btn-mini primary" onclick="openMarketModal()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">add</span> 新增人格
                    </button>
                </div>
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th>ID</th><th>头像</th><th>名称</th><th>描述</th><th>上传者</th><th>下载数</th><th>状态</th><th>操作</th>
                    </tr></thead>
                    <tbody id="marketTableBody"><tr><td colspan="8" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
        </section>

        <!-- ============ 邮件队列 ============ -->
        <section class="admin-tab" id="tab-emails">
            <div class="tab-header">
                <h2>邮件队列（最近 100 条）</h2>
                <div class="tab-actions">
                    <button class="btn-mini" onclick="loadEmails()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">refresh</span> 刷新
                    </button>
                    <button class="btn-mini danger" onclick="purgeEmails()">清理 7 天前成功记录</button>
                </div>
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th>ID</th><th>邮箱</th><th>验证码</th><th>状态</th><th>创建时间</th>
                    </tr></thead>
                    <tbody id="emailTableBody"><tr><td colspan="5" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
        </section>

        <!-- ============ 用户留言管理 ============ -->
        <!-- ============ v9.2 鸣谢管理 ============ -->
        <section class="admin-tab" id="tab-testimonials">
            <div class="tab-header">
                <h2>鸣谢管理</h2>
                <div class="tab-actions">
                    <button class="btn-mini primary" onclick="openTestimonialForm(null)">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">add</span> 新增
                    </button>
                    <button class="btn-mini" onclick="loadTestimonials()" style="margin-left:6px;">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">refresh</span> 刷新
                    </button>
                </div>
            </div>
            <div class="callout-info" style="background:#f0fdf4;color:#166534;padding:10px 14px;border-radius:8px;margin-bottom:14px;font-size:0.82rem;border:1px solid #bbf7d0;">
                在首页 Hero 区与按钮之间展示两行滑动鸣谢头像。<strong>第 0 行向右滑动,第 1 行向左滑动。</strong>
                头像填写图片 URL 或 base64 data URL;内容最多 200 字。
            </div>
            <div class="data-table-wrap">
                <table class="data-table" id="testimonialTable">
                    <thead><tr>
                        <th style="width:48px;">ID</th>
                        <th style="width:56px;">头像</th>
                        <th style="width:100px;">名字</th>
                        <th>内容</th>
                        <th style="width:60px;">行号</th>
                        <th style="width:60px;">排序</th>
                        <th style="width:64px;">状态</th>
                        <th style="width:100px;">操作</th>
                    </tr></thead>
                    <tbody id="testimonialBody"><tr><td colspan="8" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>

            <!-- 编辑弹窗 -->
            <div id="testimonialModal" class="admin-modal-backdrop" style="display:none;">
                <div class="admin-modal" style="max-width:480px;">
                    <div class="admin-modal-title" id="testimonialModalTitle">新增鸣谢</div>
                    <input type="hidden" id="tmId">
                    <input type="hidden" id="tmAvatar">
                    <div class="form-row">
                        <label>头像</label>
                        <div style="display:flex;align-items:center;gap:12px;margin-top:4px;">
                            <img id="tmAvatarPreview" src="" alt=""
                                 style="width:52px;height:52px;border-radius:50%;object-fit:cover;border:1.5px solid #e5e7eb;background:#f3f4f6;display:none;">
                            <div id="tmAvatarPlaceholder" style="width:52px;height:52px;border-radius:50%;background:#f3f4f6;border:1.5px solid #e5e7eb;display:flex;align-items:center;justify-content:center;font-size:1.4rem;color:#9ca3af;flex-shrink:0;">👤</div>
                            <div>
                                <label class="btn-mini" style="cursor:pointer;display:inline-block;">
                                    <span class="material-symbols-rounded" style="font-size:15px;vertical-align:middle">upload</span> 上传头像
                                    <input type="file" id="tmAvatarFile" accept="image/*" style="display:none;" onchange="onTmAvatarChange(this)">
                                </label>
                                <div style="font-size:0.72rem;color:#9ca3af;margin-top:4px;">建议正方形图，≤ 500 KB</div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row" style="margin-top:10px;">
                        <label>名字</label>
                        <input type="text" class="custom-input" id="tmName" placeholder="昵称 / 名字">
                    </div>
                    <div class="form-row" style="margin-top:10px;">
                        <label>内容 <span style="color:#9ca3af;font-size:0.75rem;">(最多 200 字)</span></label>
                        <textarea class="custom-input" id="tmContent" rows="3" placeholder="一句话内容" style="resize:vertical;"></textarea>
                    </div>
                    <div style="display:flex;gap:12px;margin-top:10px;">
                        <div class="form-row" style="flex:1;">
                            <label>行号</label>
                            <select class="custom-input" id="tmRowIndex">
                                <option value="0">0 — 向右滑</option>
                                <option value="1">1 — 向左滑</option>
                            </select>
                        </div>
                        <div class="form-row" style="flex:1;">
                            <label>排序(数字越小越靠前)</label>
                            <input type="number" class="custom-input" id="tmSort" value="0" min="0" step="1">
                        </div>
                        <div class="form-row" style="flex:1;">
                            <label>状态</label>
                            <select class="custom-input" id="tmActive">
                                <option value="1">展示</option>
                                <option value="0">隐藏</option>
                            </select>
                        </div>
                    </div>
                    <div style="display:flex;gap:8px;margin-top:18px;justify-content:flex-end;">
                        <button class="btn-mini" onclick="closeTestimonialForm()">取消</button>
                        <button class="btn-mini primary" onclick="saveTestimonial()">保存</button>
                    </div>
                </div>
            </div>
        </section>

        <!-- ============ 手机号黑名单 (2026-07-07) ============ -->
        <section class="admin-tab" id="tab-phone_blacklist">
            <div class="tab-header">
                <h2>手机号黑名单</h2>
                <div class="tab-actions">
                    <button class="btn-mini primary" onclick="openPhoneBlacklistForm()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">add</span> 添加手机号
                    </button>
                    <button class="btn-mini" onclick="loadPhoneBlacklist()" style="margin-left:6px;">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">refresh</span> 刷新
                    </button>
                </div>
            </div>
            <div class="callout-info" style="background:#fef2f2;color:#991b1b;padding:10px 14px;border-radius:8px;margin-bottom:14px;font-size:0.82rem;border:1px solid #fecaca;">
                黑名单中的手机号在<strong>注册发送验证码之前</strong>即被拦截,前台提示「<strong>已注销用户不得再次注册</strong>」。
                适用于已注销 / 违规注销的账号手机号,防止其重复注册。
            </div>
            <div style="display:flex;gap:8px;margin-bottom:12px;align-items:center;">
                <input type="text" class="custom-input" id="pblKeyword" placeholder="搜索手机号 / 备注..."
                       style="max-width:260px;" onkeydown="if(event.key==='Enter')loadPhoneBlacklist()">
                <button class="btn-mini" onclick="loadPhoneBlacklist()">搜索</button>
                <span id="pblCount" style="font-size:0.8rem;color:#9ca3af;margin-left:auto;"></span>
            </div>
            <div class="data-table-wrap">
                <table class="data-table" id="phoneBlacklistTable">
                    <thead><tr>
                        <th style="width:56px;">ID</th>
                        <th style="width:140px;">手机号</th>
                        <th>原因备注</th>
                        <th style="width:100px;">操作人</th>
                        <th style="width:150px;">加入时间</th>
                        <th style="width:80px;">操作</th>
                    </tr></thead>
                    <tbody id="phoneBlacklistBody"><tr><td colspan="6" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>

            <!-- 添加弹窗 -->
            <div id="phoneBlacklistModal" class="admin-modal-backdrop" style="display:none;">
                <div class="admin-modal" style="max-width:460px;">
                    <div class="admin-modal-title">添加手机号到黑名单</div>
                    <div class="form-row">
                        <label>手机号 <span style="color:#9ca3af;font-size:0.75rem;">(支持批量,每行一个,或用逗号/空格分隔,单次最多 200 个)</span></label>
                        <textarea class="custom-input" id="pblPhones" rows="4"
                                  placeholder="13800138000&#10;13900139000"
                                  style="resize:vertical;font-family:monospace;"></textarea>
                    </div>
                    <div class="form-row" style="margin-top:10px;">
                        <label>原因备注 <span style="color:#9ca3af;font-size:0.75rem;">(选填,最多 200 字)</span></label>
                        <input type="text" class="custom-input" id="pblReason" placeholder="例如:用户主动注销 / 违规封号注销">
                    </div>
                    <div style="display:flex;gap:8px;margin-top:18px;justify-content:flex-end;">
                        <button class="btn-mini" onclick="closePhoneBlacklistForm()">取消</button>
                        <button class="btn-mini primary" onclick="savePhoneBlacklist()">添加</button>
                    </div>
                </div>
            </div>
        </section>

        <!-- ============ v9.3 预设音色管理 ============ -->
        <section class="admin-tab" id="tab-preset_voices">
            <div class="tab-header">
                <h2>预设音色</h2>
                <div class="tab-actions">
                    <button class="btn-mini primary" onclick="openPresetVoiceForm(null)">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">add</span> 新增
                    </button>
                    <button class="btn-mini" onclick="loadPresetVoices()" style="margin-left:6px;">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">refresh</span> 刷新
                    </button>
                </div>
            </div>
            <div class="callout-info" style="background:#f3f1fe;color:#4a3fc0;padding:10px 14px;border-radius:8px;margin-bottom:14px;font-size:0.82rem;border:1px solid #ded9fb;">
                预设音色 ID 全局公开,所有用户在「实验性功能 → 语音」里可见。
                <strong>voice_id</strong> 是 dashscope (CosyVoice) 返回的纯字符串(如 <code>longxiaochun_v2</code> 或自行克隆的 <code>myvoice-xxxx</code>)。
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th style="width:48px;">ID</th>
                        <th style="width:200px;">voice_id</th>
                        <th>显示名</th>
                        <th style="width:64px;">状态</th>
                        <th style="width:100px;">操作</th>
                    </tr></thead>
                    <tbody id="presetVoiceBody"><tr><td colspan="5" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>

            <!-- 编辑弹窗 -->
            <div id="presetVoiceModal" class="admin-modal-backdrop" style="display:none;">
                <div class="admin-modal" style="max-width:420px;">
                    <div class="admin-modal-title" id="pvModalTitle">新增预设音色</div>
                    <input type="hidden" id="pvId">
                    <div class="form-row">
                        <label>voice_id</label>
                        <input type="text" class="custom-input" id="pvVoiceId" placeholder="如: longxiaochun_v2">
                    </div>
                    <div class="form-row" style="margin-top:10px;">
                        <label>显示名</label>
                        <input type="text" class="custom-input" id="pvName" placeholder="如: 龙小淳">
                    </div>
                    <div class="form-row" style="margin-top:10px;">
                        <label>状态</label>
                        <select class="custom-input" id="pvActive">
                            <option value="1">启用</option>
                            <option value="0">隐藏</option>
                        </select>
                    </div>
                    <div style="display:flex;gap:8px;margin-top:18px;justify-content:flex-end;">
                        <button class="btn-mini" onclick="closePresetVoiceForm()">取消</button>
                        <button class="btn-mini primary" onclick="savePresetVoice()">保存</button>
                    </div>
                </div>
            </div>
        </section>

        <section class="admin-tab" id="tab-voice_call">
            <div class="tab-header">
                <h2>语音通话</h2>
                <div class="tab-actions">
                    <button class="btn-mini" onclick="loadVoiceCall()"><span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">refresh</span> 刷新</button>
                </div>
            </div>
            <div style="display:flex;gap:12px;margin-bottom:14px;flex-wrap:wrap;">
                <div style="flex:1;min-width:130px;background:#fff;border:1px solid #eee;border-radius:10px;padding:12px 16px;">
                    <div style="font-size:1.5rem;font-weight:700;color:#111;" id="vcMemberCount">-</div>
                    <div style="font-size:0.78rem;color:#888;">有效会员</div>
                </div>
                <div style="flex:1;min-width:130px;background:#fff;border:1px solid #eee;border-radius:10px;padding:12px 16px;">
                    <div style="font-size:1.5rem;font-weight:700;color:#111;" id="vcVoiceCount">-</div>
                    <div style="font-size:0.78rem;color:#888;">已克隆音色</div>
                </div>
            </div>
            <div class="callout-info" style="background:#fff7ed;color:#9a3412;padding:10px 14px;border-radius:8px;margin-bottom:14px;font-size:0.82rem;border:1px solid #fed7aa;">
                删除音色会<strong>同时删除阿里云和数据库</strong>的音色 ID（释放阿里云配额），该用户需重新上传样音克隆。
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th style="width:60px;">用户ID</th>
                        <th style="width:110px;">用户名</th>
                        <th>音色 ID</th>
                        <th style="width:96px;">音色名</th>
                        <th style="width:92px;">会员到期</th>
                        <th style="width:52px;">微信</th>
                        <th style="width:72px;">操作</th>
                    </tr></thead>
                    <tbody id="voiceCallBody"><tr><td colspan="7" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>

            <div style="margin-top:28px;border-top:1px solid #eee;padding-top:18px;">
                <div class="tab-header" style="margin-bottom:10px;">
                    <h2 style="font-size:1.02rem;">阿里云账号音色（全部 ID）</h2>
                    <div class="tab-actions">
                        <button class="btn-mini" onclick="loadDashscopeVoices()"><span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">cloud_download</span> 拉取全部</button>
                        <button class="btn-mini" style="margin-left:6px;color:#d94a4a;border-color:#f0d2d2" onclick="purgeAllDashscope()"><span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">delete_sweep</span> 批量删除全部</button>
                    </div>
                </div>
                <div class="callout-info" style="background:#fef2f2;color:#991b1b;padding:10px 14px;border-radius:8px;margin-bottom:12px;font-size:0.82rem;border:1px solid #fecaca;">
                    这里是<strong>阿里云账号下的全部音色 ID</strong>（配额上限 1000），含已从数据库删除但阿里云仍占用的“孤儿”音色。批量删除会<strong>逐个调真实接口删除、释放全部配额，不可恢复</strong>。
                </div>
                <div id="dsVoiceSummary" style="font-size:0.85rem;color:#555;margin-bottom:10px;">点击「拉取全部」查看账号下音色。</div>
                <div class="data-table-wrap">
                    <table class="data-table">
                        <thead><tr>
                            <th style="width:44px;">#</th>
                            <th>音色 ID</th>
                            <th style="width:66px;">状态</th>
                            <th style="width:150px;">创建时间</th>
                            <th style="width:96px;">库内归属</th>
                            <th style="width:66px;">操作</th>
                        </tr></thead>
                        <tbody id="dsVoiceBody"><tr><td colspan="6" class="empty-state">未拉取</td></tr></tbody>
                    </table>
                </div>
            </div>

            <div style="margin-top:28px;border-top:1px solid #eee;padding-top:18px;">
                <div class="tab-header" style="margin-bottom:10px;">
                    <h2 style="font-size:1.02rem;">音色广场（用户可导入）</h2>
                </div>
                <div class="callout-info" style="background:#ecfeff;color:#155e75;padding:10px 14px;border-radius:8px;margin-bottom:12px;font-size:0.82rem;border:1px solid #a5f3fc;">
                    这里添加的音色会出现在用户端「音色广场」，用户可一键导入（不扣费）。音色 ID 填 DashScope 的 voice_id。
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px;">
                    <input id="sqName" placeholder="名称，如「温柔女声」" style="flex:1;min-width:140px;padding:9px 12px;border:1px solid #ddd;border-radius:8px;font-size:0.85rem;">
                    <input id="sqVoiceId" placeholder="音色 ID (voice_id)" style="flex:2;min-width:200px;padding:9px 12px;border:1px solid #ddd;border-radius:8px;font-size:0.85rem;font-family:monospace;">
                    <input id="sqNote" placeholder="备注(可选)" style="flex:1;min-width:110px;padding:9px 12px;border:1px solid #ddd;border-radius:8px;font-size:0.85rem;">
                    <button class="btn-mini" onclick="addSquare()" style="background:#0891b2;color:#fff;border-color:#0891b2;">添加</button>
                </div>
                <div class="data-table-wrap">
                    <table class="data-table">
                        <thead><tr><th style="width:50px;">ID</th><th style="width:120px;">名称</th><th>音色 ID</th><th style="width:110px;">备注</th><th style="width:60px;">操作</th></tr></thead>
                        <tbody id="squareBody"><tr><td colspan="5" class="empty-state">加载中...</td></tr></tbody>
                    </table>
                </div>
            </div>
        </section>

        <section class="admin-tab" id="tab-messages">
            <div class="tab-header">
                <h2>用户留言</h2>
                <div class="tab-actions">
                    <button class="btn-mini" onclick="loadMessages()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">refresh</span> 刷新
                    </button>
                </div>
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th style="width:64px;">ID</th>
                        <th style="width:120px;">用户</th>
                        <th>留言 / 回复</th>
                        <th style="width:140px;">时间</th>
                        <th style="width:100px;">状态</th>
                        <th style="width:90px;">操作</th>
                    </tr></thead>
                    <tbody id="msgTableBody"><tr><td colspan="6" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
            <div class="pagination" id="msgPagination"></div>
        </section>

        <!-- ============ v8.4 (2026-05-10) 限时抽奖管理 ============ -->
        <section class="admin-tab" id="tab-lottery">
            <div class="tab-header">
                <h2>限时抽奖</h2>
                <div class="tab-actions">
                    <button class="btn-mini" onclick="loadLottery()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">refresh</span> 刷新
                    </button>
                    <button class="btn-mini primary" id="lotteryDrawBtn" onclick="drawLottery(false)" style="margin-left:8px;display:none;">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">casino</span> 立即开奖
                    </button>
                    <button class="btn-mini danger" id="lotteryRedrawBtn" onclick="drawLottery(true)" style="margin-left:8px;display:none;">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">restart_alt</span> 重新开奖
                    </button>
                </div>
            </div>

            <div class="callout-info" style="background:#fffbeb;color:#92400e;padding:10px 14px;border-radius:8px;margin-bottom:14px;font-size:0.82rem;border:1px solid #fde68a;">
                <strong>使用说明:</strong>本期实现"报名 + 开奖 + 显示中奖名单"。开奖按钮在<strong>截止时间到</strong>后才可用,
                点一下服务端会随机抽人,把结果写入 <code>lottery_entries.is_winner</code> + <code>prize_id</code>。
                <strong>发奖脚本暂未实现 — 拿到中奖名单后再写发奖逻辑给他们 add 余额 / 次数包 / 订阅包额度即可。</strong>
                <br>
                奖品配置在 3 处:<code>api/api_lottery.php</code> 的 <code>lottery_prizes()</code>、
                <code>admin.php</code> 的 <code>$LOTTERY_PRIZES</code>、
                <code>console.php</code> 的 <code>LOTTERY_PRIZES_FALLBACK</code>(三处必须一致)。
            </div>

            <!-- 概览卡 -->
            <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px;">
                <div class="dash-card" style="flex:1;min-width:160px;padding:14px;background:#fff;border:1px solid #e5e7eb;border-radius:10px;">
                    <div style="font-size:0.78rem;color:#6b7280;">本期活动 ID</div>
                    <div id="lotteryActiveId" style="font-family:ui-monospace,Menlo,monospace;font-size:0.9rem;font-weight:600;margin-top:4px;word-break:break-all;">--</div>
                </div>
                <div class="dash-card" style="flex:1;min-width:140px;padding:14px;background:#fff;border:1px solid #e5e7eb;border-radius:10px;">
                    <div style="font-size:0.78rem;color:#6b7280;">报名人数</div>
                    <div id="lotteryEntryCount" style="font-size:1.6rem;font-weight:700;color:#111;margin-top:2px;">--</div>
                </div>
                <div class="dash-card" style="flex:1;min-width:140px;padding:14px;background:#fff;border:1px solid #e5e7eb;border-radius:10px;">
                    <div style="font-size:0.78rem;color:#6b7280;">中奖人数</div>
                    <div id="lotteryWinnerCount" style="font-size:1.6rem;font-weight:700;color:#16a34a;margin-top:2px;">--</div>
                </div>
                <div class="dash-card" style="flex:1;min-width:160px;padding:14px;background:#fff;border:1px solid #e5e7eb;border-radius:10px;">
                    <div style="font-size:0.78rem;color:#6b7280;">开奖时间</div>
                    <div id="lotteryDeadline" style="font-size:0.9rem;font-weight:600;color:#111;margin-top:4px;">--</div>
                </div>
                <div class="dash-card" style="flex:1;min-width:140px;padding:14px;background:#fff;border:1px solid #e5e7eb;border-radius:10px;">
                    <div style="font-size:0.78rem;color:#6b7280;">已发奖人数</div>
                    <div id="lotteryAwardedCount" style="font-size:1.6rem;font-weight:700;color:#111;margin-top:2px;">--</div>
                </div>
            </div>

            <!-- 中奖名单(开奖后填充,按奖项分组) -->
            <div id="lotteryWinnersBlock" style="display:none;margin-bottom:20px;">
                <h3 style="margin:0 0 12px;font-size:0.95rem;font-weight:600;color:#111;">🎉 中奖名单(按奖项分组)</h3>
                <div id="lotteryWinnersGrid" style="display:flex;flex-direction:column;gap:12px;"></div>
            </div>

            <!-- 报名名单 -->
            <h3 style="margin:0 0 12px;font-size:0.95rem;font-weight:600;color:#111;">📋 报名名单</h3>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th style="width:64px;">ID</th>
                        <th style="width:90px;">用户 ID</th>
                        <th>用户名</th>
                        <th style="width:120px;">报名时余额</th>
                        <th style="width:100px;">报名时邀请数</th>
                        <th style="width:140px;">IP</th>
                        <th style="width:160px;">报名时间</th>
                        <th style="width:160px;">中奖 / 奖项</th>
                    </tr></thead>
                    <tbody id="lotteryTableBody"><tr><td colspan="8" class="empty-state">加载中...</td></tr></tbody>
                </table>
            </div>
        </section>


        <!-- ============ 公告管理（v2 新增） ============ -->
        <section class="admin-tab" id="tab-announcement">
            <div class="tab-header">
                <h2>公告管理</h2>
                <div class="tab-actions">
                    <button class="btn-mini" onclick="loadAnnouncement()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">refresh</span> 刷新
                    </button>
                </div>
            </div>
            <div style="background:#fff8e1; border:1px solid rgba(245,158,11,0.25); border-radius:10px; padding:12px 14px; margin-bottom:14px; font-size:0.85rem; color:#92400e;">
                <strong>说明：</strong>每次保存公告时会自动 bump 版本号，所有用户下次进入控制台时会重新弹一次。
                公告内容支持 HTML（<code>&lt;p&gt;</code>、<code>&lt;strong&gt;</code>、<code>&lt;ul&gt;</code> 等），
                建议保持简洁。留空则不弹窗。
            </div>
            <div class="form-row">
                <div class="form-group" style="flex: 1;">
                    <label>公告内容（HTML）</label>
                    <textarea id="annContent" rows="14" style="width:100%; font-family:Menlo, Consolas, monospace; font-size:0.86rem; padding:12px; border:1px solid #ddd; border-radius:8px; resize:vertical;" placeholder="例：&lt;p&gt;&lt;strong&gt;新版上线&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;改用每周 50 万 Token 免费额度...&lt;/p&gt;"></textarea>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group" style="flex: 1;">
                    <label>预览</label>
                    <div id="annPreview" style="background:#fff; border:1px solid #eee; border-radius:8px; padding:14px 18px; min-height:60px; font-size:0.92rem; line-height:1.7; color:#333;"></div>
                </div>
            </div>
            <div class="form-row" style="align-items:center;">
                <div style="flex:1; font-size:0.85rem; color:#666;">
                    当前版本号：<code id="annVersion">--</code> · 最后更新：<span id="annUpdatedAt">--</span>
                </div>
                <button class="btn-mini primary" onclick="saveAnnouncement()" style="min-width:100px;">保存并发布</button>
            </div>
        </section>

        <!-- ============ 推广视频审核（v2.1 新增） ============ -->
        <section class="admin-tab" id="tab-videos">
            <div class="tab-header">
                <h2>推广视频审核</h2>
                <div class="tab-actions">
                    <select id="videoStatusFilter" onchange="loadVideos()">
                        <option value="pending">待审核</option>
                        <option value="approved">已通过</option>
                        <option value="rejected">已拒绝</option>
                        <option value="rewarded">已奖励 + 包</option>
                        <option value="">全部状态</option>
                    </select>
                    <input type="search" id="videoUserKw" placeholder="按用户名搜索" oninput="debouncedLoadVideos()" style="width:160px;">
                    <button class="btn-mini" onclick="loadVideos()">
                        <span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">refresh</span> 刷新
                    </button>
                </div>
            </div>
            <div style="background:#fff8e1; border:1px solid rgba(245,158,11,0.25); border-radius:10px; padding:10px 14px; margin-bottom:14px; font-size:0.82rem; color:#6c5b00;">
                <strong>说明：</strong>「通过」给用户永久 +20 万 Token / 周（叠加到 <code>bonus_weekly_tokens</code>）；
                「拒绝」需要填写原因；「赠送订阅包」选档位后将累加到用户的 <code>pro_pack_total</code> 并叠加 30 天有效期。
                每个视频只发一次奖励，重复操作不会再加。
            </div>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 60px;">ID</th>
                            <th style="width: 130px;">用户</th>
                            <th>视频链接 / 描述</th>
                            <th style="width: 90px;">状态</th>
                            <th style="width: 130px;">提交时间</th>
                            <th style="width: 280px;">操作</th>
                        </tr>
                    </thead>
                    <tbody id="videoTbody">
                        <tr><td colspan="6" class="empty-hint">加载中…</td></tr>
                    </tbody>
                </table>
            </div>
            <div class="pagination" id="videoPagination"></div>

            <!-- 用户快速调整面板（v2.1 · "小用户管理"） -->
            <div style="margin-top: 24px; padding: 18px; background: #fafafa; border: 1px solid #eee; border-radius: 12px;">
                <h3 style="margin: 0 0 4px; font-size: 1rem;">快速调整用户额度</h3>
                <p class="hint-text" style="margin-bottom: 14px;">不离开本页就能给某用户加 token / 加包，等价于用户管理那里改一次后保存。</p>
                <div class="form-row">
                    <div class="form-group" style="flex: 1.2;">
                        <label>用户名 / ID</label>
                        <input type="text" class="custom-input" id="quickUserKey" placeholder="精确用户名或数字 ID">
                    </div>
                    <div class="form-group" style="flex: 1;">
                        <label>+周额度（bonus_weekly_tokens）</label>
                        <input type="number" class="custom-input" id="quickAddBonus" min="0" step="100000" placeholder="例：200000">
                    </div>
                    <div class="form-group" style="flex: 1;">
                        <label>+订阅包档位（赠送）</label>
                        <select id="quickGiftPack">
                            <option value="0">不赠送</option>
                            <option value="9.9">¥9.9 档（150 万 token + 30 天）</option>
                            <option value="15.9">¥15.9 档（250 万 + 30 天）</option>
                            <option value="29.9">¥29.9 档（500 万 + 30 天）</option>
                            <option value="39.9">¥39.9 档（800 万 + 30 天）</option>
                            <option value="49.9">¥49.9 档（1200 万 + 30 天）</option>
                        </select>
                    </div>
                    <div class="form-group" style="flex: 0 0 100px;">
                        <label>&nbsp;</label>
                        <button class="btn-mini primary" style="width:100%; height:40px;" onclick="quickAdjustUser()">应用</button>
                    </div>
                </div>
                <div id="quickAdjustResult" style="margin-top: 10px; font-size: 0.82rem; color: #555;"></div>
            </div>
        </section>


        <!-- ============ 紧急公告广播（v2.2 新增） ============ -->
        <section class="admin-tab" id="tab-announce">
            <div class="tab-header">
                <h2>紧急公告广播</h2>
            </div>

            <div style="background:#fef2f2; border:1px solid #fecaca; border-radius:10px; padding:12px 16px; margin-bottom:16px; font-size:0.85rem; color:#991b1b; line-height:1.6;">
                <strong>⚠ 高危操作</strong>，请确认以下事项后再触发：
                <ol style="margin:6px 0 0; padding-left:20px;">
                    <li>消息会发送给<strong>所有当前 status=启动 的实例</strong>下，<strong>历史交互过的全部 uid</strong>。</li>
                    <li>全局节流 <strong>3 条 / 秒</strong>，1000 个用户大约耗时 5–6 分钟，期间不可中断。</li>
                    <li>失败的单条会记录但不重试；具体失败列表可在下方查看。</li>
                    <li>本工具不是常驻服务，每次触发会启动一个独立 Python 进程跑完即退。</li>
                </ol>
            </div>

            <div class="form-row" style="flex-direction:column;gap:10px;">
                <div class="form-group" style="flex:1;">
                    <label>公告内容（建议 ≤ 200 字，硬上限 1000 字）</label>
                    <textarea id="annText" class="custom-input" rows="6"
                        placeholder="请输入要广播给所有用户的公告内容..."
                        style="resize:vertical;min-height:120px;"></textarea>
                    <div class="hint-text" style="margin-top:4px;">
                        <span id="annCharCount">0</span> 字
                    </div>
                </div>
                <div style="display:flex;gap:10px;align-items:center;">
                    <button class="btn-mini" style="background:#dc2626;color:#fff;height:42px;padding:0 22px;font-size:0.92rem;"
                        onclick="confirmBroadcast()">
                        <span class="material-symbols-rounded" style="font-size:18px;vertical-align:middle">campaign</span>
                        立即广播
                    </button>
                    <span class="hint-text">会在下方实时显示进度</span>
                </div>
            </div>

            <!-- 派发结果 / 注意提醒 -->
            <div id="annLaunchTip" style="display:none; margin-top:14px;"></div>

            <!-- 进度面板 -->
            <div id="annProgressPanel" style="margin-top:24px; display:none;">
                <h3 style="margin:0 0 10px;font-size:1rem;">最近一次广播进度</h3>
                <div class="stat-grid" id="annStatGrid"></div>
                <!-- 进度条 -->
                <div style="margin-top:14px;background:#f3f4f6;border-radius:8px;height:18px;overflow:hidden;">
                    <div id="annBar" style="background:linear-gradient(90deg,#7367f0,#16a34a);height:100%;width:0%;transition:width 0.4s;"></div>
                </div>
                <div style="display:flex;justify-content:space-between;margin-top:6px;">
                    <span class="hint-text" id="annProgText">--</span>
                    <span class="hint-text" id="annStatusText">--</span>
                </div>

                <!-- 错误明细（最多 50 条） -->
                <div style="margin-top:18px;">
                    <h3 style="margin:0 0 8px;font-size:0.95rem;">失败明细 <span class="hint-text" id="annErrCount">(0)</span></h3>
                    <div class="data-table-wrap" style="max-height:280px;overflow-y:auto;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th style="width:80px;">实例</th>
                                    <th style="width:200px;">UID</th>
                                    <th>错误</th>
                                </tr>
                            </thead>
                            <tbody id="annErrTbody">
                                <tr><td colspan="3" class="empty-hint">暂无失败</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>

        <!-- ============ 版本日志 (v13.12 · 2026-05-14) ============ -->
        <section class="admin-tab" id="tab-versions">
            <div class="tab-header">
                <h2>版本日志</h2>
                <div class="tab-actions">
                    <button class="btn-mini" onclick="openVersionEditor()">
                        <span class="material-symbols-rounded">add</span>新增版本
                    </button>
                </div>
            </div>
            <p class="hint-text" style="margin: 0 0 14px; color:#888; font-size:0.85rem;">
                这里管理首页时间轴上展示的版本更新历史。首页只显示已发布的最近 5 条,按发布日期倒序。
            </p>
            <div class="data-table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width:90px;">版本</th>
                            <th style="width:110px;">日期</th>
                            <th>标题</th>
                            <th style="width:80px;">发布?</th>
                            <th style="width:160px;">操作</th>
                        </tr>
                    </thead>
                    <tbody id="versionsTbody">
                        <tr><td colspan="5" class="empty-hint">加载中…</td></tr>
                    </tbody>
                </table>
            </div>
        </section>

<section class="admin-tab" id="tab-broadcast">
  <style>
    #tab-broadcast .hb-wrap { max-width: 1000px; }
    #tab-broadcast h2 { margin: 0 0 4px; }
    #tab-broadcast .hb-sub { color:#888; font-size:.85rem; margin-bottom:16px; }
    #tab-broadcast .hb-form { background:#fff; border:1px solid #eee; border-radius:12px; padding:18px 20px; margin-bottom:20px; }
    #tab-broadcast .hb-form label { display:block; font-size:.82rem; color:#444; margin:10px 0 4px; }
    #tab-broadcast .hb-form input, #tab-broadcast .hb-form select, #tab-broadcast .hb-form textarea {
        width:100%; box-sizing:border-box; padding:9px 11px; border:1px solid #d8d8d8; border-radius:8px; font-size:.9rem; }
    #tab-broadcast .hb-form textarea { min-height:96px; resize:vertical; }
    #tab-broadcast .hb-row { display:grid; grid-template-columns:1fr 1fr 1fr; gap:12px; }
    #tab-broadcast .hb-send { margin-top:16px; background:#db2777; color:#fff; border:0; border-radius:9px;
        padding:11px 22px; font-size:.92rem; cursor:pointer; }
    #tab-broadcast .hb-send:hover { background:#be185d; }
    #tab-broadcast table { width:100%; border-collapse:collapse; background:#fff; border-radius:12px; overflow:hidden; box-shadow:0 2px 10px rgba(0,0,0,.04); }
    #tab-broadcast th,#tab-broadcast td { padding:11px 13px; text-align:left; font-size:.84rem; border-bottom:1px solid #f0f0f0; }
    #tab-broadcast th { background:#fafafa; color:#666; font-weight:600; }
    #tab-broadcast tr.hb-clickable:hover { background:#fafafa; cursor:pointer; }
    #tab-broadcast .hb-badge { display:inline-block; padding:2px 10px; border-radius:999px; font-size:.74rem; }
    #tab-broadcast .hb-s0 { background:#fef3c7; color:#92400e; }   /* 待派发 */
    #tab-broadcast .hb-s1 { background:#e6e2fd; color:#4a3fc0; }   /* 进行中 */
    #tab-broadcast .hb-s2 { background:#d1fae5; color:#065f46; }   /* 已完成 */
    #tab-broadcast .hb-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:9999; }
    #tab-broadcast .hb-overlay.show { display:flex; align-items:center; justify-content:center; }
    #tab-broadcast .hb-modal { background:#fff; width:min(720px,92vw); max-height:82vh; overflow:auto; border-radius:14px; padding:20px; }
    #tab-broadcast .hb-item { border:1px solid #eee; border-radius:8px; padding:9px 11px; margin-bottom:8px; font-size:.82rem; }
    #tab-broadcast .hb-item .hb-head { display:flex; justify-content:space-between; color:#666; margin-bottom:4px; }
    #tab-broadcast .hb-fbar { display:flex; gap:8px; margin-bottom:12px; flex-wrap:wrap; }
    #tab-broadcast .hb-fbtn { padding:4px 12px; border:1px solid #ddd; background:#fff; border-radius:999px; font-size:.78rem; cursor:pointer; }
    #tab-broadcast .hb-fbtn.on { background:#db2777; color:#fff; border-color:#db2777; }
    #tab-broadcast .hb-pager { display:flex; align-items:center; justify-content:center; gap:14px; margin-top:14px; font-size:.82rem; color:#555; }
    #tab-broadcast .hb-pager button { padding:5px 14px; border:1px solid #ddd; background:#fff; border-radius:8px; cursor:pointer; }
    #tab-broadcast .hb-pager button:disabled { opacity:.4; cursor:default; }
  </style>

  <div class="hb-wrap">
    <div class="tab-header" style="display:flex; justify-content:space-between; align-items:center;">
      <div>
        <h2><span class="material-symbols-rounded" style="vertical-align:middle; color:#db2777;">campaign</span> 节日推送</h2>
        <div class="hb-sub">下发一条指令 → main 给所有(或选定)实例按人设生成问候并主动发送。下发后不可撤回。</div>
      </div>
      <button class="hb-send" style="background:#fff;color:#111;border:1px solid #ddd;padding:7px 14px;" onclick="hbRefresh()">刷新</button>
    </div>

    <!-- 下发表单 -->
    <div class="hb-form">
      <label>节日提示词(给 AI) <span style="color:#db2777;">*</span></label>
      <textarea id="hbPrompt" placeholder="今天是中秋节,像平时那样温柔地给 TA 发条节日问候,别太长,体现节日氛围…"></textarea>
      <div class="hb-row">
        <div>
          <label>统一模型(留空=各实例自己的)</label>
          <input id="hbModel" placeholder="如 gemini-3.1-flash-lite-preview">
        </div>
        <div>
          <label>实例范围</label>
          <select id="hbScope">
            <option value="active" selected>仅启动中</option>
            <option value="all">所有实例</option>
          </select>
        </div>
        <div>
          <label>好友筛选</label>
          <select id="hbContactFilter">
            <option value="all_contacts" selected>所有历史好友</option>
            <option value="top_contact">每实例最常聊 1 个</option>
          </select>
        </div>
      </div>
      <div class="hb-row">
        <div>
          <label>限量(只取前 N 个实例,0=不限)</label>
          <input id="hbMax" type="number" min="0" value="0">
        </div>
        <div style="grid-column: span 2;">
          <label>定向实例 ID(逗号分隔,可空。填了就只发这些实例)</label>
          <input id="hbTargets" placeholder="如 12,34,56">
        </div>
      </div>
      <!-- 地区筛选(v13.16 2026-07):按实例所属用户的地区精准投递 -->
      <style>
        .hb-region{margin:14px 0 4px;}
        .hb-region>label{display:block;margin-bottom:6px;}
        .hbr-all{display:inline-flex;align-items:center;gap:6px;font-weight:500;cursor:pointer;user-select:none;color:#334155;}
        .hbr-all input{width:15px;height:15px;accent-color:#db2777;cursor:pointer;}
        .hbr-chips{display:flex;flex-wrap:wrap;gap:7px;margin-top:10px;}
        .hbr-chips.dim{opacity:.4;pointer-events:none;}
        .hbr-chip{padding:5px 12px;border:1px solid #e2e8f0;border-radius:999px;font-size:13px;cursor:pointer;
                  background:#fff;color:#475569;transition:all .12s;user-select:none;white-space:nowrap;}
        .hbr-chip:hover{border-color:#f9a8d4;}
        .hbr-chip.on{background:#db2777;border-color:#db2777;color:#fff;}
        .hbr-chip.none{font-style:normal;color:#94a3b8;}
        .hbr-chip.none.on{background:#64748b;border-color:#64748b;color:#fff;}
        .hbr-sum{margin-top:10px;font-size:12.5px;color:#64748b;}
      </style>
      <div class="hb-region">
        <label>地区筛选(按实例所属用户的地区)</label>
        <label class="hbr-all"><input type="checkbox" id="hbRegionAll" checked onchange="hbRegionAllToggle()"> 全部地区(不筛选,含未填写)</label>
        <div id="hbRegionChips" class="hbr-chips dim"></div>
        <div id="hbRegionSummary" class="hbr-sum">当前:全部地区</div>
      </div>
      <button class="hb-send" onclick="hbCreate()">下发指令(不可撤回)</button>
    </div>

    <!-- 状态列表(第一屏看进度) -->
    <table>
      <thead>
        <tr><th>ID</th><th>状态</th><th>进度(已发/总/失败)</th><th>提示词</th><th>下发人</th><th>时间</th></tr>
      </thead>
      <tbody id="hbBody"><tr><td colspan="6" style="color:#999;padding:18px;">加载中…</td></tr></tbody>
    </table>
  </div>

  <!-- 样例 modal -->
  <div class="hb-overlay" id="hbOverlay">
    <div class="hb-modal">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <h3 style="margin:0;">收件人与发送结果(全部)</h3>
        <button class="hb-send" style="background:#fff;color:#111;border:1px solid #ddd;padding:6px 12px;" onclick="hbCloseModal()">关闭</button>
      </div>
      <div id="hbModalBody"></div>
    </div>
  </div>
</section>

<script>
(function () {
  const API = 'api/api_holiday_broadcast.php?action=';
  async function hbApi(action, body) {
    const r = await fetch(API + encodeURIComponent(action), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || '接口异常');
    return j.data;
  }
  const esc = s => (s == null ? '' : String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'));
  const fmt = ts => ts ? new Date(ts * 1000).toLocaleString('zh-CN', { hour12:false }) : '-';
  const qStatus = s => ({0:'待发',2:'处理中',1:'已发',9:'失败'})[s] || s;

  window.hbRefresh = async function () {
    const body = document.getElementById('hbBody');
    try {
      const data = await hbApi('list');
      const cmds = data.commands || [];
      if (!cmds.length) { body.innerHTML = '<tr><td colspan="6" style="color:#999;padding:18px;">还没有下发过指令</td></tr>'; return; }
      body.innerHTML = cmds.map(c =>
        '<tr class="hb-clickable" onclick="hbDetail(' + c.id + ')">' +
          '<td>' + c.id + '</td>' +
          '<td><span class="hb-badge hb-s' + c.status + '">' + esc(c.status_text) + '</span></td>' +
          '<td>' + (c.sent||0) + ' / ' + (c.total||0) + ' (失败 ' + (c.failed||0) + ')</td>' +
          '<td style="max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="' + esc(c.prompt) + '">' + esc(c.prompt_preview || c.prompt) + '</td>' +
          '<td>' + esc(c.created_by) + '</td>' +
          '<td>' + fmt(c.created_at) + '</td>' +
        '</tr>'
      ).join('');
    } catch (e) {
      body.innerHTML = '<tr><td colspan="6" style="color:#dc2626;padding:18px;">加载失败:' + esc(e.message) + '</td></tr>';
    }
  };

  window.hbCreate = async function () {
    const prompt = document.getElementById('hbPrompt').value.trim();
    if (!prompt) return alert('提示词不能为空');
    if (!confirm('确认下发?\n范围:' + (document.getElementById('hbScope').value === 'all' ? '所有' : '所有启动中') +
                 '实例(或你填的定向实例)\n地区:' + hbRegionSummaryText() +
                 '\n将按你填的提示词主动发送消息。下发后不可撤回。')) return;
    const payload = {
      prompt,
      model_override: document.getElementById('hbModel').value.trim(),
      scope: document.getElementById('hbScope').value,
      contact_filter: document.getElementById('hbContactFilter').value,
      target_db_ids: document.getElementById('hbTargets').value.trim(),
      max_instances: parseInt(document.getElementById('hbMax').value, 10) || 0,
      region_filter: hbRegionValue(),
    };
    try {
      const data = await hbApi('create', payload);
      alert('已下发:指令 #' + data.id + '\n' + (data.message || ''));
      document.getElementById('hbPrompt').value = '';
      hbRefresh();
    } catch (e) { alert('下发失败:' + e.message); }
  };

  let hbState = { id: 0, filter: 'all', offset: 0, limit: 100 };

  window.hbDetail = function (id) {
    hbState = { id, filter: 'all', offset: 0, limit: 100 };
    document.getElementById('hbOverlay').classList.add('show');
    hbLoadDetail();
  };

  async function hbLoadDetail() {
    const box = document.getElementById('hbModalBody');
    box.innerHTML = '<div style="color:#999;padding:16px;">加载中…</div>';
    try {
      const d = await hbApi('detail', { id: hbState.id, filter: hbState.filter, offset: hbState.offset, limit: hbState.limit });
      const c = d.counts || {}; const items = d.items || []; const ft = d.filtered_total || 0;
      const from = ft ? hbState.offset + 1 : 0;
      const to = Math.min(hbState.offset + hbState.limit, ft);
      const fbtn = (k, label, n) =>
        '<button class="hb-fbtn' + (hbState.filter === k ? ' on' : '') + '" onclick="hbSetFilter(\'' + k + '\')">' + label + ' ' + n + '</button>';
      let html =
        '<div style="color:#444;font-size:.84rem;margin-bottom:8px;">指令 #' + hbState.id +
          ' · <b>' + esc(d.command.status_text) + '</b> · 总 ' + (c.total||0) +
          ' · 已发 ' + (c.sent||0) + ' · 失败 ' + (c.failed||0) + ' · 待发 ' + (c.pending||0) + '</div>' +
        '<div class="hb-fbar">' + fbtn('all','全部',c.total||0) + fbtn('sent','已发',c.sent||0) +
          fbtn('failed','失败',c.failed||0) + fbtn('pending','待发',c.pending||0) + '</div>';
      html += items.length ? items.map(t => {
        const body = t.status === 9
          ? '<span style="color:#dc2626;">' + esc(t.error_msg || 'failed') + '</span>'
          : (t.content ? esc(t.content) : '<i style="color:#999;">(无内容)</i>');
        return '<div class="hb-item"><div class="hb-head">' +
          '<span>db_id=' + t.db_id + ' → uid <code>' + esc((t.uid||'').slice(0,28)) + '</code></span>' +
          '<span>' + qStatus(t.status) + '</span></div><div>' + body + '</div></div>';
      }).join('') : '<div style="color:#999;padding:14px;">这一组没有记录</div>';
      const prevDis = hbState.offset <= 0 ? 'disabled' : '';
      const nextDis = (hbState.offset + hbState.limit) >= ft ? 'disabled' : '';
      html += '<div class="hb-pager"><button ' + prevDis + ' onclick="hbPage(-1)">上一页</button>' +
        '<span>' + from + '–' + to + ' / 共 ' + ft + ' 条</span>' +
        '<button ' + nextDis + ' onclick="hbPage(1)">下一页</button></div>';
      box.innerHTML = html;
    } catch (e) { box.innerHTML = '<div style="color:#dc2626;padding:16px;">加载失败:' + esc(e.message) + '</div>'; }
  }
  window.hbSetFilter = function (f) { hbState.filter = f; hbState.offset = 0; hbLoadDetail(); };
  window.hbPage = function (dir) { hbState.offset = Math.max(0, hbState.offset + dir * hbState.limit); hbLoadDetail(); };

  window.hbCloseModal = function () { document.getElementById('hbOverlay').classList.remove('show'); };

  // ── 地区筛选 ────────────────────────────────────────────────────────────
  // 大陆省级用本名(河南、河北…);港澳台按规范写「中国香港/中国澳门/中国台湾」。
  // 存储值即中文标签本身,与 console.php / api 白名单完全一致。'__none__' = 未知(未填写)。
  const HB_REGIONS = [
    '北京','天津','河北','山西','内蒙古','辽宁','吉林','黑龙江','上海','江苏',
    '浙江','安徽','福建','江西','山东','河南','湖北','湖南','广东','广西',
    '海南','重庆','四川','贵州','云南','西藏','陕西','甘肃','青海','宁夏','新疆',
    '中国香港','中国澳门','中国台湾',
  ];
  const hbRegionSel = new Set();

  function hbRenderRegionChips() {
    const box = document.getElementById('hbRegionChips');
    if (!box) return;
    let html = HB_REGIONS.map(function (r) {
      const on = hbRegionSel.has(r) ? ' on' : '';
      return '<span class="hbr-chip' + on + '" onclick="hbRegionToggle(\'' + r + '\')">' + r + '</span>';
    }).join('');
    // 未知(未填写/不愿透露)单独一档
    const noneOn = hbRegionSel.has('__none__') ? ' on' : '';
    html += '<span class="hbr-chip none' + noneOn + '" onclick="hbRegionToggle(\'__none__\')">未知(未填写)</span>';
    box.innerHTML = html;
    const sum = document.getElementById('hbRegionSummary');
    if (sum) sum.textContent = '当前:' + hbRegionSummaryText();
  }

  window.hbRegionToggle = function (val) {
    if (document.getElementById('hbRegionAll').checked) return; // 全部地区时不可选
    if (hbRegionSel.has(val)) hbRegionSel.delete(val); else hbRegionSel.add(val);
    hbRenderRegionChips();
  };

  window.hbRegionAllToggle = function () {
    const all = document.getElementById('hbRegionAll').checked;
    const box = document.getElementById('hbRegionChips');
    if (all) { hbRegionSel.clear(); box.classList.add('dim'); }
    else { box.classList.remove('dim'); }
    hbRenderRegionChips();
  };

  // 返回给后端:'all' 或逗号分隔的地区 token
  window.hbRegionValue = function () {
    if (document.getElementById('hbRegionAll').checked || hbRegionSel.size === 0) return 'all';
    return Array.from(hbRegionSel).join(',');
  };

  window.hbRegionSummaryText = function () {
    if (document.getElementById('hbRegionAll').checked || hbRegionSel.size === 0) return '全部地区';
    const arr = Array.from(hbRegionSel).map(function (r) { return r === '__none__' ? '未知' : r; });
    return arr.join('、') + '(共 ' + arr.length + ' 个)';
  };

  // 自动轮询:tab 可见时每 5s 刷新一次(第一屏实时看进度)
  setInterval(function () {
    const sec = document.getElementById('tab-broadcast');
    if (sec && sec.offsetParent !== null) hbRefresh();
  }, 5000);
  // 首次进入也刷一次
  document.addEventListener('DOMContentLoaded', function () {
    hbRenderRegionChips();
    const sec = document.getElementById('tab-broadcast');
    if (sec && sec.offsetParent !== null) hbRefresh();
  });
})();
</script>

        <!-- ════════════════════════════════════════════════════════════════
             v14.0 (2026-05-19) 520 抽奖管理
             ════════════════════════════════════════════════════════════════ -->
        <section class="admin-tab" id="tab-lottery_520">
            <div class="tab-header">
                <h2><span class="material-symbols-rounded" style="vertical-align:middle; color:#b04e5c;">redeem</span> 520 抽奖管理</h2>
                <div class="tab-actions">
                    <button class="bc-modal-close" onclick="loadLottery520()">
                        <span class="material-symbols-rounded" style="font-size:14px;">refresh</span> 刷新
                    </button>
                </div>
            </div>

            <!-- 统计卡 -->
            <div id="l520Stats" style="display:flex; gap:14px; margin-bottom:20px; flex-wrap:wrap;">
                <div style="flex:1; min-width:160px; background:#fff; border-radius:10px; padding:14px 18px; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
                    <div style="font-size:11px; color:#888; letter-spacing:2px;">余额奖</div>
                    <div style="font-size:22px; color:#b04e5c; font-weight:700; margin-top:6px;">
                        <span id="l520StatBalPending">0</span>
                        <span style="font-size:13px; color:#999; font-weight:400;">/ 待发 · 已发 <span id="l520StatBalPaid">0</span></span>
                    </div>
                </div>
                <div style="flex:1; min-width:160px; background:#fff; border-radius:10px; padding:14px 18px; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
                    <div style="font-size:11px; color:#888; letter-spacing:2px;">现金奖</div>
                    <div style="font-size:22px; color:#b04e5c; font-weight:700; margin-top:6px;">
                        <span id="l520StatCashPending">0</span>
                        <span style="font-size:13px; color:#999; font-weight:400;">/ 待转 · 已转 <span id="l520StatCashPaid">0</span></span>
                    </div>
                </div>
                <div style="flex:1; min-width:160px; background:#fff; border-radius:10px; padding:14px 18px; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
                    <div style="font-size:11px; color:#888; letter-spacing:2px;">奶茶奖</div>
                    <div style="font-size:22px; color:#b04e5c; font-weight:700; margin-top:6px;">
                        <span id="l520StatMilkteaPending">0</span>
                        <span style="font-size:13px; color:#999; font-weight:400;">/ 待发 · 已发 <span id="l520StatMilkteaPaid">0</span></span>
                    </div>
                </div>
                <div style="flex:1; min-width:160px; background:#fafafa; border-radius:10px; padding:14px 18px;">
                    <div style="font-size:11px; color:#aaa; letter-spacing:2px;">谢谢惠顾</div>
                    <div style="font-size:22px; color:#aaa; font-weight:600; margin-top:6px;">
                        <span id="l520StatThanksTotal">0</span>
                        <span style="font-size:13px; font-weight:400;">人次</span>
                    </div>
                </div>
            </div>

            <!-- sub-tab -->
            <div style="display:flex; gap:6px; margin-bottom:16px; border-bottom:1px solid #eee;">
                <div class="l520-subtab active" data-sub="balance"
                     onclick="switchLottery520Sub('balance')"
                     style="padding:10px 22px; cursor:pointer; font-size:13px; letter-spacing:2px;">
                    中余额
                </div>
                <div class="l520-subtab" data-sub="cash"
                     onclick="switchLottery520Sub('cash')"
                     style="padding:10px 22px; cursor:pointer; font-size:13px; letter-spacing:2px; color:#888;">
                    中现金
                </div>
                <div class="l520-subtab" data-sub="milktea"
                     onclick="switchLottery520Sub('milktea')"
                     style="padding:10px 22px; cursor:pointer; font-size:13px; letter-spacing:2px; color:#888;">
                    中奶茶
                </div>
            </div>

            <style>
                .l520-subtab.active { background:#fff; color:#b04e5c; font-weight:600; border-radius:8px 8px 0 0; box-shadow: 0 -2px 8px rgba(0,0,0,0.03); }
                #tab-lottery_520 table { width:100%; border-collapse:collapse; background:#fff; border-radius:10px; overflow:hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.04); }
                #tab-lottery_520 th, #tab-lottery_520 td { padding:12px 14px; text-align:left; font-size:13px; }
                #tab-lottery_520 th { background:#f6e5e8; color:#6b2935; letter-spacing:1px; font-weight:600; font-size:12px; }
                #tab-lottery_520 tr:not(:last-child) td { border-bottom:1px solid #f0e8eb; }
                #tab-lottery_520 tr.l520-paid td { background:rgba(107,163,104,0.05); color:#999; }
                .l520-badge { display:inline-block; padding:2px 10px; border-radius:999px; font-size:11px; letter-spacing:1px; }
                .l520-badge-pending { background:rgba(232,160,64,0.18); color:#8a5500; }
                .l520-badge-paid    { background:rgba(107,163,104,0.18); color:#5a8c58; }
                .l520-badge-type    { background:rgba(176,78,92,0.15); color:#b04e5c; font-weight:600; }
                .l520-copy-btn { background:none; border:1px dashed #ccc; padding:2px 8px; font-size:10px; color:#888; margin-left:6px; cursor:pointer; border-radius:4px; }
                .l520-copy-btn:hover { color:#b04e5c; border-color:#b04e5c; }
                .l520-phone { font-family:monospace; color:#b04e5c; font-weight:600; }
            </style>

            <div id="l520TableWrap">
                <div style="text-align:center; padding:40px; color:#999;">加载中…</div>
            </div>
        </section>

        </main>
</div>


<!-- 版本日志:新增/编辑弹窗 -->
<div class="admin-modal-overlay" id="versionModal">
    <div class="admin-modal">
        <div class="admin-modal-header">
            <div class="admin-modal-title" id="versionModalTitle">新增版本</div>
            <span class="admin-modal-close material-symbols-rounded" onclick="closeModal('versionModal')">close</span>
        </div>
        <input type="hidden" id="verEditId">
        <div class="form-row">
            <div class="form-group">
                <label>版本号 <span style="color:#dc2626;">*</span></label>
                <input type="text" id="verVersion" placeholder="v13.11.2" maxlength="30">
            </div>
            <div class="form-group">
                <label>发布日期 <span style="color:#dc2626;">*</span></label>
                <input type="date" id="verReleased">
            </div>
        </div>
        <div class="form-group">
            <label>一句标题 <span style="color:#dc2626;">*</span></label>
            <input type="text" id="verTitle" placeholder="主动消息修复 & 钱包页 UI 简化" maxlength="120">
        </div>
        <div class="form-group">
            <label>详细更新内容</label>
            <textarea id="verContent" rows="8" placeholder="支持换行;前端按原始换行展示" style="width:100%; font-family: ui-monospace, monospace; font-size: 0.86rem; line-height: 1.65;"></textarea>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>排序权重</label>
                <input type="number" id="verSortOrder" value="0">
                <span class="hint">同日多条:大的先,默认 0</span>
            </div>
            <div class="form-group">
                <label>已发布?</label>
                <select id="verPublished">
                    <option value="1">是 (上首页)</option>
                    <option value="0">否 (草稿)</option>
                </select>
            </div>
        </div>
        <div class="admin-modal-footer">
            <button class="btn-cancel" onclick="closeModal('versionModal')">取消</button>
            <button class="btn-save" onclick="saveVersion()">保存</button>
        </div>
    </div>
</div>

<!-- ============ 通用弹窗 ============ -->
<!-- 新增用户弹窗（2026-06-27）：用户名 + 手机号 + 密码 -->
<div class="admin-modal-overlay" id="createUserModal">
    <div class="admin-modal">
        <div class="admin-modal-header">
            <div class="admin-modal-title">新增用户</div>
            <span class="admin-modal-close" onclick="closeModal('createUserModal')">close</span>
        </div>
        <div style="background:#f5f5f5;padding:10px 14px;border-radius:8px;font-size:0.82rem;color:#666;margin-bottom:14px;">
            创建后用户即可用「用户名 + 密码」登录；其余额度/套餐按注册默认值发放，可在用户列表里再编辑。
        </div>
        <div class="form-group">
            <label>用户名</label>
            <input type="text" id="cuUsername" maxlength="32" autocomplete="off" placeholder="2-32 个字符，登录用">
        </div>
        <div class="form-group">
            <label>手机号</label>
            <input type="text" id="cuPhone" maxlength="20" autocomplete="off" inputmode="numeric" placeholder="6-20 位数字">
        </div>
        <div class="form-group">
            <label>初始密码</label>
            <input type="text" id="cuPassword" maxlength="64" autocomplete="off" placeholder="至少 6 位">
            <div class="hint">明文展示便于告知用户；后端按 password_hash 加密存储。</div>
        </div>
        <div class="modal-footer">
            <button class="btn-mini" onclick="closeModal('createUserModal')">取消</button>
            <button class="btn-mini primary" id="cuSubmitBtn" onclick="submitCreateUser()">创建用户</button>
        </div>
    </div>
</div>

<div class="admin-modal-overlay" id="userModal">
    <div class="admin-modal">
        <div class="admin-modal-header">
            <div class="admin-modal-title">编辑用户</div>
            <span class="admin-modal-close" onclick="closeModal('userModal')">close</span>
        </div>
        <input type="hidden" id="userEditId">
        <div style="background:#f5f5f5;padding:10px 14px;border-radius:8px;font-size:0.85rem;color:#555;margin-bottom:14px;" id="userEditMeta">--</div>
        <div class="form-row">
            <div class="form-group">
                <label>套餐</label>
                <select id="userEditPlan">
                    <option value="free">Free（无订阅包）</option>
                    <option value="pro">Pro（持有订阅包）</option>
                </select>
            </div>
            <div class="form-group">
                <label>计费策略</label>
                <select id="userEditBilling">
                    <option value="quota_first">订阅包优先</option>
                    <option value="balance_first">余额优先</option>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>余额（元）</label>
                <input type="number" id="userEditBalance" step="0.0001" min="0">
            </div>
            <div class="form-group">
                <label>订阅包到期</label>
                <input type="datetime-local" id="userEditExpired">
                <div class="hint">清空 = 永久(不会过期)；填日期 = 到期后自动降级 free</div>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>每周基础 Token</label>
                <input type="number" id="userEditBaseWeekly" min="0" step="10000">
                <div class="hint">默认 500000（注册赠送）</div>
            </div>
            <div class="form-group">
                <label>邀请永久叠加 Token / 周</label>
                <input type="number" id="userEditBonusWeekly" min="0" step="10000">
                <div class="hint">每邀请 1 人 +200000，admin 可手动调整</div>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>本周已用 Token</label>
                <input type="number" id="userEditWeeklyUsed" min="0">
                <div class="hint">跨周自动归零，admin 可手动重置</div>
            </div>
            <div class="form-group">
                <label>邀请人数</label>
                <input type="number" id="userEditInviteCount" min="0">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>订阅包总额</label>
                <input type="number" id="userEditPackTotal" min="0" step="100000">
                <div class="hint">购买叠加，过期清零</div>
            </div>
            <div class="form-group">
                <label>订阅包已用</label>
                <input type="number" id="userEditPackUsed" min="0" step="1000">
                <div class="hint">过期清零，重购不重置</div>
            </div>
        </div>

        <!-- v12.10 (2026-05-12) 次数包(独立于按 token 计费的订阅包) -->
        <div style="margin-top:16px;padding-top:14px;border-top:1px dashed #ddd;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
                <strong style="font-size:0.92rem;color:#111;">次数包</strong>
                <button type="button" class="btn-mini danger" onclick="clearUserCountPack()"
                        style="font-size:0.74rem;padding:3px 10px;">清空次数包</button>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>次数包总额(次)</label>
                    <input type="number" id="userEditCountTotal" min="0" step="100">
                    <div class="hint">购买叠加,过期清零</div>
                </div>
                <div class="form-group">
                    <label>次数包已用(次)</label>
                    <input type="number" id="userEditCountUsed" min="0" step="1">
                    <div class="hint">过期清零,重购不重置</div>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>次数包到期</label>
                    <input type="datetime-local" id="userEditCountExpired">
                    <div class="hint">清空 = 无次数包 / 已过期;填日期 = 到期后失效</div>
                </div>
                <div class="form-group">
                    <label>允许的模型 (JSON 数组)</label>
                    <input type="text" id="userEditCountModels" placeholder='["gemini-3.1-pro-preview", "claude-opus-4-7"]'>
                    <div class="hint">必须是合法 JSON;留空 = 所有模型</div>
                </div>
            </div>
        </div>

        <!-- v19 (2026-05-26) 次数包·多桶（user_count_packs，独立包，可任意增删） -->
        <div style="margin-top:16px;padding-top:14px;border-top:1px dashed #ddd;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
                <strong style="font-size:0.92rem;color:#111;">独立次数包（多桶）</strong>
                <button type="button" class="btn-mini primary" onclick="openCountPackEditor(0)"
                        style="font-size:0.74rem;padding:3px 10px;">+ 新增独立包</button>
            </div>
            <div class="hint" style="margin-bottom:8px;">
                用户每购买一个次数包 = 一行独立包，次数 / 模型 / 有效期物理隔离、永不互串。
                这里管理的是 user_count_packs 表，与上方「次数包」单桶字段相互独立。
            </div>
            <div id="userCountPacksList"
                 style="display:flex;flex-direction:column;gap:8px;">
                <div style="color:#999;font-size:0.82rem;padding:8px 0;">加载中…</div>
            </div>
        </div>

        <div class="form-group" style="margin-top:14px;padding-top:14px;border-top:1px dashed #ddd;">
            <label>邮箱</label>
            <input type="email" id="userEditEmail">
        </div>
        <!-- 人工客服身份（2026-07 新增）：勾选后需填客服邮箱，保存走独立按钮 -->
        <div class="form-group" style="margin-top:14px;padding-top:14px;border-top:1px dashed #ddd;">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                <input type="checkbox" id="userEditIsSupport" onchange="_syncSupportRow()"
                       style="width:16px;height:16px;">
                设为人工客服
            </label>
            <div class="hint">勾选后，该用户控制台会出现「客服工单」列表，可查看并回复所有工单。</div>
            <div id="userEditSupportRow" style="display:none;margin-top:8px;">
                <label>客服邮箱 <span style="color:#d32f2f;">*</span></label>
                <input type="email" id="userEditSupportEmail" maxlength="200"
                       placeholder="接收新工单通知的邮箱，如 kefu@qq.com">
                <div class="hint">有新工单时，系统会把用户的问题发送到这个邮箱。</div>
            </div>
            <div style="margin-top:8px;">
                <button class="btn-mini primary" onclick="saveUserSupport()">保存客服设置</button>
            </div>
        </div>
        <!-- 论坛头衔 -->
        <div class="form-row" style="margin-top:14px;padding-top:14px;border-top:1px dashed #ddd;">
            <div class="form-group">
                <label>论坛头衔</label>
                <input type="text" id="userEditTitle" maxlength="32" placeholder="如：资深玩家 / 官方认证">
                <div class="hint">展示在论坛帖子/评论作者名旁；留空则不显示</div>
            </div>
            <div class="form-group">
                <label>头衔背景色</label>
                <div style="display:flex;align-items:center;gap:8px;">
                    <input type="color" id="userEditTitleColor" value="#b04e5c"
                           style="width:48px;height:38px;padding:2px;border:1px solid #ddd;border-radius:8px;cursor:pointer;"
                           oninput="document.getElementById('userEditTitleColorText').value=this.value;_syncTitlePreview();">
                    <input type="text" id="userEditTitleColorText" value="#b04e5c" maxlength="9"
                           style="flex:1;" placeholder="#b04e5c"
                           oninput="document.getElementById('userEditTitleColor').value=this.value;_syncTitlePreview();">
                </div>
                <div class="hint">预览：<span id="userEditTitlePreview" style="display:inline-block;font-size:0.72rem;font-weight:700;color:#fff;padding:2px 9px;border-radius:999px;background:#b04e5c;">头衔</span></div>
            </div>
        </div>
        <div class="form-group">
            <label>手机号 <span style="font-size:0.74rem;color:#888;font-weight:400;">(只读 · 由用户自行绑定)</span></label>
            <input type="text" id="userEditPhone" readonly style="background:#f9fafb;color:#666;">
        </div>
        <div class="form-group" style="margin-top:14px;padding-top:14px;border-top:1px dashed #ddd;">
            <label>重置密码（留空表示不重置）</label>
            <input type="text" id="userEditNewPwd" placeholder="至少 6 位">
        </div>
        <div class="modal-footer">
            <button class="btn-mini danger" onclick="deleteUser()">删除用户</button>
            <button class="btn-mini" onclick="closeModal('userModal')">取消</button>
            <button class="btn-mini primary" onclick="saveUser()">保存</button>
        </div>
    </div>
</div>

<!-- ============ 用户封禁 / 解封弹窗（2026 新增） ============ -->
<!--
    管理员选择用户 → 设置封禁原因 + 封禁时长 → 封禁。
    封禁后:该用户的微信实例收消息时不再调大模型,直接用「封禁原因」回复;
            该用户登录控制台只能看到红色封禁提示页。
    时长支持预设(小时/天)或自定义到期时间;「永久」对应 banned_until=0。
    支持随时手动解封。
-->
<div class="admin-modal-overlay" id="banModal">
    <div class="admin-modal" style="width:min(520px, 92vw);">
        <div class="admin-modal-header">
            <div class="admin-modal-title">用户封禁管理</div>
            <span class="admin-modal-close" onclick="closeModal('banModal')">close</span>
        </div>
        <input type="hidden" id="banUserId">
        <div style="background:#f5f5f5;padding:10px 14px;border-radius:8px;font-size:0.85rem;color:#555;margin-bottom:14px;" id="banUserMeta">--</div>

        <!-- 当前封禁状态 -->
        <div id="banCurrentStatus" style="margin-bottom:16px;"></div>

        <div class="form-group">
            <label>封禁原因 <span style="color:#d32f2f;">*</span></label>
            <textarea id="banReason" rows="3" maxlength="500"
                      placeholder="例如：检测到恶意刷量行为，账号暂时封禁。此原因会展示给被封禁用户与其微信好友。"
                      style="width:100%;resize:vertical;padding:10px 12px;border:1px solid #ddd;border-radius:8px;font-size:0.9rem;font-family:inherit;line-height:1.5;"></textarea>
            <div class="hint">封禁后会原样作为该用户微信实例的自动回复内容，并显示在其控制台。最多 500 字。</div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>封禁时长</label>
                <select id="banDuration" onchange="onBanDurationChange()">
                    <option value="1">1 小时</option>
                    <option value="6">6 小时</option>
                    <option value="12">12 小时</option>
                    <option value="24" selected>1 天</option>
                    <option value="72">3 天</option>
                    <option value="168">7 天</option>
                    <option value="720">30 天</option>
                    <option value="permanent">永久封禁</option>
                    <option value="custom">自定义到期时间…</option>
                </select>
                <div class="hint" id="banUntilPreview">将于到期后自动解封</div>
            </div>
            <div class="form-group" id="banCustomWrap" style="display:none;">
                <label>自定义到期时间</label>
                <input type="datetime-local" id="banCustomUntil" onchange="_syncBanUntilPreview()">
                <div class="hint">到此时间后自动解封</div>
            </div>
        </div>

        <div class="modal-footer">
            <button class="btn-mini" onclick="closeModal('banModal')">取消</button>
            <button class="btn-mini" id="banUnbanBtn" onclick="submitUnban()"
                    style="display:none;background:#dcfce7;color:#166534;border:1px solid #4ade80;">解除封禁</button>
            <button class="btn-mini danger" id="banConfirmBtn" onclick="submitBan()">确认封禁</button>
        </div>
    </div>
</div>

<!-- ============ 独立次数包·编辑子弹窗（v19 · 2026-05-26） ============ -->
<!-- 新增 / 编辑 user_count_packs 一行独立包。从用户弹窗的多桶区调起。
     注意:命名一律用 ucp 前缀(user_count_pack),避开既有「次数包档位」
     管理用的 countPackModal / deleteCountPack 等同名标识,防止 id 重复与
     函数覆盖。 -->
<div class="admin-modal-overlay" id="ucpModal">
    <div class="admin-modal" style="width:min(560px, 92vw);">
        <div class="admin-modal-header">
            <div class="admin-modal-title" id="ucpModalTitle">新增独立次数包</div>
            <span class="admin-modal-close" onclick="closeModal('ucpModal')">close</span>
        </div>
        <input type="hidden" id="ucpUserId">
        <input type="hidden" id="ucpPackId">
        <div class="form-group">
            <label>包名称</label>
            <input type="text" id="ucpName" placeholder="留空自动按模型/价格生成">
            <div class="hint">例如「Gemini Pro 次数包」；留空则自动命名</div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>次数总额</label>
                <input type="number" id="ucpTotal" min="0" step="100">
            </div>
            <div class="form-group">
                <label>已用次数</label>
                <input type="number" id="ucpUsed" min="0" step="1">
                <div class="hint">不会超过总额，超出自动截断</div>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>来源价格（元）</label>
                <input type="number" id="ucpPrice" min="0" step="0.01">
                <div class="hint">仅作记录，购买时的档位价</div>
            </div>
            <div class="form-group">
                <label>到期时间</label>
                <input type="datetime-local" id="ucpExpired">
                <div class="hint">清空 = 永久不过期</div>
            </div>
        </div>
        <div class="form-group">
            <label>允许的模型（JSON 数组）</label>
            <input type="text" id="ucpModels" placeholder='["gemini-3.1-pro-preview", "claude-opus-4-7"]'>
            <div class="hint">必须是合法 JSON；留空 = 不限模型</div>
        </div>
        <div class="form-group">
            <label>状态</label>
            <select id="ucpActive">
                <option value="1">启用（参与计费）</option>
                <option value="0">停用（暂不计费）</option>
            </select>
        </div>
        <div class="modal-footer">
            <button class="btn-mini" onclick="closeModal('ucpModal')">取消</button>
            <button class="btn-mini primary" onclick="saveUserCountPack()">保存</button>
        </div>
    </div>
</div>

<!-- ============ 用户临时日志弹窗(2026-05-07 新增) ============ -->
<!--
    显示某个用户名下所有实例的 temp_log。
    每个实例一个 <details>(可折叠),首项默认展开。
    日志使用 monospace 字体 + 滚动区,保留原始换行格式。
-->
<div class="admin-modal-overlay" id="userLogModal">
    <div class="admin-modal" style="width:min(900px, 92vw); max-width:92vw;">
        <div class="admin-modal-header">
            <div class="admin-modal-title" id="userLogModalTitle">用户日志</div>
            <span class="admin-modal-close" onclick="closeModal('userLogModal')">close</span>
        </div>
        <div style="background:#f5f5f5; padding:10px 14px; border-radius:8px; font-size:0.82rem; color:#555; margin-bottom:14px; line-height:1.6;">
            展示该用户名下所有实例的临时运行日志(与用户在自己控制台中的「日志」按钮看到的一致),用于排查问题。日志由 _append_log 滚动保留最近 200 行。
        </div>
        <div id="userLogBody" style="max-height:65vh; overflow-y:auto;">
            <div class="empty-state" style="padding:40px;text-align:center;color:#999;">加载中...</div>
        </div>
        <div class="admin-modal-actions" style="margin-top:14px;">
            <button class="btn-mini" onclick="closeModal('userLogModal')">关闭</button>
        </div>
    </div>
</div>

<!-- ============ 论坛分区编辑弹窗 ============ -->
<div class="admin-modal-overlay" id="forumSectionModal">
    <div class="admin-modal" style="max-width:440px;">
        <div class="admin-modal-header">
            <div class="admin-modal-title" id="forumSectionModalTitle">新增分区</div>
            <span class="admin-modal-close" onclick="closeModal('forumSectionModal')">close</span>
        </div>
        <input type="hidden" id="fsEditId" value="0">
        <div class="form-group">
            <label>分区名称</label>
            <input type="text" id="fsName" maxlength="40" placeholder="如：综合讨论">
        </div>
        <div class="form-group">
            <label>简介（可选）</label>
            <input type="text" id="fsIntro" maxlength="160" placeholder="一句话介绍这个分区">
        </div>
        <div class="form-group">
            <label>排序（数字越小越靠前）</label>
            <input type="number" id="fsSort" value="0" min="0">
        </div>
        <div class="admin-modal-actions" style="margin-top:14px;">
            <button class="btn-mini" onclick="closeModal('forumSectionModal')">取消</button>
            <button class="btn-mini primary" onclick="saveForumSection()">保存</button>
        </div>
    </div>
</div>

<!-- ============ 论坛帖子审核弹窗 ============ -->
<div class="admin-modal-overlay" id="forumPostModal">
    <div class="admin-modal" style="width:min(680px, 92vw); max-width:92vw;">
        <div class="admin-modal-header">
            <div class="admin-modal-title">帖子管理</div>
            <span class="admin-modal-close" onclick="closeModal('forumPostModal')">close</span>
        </div>
        <input type="hidden" id="fpReviewId" value="0">
        <div id="forumPostDetailBody" style="max-height:60vh; overflow-y:auto;">
            <div class="empty-state" style="padding:40px;text-align:center;color:#999;">加载中...</div>
        </div>
        <div class="form-group" style="margin-top:14px;">
            <label>驳回原因（驳回 / 撤下时填写，会展示给作者）</label>
            <input type="text" id="fpRejectReason" maxlength="160" placeholder="如：内容含广告 / 不符合社区规范">
        </div>
        <div class="admin-modal-actions" style="margin-top:14px;display:flex;gap:8px;flex-wrap:wrap;">
            <button class="btn-mini danger" id="fpRejectBtn" onclick="reviewForumPost('reject')">驳回</button>
            <button class="btn-mini" style="background:#fdecec;color:#d32f2f;border:1px solid #f5b5b5;" onclick="adminDeleteForumPost()">删除</button>
            <span style="flex:1;"></span>
            <button class="btn-mini" onclick="closeModal('forumPostModal')">关闭</button>
            <button class="btn-mini primary" id="fpApproveBtn" onclick="reviewForumPost('approve')">通过</button>
        </div>
    </div>
</div>

<div class="admin-modal-overlay" id="modelModal">
    <div class="admin-modal">
        <div class="admin-modal-header">
            <div class="admin-modal-title" id="modelModalTitle">新增模型</div>
            <span class="admin-modal-close" onclick="closeModal('modelModal')">close</span>
        </div>
        <input type="hidden" id="modelEditId" value="0">
        <div class="form-group">
            <label>模型名（与 API 接口一致）</label>
            <input type="text" id="modelName" placeholder="例如：gpt-4o-mini">
        </div>
        <div class="form-group">
            <label>显示名称（前端下拉里显示给用户看的友好名）</label>
            <input type="text" id="modelDisplayName" placeholder="例如：GPT-4o mini · 高性价比版（留空则与模型名一致）">
        </div>

        <!-- v12.11 (2026-05-12) 模型图标 + 分组 -->
        <div class="form-row">
            <div class="form-group">
                <label>分组(前端切换用)</label>
                <input type="text" id="modelCategory" placeholder="例如:官方/三方/国产/实验" maxlength="40">
                <div class="hint">空 = 未分组;前端按这个名字分类筛选</div>
            </div>
            <div class="form-group">
                <label>图标</label>
                <div style="display:flex;gap:8px;align-items:center;">
                    <div id="modelIconPreview" style="width:42px;height:42px;border-radius:10px;border:1px solid #e5e7eb;background:#f9fafb;display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0;color:#888;font-size:0.7rem;">无</div>
                    <input type="file" id="modelIconFile" accept="image/png,image/jpeg,image/webp,image/svg+xml" onchange="onModelIconPick(event)" style="font-size:0.78rem;flex:1;min-width:0;">
                    <button type="button" class="btn-mini danger" onclick="clearModelIcon()" style="font-size:0.72rem;padding:4px 8px;">清空</button>
                </div>
                <input type="hidden" id="modelIconData">
                <div class="hint">建议 64×64 PNG/SVG,≤ 30KB。会转 base64 存库</div>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>输入价（元/百万 Token）</label>
                <input type="number" id="modelInPrice" step="0.0001" min="0" value="0">
            </div>
            <div class="form-group">
                <label>输出价（元/百万 Token）</label>
                <input type="number" id="modelOutPrice" step="0.0001" min="0" value="0">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>订阅包(pack)桶</label>
                <select id="modelPackAllowed">
                    <option value="0">不在白名单</option>
                    <option value="1">允许订阅包用户使用</option>
                </select>
                <div class="hint">订阅包用户切到 pack 模式时,只能选到这里勾选过的模型</div>
            </div>
            <div class="form-group">
                <label>状态</label>
                <select id="modelActive">
                    <option value="1">在线可用</option>
                    <option value="0">下架</option>
                </select>
            </div>
        </div>

        <!-- ===== v7 新增:模型自有端点 / API Key / 协议 / 思维链(2026-05-08)===== -->
        <div class="form-group">
            <label>模型端点(Endpoint)</label>
            <input type="text" id="modelEndpoint" placeholder="例如：https://yunwu.ai/v1   留空 → 用系统配置 platform_endpoint">
            <div class="hint">
                只填到 <code>/v1</code> 即可,系统会自动补 <code>/chat/completions</code>;<br>
                若填了 <code>/v1/xxx</code> 完整路径(特殊端点),系统不再自动补全,原样请求；<br>
                <strong>Gemini 原生协议忽略此项</strong>，固定使用协议文件顶部的
                <code>https://api.openlux.ai/v1beta/models/{model}:generateContent</code>。
            </div>
        </div>
        <div class="form-group">
            <label>模型 API Key</label>
            <input type="text" id="modelApiKey" placeholder="例如：sk-xxxxx   留空 → 用系统配置 platform_api_key">
            <div class="hint">每个模型可用独立 Key,留空则共享系统全局 Key</div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>请求协议</label>
                <select id="modelProtocol" onchange="onModelProtocolChange()">
                    <option value="openai">OpenAI 通用 (/v1/chat/completions)</option>
                    <option value="anthropic">Anthropic Messages (/v1/messages)</option>
                    <option value="gemini">Gemini 原生 (/v1beta/models/{model}:generateContent)</option>
                </select>
                <div class="hint">gemini 使用原生 contents、inlineData、functionCall/functionResponse、thinkingConfig 和 usageMetadata，不经过 OpenAI 格式转换</div>
            </div>
            <div class="form-group">
                <label>思维链支持</label>
                <select id="modelSupportsThinking">
                    <option value="0">不支持(普通模型)</option>
                    <option value="1">支持(下发 enable_thinking 等字段)</option>
                </select>
                <div class="hint">原 chat.py 硬编码白名单的 6 个前缀已迁到此字段</div>
            </div>
        </div>

        <!-- ===== v8 新增:能力标签 (2026-05-09) =====
             仅展示用,前端控制台下拉里给用户看;不参与计费/权限判断 -->
        <div class="form-group">
            <label>能力标签 <span class="hint" style="font-weight:normal;color:#888;">(展示用,会显示在控制台模型下拉中,可全不勾)</span></label>
            <div class="model-tag-checkbox-row" style="display:flex;flex-wrap:wrap;gap:14px;padding:8px 2px 4px;">
                <label class="model-tag-checkbox" style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-size:0.88rem;font-weight:500;">
                    <input type="checkbox" id="modelTagChat" value="chat" style="width:14px;height:14px;cursor:pointer;">
                    <span>对话</span>
                </label>
                <label class="model-tag-checkbox" style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-size:0.88rem;font-weight:500;">
                    <input type="checkbox" id="modelTagVision" value="vision" style="width:14px;height:14px;cursor:pointer;">
                    <span>识图</span>
                </label>
                <label class="model-tag-checkbox" style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-size:0.88rem;font-weight:500;">
                    <input type="checkbox" id="modelTagThinking" value="thinking" style="width:14px;height:14px;cursor:pointer;">
                    <span>思考</span>
                </label>
                <label class="model-tag-checkbox" style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-size:0.88rem;font-weight:500;">
                    <input type="checkbox" id="modelTagTools" value="tools" style="width:14px;height:14px;cursor:pointer;">
                    <span>工具</span>
                </label>
            </div>
            <div class="hint">这只是给用户看的能力提示标签,不会影响 API 行为或计费。识图/思考能力是否真的可用,仍由模型本身决定。</div>
        </div>

        <div class="modal-footer">
            <button class="btn-mini" onclick="closeModal('modelModal')">取消</button>
            <button class="btn-mini primary" onclick="saveModel()">保存</button>
        </div>
    </div>
</div>

<!-- ============ 弹窗:订阅包档位编辑(v5 新增) ============ -->
<div class="admin-modal-overlay" id="packTierModal">
    <div class="admin-modal">
        <div class="admin-modal-header">
            <div class="admin-modal-title" id="packTierModalTitle">新增档位</div>
            <span class="admin-modal-close" onclick="closeModal('packTierModal')">close</span>
        </div>
        <input type="hidden" id="packTierEditId" value="0">
        <div class="form-row">
            <div class="form-group">
                <label>价格(元)</label>
                <input type="number" id="packTierPrice" step="0.01" min="0.01" placeholder="例如:9.9 / 49.9">
                <div class="hint">前端展示价 + 支付时的校验值(精确到 2 位小数)</div>
            </div>
            <div class="form-group">
                <label>Token 数</label>
                <input type="number" id="packTierTokens" step="100000" min="0" placeholder="例如:1500000">
                <div class="hint">本档位赠送的 token 量,会累加到 pro_pack_total</div>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>赠送余额(元)</label>
                <input type="number" id="packTierGift" step="0.01" min="0" value="0">
                <div class="hint">购买该档位附赠的余额,累加到 users.balance</div>
            </div>
            <div class="form-group">
                <label>有效期(天)</label>
                <input type="number" id="packTierDays" step="1" min="1" value="30">
                <div class="hint">叠加到 plan_expired_at 的天数</div>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>标签(角标文字)</label>
                <input type="text" id="packTierLabel" maxlength="32" placeholder="留空 / 推荐 / 最划算 / 限时">
                <div class="hint">前端在卡片上显示的角标;填"最划算"会自动套用金色样式</div>
            </div>
            <div class="form-group">
                <label>排序</label>
                <input type="number" id="packTierSort" step="1" value="0" min="0">
                <div class="hint">数字小的排前面</div>
            </div>
        </div>
        <div class="form-group">
            <label>状态</label>
            <select id="packTierActive">
                <option value="1">在售(用户可见)</option>
                <option value="0">下架(隐藏)</option>
            </select>
        </div>
        <div class="modal-footer">
            <button class="btn-mini danger" onclick="deletePackTier()" id="packTierDeleteBtn" style="display:none">删除档位</button>
            <button class="btn-mini" onclick="closeModal('packTierModal')">取消</button>
            <button class="btn-mini primary" onclick="savePackTier()">保存</button>
        </div>
    </div>
</div>

<!-- 次数包档位 modal（v7） -->
<div class="admin-modal-overlay" id="countPackModal">
    <div class="admin-modal" style="max-width:560px;">
        <div class="admin-modal-header">
            <div class="admin-modal-title" id="countPackModalTitle">新增档位</div>
            <span class="admin-modal-close" onclick="closeModal('countPackModal')">&times;</span>
        </div>
        <input type="hidden" id="countPackEditId" value="0">
        <div class="form-row">
            <div class="form-group">
                <label>价格（元）</label>
                <input type="number" id="countPackPrice" step="0.01" min="0.01" placeholder="例如：9.90">
            </div>
            <div class="form-group">
                <label>次数</label>
                <input type="number" id="countPackCounts" step="1" min="1" placeholder="例如：100">
                <div class="hint">本套餐总共可调用次数</div>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>有效期（天）</label>
                <input type="number" id="countPackDays" step="1" min="1" value="30">
                <div class="hint">叠加到 count_pack_expired_at 的天数</div>
            </div>
            <div class="form-group">
                <label>标签</label>
                <input type="text" id="countPackLabel" maxlength="32" placeholder="留空 / 热卖 / 推荐">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>排序</label>
                <input type="number" id="countPackSort" step="1" value="0" min="0">
            </div>
            <div class="form-group">
                <label>状态</label>
                <select id="countPackActive">
                    <option value="1">在售（用户可见）</option>
                    <option value="0">下架</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>绑定模型（单选 · 每个次数包只绑定一个模型）</label>
            <div id="countPackModelsBox" style="
                max-height:240px; overflow-y:auto; border:1px solid #e0e0e0;
                border-radius:8px; padding:10px 12px; background:#fafafa;
                display:flex; flex-wrap:wrap; gap:6px 14px; font-size:0.85rem;
            ">
                <span style="color:#999;">加载中…</span>
            </div>
            <div class="hint" style="color:#b91c1c;">
                ⚠ 用户重复购买不同套餐时，<strong>模型清单以最新购买的套餐为准</strong>（次数累加但模型范围会被覆盖）。
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-mini danger" onclick="deleteCountPack()" id="countPackDeleteBtn" style="display:none">删除档位</button>
            <button class="btn-mini" onclick="closeModal('countPackModal')">取消</button>
            <button class="btn-mini primary" onclick="saveCountPack()">保存</button>
        </div>
    </div>
</div>

<!-- ============ 兑换码:批量生成弹窗 (2026-06-19) ============ -->
<div class="admin-modal-overlay" id="redeemModal">
    <div class="admin-modal" style="max-width:580px;">
        <div class="admin-modal-header">
            <div class="admin-modal-title">批量生成兑换码</div>
            <span class="admin-modal-close" onclick="closeModal('redeemModal')">&times;</span>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>奖励类型</label>
                <select id="redeemType" onchange="onRedeemTypeChange()">
                    <option value="balance">余额（元）</option>
                    <option value="token">Token 订阅包（token 数 + 有效期）</option>
                    <option value="count">次数包（模型 + 次数 + 有效期）</option>
                </select>
            </div>
            <div class="form-group">
                <label>生成数量</label>
                <input type="number" id="redeemCount" step="1" min="1" max="2000" value="10">
                <div class="hint">单次最多 2000 个</div>
            </div>
        </div>

        <!-- 数值 + 有效期 -->
        <div class="form-row">
            <div class="form-group">
                <label id="redeemValueLabel">金额（元）</label>
                <input type="number" id="redeemValue" step="0.01" min="0.01" placeholder="例如：10">
                <div class="hint" id="redeemValueHint">每个码到账的余额（元）</div>
            </div>
            <div class="form-group" id="redeemDaysGroup" style="display:none;">
                <label>有效期（天）</label>
                <input type="number" id="redeemDays" step="1" min="1" value="30">
                <div class="hint">Token / 次数包的有效期，从兑换时起算</div>
            </div>
        </div>

        <!-- 次数类型:模型勾选 -->
        <div class="form-group" id="redeemModelsGroup" style="display:none;">
            <label>绑定模型（次数包命中这些模型时每次扣 1 次）</label>
            <div id="redeemModelsBox" style="
                max-height:220px; overflow-y:auto; border:1px solid #e0e0e0;
                border-radius:8px; padding:10px 12px; background:#fafafa;
                display:flex; flex-wrap:wrap; gap:6px 14px; font-size:0.85rem;">
                <span style="color:#999;">加载中…</span>
            </div>
        </div>

        <div class="form-group">
            <label>备注（可选）</label>
            <input type="text" id="redeemNote" maxlength="128" placeholder="例如：双十一活动 / 客服补偿">
        </div>

        <div class="modal-footer">
            <button class="btn-mini" onclick="closeModal('redeemModal')">取消</button>
            <button class="btn-mini primary" onclick="createRedeem()">生成</button>
        </div>
    </div>
</div>

<!-- ============ 兑换码:生成结果弹窗 ============ -->
<div class="admin-modal-overlay" id="redeemResultModal">
    <div class="admin-modal" style="max-width:520px;">
        <div class="admin-modal-header">
            <div class="admin-modal-title" id="redeemResultModalTitle">生成成功</div>
            <span class="admin-modal-close" onclick="closeModal('redeemResultModal')">&times;</span>
        </div>
        <div style="font-size:0.85rem;color:#374151;margin-bottom:8px;" id="redeemResultModalSub"></div>
        <textarea id="redeemResultCodes" readonly
            style="width:100%;min-height:200px;padding:10px 12px;border:1px solid #e0e0e0;border-radius:8px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:0.85rem;line-height:1.8;letter-spacing:1px;resize:vertical;"></textarea>
        <div class="modal-footer">
            <button class="btn-mini" onclick="copyRedeemCodes()">复制全部</button>
            <button class="btn-mini primary" onclick="closeModal('redeemResultModal')">完成</button>
        </div>
    </div>
</div>

<div class="admin-modal-overlay" id="toolModal">
    <div class="admin-modal">
        <div class="admin-modal-header">
            <div class="admin-modal-title" id="toolModalTitle">新增工具</div>
            <span class="admin-modal-close" onclick="closeModal('toolModal')">close</span>
        </div>
        <input type="hidden" id="toolEditId" value="0">
        <div class="form-row">
            <div class="form-group">
                <label>tool_name <span style="color:#888;font-weight:normal">(对应 skills/xxx.py 的 NAME)</span></label>
                <input type="text" id="toolName" placeholder="例如：get_weather">
            </div>
            <div class="form-group">
                <label>展示名</label>
                <input type="text" id="toolDisplay" placeholder="例如：天气查询">
            </div>
        </div>
        <div class="form-group">
            <label>描述</label>
            <textarea id="toolDesc" rows="3" placeholder="工具市场展示给用户看的说明"></textarea>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>图标 (Material Symbols)</label>
                <input type="text" id="toolIcon" placeholder="extension" value="extension">
                <div class="hint">参考 fonts.google.com/icons</div>
            </div>
            <div class="form-group">
                <label>排序（小靠前）</label>
                <input type="number" id="toolSort" value="0">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>状态</label>
                <select id="toolActive">
                    <option value="1">上架</option>
                    <option value="0">下架</option>
                </select>
            </div>
            <div class="form-group">
                <label>核心工具？</label>
                <select id="toolCore">
                    <option value="0">普通（用户可禁用）</option>
                    <option value="1">核心（用户禁用按钮置灰）</option>
                </select>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-mini" onclick="closeModal('toolModal')">取消</button>
            <button class="btn-mini primary" onclick="saveTool()">保存</button>
        </div>
    </div>
</div>

<!-- v11 (2026-05-12) 提示词预设编辑器 -->
<div class="admin-modal-overlay" id="presetEditorModal">
    <div class="admin-modal admin-modal-large" style="max-width:980px;">
        <div class="admin-modal-header">
            <div class="admin-modal-title" id="presetEditorTitle">编辑预设</div>
            <span class="admin-modal-close" onclick="closeModal('presetEditorModal')">close</span>
        </div>
        <input type="hidden" id="presetId" value="">

        <div class="callout-info" style="background:#fef3c7;color:#92400e;padding:8px 12px;border-radius:6px;margin-bottom:12px;font-size:0.78rem;border:1px solid #fde68a;line-height:1.6;">
            <strong>可用变量(花括号严格):</strong>
            <code>{persona}</code> 人格设定 ·
            <code>{user_persona}</code> 用户自我介绍 ·
            <code>{emojis}</code> 表情清单 ·
            <code>{current_time}</code> 北京时间(实例关时间感知时为空) ·
            <code>{user_text}</code> 用户当前消息(仅被动场景有值)
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>预设名 <span style="color:#dc2626;">*</span></label>
                <input type="text" id="presetName" placeholder="例如:角色扮演·标准版" maxlength="80">
            </div>
            <div class="form-group">
                <label>简介(可选,展示给用户的副标题)</label>
                <input type="text" id="presetDesc" placeholder="例如:克制温柔,适合长对话" maxlength="255">
            </div>
        </div>

        <div class="form-group">
            <label>系统提示词(注入 system role) <span style="color:#dc2626;">*</span></label>
            <textarea id="presetSystem" rows="9" style="font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:0.84rem;" placeholder="【角色设定】&#10;{persona}&#10;{user_persona}{emojis}&#10;&#10;【工具调用】..."></textarea>
        </div>

        <div class="form-group">
            <label>被动回复提示词(用户主动发消息时,user role 内容) <span style="color:#dc2626;">*</span></label>
            <textarea id="presetPassive" rows="7" style="font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:0.84rem;" placeholder="用户发送了新消息:【{user_text}】&#10;请针对这句话回复..."></textarea>
        </div>

        <div class="form-group">
            <label>主动消息提示词(定时器触发 AI 主动发时,user role 内容) <span style="color:#dc2626;">*</span></label>
            <textarea id="presetProactive" rows="7" style="font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:0.84rem;" placeholder="【当前北京时间】{current_time}&#10;当前是主动消息模式..."></textarea>
        </div>

        <div class="form-group">
            <label>主动回复提示词 / 附加约束(可选,会附加到上面两个 user_prompt 末尾;留空跳过)</label>
            <textarea id="presetActive" rows="5" style="font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:0.84rem;" placeholder="【附加约束】&#10;- 格式纯净&#10;- 严禁输出时间戳..."></textarea>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>启用?</label>
                <label style="display:inline-flex;align-items:center;gap:8px;cursor:pointer;">
                    <input type="checkbox" id="presetIsActive" checked>
                    <span>启用后用户可在实例配置选用</span>
                </label>
            </div>
            <div class="form-group">
                <label>排序(小靠前)</label>
                <input type="number" id="presetSortOrder" value="0" step="1">
            </div>
        </div>

        <div class="modal-footer">
            <button class="btn-mini" onclick="closeModal('presetEditorModal')">取消</button>
            <button class="btn-mini primary" onclick="savePresetForm()">保存</button>
        </div>
    </div>
</div>

<div class="admin-modal-overlay" id="marketModal">
    <div class="admin-modal admin-modal-large">
        <div class="admin-modal-header">
            <div class="admin-modal-title" id="marketModalTitle">新增人格</div>
            <span class="admin-modal-close" onclick="closeModal('marketModal')">close</span>
        </div>
        <input type="hidden" id="marketEditId" value="0">
        <input type="hidden" id="marketAvatar" value="image/logo.png">

        <div style="display:flex;align-items:center;gap:16px;margin-bottom:14px;">
            <img id="marketAvatarPreview" src="image/logo.png" style="width:64px;height:64px;border-radius:50%;border:2px solid #eee;cursor:pointer;object-fit:cover;" onclick="document.getElementById('marketAvatarFile').click()">
            <div>
                <div style="font-weight:600">人格头像</div>
                <div class="hint" style="font-size:0.78rem;color:#888;">点击上传，自动压缩为 96×96 JPEG</div>
            </div>
            <input type="file" id="marketAvatarFile" accept="image/*" style="display:none" onchange="handleMarketAvatar(this)">
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>名称</label>
                <input type="text" id="marketName" placeholder="例如：温柔学姐">
            </div>
            <div class="form-group">
                <label>状态</label>
                <select id="marketActive">
                    <option value="1">上架</option>
                    <option value="0">下架</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>简短介绍</label>
            <textarea id="marketDesc" rows="2" placeholder="人格市场列表展示用"></textarea>
        </div>
        <div class="form-group">
            <label>System Prompt</label>
            <textarea id="marketPrompt" rows="8" placeholder="完整的 system prompt"></textarea>
        </div>
        <div class="modal-footer">
            <button class="btn-mini" onclick="closeModal('marketModal')">取消</button>
            <button class="btn-mini primary" onclick="saveMarket()">保存</button>
        </div>
    </div>
</div>

<!-- 留言回复弹窗 -->
<div class="admin-modal-overlay" id="messageReplyModal">
    <div class="admin-modal admin-modal-large">
        <div class="admin-modal-header">
            <div class="admin-modal-title">回复用户留言</div>
            <span class="admin-modal-close" onclick="closeModal('messageReplyModal')">close</span>
        </div>
        <input type="hidden" id="msgReplyId">
        <div style="background:#f5f5f5;padding:12px 16px;border-radius:10px;margin-bottom:14px;">
            <div style="font-size:0.78rem;color:#888;margin-bottom:6px;" id="msgReplyMeta">--</div>
            <div style="font-size:0.92rem;color:#222;line-height:1.65;white-space:pre-wrap;word-break:break-word;" id="msgReplyContent">--</div>
        </div>
        <div class="form-group">
            <label>回复内容</label>
            <textarea id="msgReplyText" rows="6" placeholder="输入回复内容..."></textarea>
        </div>
        <div class="modal-footer">
            <button class="btn-mini" onclick="closeModal('messageReplyModal')">取消</button>
            <button class="btn-mini primary" onclick="submitMessageReply()">发送回复</button>
        </div>
    </div>
</div>

<div id="global-toast"></div>

<script>
/* =========================================================
 * 通用工具
 * ========================================================= */
function showToast(msg, type = 'info') {
    const t = document.getElementById('global-toast');
    t.textContent = msg;
    t.className = `show toast-${type}`;
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.remove('show'), 2800);
}

async function adminApi(action, data = {}) {
    const formData = new FormData();
    for (const [k, v] of Object.entries(data)) {
        if (v !== null && v !== undefined) formData.append(k, v);
    }
    try {
        const res = await fetch(`admin.php?action=${action}`, { method: 'POST', body: formData });
        const j = await res.json();
        if (j.code !== 200) {
            showToast(j.message || '操作失败', 'error');
            return null;
        }
        return j.data ?? true;
    } catch (e) {
        console.error(e);
        showToast('网络异常', 'error');
        return null;
    }
}

async function adminApiJSON(action, data) {
    try {
        const res = await fetch(`admin.php?action=${action}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });
        const j = await res.json();
        if (j.code !== 200) { showToast(j.message || '操作失败', 'error'); return null; }
        return j.data ?? true;
    } catch (e) {
        showToast('网络异常', 'error');
        return null;
    }
}

function escHtml(s) {
    if (s === null || s === undefined) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
                    .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

function fmt(n) { return Number(n||0).toLocaleString('zh-CN'); }

function fmtTs(ts) {
    if (!ts) return '--';
    const d = new Date(ts * 1000);
    return d.getFullYear() + '-'
         + String(d.getMonth()+1).padStart(2,'0') + '-'
         + String(d.getDate()).padStart(2,'0') + ' '
         + String(d.getHours()).padStart(2,'0') + ':'
         + String(d.getMinutes()).padStart(2,'0');
}

function tsToDatetimeLocal(ts) {
    if (!ts) return '';
    const d = new Date(ts * 1000);
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function datetimeLocalToTs(s) {
    if (!s) return 0;
    return Math.floor(new Date(s).getTime() / 1000);
}

let _debounce = null;
function debounce(fn, ms = 300) {
    return function (...args) {
        clearTimeout(_debounce);
        _debounce = setTimeout(() => fn.apply(this, args), ms);
    };
}

function openModal(id) { document.getElementById(id).classList.add('active'); }
function closeModal(id) { document.getElementById(id).classList.remove('active'); }

/* =========================================================
 * Tab 切换
 * ========================================================= */
function switchTab(name) {
    document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.admin-nav-item').forEach(t => t.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    document.querySelector(`[data-tab="${name}"]`).classList.add('active');
    location.hash = name;

    // 离开实时监控页就停掉轮询，避免后台继续打 DB
    if (name !== 'monitor') stopMonitorPolling();
    if (name !== 'announce') stopAnnouncePolling();
    if (name !== 'dashboard') stopRtMonitor();

    const loaders = {
        dashboard: loadDashboard,
        users:     loadUsers,
        phone_blacklist: loadPhoneBlacklist,
        instances: loadInstances,
        orders:    loadOrders,
        user_stats: loadUserStats,
        models:    loadModels,
        packs:     loadPacks,
        count_packs: loadCountPacks,
        redeem:    loadRedeem,
        config:    loadConfigs,
        prompt_presets: loadPromptPresets,
        tools:     loadTools,
        market:    loadMarkets,
        emails:    loadEmails,
        messages:       loadMessages,
        forum:          loadForumAdmin,
        testimonials:   loadTestimonials,
        preset_voices:  loadPresetVoices,
        voice_call:     loadVoiceCall,
        lottery:        loadLottery,
        testimonials:   loadTestimonials,
        announcement: loadAnnouncement,
        videos:    loadVideos,
        monitor:   loadMonitor,
        announce:  loadAnnounce,
        versions:  loadVersions,
    };
    if (loaders[name]) loaders[name]();
}

/* =========================================================
 * 语音通话 (语音会员/音色管理)
 * ========================================================= */
async function loadVoiceCall() {
    const body = document.getElementById('voiceCallBody');
    const data = await adminApi('voice_call.list');
    if (!data) { body.innerHTML = '<tr><td colspan="7" class="empty-state">加载失败</td></tr>'; return; }
    document.getElementById('vcMemberCount').textContent = data.member_count || 0;
    document.getElementById('vcVoiceCount').textContent = data.voice_count || 0;
    const list = data.list || [];
    const now = data.now || 0;
    if (!list.length) { body.innerHTML = '<tr><td colspan="7" class="empty-state">暂无语音会员</td></tr>'; return; }
    let html = '';
    for (const r of list) {
        const exp = r.voice_expired_at ? new Date(r.voice_expired_at * 1000).toLocaleDateString() : '-';
        const active = r.voice_expired_at > now;
        const vid = r.voice_id || '';
        const hasVoice = vid !== '';
        const vidCell = hasVoice ? escHtml(vid) : '<span style="color:#bbb">无</span>';
        const delCell = hasVoice
            ? '<button class="btn-mini" style="color:#d94a4a;border-color:#f0d2d2" onclick="deleteUserVoice(' + r.user_id + ')">删除</button>'
            : '<span style="color:#bbb">\u2014</span>';
        html += '<tr>'
            + '<td>' + r.user_id + '</td>'
            + '<td>' + escHtml(r.username || '-') + '</td>'
            + '<td style="font-family:monospace;font-size:0.76rem;word-break:break-all">' + vidCell + '</td>'
            + '<td>' + escHtml(r.voice_name || '-') + '</td>'
            + '<td style="color:' + (active ? '#2e7d32' : '#d94a4a') + '">' + exp + '</td>'
            + '<td style="text-align:center">' + (r.wechat_enabled == 1 ? '\u2713' : '\u2014') + '</td>'
            + '<td>' + delCell + '</td>'
            + '</tr>';
    }
    body.innerHTML = html;
    loadSquareAdmin();
}
async function deleteUserVoice(uid) {
    if (!confirm('\u786e\u5b9a\u5220\u9664\u8be5\u7528\u6237\u7684\u97f3\u8272\uff1f\u5c06\u540c\u65f6\u5220\u9664\u963f\u91cc\u4e91\u548c\u6570\u636e\u5e93\u7684\u97f3\u8272 ID\uff0c\u7528\u6237\u9700\u91cd\u65b0\u514b\u9686\u3002')) return;
    const r = await adminApi('voice_call.delete_voice', { user_id: uid });
    if (r) loadVoiceCall();
}

async function loadDashscopeVoices() {
    const body = document.getElementById('dsVoiceBody');
    const summary = document.getElementById('dsVoiceSummary');
    summary.textContent = '正在拉取阿里云全部音色...';
    body.innerHTML = '<tr><td colspan="6" class="empty-state">加载中...</td></tr>';
    const data = await adminApi('voice_call.list_dashscope');
    if (!data) { summary.textContent = '拉取失败'; body.innerHTML = '<tr><td colspan="6" class="empty-state">拉取失败</td></tr>'; return; }
    const list = data.list || [];
    const inUse = data.in_use || {};
    summary.innerHTML = '账号下共 <strong>' + (data.total || 0) + '</strong> 个音色 ID（配额上限 1000）。';
    if (!list.length) { body.innerHTML = '<tr><td colspan="6" class="empty-state">账号下暂无音色</td></tr>'; return; }
    let html = '';
    list.forEach(function (v, i) {
        const vid = v.voice_id;
        const owner = inUse[vid] ? ('用户 ' + inUse[vid]) : '<span style="color:#bbb">孤儿</span>';
        html += '<tr>'
            + '<td>' + (i + 1) + '</td>'
            + '<td style="font-family:monospace;font-size:0.74rem;word-break:break-all">' + escHtml(vid) + '</td>'
            + '<td>' + escHtml(v.status || '-') + '</td>'
            + '<td style="font-size:0.75rem;color:#888">' + escHtml(v.gmt_create || '-') + '</td>'
            + '<td>' + owner + '</td>'
            + '<td><button class="btn-mini" style="color:#d94a4a;border-color:#f0d2d2" onclick="deleteDashscopeVoice(\'' + encodeURIComponent(vid) + '\')">删除</button></td>'
            + '</tr>';
    });
    body.innerHTML = html;
}
async function deleteDashscopeVoice(vidEnc) {
    const vid = decodeURIComponent(vidEnc);
    if (!confirm('确定从阿里云删除音色\n' + vid + '\n不可恢复。')) return;
    const r = await adminApi('voice_call.delete_dashscope', { voice_id: vid });
    if (r) loadDashscopeVoices();
}
async function purgeAllDashscope() {
    if (!confirm('确定批量删除阿里云账号下【全部】音色 ID？\n将逐个真实删除、释放全部配额，不可恢复！')) return;
    const summary = document.getElementById('dsVoiceSummary');
    let total = 0;
    for (let i = 0; i < 200; i++) {
        const r = await adminApi('voice_call.purge_dashscope');
        if (!r) { summary.textContent = '批量删除中断（网络/接口错误），已删 ' + total + ' 个。'; break; }
        total += (r.deleted || 0);
        summary.innerHTML = '批量删除中... 已删除 <strong>' + total + '</strong> 个' + (r.failed ? '（本批 ' + r.failed + ' 个失败）' : '') + '...';
        if (!r.batch) { summary.innerHTML = '✅ 批量删除完成，共删除 <strong>' + total + '</strong> 个音色，配额已释放。'; break; }
        if (!r.deleted) { summary.innerHTML = '⚠ 本批 ' + r.batch + ' 个音色全部删除失败，已累计删除 ' + total + ' 个，请查服务器日志。'; break; }
    }
    loadDashscopeVoices();
}

async function loadSquareAdmin() {
    var body = document.getElementById('squareBody');
    if (!body) return;
    var data = await adminApi('square.list');
    if (!data) { body.innerHTML = '<tr><td colspan="5" class="empty-state">加载失败</td></tr>'; return; }
    var list = data.list || [];
    if (!list.length) { body.innerHTML = '<tr><td colspan="5" class="empty-state">暂无音色，用上方表单添加</td></tr>'; return; }
    var html = '';
    for (var i = 0; i < list.length; i++) {
        var r = list[i];
        html += '<tr>'
            + '<td>' + r.id + '</td>'
            + '<td>' + escHtml(r.name || '-') + '</td>'
            + '<td style="font-family:monospace;font-size:0.76rem;word-break:break-all">' + escHtml(r.voice_id || '') + '</td>'
            + '<td>' + escHtml(r.note || '') + '</td>'
            + '<td><button class="btn-mini" style="color:#d94a4a;border-color:#f0d2d2" onclick="deleteSquareEntry(' + r.id + ')">删除</button></td>'
            + '</tr>';
    }
    body.innerHTML = html;
}
async function addSquare() {
    var name = (document.getElementById('sqName').value || '').trim();
    var vid  = (document.getElementById('sqVoiceId').value || '').trim();
    var note = (document.getElementById('sqNote').value || '').trim();
    if (!name || !vid) { alert('名称和音色 ID 不能为空'); return; }
    var r = await adminApi('square.add', { name: name, voice_id: vid, note: note });
    if (r) { document.getElementById('sqName').value = ''; document.getElementById('sqVoiceId').value = ''; document.getElementById('sqNote').value = ''; loadSquareAdmin(); }
}
async function deleteSquareEntry(id) {
    if (!confirm('确定从音色广场删除该音色？(不影响已导入的用户)')) return;
    var r = await adminApi('square.delete', { id: id });
    if (r) loadSquareAdmin();
}

/* =========================================================
 * Dashboard
 * ========================================================= */
async function loadDashboard() {
    const data = await adminApi('stats');
    if (!data) return;
    const grid = document.getElementById('statGrid');
    // Ovation 风格 6 卡:左上彩色圆角图标底 + 大数字 + 标签 + 数据胶囊
    grid.innerHTML = `
        <div class="stat-card">
            <div class="sc-top"><span class="icon-chip icon-chip--violet"><span class="material-symbols-rounded">group</span></span></div>
            <div class="value">${fmt(data.user_total)}</div>
            <div class="label">用户总数</div>
            <div class="delta">今日 <strong>+${fmt(data.user_today)}</strong></div>
        </div>
        <div class="stat-card">
            <div class="sc-top"><span class="icon-chip icon-chip--warning"><span class="material-symbols-rounded">workspace_premium</span></span></div>
            <div class="value">${fmt(data.user_with_pack || 0)}</div>
            <div class="label">订阅用户</div>
            <div class="delta">Pro <span class="neu">${fmt(data.user_pro || 0)}</span></div>
        </div>
        <div class="stat-card">
            <div class="sc-top"><span class="icon-chip icon-chip--info"><span class="material-symbols-rounded">smart_toy</span></span></div>
            <div class="value">${fmt(data.instance_total)}</div>
            <div class="label">实例总数</div>
            <div class="delta">在线 <strong>${fmt(data.instance_active)}</strong></div>
        </div>
        <div class="stat-card">
            <div class="sc-top"><span class="icon-chip icon-chip--success"><span class="material-symbols-rounded">payments</span></span></div>
            <div class="value">¥${fmt(Math.round(data.order_amount))}</div>
            <div class="label">累计收入</div>
            <div class="delta">${fmt(data.order_total)} 单</div>
        </div>
        <div class="stat-card">
            <div class="sc-top"><span class="icon-chip icon-chip--pink"><span class="material-symbols-rounded">receipt_long</span></span></div>
            <div class="value">${fmt(data.order_today)}</div>
            <div class="label">今日订单</div>
            <div class="delta">¥<strong>${data.order_today_amount.toFixed(2)}</strong></div>
        </div>
        <div class="stat-card">
            <div class="sc-top"><span class="icon-chip icon-chip--violet"><span class="material-symbols-rounded">forum</span></span></div>
            <div class="value">${fmt(data.msg_total)}</div>
            <div class="label">AI 回复</div>
            <div class="delta">累计</div>
        </div>
    `;

    // 更新时间
    const updEl = document.getElementById('dashUpdated');
    if (updEl) {
        const d = new Date();
        const pad = n => String(n).padStart(2, '0');
        updEl.textContent = `· 更新于 ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
    }

    // v15.0 折线/柱状图 + 卡片头聚合数据
    const trend = data.trend || { labels: [], users: [], orders: [], revenue: [] };

    // ── 用户增长聚合 ───────────────────────────────────────────
    const userArr = trend.users || [];
    const userSum = userArr.reduce((a, b) => a + b, 0);
    const userAvg = userArr.length ? Math.round(userSum / userArr.length) : 0;
    const userToday = userArr.length ? userArr[userArr.length - 1] : 0;
    const userYday  = userArr.length >= 2 ? userArr[userArr.length - 2] : 0;
    const userDiff  = userToday - userYday;
    const userBigEl = document.getElementById('usersBig');
    const userSubEl = document.getElementById('usersSub');
    if (userBigEl) userBigEl.textContent = '+' + fmt(userSum) + ' 人';
    if (userSubEl) {
        const arrow = userDiff > 0 ? `<span class="up">▲ +${userDiff}</span>`
                   : userDiff < 0 ? `<span class="down">▼ ${userDiff}</span>`
                   : `<span style="color:#94a3b8;">持平</span>`;
        userSubEl.innerHTML = `日均 <strong>${fmt(userAvg)}</strong> 人 · 今日 <strong>+${userToday}</strong> ${arrow}`;
    }

    // ── 每日收入聚合 ───────────────────────────────────────────
    const revArr = trend.revenue || [];
    const revSum = revArr.reduce((a, b) => a + b, 0);
    const revAvg = revArr.length ? revSum / revArr.length : 0;
    const revToday = revArr.length ? revArr[revArr.length - 1] : 0;
    const revYday  = revArr.length >= 2 ? revArr[revArr.length - 2] : 0;
    const revDiff  = revToday - revYday;
    const revBigEl = document.getElementById('revBig');
    const revSubEl = document.getElementById('revSub');
    if (revBigEl) revBigEl.textContent = '¥' + revSum.toFixed(2);
    if (revSubEl) {
        const arrow = revDiff > 0 ? `<span class="up">▲ +¥${revDiff.toFixed(2)}</span>`
                   : revDiff < 0 ? `<span class="down">▼ ¥${revDiff.toFixed(2)}</span>`
                   : `<span style="color:#94a3b8;">持平</span>`;
        revSubEl.innerHTML = `日均 <strong>¥${revAvg.toFixed(2)}</strong> · 今日 <strong>¥${revToday.toFixed(2)}</strong> ${arrow}`;
    }

    // 用户:折线图(看增长趋势) / 收入:柱状图(看每日分布更直观)
    _drawDashChart('chartUsers', '#8b7fff', trend.labels, trend.users,
        (v) => `${v} 人`, { type: 'line' });
    _drawDashChart('chartRevenue', '#10b981', trend.labels, trend.revenue,
        (v) => '¥' + Number(v).toFixed(2), { type: 'bar' });

    // v13.12 (2026-05-14) 系统监控小卡(异步拉,不阻塞 stats)
    loadSystemStatus();

    // v15.1 (2026-06-28) 检查是否有新订单
    _checkOrderAlert(data.order_today, data.order_today_amount);

    // 2026-07 支付回调掉单监控:每次 dashboard 加载/刷新都同步一次面板
    if (typeof _refreshNotifyAnomalies === 'function') _refreshNotifyAnomalies();
    if (typeof _nsReload === 'function' && _reconOpen) _nsReload(_nsPage || 1);

    // 实时运行 · 监控（默认折叠；展开后才开始每秒轮询）
    // 折叠状态下不轮询，不占屏也不打数据库。
}

/* =========================================================
 * v15.1 (2026-06-28) 全屏看板 + 每分钟数据刷新 + 新订单警报
 * v15.2 (2026-06-28) 提示音权限按钮(浏览器自动播放限制必需)
 *   - 浏览器要求:audio.play() 必须从用户手势中触发,刷新后 audio context
 *     重置 → 每次进后台都需要用户手动点一下"申请提示音权限"
 *   - localStorage 持久化"用户曾启用过"的标志,二次进入按钮换文案提示
 *   - 已启用前订单警报照旧弹红边框 + 顶部条,仅跳过音效(并 console.warn)
 * ========================================================= */
let _dashFullscreen   = false;
let _dashAutoTimer    = null;
let _lastOrderToday   = null;   // null = 首次加载,不触发
let _lastOrderAmount  = 0;
let _audioPrimed      = false;  // 当前 session 是否已通过用户手势激活 audio

/* 切换全屏看板:隐藏侧栏 + 自动展开实时运行 */
function toggleDashboardFullscreen() {
    _dashFullscreen = !_dashFullscreen;
    document.body.classList.toggle('dashboard-fullscreen', _dashFullscreen);
    const btn = document.getElementById('dashFsBtn');
    const lbl = document.getElementById('dashFsBtnLabel');
    if (btn && lbl) {
        const icon = btn.querySelector('.material-symbols-rounded');
        if (_dashFullscreen) {
            lbl.textContent = '退出全屏';
            if (icon) icon.textContent = 'fullscreen_exit';
            // 实时运行默认展开
            const rt = document.getElementById('rtMonitor');
            if (rt && rt.classList.contains('collapsed')) {
                toggleRtMonitor();   // 这函数本身会启动每秒轮询
            }
        } else {
            lbl.textContent = '全屏看板';
            if (icon) icon.textContent = 'fullscreen';
        }
    }
}

/* dashboard 每 60 秒数据刷新(走 adminApi fetch,不是页面 reload) */
function startDashAutoRefresh() {
    if (_dashAutoTimer) clearInterval(_dashAutoTimer);
    _dashAutoTimer = setInterval(() => {
        const t = document.getElementById('tab-dashboard');
        if (t && t.classList.contains('active')) {
            loadDashboard();
        }
    }, 60000);
}
function stopDashAutoRefresh() {
    if (_dashAutoTimer) { clearInterval(_dashAutoTimer); _dashAutoTimer = null; }
}

/* ── 提示音权限 ──────────────────────────────────────────────
 * 浏览器自动播放策略:audio.play() 只能在用户手势(click/touch/keydown)
 * 的同步调用栈里触发一次,之后该 audio 元素就被"激活",后续 play() 不再被拦。
 * 刷新页面后 audio context 重置,需要重新激活,所以按钮要每次进入都显示。
 * 这一次点击激活订单 a.mp3,并解锁合成告警引擎(Web Audio)+ 语音播报。
 * ──────────────────────────────────────────────────────── */
async function onAudioPermClick() {
    // v16:同一次用户手势里解锁合成告警引擎(Web Audio)+ 语音播报(speechSynthesis)
    try { _ax(); } catch (e) {}
    try {
        if (window.speechSynthesis) {
            const _warm = new SpeechSynthesisUtterance(' ');
            _warm.volume = 0;
            window.speechSynthesis.speak(_warm);
        }
    } catch (e) {}
    const ids = ['orderAlertAudio'];
    const btn = document.getElementById('audioPermBtn');
    let anyOk = false;
    let lastErr = null;
    for (const id of ids) {
        const audio = document.getElementById(id);
        if (!audio) continue;
        try {
            // 静音 prime:play→pause 解锁该 audio,不打扰用户
            audio.volume = 0;
            audio.currentTime = 0;
            await audio.play();
            try { audio.pause(); audio.currentTime = 0; } catch (e) {}
            audio.volume = 1;
            anyOk = true;
        } catch (e) {
            lastErr = e;
            console.warn('[音效权限] 激活', id, '失败:', e.message);
        }
    }
    if (anyOk) {
        _audioPrimed = true;
        try { localStorage.setItem('audioAlertEnabled', '1'); } catch (e) {}
        _updateAudioPermUI();
        if (typeof showToast === 'function') {
            showToast('提示音已启用(订单 + 异常告警)', 'success');
        }
    } else {
        if (btn) {
            btn.classList.remove('pending');
            btn.classList.add('warn');
        }
        const label = document.getElementById('audioPermLabel');
        if (label) label.textContent = '启用失败 · 点击重试';
        if (typeof showToast === 'function') {
            showToast('音效启用失败:' + (lastErr && lastErr.message) + '。请检查浏览器自动播放设置', 'error');
        }
    }
}

/* 根据 _audioPrimed + localStorage 历史标志更新按钮外观 */
function _updateAudioPermUI() {
    const btn = document.getElementById('audioPermBtn');
    const label = document.getElementById('audioPermLabel');
    const icon = document.getElementById('audioPermIcon');
    if (!btn || !label || !icon) return;
    if (_audioPrimed) {
        btn.classList.remove('pending', 'warn');
        btn.classList.add('granted');
        btn.disabled = true;
        icon.textContent = 'volume_up';
        label.textContent = '提示音已启用';
        btn.title = '本次会话内,新订单会自动播报;刷新页面后需重新点击';
        return;
    }
    let wasGranted = false;
    try { wasGranted = localStorage.getItem('audioAlertEnabled') === '1'; } catch (e) {}
    btn.classList.remove('granted', 'warn');
    btn.classList.add('pending');
    btn.disabled = false;
    icon.textContent = 'notifications_off';
    label.textContent = wasGranted ? '点击重新启用提示音' : '申请提示音权限';
    btn.title = wasGranted
        ? '您之前已授权,但刷新页面后浏览器要求重新激活 — 点一下即可'
        : '点击后允许浏览器播放新订单提示音(必需,每次刷新页面需要重新点击)';
}

/* 比对今日订单数:首次见仅记录,涨了才告警 */
function _checkOrderAlert(newCount, newAmount) {
    newCount  = parseInt(newCount, 10) || 0;
    newAmount = parseFloat(newAmount) || 0;
    if (_lastOrderToday === null) {
        // 首次加载,只记不报
        _lastOrderToday  = newCount;
        _lastOrderAmount = newAmount;
        return;
    }
    if (newCount > _lastOrderToday) {
        const deltaCnt = newCount  - _lastOrderToday;
        const deltaAmt = newAmount - _lastOrderAmount;
        _triggerOrderAlert(deltaCnt, deltaAmt, newAmount);
    }
    // 跨天后 newCount 会重置成 0 或较小值,同步即可
    _lastOrderToday  = newCount;
    _lastOrderAmount = newAmount;
}

/* 触发新订单警报:播放 a.mp3 + 红色边框闪烁 + 顶部通知条 */
function _triggerOrderAlert(deltaCnt, deltaAmt, totalAmt) {
    // 1) 播放音效(必须已通过权限按钮激活)
    if (_audioPrimed) {
        try {
            const audio = document.getElementById('orderAlertAudio');
            if (audio) {
                audio.currentTime = 0;
                audio.volume = 1;
                const p = audio.play();
                if (p && p.catch) {
                    p.catch(e => {
                        console.warn('[新订单警报] 音效仍被拦截,可能权限失效:', e.message);
                        _audioPrimed = false;
                        _updateAudioPermUI();
                    });
                }
            }
        } catch (e) {
            console.warn('[新订单警报] 音效播放异常:', e.message);
        }
    } else {
        console.warn('[新订单警报] 未启用提示音权限,跳过音效(仅弹视觉警报)');
    }
    // 2) 红色边框闪烁
    const ov = document.getElementById('orderAlertOverlay');
    if (ov) ov.classList.add('active');
    // 3) 顶部通知条
    const bn = document.getElementById('orderAlertBanner');
    const sub = document.getElementById('orderAlertSub');
    if (sub) {
        const now = new Date();
        const pad = n => String(n).padStart(2, '0');
        const tm = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
        let txt = `+${deltaCnt} 单`;
        if (deltaAmt > 0) txt += ` · 本笔约 ¥${deltaAmt.toFixed(2)}`;
        txt += ` · ${tm}`;
        sub.textContent = txt;
    }
    if (bn) bn.classList.add('active');
}

/* 点击"确认"按钮:解除红色边框 + 隐藏通知条 */
function dismissOrderAlert() {
    const ov = document.getElementById('orderAlertOverlay');
    const bn = document.getElementById('orderAlertBanner');
    if (ov) ov.classList.remove('active');
    if (bn) bn.classList.remove('active');
}

/* =========================================================
 * v15.3 (2026-06-28) 接口异常告警系统
 *   日志中提取 HTTP 403 / 405 / 500 → 异常列表 + 红色闪烁 + b.wav
 *   单条 = 播一次,屏幕短暂红闪;1 分钟超过 12 条 = 循环播放直到确认
 *   只对增量日志(fresh)生效,不对历史回放触发告警
 * ========================================================= */
const _errorLog = [];            // 最近 50 条异常,新的在前
const _errorRateWindow = [];     // 最近 60s 内的错误时间戳(秒)
let _errorLoopMode = false;      // 当前是否处于循环告警状态
let _errorLoopDismissedAt = 0;   // 上次解除循环的毫秒时间戳(冷却 60s)
let _errorOneshotTimer = null;   // 单次告警的闪烁自动关闭定时器
const ERROR_RATE_THRESHOLD = 12; // 1 分钟超过此阈值进入循环模式
const ERROR_COOLDOWN_MS = 60000; // 确认后 60s 冷却,期间高频率也只单次告警

/* =========================================================
 * v16 合成告警引擎(纯前端,替代 b.wav)
 *   - Web Audio 实时合成:急促声(连接断开) / 核弹音(接口异常 · 连接建立)
 *   - speechSynthesis 语音播报
 *   - 所有告警都有顶部横幅 + 「确定」按钮,可手动点掉
 *   浏览器自动播放策略:首帧声音需在用户手势里解锁 —— 复用页面顶部
 *   「启用提示音权限」按钮,onAudioPermClick() 里已 resume 本引擎。
 * ========================================================= */
let _axCtx = null, _axMaster = null;
const _axOscs = new Set();
function _ax() {
    if (!_axCtx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        _axCtx = new AC();
        _axMaster = _axCtx.createGain();
        _axMaster.gain.value = 0.6;
        _axMaster.connect(_axCtx.destination);
    }
    if (_axCtx.state === 'suspended') { try { _axCtx.resume(); } catch (e) {} }
    return _axCtx;
}
function _axTone(o, t) {
    if (!_axCtx) return;
    const osc = _axCtx.createOscillator(), g = _axCtx.createGain();
    osc.type = o.wave;
    osc.frequency.setValueAtTime(o.f, t);
    if (o.f2 && o.f2 !== o.f) osc.frequency.linearRampToValueAtTime(o.f2, t + o.dur);
    const v = Math.max(o.vol, 0.0004);
    const atk = Math.min(0.006, o.dur * 0.25), rel = Math.min(0.05, o.dur * 0.4);
    g.gain.setValueAtTime(0.0004, t);
    g.gain.exponentialRampToValueAtTime(v, t + atk);
    g.gain.setValueAtTime(v, Math.max(t + atk, t + o.dur - rel));
    g.gain.exponentialRampToValueAtTime(0.0004, t + o.dur);
    osc.connect(g).connect(_axMaster);
    osc.start(t); osc.stop(t + o.dur + 0.03);
    _axOscs.add(osc);
    osc.onended = () => { _axOscs.delete(osc); try { osc.disconnect(); g.disconnect(); } catch (e) {} };
}
/* 急促声一批(~1s):高频方波快点,近乎连续 */
function _sndRapid(t) {
    for (let i = 0; i < 8; i++) { _axTone({ wave: 'square', f: 2100, dur: 0.06, vol: 0.32 }, t); t += 0.12; }
    return t;
}
/* 核弹音一声:低沉上下扫频(slow=更慢更长,音量更柔,用于「连接建立」) */
function _sndNuke(t, slow) {
    const dur = slow ? 1.2 : 0.55;
    const v = slow ? 0.26 : 0.34;
    _axTone({ wave: 'sawtooth', f: 196, f2: 660, dur: dur * 0.6, vol: v }, t);
    _axTone({ wave: 'sawtooth', f: 660, f2: 196, dur: dur * 0.4, vol: v * 0.9 }, t + dur * 0.6);
    return t + dur;
}
/* 核弹音一批(循环用,~1.4s 两声) */
function _sndNukeBatch(t) { t = _sndNuke(t, false); t += 0.12; t = _sndNuke(t, false); return t + 0.12; }

/* ── 语音播报 ── */
const _tts = window.speechSynthesis || null;
let _ttsVoice = null;
function _pickVoice() {
    if (!_tts) return;
    const vs = _tts.getVoices();
    _ttsVoice = vs.find(v => /zh|cmn|chinese|中文|普通话|粤/i.test(v.lang + ' ' + v.name)) || vs[0] || null;
}
if (_tts) { _pickVoice(); _tts.onvoiceschanged = _pickVoice; }
function _say(text) {
    if (!_tts) return;
    try {
        const u = new SpeechSynthesisUtterance(text);
        if (_ttsVoice) u.voice = _ttsVoice;
        u.lang = (_ttsVoice && _ttsVoice.lang) || 'zh-CN';
        u.rate = 1; u.pitch = 1; u.volume = 1;
        _tts.speak(u);
    } catch (e) {}
}
function _sayNow(text) { if (_tts) { try { _tts.cancel(); } catch (e) {} } _say(text); }

/* ── 接口异常:循环核弹音 + 语音「无法处理请求数据」(由 _triggerErrorAlertLoop 启停) ── */
let _logErrTimer = null, _logErrSpokeAt = 0;
function _logErrTick() {
    if (!_errorLoopMode) { _logErrTimer = null; return; }
    const ctx = _ax();
    if (ctx) _sndNukeBatch(ctx.currentTime + 0.02);
    if (Date.now() - _logErrSpokeAt >= 12000) { _logErrSpokeAt = Date.now(); _say('无法处理请求数据'); }
    _logErrTimer = setTimeout(_logErrTick, 1300);
}

/* ── 连接断开告警:循环急促音 + 语音「连接断开」;超 1 分钟升级「断开危险，无法重连」── */
let _connDown = false, _connBadStreak = 0;
const CONN_STALE_ENTER = 5, CONN_STALE_EXIT = 2, CONN_BAD_TICKS = 2;
const _connAl = { on: false, startedAt: 0, escalated: false, timer: null, spokeAt: 0 };

/* 由 loadRtMonitor 每秒调用:available=false 或 age>=5 视为异常(带 2 拍防抖) */
function _evalConnHealth(available, age) {
    const bad  = !available || age >= CONN_STALE_ENTER;
    const good = available && age <= CONN_STALE_EXIT;
    if (bad) _connBadStreak++; else if (good) _connBadStreak = 0;
    if (!_connDown && bad && _connBadStreak >= CONN_BAD_TICKS) {
        _connDown = true;
        _startConnAlarm();
    } else if (_connDown && good) {
        _connDown = false;
        _stopConnAlarm();        // 停掉断开告警
        _connEstablishedCue();   // 缓慢核弹音 ×3 +「连接建立」×3
    }
}
function _showConnBanner(escalated) {
    const ov = document.getElementById('connAlertOverlay');
    const bn = document.getElementById('connAlertBanner');
    const ti = document.getElementById('connAlertTitle');
    const su = document.getElementById('connAlertSub');
    if (ti) ti.textContent = escalated ? '断开危险，无法重连' : '连接断开';
    if (su) su.textContent = escalated ? '已超过 1 分钟未恢复,请立即检查后端服务' : '实时快照已停止更新';
    if (ov) ov.classList.add('active', 'loop');
    if (bn) bn.classList.add('active', 'loop');
}
function _hideConnBanner() {
    const ov = document.getElementById('connAlertOverlay');
    const bn = document.getElementById('connAlertBanner');
    if (ov) ov.classList.remove('active', 'loop');
    if (bn) bn.classList.remove('active', 'loop');
}
function _startConnAlarm() {
    if (_connAl.on) return;
    _connAl.on = true; _connAl.startedAt = Date.now(); _connAl.escalated = false; _connAl.spokeAt = Date.now();
    _ax();
    _showConnBanner(false);
    _sayNow('连接断开');
    _connTick();
}
function _connTick() {
    if (!_connAl.on) return;
    const ctx = _ax();
    if (ctx) _sndRapid(ctx.currentTime + 0.02);
    const elapsed = Date.now() - _connAl.startedAt;
    if (elapsed >= 60000 && !_connAl.escalated) {
        _connAl.escalated = true;
        _showConnBanner(true);
        _sayNow('断开危险，无法重连');
        _connAl.spokeAt = Date.now();
    } else {
        const phrase = _connAl.escalated ? '断开危险，无法重连' : '连接断开';
        const iv = _connAl.escalated ? 10000 : 14000;
        if (Date.now() - _connAl.spokeAt >= iv) { _connAl.spokeAt = Date.now(); _say(phrase); }
    }
    _connAl.timer = setTimeout(_connTick, 1000);
}
function _stopConnAlarm() {
    _connAl.on = false;
    if (_connAl.timer) { clearTimeout(_connAl.timer); _connAl.timer = null; }
    _hideConnBanner();
}
/* 用户点「确定」:静音断开告警(连接仍断时不再重复报,恢复后会有建立提示) */
function dismissConnAlert() { _stopConnAlarm(); }

/* ── 连接建立提示:缓慢核弹音 ×3 + 语音「连接建立」×3(瞬时,可提前确定) ── */
const _connOk = { timer: null, seq: 0 };
function _connEstablishedCue() {
    _ax();
    if (_tts) { try { _tts.cancel(); } catch (e) {} }   // 打断残留的「连接断开」
    const bn = document.getElementById('connOkBanner');
    if (bn) bn.classList.add('active');
    if (_connOk.timer) { clearTimeout(_connOk.timer); }
    _connOk.seq = 0;
    const step = () => {
        if (_connOk.seq >= 3) { _connOk.timer = setTimeout(dismissConnOk, 1600); return; }
        _connOk.seq++;
        const ctx = _ax();
        if (ctx) _sndNuke(ctx.currentTime + 0.02, true);
        _say('连接建立');
        _connOk.timer = setTimeout(step, 1600);
    };
    step();
}
function dismissConnOk() {
    if (_connOk.timer) { clearTimeout(_connOk.timer); _connOk.timer = null; }
    _connOk.seq = 3;
    if (_tts) { try { _tts.cancel(); } catch (e) {} }
    const bn = document.getElementById('connOkBanner');
    if (bn) bn.classList.remove('active');
}

/* 在日志原文里识别接口错误:返回错误码("403"/"405"/"500")或 null */
function _scanLogForErrors(logEntry) {
    const msg = String((logEntry && logEntry.msg) || '');
    if (!msg) return;
    // 快速否决:不含 403/405/500 直接退出
    if (!/\b(403|405|500)\b/.test(msg)) return;
    // 上下文确认:必须看起来像 HTTP / 接口错误,避免误伤 "took 500ms" 之类
    const isErrLine = /(\[异常\]|\[超时\]|\[错误\]|\bError\b|\bException\b|Traceback|HTTPError|RequestException|ConnectionError|失败|拒绝|Forbidden|Not\s+Allowed|Internal\s+Server|Bad\s+Gateway|Service\s+Unavailable|Gateway\s+Timeout)/i.test(msg);
    const hasHttpKeyword = /\b(HTTP|http|status[\s_-]?code|状态码|响应码|response[_\s-]?code)\b/i.test(msg);
    if (!isErrLine && !hasHttpKeyword) return;
    const m = msg.match(/\b(403|405|500)\b/);
    if (!m) return;
    // 提取分片号(日志原文以 [分片N] 开头)
    let shard = '0';
    const sm = msg.match(/^\[分片(\d+)\]/);
    if (sm) shard = sm[1];
    _recordError({
        ts:    logEntry.ts || Math.floor(Date.now() / 1000),
        code:  m[1],
        msg:   msg,
        shard: shard,
    });
}

/* 记录一条异常 → 更新列表 + 评估告警等级 */
function _recordError(err) {
    // 1) 写入异常列表(新的在前,最多 50 条)
    _errorLog.unshift(err);
    if (_errorLog.length > 50) _errorLog.length = 50;
    // 2) 更新最近 60s 速率窗口
    _errorRateWindow.push(err.ts);
    const cutoff = Math.floor(Date.now() / 1000) - 60;
    while (_errorRateWindow.length && _errorRateWindow[0] < cutoff) {
        _errorRateWindow.shift();
    }
    // 3) 刷新 UI
    _updateExceptionList();
    _updateExceptionRate();
    // 4) v16:任何日志报错 → 循环核弹音 + 语音「无法处理请求数据」,须点确定。
    //    已在循环中 → 只更新文字;确认后 60s 冷却期内 → 静默记录,不重启循环。
    const inCooldown = (Date.now() - _errorLoopDismissedAt) < ERROR_COOLDOWN_MS;
    if (_errorLoopMode) {
        _updateErrorBannerText(err);
    } else if (!inCooldown) {
        _triggerErrorAlertLoop(err);
    }
}

/* v16:接口异常 → 循环核弹音 + 语音「无法处理请求数据」+ 红闪,必须点确定 */
function _triggerErrorAlertLoop(err) {
    _errorLoopMode = true;
    _ax();
    const ov = document.getElementById('errorAlertOverlay');
    const bn = document.getElementById('errorAlertBanner');
    if (ov) ov.classList.add('active', 'loop');
    if (bn) bn.classList.add('active', 'loop');
    _updateErrorBannerText(err);
    // 卡片本体也呼吸,提示有"未确认"的循环
    const card = document.getElementById('exceptionCard');
    if (card) card.classList.add('loop');
    // 启动循环核弹音 + 周期语音(_logErrTick 自带守卫,重复调用不叠加)
    if (!_logErrTimer) { _logErrSpokeAt = 0; _logErrTick(); }
}

/* 仅更新顶部通知条文字(不改告警等级) */
function _updateErrorBannerText(err) {
    const title = document.getElementById('errorAlertTitle');
    const sub = document.getElementById('errorAlertSub');
    if (title) {
        const rate = _errorRateWindow.length;
        title.textContent = '无法处理请求数据'
            + (rate > 1 ? ' · 1 分钟内 ' + rate + ' 条' : '');
    }
    if (sub) {
        // 取消息里的关键片段:去掉 [分片N] 前缀,截断到 ~80 字
        let s = String(err.msg).replace(/^\[分片\d+\]\s*/, '');
        if (s.length > 80) s = s.slice(0, 80) + '…';
        sub.textContent = 'HTTP ' + err.code + ' · 分片 #' + err.shard + ' · ' + s;
    }
}

/* 点击"确认"按钮:停止循环 + 解除红闪 + 启动 60s 冷却 */
function dismissErrorAlert() {
    _errorLoopMode = false;
    _errorLoopDismissedAt = Date.now();
    // v16:停掉循环核弹音 + 语音(已调度的最后一批 ≤1.3s 尾音会自然收尾)
    if (_logErrTimer) { clearTimeout(_logErrTimer); _logErrTimer = null; }
    if (_tts) { try { _tts.cancel(); } catch (e) {} }
    const ov = document.getElementById('errorAlertOverlay');
    const bn = document.getElementById('errorAlertBanner');
    if (ov) ov.classList.remove('active', 'loop');
    if (bn) bn.classList.remove('active', 'loop');
    const card = document.getElementById('exceptionCard');
    if (card) card.classList.remove('loop');
    if (_errorOneshotTimer) { clearTimeout(_errorOneshotTimer); _errorOneshotTimer = null; }
}

/* 渲染异常列表 */
function _updateExceptionList() {
    const list = document.getElementById('exceptionList');
    const cnt = document.getElementById('exceptionCount');
    const card = document.getElementById('exceptionCard');
    if (!list) return;
    if (_errorLog.length === 0) {
        list.innerHTML = '<div class="exception-empty">无异常<span class="hint">展开下方「实时运行」后开始监测日志中的 HTTP 403 / 405 / 500</span></div>';
        if (cnt) cnt.textContent = '共 0 条记录';
        if (card) card.classList.remove('has-recent');
        _applyExcCollapse();
        return;
    }
    const lines = _errorLog.map(function (e) {
        const d = new Date((e.ts || 0) * 1000);
        const pad = function (n) { return String(n).padStart(2, '0'); };
        const tm = pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
        // 截短消息,去 [分片N] 前缀
        let msg = String(e.msg).replace(/^\[分片\d+\]\s*/, '');
        if (msg.length > 200) msg = msg.slice(0, 200) + '…';
        // HTML 转义
        msg = msg.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return '<div class="exception-item code-' + e.code + '" title="' + msg.replace(/"/g, '&quot;') + '">'
             +   '<span class="exc-time">' + tm + '</span>'
             +   '<span class="exc-code">' + e.code + '</span>'
             +   '<span class="exc-msg">' + msg + '</span>'
             +   '<span class="exc-shard">#' + e.shard + '</span>'
             + '</div>';
    }).join('');
    list.innerHTML = lines;
    if (cnt) cnt.textContent = '共 ' + _errorLog.length + ' 条记录';
    if (card) card.classList.add('has-recent');
    _applyExcCollapse();
}

/* 运行日志异常面板:收起/展开。有错时自动展开(收起也不隐藏未处理的错误)。 */
let _excManualOpen = false;
function _toggleExcPanel() { _excManualOpen = !_excManualOpen; _applyExcCollapse(); }
function _applyExcCollapse() {
    const has  = (typeof _errorLog !== 'undefined') && _errorLog.length > 0;
    const open = has || _excManualOpen;
    const card = document.getElementById('exceptionCard');
    const dot  = document.getElementById('excDot');
    const st   = document.getElementById('excStatus');
    const ch   = document.getElementById('excChevron');
    const sec  = document.getElementById('excSection');
    if (card) card.style.display = open ? '' : 'none';
    if (dot)  dot.className = 'pm-dot ' + (has ? 'bad' : 'ok');
    if (st)   st.textContent = has ? ('⚠ ' + _errorLog.length + ' 条异常') : '';
    if (ch)   ch.textContent = open ? 'expand_less' : 'expand_more';
    if (sec)  sec.classList.toggle('has-alert', has);
}

/* 更新区块标题处的速率徽章 */
function _updateExceptionRate() {
    const badge = document.getElementById('excRateBadge');
    if (!badge) return;
    const rate = _errorRateWindow.length;
    badge.textContent = '最近 1 分钟 ' + rate + ' 条';
    badge.classList.remove('warn', 'crit');
    if (rate > ERROR_RATE_THRESHOLD) badge.classList.add('crit');
    else if (rate > 5) badge.classList.add('warn');
}

/* 清空异常列表 */
function _clearExceptionList() {
    _errorLog.length = 0;
    _errorRateWindow.length = 0;
    _updateExceptionList();
    _updateExceptionRate();
}

/* 页面加载后:启动 60s 数据刷新 + 初始化权限按钮 UI */
function _initDashboardAddons() {
    startDashAutoRefresh();
    _updateAudioPermUI();
}
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _initDashboardAddons);
} else {
    _initDashboardAddons();
}

/* =========================================================
 * 支付回调掉单监控 + 循环告警 (2026-07)
 *   数据源 notify_log:每次易支付回调落一行。
 *   异常 = 未处理 + 从未成功 + 有验签通过的失败回调(真实掉单风险)。
 *   有异常 → 顶部红条 + 循环 b.wav(复用异常告警音),直到逐单/一键处理清零。
 *   全局轮询(不限于 dashboard tab),保证人在任何页面都能收到告警。
 * ========================================================= */
let _payAlertTimer  = null;
let _payLoopMode    = false;
let _paySnoozeUntil = 0;          // 静音截止(ms 时间戳);静音期内只压声音,红条保留
const PAY_POLL_MS   = 30000;      // 30s 轮询一次

function _payEsc(s){ return String(s==null?'':s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function _payPrettyJson(s){ try { return JSON.stringify(JSON.parse(s), null, 2); } catch(e){ return s||''; } }
function _toggleNaRaw(id){ const el=document.getElementById(id); if(el) el.style.display = (el.style.display==='none'?'table-row':'none'); }

async function _refreshNotifyAnomalies() {
    const data = await adminApi('notify_log.anomalies');
    if (!data) return;                       // 网络/接口异常时不误清告警
    const rows = data.rows || [];
    _renderNotifyPanel(rows);
    _syncPayAlarm(parseInt(data.count, 10) || 0, rows);
}

function _renderNotifyPanel(rows) {
    const wrap = document.getElementById('notifyAnomalyBody');
    const cnt  = document.getElementById('notifyAnomalyCount');
    const card = document.getElementById('notifyAlertCard');
    const dot  = document.getElementById('pmDot');
    const rall = document.getElementById('pmResolveAll');
    const hasAlert = rows.length > 0;

    if (card) card.classList.toggle('has-alert', hasAlert);
    if (dot)  dot.className = 'pm-dot ' + (hasAlert ? 'bad' : 'ok');
    if (rall) rall.style.display = hasAlert ? '' : 'none';
    if (cnt)  cnt.textContent = hasAlert ? ('⚠ ' + rows.length + ' 笔可能掉单') : '';
    if (!wrap) return;

    // 无异常:收起异常区(只留顶部状态条 + 对账入口)
    if (!hasAlert) { wrap.style.display = 'none'; wrap.innerHTML = ''; return; }
    wrap.style.display = '';

    const pad = n => String(n).padStart(2, '0');
    const body = rows.map(function (r, i) {
        const d  = new Date((r.last_ts || 0) * 1000);
        const tm = (d.getMonth()+1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
        const rawId = 'naRaw' + i;
        const reason = _payEsc(r.last_reason || '-')
            + (r.stage ? '<span class="na-stage">' + _payEsc(r.stage) + '</span>' : '');
        return ''
          + '<tr>'
          +   '<td class="na-oid">' + _payEsc(r.out_trade_no) + '</td>'
          +   '<td>' + _payEsc(r.order_type || '-') + '</td>'
          +   '<td>¥' + _payEsc(r.amount || '-') + '</td>'
          +   '<td>' + _payEsc(r.username || '-') + '</td>'
          +   '<td><span class="na-badge">' + (r.callbacks|0) + ' 次</span></td>'
          +   '<td><span class="na-status">' + _payEsc(r.order_status || '?') + '</span></td>'
          +   '<td class="na-reason r-fail">' + reason + '</td>'
          +   '<td class="na-time">' + tm + '</td>'
          +   '<td class="na-ops">'
          +     '<button onclick="_toggleNaRaw(\'' + rawId + '\')">原始</button>'
          +     '<button class="na-resolve" onclick="_resolveNotify(\'' + _payEsc(r.out_trade_no) + '\')">标记已处理</button>'
          +   '</td>'
          + '</tr>'
          + '<tr class="na-rawrow" id="' + rawId + '" style="display:none;">'
          +   '<td colspan="9"><pre>' + _payEsc(_payPrettyJson(r.raw)) + '</pre></td>'
          + '</tr>';
    }).join('');

    wrap.innerHTML =
        '<table class="na-table"><thead><tr>'
      + '<th>订单号</th><th>类型</th><th>金额</th><th>用户</th><th>回调次数</th>'
      + '<th>当前状态</th><th>最近失败原因</th><th>最近时间</th><th>操作</th>'
      + '</tr></thead><tbody>' + body + '</tbody></table>';
}

async function _resolveNotify(oid) {
    const r = await adminApi('notify_log.resolve', { out_trade_no: oid });
    if (r) { showToast('已标记处理', 'success'); _refreshNotifyAnomalies(); }
}
async function resolveAllNotify() {
    if (!confirm('确认把当前所有回调异常标记为「已处理」?\n这会停止告警声 —— 请确保你已逐单核实/补单,否则可能漏掉真实掉单。')) return;
    const r = await adminApi('notify_log.resolve_all');
    if (r) { showToast('已全部标记处理', 'success'); _refreshNotifyAnomalies(); }
}

/* 同步告警:count>0 → 顶部红条(v16 起不出声);=0 → 全部解除 */
function _syncPayAlarm(count, rows) {
    const banner  = document.getElementById('payAlertBanner');
    const overlay = document.getElementById('payAlertOverlay');
    const sub     = document.getElementById('payAlertSub');
    if (count > 0) {
        if (banner)  banner.classList.add('active');
        if (overlay) overlay.classList.add('active');
        if (sub) {
            const top = rows[0];
            sub.textContent = count + ' 笔已收款但未成功发货'
                + (top ? ' · 最新 ' + top.out_trade_no + '(回调 ' + (top.callbacks|0) + ' 次)' : '');
        }
        _startPayLoop();
    } else {
        _stopPayLoop(true);
    }
}
function _startPayLoop() {
    _payLoopMode = true;
    // v16:按要求音频只保留 a.mp3;掉单告警不再用 b.wav,仅保留顶部红条视觉提示。
    // (如需给掉单也配上合成音 / 语音,告诉我即可复用本引擎)
}
function _stopPayLoop(clearVisual) {
    _payLoopMode = false;
    if (clearVisual) {
        const banner  = document.getElementById('payAlertBanner');
        const overlay = document.getElementById('payAlertOverlay');
        if (banner)  banner.classList.remove('active');
        if (overlay) overlay.classList.remove('active');
    }
}
/* 静音 5 分钟:压住声音,红条保留;处理清零后告警彻底消失 */
function snoozePayAlarm() {
    _paySnoozeUntil = Date.now() + 5 * 60000;
    _stopPayLoop(false);
    showToast('已静音 5 分钟(红条保留,处理清零后自动消失)', 'info');
}

function _startPayPoller() {
    _refreshNotifyAnomalies();
    if (_payAlertTimer) clearInterval(_payAlertTimer);
    _payAlertTimer = setInterval(_refreshNotifyAnomalies, PAY_POLL_MS);
}
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _startPayPoller);
} else {
    _startPayPoller();
}

/* =========================================================
 * 回调流水(全部 · 自动刷新 · 分页 10/页) (2026-07)
 *   显示每一笔回调(success/fail/duplicate),最新在前。
 *   第 1 页 = 实时跟随(每 10 秒自动刷);翻到第 2 页起自动暂停,
 *   回到第 1 页恢复。展开某条原始报文时,这一拍不刷,免得打断查看。
 *   仅在「系统概览」可见时轮询,省 DB。
 * ========================================================= */
let _nsPage  = 1;
let _nsSize  = 10;
let _nsTotal = 0;
let _nsTimer = null;
let _reconOpen = false;          // 对账(全部流水)面板是否展开 —— 展开后才轮询
const NS_POLL_MS = 10000;

/* 展开/收起对账面板:展开时才加载 + 开始实时跟随,收起即停止占用 */
function _toggleRecon() {
    _reconOpen = !_reconOpen;
    const wrap = document.getElementById('notifyStreamWrap');
    const btn  = document.getElementById('pmReconToggle');
    if (wrap) wrap.style.display = _reconOpen ? '' : 'none';
    if (btn)  btn.classList.toggle('active', _reconOpen);
    if (_reconOpen) { _nsReload(1); }
    else { _nsUpdateLive(); }
}

async function _nsReload(page) {
    page = Math.max(1, page | 0);
    const sel = document.getElementById('nsFilter');
    const filter = (sel && sel.value) ? sel.value : 'all';
    const data = await adminApi('notify_log.recent', { page: page, size: _nsSize, filter: filter });
    if (!data) return;                       // 网络异常时保持当前显示
    _nsPage  = parseInt(data.page, 10) || page;
    _nsTotal = parseInt(data.total, 10) || 0;
    _nsRender(data.rows || []);
    _nsUpdateLive();
}

function _nsRender(rows) {
    const body  = document.getElementById('nsBody');
    const pager = document.getElementById('nsPager');
    const meta  = document.getElementById('nsMeta');
    if (!body) return;

    if (rows.length === 0) {
        body.innerHTML = '<div class="na-empty"><span class="material-symbols-rounded">inbox</span> 暂无回调记录</div>';
    } else {
        const pad = n => String(n).padStart(2, '0');
        const tagOf = function (res) {
            const m = { success: ['成功','ns-ok'], fail: ['失败','ns-fail'], duplicate: ['重复','ns-dup'] };
            const x = m[res] || [res || '?', 'ns-dup'];
            return '<span class="ns-tag ' + x[1] + '">' + x[0] + '</span>';
        };
        const tr = rows.map(function (r, i) {
            const d  = new Date((r.created_at || 0) * 1000);
            const tm = (d.getMonth()+1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
            const rawId = 'nsRaw' + i;
            const signBad = !(r.sign_ok == 1 || r.sign_ok === true)
                ? '<span class="ns-nosign" title="验签未通过(疑似探测/伪造)">验签✗</span>' : '';
            const rcls = ({ success:'r-ok', fail:'r-fail', duplicate:'r-dup' })[r.result] || '';
            const reason = _payEsc(r.reason || '')
                + (r.stage ? '<span class="na-stage">' + _payEsc(r.stage) + '</span>' : '');
            return ''
              + '<tr class="ns-row ' + (r.result === 'fail' ? 'is-fail' : '') + '">'
              +   '<td class="na-time">' + tm + '</td>'
              +   '<td class="na-oid">' + _payEsc(r.out_trade_no || '-') + '</td>'
              +   '<td>' + _payEsc(r.order_type || '-') + '</td>'
              +   '<td>' + (r.amount ? ('¥' + _payEsc(r.amount)) : '-') + '</td>'
              +   '<td>' + _payEsc(r.username || '-') + '</td>'
              +   '<td>第 ' + (r.attempt_no | 0) + ' 次</td>'
              +   '<td>' + tagOf(r.result) + ' ' + signBad + '</td>'
              +   '<td class="na-reason ' + rcls + '">' + (reason || '-') + '</td>'
              +   '<td class="na-ops"><button onclick="_toggleNaRaw(\'' + rawId + '\')">原始</button></td>'
              + '</tr>'
              + '<tr class="na-rawrow" id="' + rawId + '" style="display:none;">'
              +   '<td colspan="9"><pre>' + _payEsc(_payPrettyJson(r.raw)) + '</pre></td>'
              + '</tr>';
        }).join('');
        body.innerHTML =
            '<table class="na-table ns-table"><thead><tr>'
          + '<th>时间</th><th>订单号</th><th>类型</th><th>金额</th><th>用户</th><th>回调</th><th>结果</th><th>原因/阶段</th><th>操作</th>'
          + '</tr></thead><tbody>' + tr + '</tbody></table>';
    }

    const pages = Math.max(1, Math.ceil(_nsTotal / _nsSize));
    if (_nsPage > pages) _nsPage = pages;
    if (pager) {
        pager.innerHTML = ''
          + '<button class="ns-pg" ' + (_nsPage <= 1 ? 'disabled' : '') + ' onclick="_nsReload(1)">⏮ 最新</button>'
          + '<button class="ns-pg" ' + (_nsPage <= 1 ? 'disabled' : '') + ' onclick="_nsReload(' + (_nsPage - 1) + ')">上一页</button>'
          + '<span class="ns-pgnum">第 ' + _nsPage + ' / ' + pages + ' 页</span>'
          + '<button class="ns-pg" ' + (_nsPage >= pages ? 'disabled' : '') + ' onclick="_nsReload(' + (_nsPage + 1) + ')">下一页</button>'
          + '<button class="ns-pg" ' + (_nsPage >= pages ? 'disabled' : '') + ' onclick="_nsReload(' + pages + ')">末页 ⏭</button>';
    }
    if (meta) meta.textContent = '共 ' + _nsTotal + ' 条 · 每页 ' + _nsSize + ' 条';
}

function _nsUpdateLive() {
    const live = document.getElementById('nsLive');
    if (!live) return;
    if (_nsPage === 1) {
        live.className = 'ns-live on';
        live.textContent = '● 实时跟随 · 每 ' + (NS_POLL_MS / 1000) + ' 秒';
    } else {
        live.className = 'ns-live off';
        live.textContent = '⏸ 已暂停(第 ' + _nsPage + ' 页 · 回最新页恢复)';
    }
}

function _nsAutoTick() {
    if (!_reconOpen) return;                                  // 对账面板没展开,不轮询(省 DB)
    const t = document.getElementById('tab-dashboard');
    if (!t || !t.classList.contains('active')) return;       // 只在概览页刷
    if (_nsPage !== 1) { _nsUpdateLive(); return; }           // 浏览历史页不自动刷
    const body = document.getElementById('nsBody');
    if (body && body.querySelector('.na-rawrow[style*="table-row"]')) return; // 正在看原始报文,先不刷
    _nsReload(1);
}

function _startNsPoller() {
    if (_nsTimer) clearInterval(_nsTimer);
    _nsTimer = setInterval(_nsAutoTick, NS_POLL_MS);
}
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _startNsPoller);
} else {
    _startNsPoller();
}

/* ============ 实时运行 · 监控 ============ */
let _rtTimer = null;
let _rtStars = {};        // wid -> {el, stage, doneTimer}
let _rtLogTs = 0;

/* 折叠 / 展开 */
function toggleRtMonitor() {
    const box = document.getElementById('rtMonitor');
    if (!box) return;
    box.classList.toggle('collapsed');
    if (box.classList.contains('collapsed')) {
        stopRtMonitor();                       // 收起 → 停轮询
        const age = document.getElementById('rtAge');
        if (age) age.textContent = '点击展开';
    } else {
        startRtMonitor();                      // 展开 → 开始轮询
    }
}

/* 把 main.py 上报的真实 stage 映射成 4 类工作状态。
   worker 永远在干活 —— 没有「等待 / 排队」（那是延迟队列的事）。
   真实 stage 取值：dequeued / fetch_send_config / query_user /
   image_decrypt / image_analyze / voice_decrypt / voice_transcribe /
   llm_thinking / sending_wx / tool:xxx */
function _rtStageInfo(stage) {
    const s = (stage || '').toLowerCase();
    // 工具调用
    if (s.startsWith('tool:'))
        return { cls: 's-tool',  name: '调用工具 · ' + stage.slice(5) };
    if (s.includes('tool') || s.includes('工具'))
        return { cls: 's-tool',  name: '调用工具' };
    // LLM 思考
    if (s.includes('think') || s.includes('思考') || s.includes('推理') || s.includes('llm'))
        return { cls: 's-think', name: 'LLM 思考中' };
    // 图片 / 语音处理 → 也算工具类
    if (s.includes('image'))
        return { cls: 's-tool',  name: s.includes('analyze') ? '图片识别' : '图片解密' };
    if (s.includes('voice'))
        return { cls: 's-tool',  name: s.includes('transcribe') ? '语音转写' : '语音解密' };
    // 发送至微信
    if (s.includes('send') || s.includes('发送') || s.includes('wx'))
        return { cls: 's-send',  name: '发送至微信' };
    // 准备阶段：出队 / 查配置 / 查 user
    if (s.includes('dequeu') || s.includes('出队'))
        return { cls: 's-prep', name: '出队处理' };
    if (s.includes('config') || s.includes('配置'))
        return { cls: 's-prep', name: '读取配置' };
    if (s.includes('user') || s.includes('query'))
        return { cls: 's-prep', name: '查询用户' };
    // 其它准备类
    return { cls: 's-prep', name: stage || '处理中' };
}

function _rtSetMetric(id, val, level, sub) {
    const box = document.getElementById(id);
    if (!box) return;
    const vEl = box.querySelector('.rt-metric-val');
    if (vEl.textContent !== String(val)) {
        vEl.textContent = val;
        box.classList.remove('flash'); void box.offsetWidth; box.classList.add('flash');
    }
    box.classList.remove('ok', 'warn', 'crit');
    if (level) box.classList.add(level);
    if (sub !== undefined) {
        const lbl = box.querySelector('.rt-metric-label');
        if (lbl && lbl.dataset.base === undefined) lbl.dataset.base = lbl.textContent;
        if (lbl) lbl.textContent = sub || lbl.dataset.base;
    }
}

async function startRtMonitor() {
    stopRtMonitor();
    await loadRtMonitor();
}
function stopRtMonitor() {
    if (_rtTimer) { clearTimeout(_rtTimer); _rtTimer = null; }
}

async function loadRtMonitor() {
    const data = await adminApi('monitor.snapshot');
    const pulse = document.getElementById('rtPulse');
    const ageEl = document.getElementById('rtAge');
    if (!data) { if (pulse) pulse.style.background = '#f87171'; _evalConnHealth(false, 999); _rtTimer = setTimeout(loadRtMonitor, 1000); return; }

    if (!data.available) {
        if (pulse) pulse.style.background = '#f87171';
        if (ageEl) ageEl.textContent = 'main.py 未上报';
        _rtSetMetric('rtmSnapshot', '离线', 'crit');
        _evalConnHealth(false, 999);
        // 分片进程数即使主进程没写快照也能数到
        _rtFillShard(data);
        Object.values(_rtStars).forEach(o => {
            if (o.doneTimer) clearTimeout(o.doneTimer);
            o.el.remove();
        });
        _rtStars = {};
        const empty = document.getElementById('rtWkEmpty');
        if (empty) empty.style.display = 'block';
        const cnt = document.getElementById('rtWkCount');
        if (cnt) cnt.textContent = '';
        _renderShards([]);
    } else {
        if (pulse) pulse.style.background = (data.snapshot_age >= 5) ? '#fbbf24' : '#22c55e';
        const age = data.snapshot_age || 0;
        if (ageEl) ageEl.textContent = '更新于 ' + age + 's 前';
        _evalConnHealth(true, age);

        // ── 盖板核心指标 ──
        _rtSetMetric('rtmSnapshot', age + 's',
            age >= 5 ? 'crit' : (age >= 3 ? 'warn' : 'ok'));

        // 延迟队列：只要有积压就直接标红（队列里有东西本就不该是常态）
        const q = data.queue_size || 0;
        _rtSetMetric('rtmQueue', q, q > 0 ? 'crit' : 'ok');

        const aw = data.active_workers || 0, tw = data.total_workers || 0;
        const wPct = tw > 0 ? Math.round(aw / tw * 100) : 0;
        _rtSetMetric('rtmWorker', aw + ' / ' + tw,
            wPct > 90 ? 'crit' : (wPct > 70 ? 'warn' : null), '活跃 Worker · ' + wPct + '%');

        const m = data.mysql || {};
        const mNow = m.now || 0, mMax = m.max || 0;
        const mPct = mMax > 0 ? Math.round(mNow / mMax * 100) : 0;
        _rtSetMetric('rtmMysql', mNow + ' / ' + mMax,
            mPct > 90 ? 'crit' : (mPct > 75 ? 'warn' : null));

        _rtSetMetric('rtmPool', (data.pool_used || 0) + ' / ' + (data.pool_size || 0));

        const pf = data.pending_failed || 0;
        _rtSetMetric('rtmFailed', pf, pf > 0 ? 'crit' : 'ok');

        _rtFillShard(data);

        _renderWorkers(Array.isArray(data.workers) ? data.workers : []);
        _renderShards(Array.isArray(data.shards) ? data.shards : []);
        _renderRtLog(Array.isArray(data.logs) ? data.logs : []);
    }

    _rtTimer = setTimeout(loadRtMonitor, 1000);
}

/* 渲染分片进程明细:v15.0 — 用状态徽章代替左侧颜色条 */
function _renderShards(shards) {
    const box = document.getElementById('rtShards');
    const cntEl = document.getElementById('rtShardCount');
    if (!box) return;

    // 记下当前分片列表 → 给日志筛选 chips 用
    window._rtLastShards = shards || [];
    _updateLogShardChips(window._rtLastShards);

    if (cntEl) cntEl.textContent = shards.length ? (' · ' + shards.length + ' 个进程') : '';
    if (!shards.length) {
        box.innerHTML = '<div class="rt-worker-empty">暂无分片数据</div>';
        return;
    }
    box.innerHTML = shards.map(function (s) {
        const idx     = s.shard_index != null ? s.shard_index : '?';
        const age     = s.snapshot_age || 0;
        const workers = Array.isArray(s.workers) ? s.workers : [];
        const aw      = s.active_workers || 0;
        const tw      = s.total_workers || 0;
        const q       = s.queue_size || 0;
        const pf      = s.pending_failed || 0;
        // 该分片 worker 平均已耗时(ms) → 粗略反映回复速度
        let avgMs = 0;
        if (workers.length) {
            let sum = 0;
            workers.forEach(function (w) { sum += (w.ms || 0); });
            avgMs = Math.round(sum / workers.length);
        }
        const avgSec = (avgMs / 1000).toFixed(1);
        // 卡片状态:快照超 5s 偏滞后,超 15s 判离线
        let cls = 'rt-shard-card';
        let badgeText = '在线';
        if (age >= 15) { cls += ' off'; badgeText = '离线'; }
        else if (age >= 5) { cls += ' stale'; badgeText = '滞后'; }
        // 平均耗时颜色:>30s 黄,>50s 红
        let avgCls = 'v';
        if (avgMs > 50000) avgCls = 'v crit';
        else if (avgMs > 30000) avgCls = 'v busy';
        const qCls = q > 0 ? 'v crit' : 'v';
        const mainMark = (idx === 0) ? '<span class="main-mark">主</span>' : '';
        return '<div class="' + cls + '">'
            + '<div class="rt-shard-head">'
            +   '<span class="rt-shard-name">分片 #' + idx + mainMark
            +     '<span class="shard-tag">' + badgeText + '</span></span>'
            +   '<span class="rt-shard-age">' + age + 's 前</span>'
            + '</div>'
            + '<div class="rt-shard-grid">'
            +   '<div class="rt-shard-kv"><span class="k">活跃 W</span>'
            +     '<span class="v">' + aw + '/' + tw + '</span></div>'
            +   '<div class="rt-shard-kv"><span class="k">运行中</span>'
            +     '<span class="v">' + workers.length + '</span></div>'
            +   '<div class="rt-shard-kv"><span class="k">队列</span>'
            +     '<span class="' + qCls + '">' + q + '</span></div>'
            +   '<div class="rt-shard-kv"><span class="k">失败重试</span>'
            +     '<span class="' + (pf > 0 ? 'v crit' : 'v') + '">' + pf + '</span></div>'
            +   '<div class="rt-shard-kv"><span class="k">平均耗时</span>'
            +     '<span class="' + avgCls + '">' + avgSec + 's</span></div>'
            + '</div>'
            + '</div>';
    }).join('');
}

/* 分片进程指标:仅更新顶部指标小卡 */
function _rtFillShard(data) {
    const cnt = (data && data.shard_count) ? data.shard_count : 0;
    if (cnt > 0) {
        _rtSetMetric('rtmShard', cnt + ' 个', 'ok');
    } else {
        _rtSetMetric('rtmShard', '--', 'warn');
    }
}

function _renderWorkers(workers) {
    const grid  = document.getElementById('rtWorkers');
    const empty = document.getElementById('rtWkEmpty');
    const cntEl = document.getElementById('rtWkCount');
    if (!grid) return;

    const seen = {};

    workers.forEach(wk => {
        // 多进程:worker 编号在每个分片内从 1 起,会跨分片重复。
        // 用 "分片:wid" 作为唯一 key,并在卡片上标出分片号。
        const sh   = (wk.shard != null) ? wk.shard : 0;
        const wid  = String(wk.wid);
        const ukey = sh + ':' + wid;
        seen[ukey] = true;
        const info = _rtStageInfo(wk.stage);
        let card = _rtStars[ukey];

        if (!card) {
            // 新 worker → 一张整齐卡片
            const el = document.createElement('div');
            el.className = 'rt-wk ' + info.cls;
            el.innerHTML =
                '<div class="rt-wk-dot"></div>' +
                '<div class="rt-wk-main">' +
                  '<div class="rt-wk-id">#' + escHtml(String(sh)) +
                    ' · W' + escHtml(wid) +
                    (wk.pro ? ' · 主动' : '') + '</div>' +
                  '<div class="rt-wk-stage"></div>' +
                '</div>' +
                '<div class="rt-wk-ms"></div>';
            grid.appendChild(el);
            card = _rtStars[ukey] = { el: el, doneTimer: null };
        }
        // worker 仍在干活 → 取消"完成停留"计时
        if (card.doneTimer) { clearTimeout(card.doneTimer); card.doneTimer = null; }

        card.el.className = 'rt-wk ' + info.cls;
        const stEl = card.el.querySelector('.rt-wk-stage');
        if (stEl && stEl.textContent !== info.name) stEl.textContent = info.name;
        const msEl = card.el.querySelector('.rt-wk-ms');
        if (msEl) msEl.textContent = (wk.ms != null) ? _msFmt(wk.ms) : '';
    });

    // 消失的 worker → 转「回复完成」绿色停留 2 秒再淡出移除
    // 注:_rtStars 的 key 是 "分片:wid",seen 同样用该 key,逻辑一致。
    Object.keys(_rtStars).forEach(ukey => {
        if (!seen[ukey]) {
            const o = _rtStars[ukey];
            if (o.doneTimer) return;
            o.el.className = 'rt-wk s-done';
            const stEl = o.el.querySelector('.rt-wk-stage');
            if (stEl) stEl.textContent = '回复完成';
            const msEl = o.el.querySelector('.rt-wk-ms');
            if (msEl) msEl.textContent = '✓';
            o.doneTimer = setTimeout(() => {
                o.el.classList.add('leaving');
                setTimeout(() => o.el.remove(), 400);
                delete _rtStars[ukey];
            }, 2000);
        }
    });

    // 空态 + 计数
    const liveCount = Object.keys(_rtStars).length;
    if (empty) empty.style.display = liveCount === 0 ? 'block' : 'none';
    if (cntEl) cntEl.textContent = liveCount > 0 ? ('· ' + workers.length + ' 个运行中') : '';
}

/* v15.0 ─────────────────────────────────────────────────
 * 命令行日志:支持按分片筛选(全部 / 单个 / 多个)
 * 实现:
 *  - 每条 log line 写 data-shard 属性
 *  - 筛选用 CSS class rt-log-hidden 隐藏(不重渲染,性能好)
 *  - 顶部 chips 多选切换;空集自动回 "全部"
 * ─────────────────────────────────────────────────────── */
let _rtShardFilter = new Set(['all']);

function _renderRtLog(logs) {
    const box = document.getElementById('monLogBox');
    if (!box) return;
    const auto = document.getElementById('monAutoScroll');
    const follow = !auto || auto.checked;
    const fresh = logs.filter(l => (l.ts || 0) > _rtLogTs);
    if (fresh.length > 0) {
        if (_rtLogTs === 0) {
            // 首次渲染:不对历史日志触发告警,只渲染
            box.innerHTML = logs.map(_logLineHtml).join('');
        } else {
            // 增量:渲染 + 错误扫描
            box.insertAdjacentHTML('beforeend', fresh.map(_logLineHtml).join(''));
            // v15.3:对每条新日志扫描 HTTP 错误码
            for (let i = 0; i < fresh.length; i++) _scanLogForErrors(fresh[i]);
        }
        _rtLogTs = fresh[fresh.length - 1].ts;
        while (box.children.length > 800) box.removeChild(box.firstChild);
        _applyLogFilter();           // 新增行也要应用筛选
        if (follow) box.scrollTop = box.scrollHeight;
    }
    _updateLogCount();
}

/* 收集已渲染日志中每个分片的行数,用于 chips 上的计数小标 */
function _collectShardCounts() {
    const box = document.getElementById('monLogBox');
    if (!box) return {};
    const counts = {};
    box.querySelectorAll('[data-shard]').forEach(el => {
        const s = el.getAttribute('data-shard');
        counts[s] = (counts[s] || 0) + 1;
    });
    return counts;
}

/* 重渲染 chips,根据当前 shards 列表 + 行数计数 */
function _updateLogShardChips(shards) {
    const wrap = document.getElementById('rtLogFilter');
    if (!wrap) return;
    const counts = _collectShardCounts();
    const indices = (shards || []).map(s => s.shard_index)
        .filter(v => v != null).sort((a, b) => a - b);

    let html = '<span class="rt-log-filter-label">显示分片</span>';
    const allActive = _rtShardFilter.has('all');
    html += `<button class="rt-log-chip ${allActive ? 'active' : ''}" data-shard="all" onclick="toggleLogShard('all')">全部</button>`;
    indices.forEach(i => {
        const key = String(i);
        const active = _rtShardFilter.has(key);
        const count = counts[key] || 0;
        const tag = i === 0 ? '#' + i + ' 主' : '#' + i;
        html += `<button class="rt-log-chip ${active ? 'active' : ''}" data-shard="${key}" onclick="toggleLogShard('${key}')">${tag}${count ? `<span class="chip-count">${count}</span>` : ''}</button>`;
    });
    wrap.innerHTML = html;
}

/* 点击 chip:切换某分片的可见性。"全部"互斥;空集回 "全部"。 */
function toggleLogShard(s) {
    if (s === 'all') {
        _rtShardFilter = new Set(['all']);
    } else {
        if (_rtShardFilter.has('all')) _rtShardFilter = new Set();
        if (_rtShardFilter.has(s)) _rtShardFilter.delete(s);
        else _rtShardFilter.add(s);
        if (_rtShardFilter.size === 0) _rtShardFilter = new Set(['all']);
    }
    _applyLogFilter();
    _updateLogCount();
    if (window._rtLastShards) _updateLogShardChips(window._rtLastShards);
}

/* 把当前过滤集合应用到日志框 */
function _applyLogFilter() {
    const box = document.getElementById('monLogBox');
    if (!box) return;
    const showAll = _rtShardFilter.has('all');
    box.querySelectorAll('[data-shard]').forEach(el => {
        if (showAll) {
            el.classList.remove('rt-log-hidden');
        } else {
            const s = el.getAttribute('data-shard');
            if (_rtShardFilter.has(s)) el.classList.remove('rt-log-hidden');
            else el.classList.add('rt-log-hidden');
        }
    });
}

/* 更新日志计数文字(可见/总数) */
function _updateLogCount() {
    const box = document.getElementById('monLogBox');
    const cnt = document.getElementById('monLogCount');
    if (!box || !cnt) return;
    const total = box.children.length;
    if (_rtShardFilter.has('all')) {
        cnt.textContent = total + ' 行';
    } else {
        const visible = box.querySelectorAll('[data-shard]:not(.rt-log-hidden)').length;
        cnt.textContent = visible + ' / ' + total + ' 行';
    }
}

/* v13.12 (2026-05-14) 系统监控小卡 ─────────────────────────────────
   占地小,5 个挤一行,移动端 2-3 列;字号小,确保整页不滚动。 */
async function loadSystemStatus() {
    const box = document.getElementById('sysStatusGrid');
    if (!box) return;
    const s = await adminApi('system.status');
    if (!s) {
        box.innerHTML = '<div class="sys-card err">系统状态读取失败</div>';
        return;
    }
    const workerCell = s.workers !== null
        ? `<span class="sv">${s.workers}</span>`
        : `<span class="sv muted">—</span>`;
    const workerHint = s.workers_err ? `<span class="sh err">${s.workers_err}</span>` : `<span class="sh">main.py 进程</span>`;

    const memBar = s.mem_used_pct !== null
        ? `<div class="sys-bar"><span style="width:${s.mem_used_pct}%"></span></div>`
        : '';

    box.innerHTML = `
        <div class="sys-card">
            <div class="sl">Worker</div>
            ${workerCell}
            ${workerHint}
        </div>
        <div class="sys-card">
            <div class="sl">MySQL 连接</div>
            <span class="sv">${s.mysql_connections ?? '—'}</span>
            <span class="sh">运行中 ${s.mysql_running ?? '—'}</span>
        </div>
        <div class="sys-card">
            <div class="sl">实例在线</div>
            <span class="sv">${s.instances_active}</span>
            <span class="sh">来自 instances 表</span>
        </div>
        <div class="sys-card">
            <div class="sl">系统负载</div>
            <span class="sv">${s.load1 ?? '—'}</span>
            <span class="sh">5m ${s.load5 ?? '—'} · 15m ${s.load15 ?? '—'}</span>
        </div>
        <div class="sys-card">
            <div class="sl">内存使用</div>
            <span class="sv">${s.mem_used_pct !== null ? s.mem_used_pct + '%' : '—'}</span>
            ${memBar}
            <span class="sh">${s.mem_total_mb ? (s.mem_avail_mb + ' / ' + s.mem_total_mb + ' MB 可用') : '不可读'}</span>
        </div>
    `;
}

/* =========================================================
 * v13.12 (2026-05-14) 版本日志管理
 * ========================================================= */
async function loadVersions() {
    const tb = document.getElementById('versionsTbody');
    if (!tb) return;
    const data = await adminApi('versions.list');
    if (!data || !data.items || data.items.length === 0) {
        tb.innerHTML = '<tr><td colspan="5" class="empty-hint">还没有版本日志</td></tr>';
        return;
    }
    tb.innerHTML = data.items.map(v => `
        <tr>
            <td><strong>${escHtml(v.version)}</strong></td>
            <td>${escHtml(v.released_at)}</td>
            <td>${escHtml(v.title)}</td>
            <td>${v.is_published == 1
                ? '<span style="color:#059669;font-weight:600;">已发布</span>'
                : '<span style="color:#999;">草稿</span>'}</td>
            <td>
                <button class="btn-mini" onclick='openVersionEditor(${JSON.stringify(v)})'>编辑</button>
                <button class="btn-mini" style="color:#dc2626;border-color:#fecaca;" onclick="deleteVersion(${v.id})">删除</button>
            </td>
        </tr>
    `).join('');
}

function openVersionEditor(v) {
    const isNew = !v || !v.id;
    document.getElementById('versionModalTitle').textContent = isNew ? '新增版本' : '编辑版本 #' + v.id;
    document.getElementById('verEditId').value     = isNew ? '' : v.id;
    document.getElementById('verVersion').value    = isNew ? '' : (v.version || '');
    document.getElementById('verReleased').value   = isNew ? new Date().toISOString().slice(0,10) : (v.released_at || '');
    document.getElementById('verTitle').value      = isNew ? '' : (v.title || '');
    document.getElementById('verContent').value    = isNew ? '' : (v.content || '');
    document.getElementById('verSortOrder').value  = isNew ? 0 : (v.sort_order || 0);
    document.getElementById('verPublished').value  = isNew ? '1' : String(v.is_published);
    openModal('versionModal');
}

async function saveVersion() {
    const id = parseInt(document.getElementById('verEditId').value || '0', 10);
    const payload = {
        id: id,
        version:      document.getElementById('verVersion').value.trim(),
        released_at:  document.getElementById('verReleased').value.trim(),
        title:        document.getElementById('verTitle').value.trim(),
        content:      document.getElementById('verContent').value,
        sort_order:   parseInt(document.getElementById('verSortOrder').value || '0', 10),
        is_published: parseInt(document.getElementById('verPublished').value, 10),
    };
    if (!payload.version || !payload.title) {
        showToast('版本号和标题必填', 'error');
        return;
    }
    const r = await adminApi('versions.save', payload);
    if (r) {
        showToast(id ? '已更新' : '已新增', 'success');
        closeModal('versionModal');
        loadVersions();
    }
}

async function deleteVersion(id) {
    if (!confirm('确定删除该版本日志?(不可恢复)')) return;
    const r = await adminApi('versions.delete', { id });
    if (r) {
        showToast('已删除', 'success');
        loadVersions();
    }
}

// 折线图/柱状图绘制(共用) — 全局 Chart 实例缓存防止重复 mount 报错
window._dashCharts = window._dashCharts || {};
function _drawDashChart(canvasId, color, labels, values, tooltipFmt, opts) {
    opts = opts || {};
    const chartType = opts.type || 'line';
    if (typeof Chart === 'undefined') {
        // Chart.js 未加载(CDN 失败)— 安静降级,不阻塞别的
        console.warn('[dashboard] Chart.js 未加载,跳过', canvasId);
        return;
    }
    const cv = document.getElementById(canvasId);
    if (!cv) return;
    if (window._dashCharts[canvasId]) {
        try { window._dashCharts[canvasId].destroy(); } catch (e) {}
    }

    // 柱状图(更适合每日离散收入):末柱(今天)实色,其它半透明
    // 折线图(更适合用户累积增长):梯度填充,圆头节点
    let dataset;
    if (chartType === 'bar') {
        const bgs = values.map((_, i) => i === values.length - 1 ? color : color + '4d');
        const borderClrs = values.map((_, i) => i === values.length - 1 ? color : color + '00');
        dataset = {
            data: values,
            backgroundColor: bgs,
            borderColor: borderClrs,
            borderWidth: 0,
            borderRadius: 6,
            barPercentage: 0.62,
            categoryPercentage: 0.85,
            hoverBackgroundColor: color,
        };
    } else {
        dataset = {
            data: values,
            borderColor: color,
            backgroundColor: (ctx) => {
                const c = ctx.chart.ctx;
                const grad = c.createLinearGradient(0, 0, 0, 200);
                grad.addColorStop(0, color + '55');
                grad.addColorStop(1, color + '00');
                return grad;
            },
            fill: true,
            tension: 0.4,
            pointRadius: 3,
            pointHoverRadius: 6,
            pointBackgroundColor: '#fff',
            pointBorderColor: color,
            pointBorderWidth: 2,
            pointHoverBackgroundColor: color,
            pointHoverBorderColor: '#fff',
            pointHoverBorderWidth: 2,
            borderWidth: 2.5,
        };
    }

    window._dashCharts[canvasId] = new Chart(cv, {
        type: chartType,
        data: { labels: labels, datasets: [dataset] },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#0f172a',
                    padding: { top: 8, bottom: 8, left: 12, right: 12 },
                    titleFont: { size: 11, weight: '500' },
                    titleColor: '#cbd5e1',
                    bodyFont: { size: 13, weight: '700' },
                    bodyColor: '#fff',
                    displayColors: false,
                    borderColor: 'rgba(255,255,255,0.08)',
                    borderWidth: 1,
                    cornerRadius: 8,
                    callbacks: {
                        label: (ctx) => tooltipFmt ? tooltipFmt(ctx.parsed.y) : ctx.parsed.y,
                    },
                },
            },
            scales: {
                x: {
                    grid: { display: false, drawBorder: false },
                    border: { display: false },
                    ticks: { font: { size: 10 }, color: '#94a3b8' },
                },
                y: {
                    beginAtZero: true,
                    grid: { color: '#f1f5f9', drawBorder: false },
                    border: { display: false },
                    ticks: { font: { size: 10 }, color: '#94a3b8', precision: 0, maxTicksLimit: 4 },
                },
            },
        },
    });
}

/* =========================================================
 * 用户管理
 * ========================================================= */
let _userPage = 1;
async function loadUsers(page) {
    if (page) _userPage = page;
    const kw = document.getElementById('userKeyword').value.trim();
    const plan = document.getElementById('userPlanFilter').value;
    const data = await adminApi('users.list', { keyword: kw, plan, page: _userPage });
    if (!data) return;

    // 全局缓存 — 让 editUser 按 id 查找,避免 onclick 嵌 JSON 字符串(v20 同模式)
    window._userMap = {};
    data.rows.forEach(u => { window._userMap[u.id] = u; });

    const tbody = document.getElementById('userTableBody');
    if (!data.rows.length) {
        tbody.innerHTML = '<tr><td colspan="10" class="empty-state">暂无数据</td></tr>';
    } else {
        tbody.innerHTML = data.rows.map(u => {
            const plan = u.plan_type || 'free';
            const planTag = `<span class="tag tag-${plan}">${plan.toUpperCase()}</span>`;
            const expDate = u.plan_expired_at ? fmtTs(u.plan_expired_at) : '永久';
            // 封禁状态(后端 users.list 已合并 u.ban)
            const banned = !!(u.ban && u.ban.is_banned);
            const banBadge = banned
                ? `<span class="tag" style="background:#fee2e2;color:#b91c1c;border:1px solid #f87171;margin-left:6px;">已封禁</span>`
                : '';
            const banBtn = banned
                ? `<button class="btn-mini" onclick="openBanModal(${u.id})" title="管理封禁 / 解封" style="background:#fee2e2;color:#b91c1c;border:1px solid #f87171;">已封禁</button>`
                : `<button class="btn-mini" onclick="openBanModal(${u.id})" title="封禁该用户" style="background:#fff7ed;color:#c2410c;border:1px solid #fdba74;">封禁</button>`;
            return `<tr>
                <td>${u.id}</td>
                <td><strong>${escHtml(u.username)}</strong>${banBadge}</td>
                <td style="font-family:monospace;font-size:0.78rem;color:#666;">${escHtml(u.phone||'')}</td>
                <td style="font-size:0.8rem;color:#666;">${escHtml(u.email||'')}</td>
                <td>${planTag}</td>
                <td>¥${Number(u.balance||0).toFixed(2)}</td>
                <td style="font-size:0.78rem;color:#666;">${expDate}</td>
                <td style="font-family:monospace;font-size:0.78rem;">${escHtml(u.invite_code||'')}</td>
                <td>${fmt(u.total_ai_messages)}</td>
                <td>
                    <div class="row-actions">
                        <button class="btn-mini" onclick="editUser(${u.id})">编辑</button>
                        <button class="btn-mini" onclick="viewUserLogs(${u.id})" style="background:#e0f2fe;color:#075985;border:1px solid #38bdf8;">日志</button>
                        ${banBtn}
                    </div>
                </td>
            </tr>`;
        }).join('');
    }
    renderPagination('userPagination', data.total, data.page, data.size, p => loadUsers(p));
}
const debouncedLoadUsers = debounce(() => loadUsers(1), 300);

/* ── 新增用户（2026-06-27）：用户名 + 手机号 + 密码 ───────────────── */
function openCreateUserModal() {
    document.getElementById('cuUsername').value = '';
    document.getElementById('cuPhone').value    = '';
    document.getElementById('cuPassword').value = '';
    const btn = document.getElementById('cuSubmitBtn');
    if (btn) { btn.disabled = false; btn.textContent = '创建用户'; }
    openModal('createUserModal');
    setTimeout(() => { const el = document.getElementById('cuUsername'); if (el) el.focus(); }, 80);
}

async function submitCreateUser() {
    const username = (document.getElementById('cuUsername').value || '').trim();
    const phone    = (document.getElementById('cuPhone').value || '').trim();
    const password = document.getElementById('cuPassword').value || '';
    if (username.length < 2)       return showToast('用户名至少 2 个字符', 'error');
    if (!/^\d{6,20}$/.test(phone)) return showToast('手机号应为 6-20 位数字', 'error');
    if (password.length < 6)       return showToast('密码至少 6 位', 'error');

    const btn = document.getElementById('cuSubmitBtn');
    if (btn) { btn.disabled = true; btn.textContent = '创建中…'; }
    const data = await adminApi('users.create', { username, phone, password });
    if (data === false) {
        if (btn) { btn.disabled = false; btn.textContent = '创建用户'; }
        return;   // adminApi 已弹错误 toast
    }
    showToast('用户创建成功', 'success');
    closeModal('createUserModal');
    loadUsers(1);   // 刷新到第一页(新用户 id 最大,排在最前)
}

function editUser(id) {
    const u = (window._userMap || {})[id];
    if (!u) {
        showToast('未找到该用户,请刷新后重试', 'error');
        return;
    }
    document.getElementById('userEditId').value = u.id;
    document.getElementById('userEditPlan').value = u.plan_type === 'pro' ? 'pro' : 'free';
    document.getElementById('userEditBilling').value = u.billing_mode || 'quota_first';
    document.getElementById('userEditBalance').value = u.balance;
    document.getElementById('userEditExpired').value = u.plan_expired_at ? tsToDatetimeLocal(u.plan_expired_at) : '';
    document.getElementById('userEditBaseWeekly').value  = u.base_weekly_tokens  || 0;
    document.getElementById('userEditBonusWeekly').value = u.bonus_weekly_tokens || 0;
    document.getElementById('userEditWeeklyUsed').value  = u.weekly_used_tokens  || 0;
    document.getElementById('userEditPackTotal').value   = u.pro_pack_total      || 0;
    document.getElementById('userEditPackUsed').value    = u.pro_pack_used       || 0;
    // v12.10 次数包
    document.getElementById('userEditCountTotal').value   = u.count_pack_total      || 0;
    document.getElementById('userEditCountUsed').value    = u.count_pack_used       || 0;
    document.getElementById('userEditCountExpired').value =
        u.count_pack_expired_at ? tsToDatetimeLocal(u.count_pack_expired_at) : '';
    // count_pack_models 后端存的是 JSON 字符串(如 '["m1","m2"]'),展示时保持原样
    document.getElementById('userEditCountModels').value  = u.count_pack_models   || '';
    document.getElementById('userEditInviteCount').value = u.invite_count        || 0;
    document.getElementById('userEditEmail').value       = u.email || '';
    document.getElementById('userEditPhone').value       = u.phone || '';
    // 人工客服身份回填
    var _isSup = (parseInt(u.is_support, 10) === 1);
    document.getElementById('userEditIsSupport').checked  = _isSup;
    document.getElementById('userEditSupportEmail').value = u.support_email || '';
    _syncSupportRow();
    // 论坛头衔
    var _title = u.title || '';
    var _tcolor = u.title_color || '#b04e5c';
    document.getElementById('userEditTitle').value          = _title;
    document.getElementById('userEditTitleColor').value     = _tcolor;
    document.getElementById('userEditTitleColorText').value = _tcolor;
    _syncTitlePreview();
    document.getElementById('userEditNewPwd').value      = '';
    document.getElementById('userEditMeta').textContent =
        `ID: ${u.id} · ${u.username} · 注册于 ${fmtTs(u.created_at)} · 上次刷新周 ${u.last_reset_week || '(未设置)'}`;
    openModal('userModal');
    // v19 多桶:打开弹窗即加载该用户的独立次数包列表
    loadUserCountPacks(u.id);
}

// 头衔预览同步(颜色/文字实时反映到小徽标)
function _syncTitlePreview() {
    var t = (document.getElementById('userEditTitle').value || '').trim() || '头衔';
    var c = (document.getElementById('userEditTitleColorText').value || '#b04e5c').trim() || '#b04e5c';
    var prev = document.getElementById('userEditTitlePreview');
    if (prev) { prev.textContent = t; prev.style.background = c; }
}

/* ────────────────────────────────────────────────────────
 * 用户临时日志查看(2026-05-07 新增)
 * 把这个用户名下所有实例的 temp_log 一次拉过来,
 * 在弹窗里以 tab/折叠形式展示
 * ──────────────────────────────────────────────────────── */
async function viewUserLogs(id) {
    const data = await adminApi('users.logs', { id });
    if (!data) return;

    const titleEl = document.getElementById('userLogModalTitle');
    const bodyEl  = document.getElementById('userLogBody');
    titleEl.textContent = `用户日志 · ${data.user.username} (#${data.user.id})`;

    if (!data.instances || data.instances.length === 0) {
        bodyEl.innerHTML = '<div class="empty-state" style="padding:40px;text-align:center;color:#999;">该用户暂无任何实例</div>';
    } else {
        bodyEl.innerHTML = data.instances.map((ins, idx) => {
            const statusClass = ins.status === 'running' ? 'tag-running'
                              : ins.status === 'stopped' ? 'tag-stopped'
                              : 'tag-pending';
            const log = ins.temp_log && ins.temp_log.trim() ? ins.temp_log : '(暂无日志)';
            const escLog = escHtml(log);
            return `
            <details class="user-log-instance" ${idx === 0 ? 'open' : ''}
                     style="border:1px solid rgba(0,0,0,0.1); border-radius:8px; margin-bottom:12px; overflow:hidden;">
                <summary style="padding:12px 16px; background:#f9fafb; cursor:pointer;
                                display:flex; align-items:center; justify-content:space-between; gap:8px;">
                    <div style="display:flex; align-items:center; gap:10px; flex:1; min-width:0;">
                        <span class="tag ${statusClass}" style="flex-shrink:0;">${escHtml(ins.status || 'unknown')}</span>
                        <strong style="font-family:monospace; font-size:0.82rem;">${escHtml(ins.instance_id)}</strong>
                        <span style="font-size:0.78rem; color:#888;">·</span>
                        <span style="font-size:0.82rem; color:#374151;">${escHtml(ins.persona_name || '未绑定人格')}</span>
                        <span style="font-size:0.78rem; color:#888;">·</span>
                        <span style="font-size:0.78rem; color:#666;">${escHtml(ins.model || '')}</span>
                    </div>
                    <span style="font-size:0.75rem; color:#9ca3af; flex-shrink:0;">
                        AI: ${fmt(ins.ai_message_count || 0)} · USER: ${fmt(ins.user_message_count || 0)}
                    </span>
                </summary>
                <pre style="margin:0; padding:14px 16px; background:#fff; color:#1f2937;
                            font-size:0.78rem; line-height:1.65; max-height:480px; overflow:auto;
                            white-space:pre-wrap; word-break:break-all;
                            font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;">${escLog}</pre>
            </details>`;
        }).join('');
    }

    openModal('userLogModal');
}

async function saveUser() {
    const id = document.getElementById('userEditId').value;
    if (!id) return;

    // v12.10 次数包 JSON 校验:留空 = '[]',否则必须是合法 JSON 数组
    let countModels = document.getElementById('userEditCountModels').value.trim();
    if (countModels !== '') {
        try {
            const parsed = JSON.parse(countModels);
            if (!Array.isArray(parsed)) {
                showToast('次数包"允许的模型"必须是 JSON 数组,例如 ["m1","m2"]', 'error');
                return;
            }
        } catch (e) {
            showToast('次数包"允许的模型" JSON 格式错误: ' + e.message, 'error');
            return;
        }
    }
    const countExp = document.getElementById('userEditCountExpired').value;

    const exp = document.getElementById('userEditExpired').value;
    const payload = {
        id,
        plan_type:           document.getElementById('userEditPlan').value,
        billing_mode:        document.getElementById('userEditBilling').value,
        balance:             document.getElementById('userEditBalance').value,
        // 清空过期日期 = 永久,显式传 0(而非空串,避免后端把"清空"误判为"未传")
        plan_expired_at:     exp ? datetimeLocalToTs(exp) : 0,
        base_weekly_tokens:  document.getElementById('userEditBaseWeekly').value,
        bonus_weekly_tokens: document.getElementById('userEditBonusWeekly').value,
        weekly_used_tokens:  document.getElementById('userEditWeeklyUsed').value,
        pro_pack_total:      document.getElementById('userEditPackTotal').value,
        pro_pack_used:       document.getElementById('userEditPackUsed').value,
        // v12.10 次数包字段
        count_pack_total:      document.getElementById('userEditCountTotal').value,
        count_pack_used:       document.getElementById('userEditCountUsed').value,
        count_pack_expired_at: countExp ? datetimeLocalToTs(countExp) : 0,
        count_pack_models:     countModels,    // 空串后端 SQL 会保留为空,等同 "无限制"
        invite_count:        document.getElementById('userEditInviteCount').value,
        email:               document.getElementById('userEditEmail').value,
        title:               document.getElementById('userEditTitle').value,
        title_color:         (document.getElementById('userEditTitleColorText').value || '#b04e5c').trim(),
    };

    const ret = await adminApi('users.update', payload);
    if (!ret) return;

    // 重置密码
    const newPwd = document.getElementById('userEditNewPwd').value.trim();
    if (newPwd) {
        if (newPwd.length < 6) { showToast('新密码至少 6 位', 'error'); return; }
        await adminApi('users.reset_password', { id, new_password: newPwd });
    }

    // 防御:如果后端返回了 after 字段,直接用它更新本地缓存
    // 避免 loadUsers 因分页/缓存等原因拿到不一致的数据
    if (ret && typeof ret === 'object' && ret.after && window._userMap && window._userMap[id]) {
        Object.assign(window._userMap[id], ret.after);
        const aff = ret.affected ?? 0;
        const setCount = ret.sets_count ?? 0;
        // 后端实际写入了几个字段 / 真正改变了几行,console 调试可见
        console.log(`[saveUser] id=${id} affected=${aff} sets=${setCount}`, ret.after);
    }

    showToast('用户已更新', 'success');
    closeModal('userModal');
    loadUsers();
}

/* ── 人工客服身份（2026-07 新增）──────────────────────────────
 * 勾选 / 取消「设为人工客服」时显隐邮箱行；保存走独立的 users.set_support，
 * 不和上面的 saveUser（users.update）混在一起。
 * ──────────────────────────────────────────────────────────── */
function _syncSupportRow() {
    var on  = document.getElementById('userEditIsSupport').checked;
    var row = document.getElementById('userEditSupportRow');
    if (row) row.style.display = on ? 'block' : 'none';
}
async function saveUserSupport() {
    const id = document.getElementById('userEditId').value;
    if (!id) return;
    const on   = document.getElementById('userEditIsSupport').checked;
    const mail = (document.getElementById('userEditSupportEmail').value || '').trim();
    if (on) {
        if (!mail) { showToast('请填写客服邮箱', 'error'); return; }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) { showToast('客服邮箱格式不正确', 'error'); return; }
    }
    const ret = await adminApi('users.set_support', {
        id, is_support: on ? 1 : 0, support_email: on ? mail : ''
    });
    if (!ret) return;
    // 同步本地缓存，避免重开弹窗看到旧值
    if (window._userMap && window._userMap[id]) {
        window._userMap[id].is_support    = on ? 1 : 0;
        window._userMap[id].support_email = on ? mail : '';
    }
    showToast(on ? '已设为人工客服' : '已取消人工客服', 'success');
}

/* =========================================================
 * 用户封禁 / 解封（2026 新增）
 * 数据来自 window._userMap[id].ban（后端 users.list 已合并）。
 * 时长统一换算为「绝对到期 UNIX 秒」再交给后端:0=永久。
 * ========================================================= */
function openBanModal(id) {
    const u = (window._userMap || {})[id];
    if (!u) { showToast('未找到该用户,请刷新后重试', 'error'); return; }
    document.getElementById('banUserId').value = u.id;
    document.getElementById('banUserMeta').textContent =
        `ID: ${u.id} · ${u.username}${u.email ? ' · ' + u.email : ''}`;

    const ban = u.ban || {};
    const banned = !!ban.is_banned;

    const statusEl = document.getElementById('banCurrentStatus');
    if (banned) {
        const untilTxt = (Number(ban.banned_until) > 0) ? fmtTs(ban.banned_until) : '永久（不会自动解封）';
        const byTxt = ban.banned_by ? ` · 操作人 ${escHtml(ban.banned_by)}` : '';
        statusEl.innerHTML =
            `<div style="background:#fef2f2;border:1px solid #fca5a5;border-radius:10px;padding:12px 14px;">
               <div style="color:#b91c1c;font-weight:700;font-size:0.9rem;margin-bottom:6px;">⚠ 当前处于封禁中</div>
               <div style="font-size:0.82rem;color:#7f1d1d;line-height:1.6;">
                 原因：${escHtml(ban.reason || '(无)')}<br>解封时间：${untilTxt}${byTxt}
               </div>
             </div>`;
        document.getElementById('banReason').value = ban.reason || '';
        document.getElementById('banUnbanBtn').style.display = '';
        document.getElementById('banConfirmBtn').textContent = '更新封禁';
    } else {
        statusEl.innerHTML =
            `<div style="background:#f0fdf4;border:1px solid #86efac;border-radius:10px;padding:10px 14px;font-size:0.85rem;color:#166534;">
               该用户当前未被封禁
             </div>`;
        document.getElementById('banReason').value = '';
        document.getElementById('banUnbanBtn').style.display = 'none';
        document.getElementById('banConfirmBtn').textContent = '确认封禁';
    }

    // 时长默认回到「1 天」
    document.getElementById('banDuration').value = '24';
    document.getElementById('banCustomWrap').style.display = 'none';
    document.getElementById('banCustomUntil').value = '';
    _syncBanUntilPreview();

    openModal('banModal');
}

function onBanDurationChange() {
    const v = document.getElementById('banDuration').value;
    document.getElementById('banCustomWrap').style.display = (v === 'custom') ? '' : 'none';
    _syncBanUntilPreview();
}

// 把当前选择换算成「绝对到期 UNIX 秒」:0=永久;-1=选了自定义但未填(非法)
function _banComputeUntil() {
    const v = document.getElementById('banDuration').value;
    if (v === 'permanent') return 0;
    if (v === 'custom') {
        const s = document.getElementById('banCustomUntil').value;
        if (!s) return -1;
        return datetimeLocalToTs(s);
    }
    const hours = parseFloat(v) || 0;
    return Math.floor(Date.now() / 1000) + Math.round(hours * 3600);
}

function _syncBanUntilPreview() {
    const hint = document.getElementById('banUntilPreview');
    if (!hint) return;
    const until = _banComputeUntil();
    if (until === 0)  { hint.textContent = '永久封禁（不会自动解封）'; return; }
    if (until === -1) { hint.textContent = '请选择自定义到期时间'; return; }
    hint.textContent = '到期自动解封：' + fmtTs(until);
}

async function submitBan() {
    const id = document.getElementById('banUserId').value;
    if (!id) return;
    const reason = document.getElementById('banReason').value.trim();
    if (!reason) { showToast('请填写封禁原因', 'error'); return; }
    const until = _banComputeUntil();
    if (until === -1) { showToast('请选择自定义到期时间', 'error'); return; }
    if (until !== 0 && until <= Math.floor(Date.now() / 1000)) {
        showToast('解封时间必须晚于当前时间', 'error'); return;
    }
    const ret = await adminApi('users.ban', { id, reason, until });
    if (!ret) return;
    if (window._userMap && window._userMap[id]) {
        window._userMap[id].ban = {
            is_banned: 1, reason: ret.reason, banned_until: ret.banned_until,
            banned_at: ret.banned_at, banned_by: ret.banned_by,
        };
    }
    showToast(until === 0 ? '已永久封禁' : '已封禁', 'success');
    closeModal('banModal');
    loadUsers();
}

async function submitUnban() {
    const id = document.getElementById('banUserId').value;
    if (!id) return;
    if (!confirm('确认解除该用户的封禁？\n\n解封后其微信实例立即恢复正常 AI 服务，控制台也恢复访问。')) return;
    const ret = await adminApi('users.unban', { id });
    if (!ret) return;
    if (window._userMap && window._userMap[id] && window._userMap[id].ban) {
        window._userMap[id].ban.is_banned = 0;
    }
    showToast('已解除封禁', 'success');
    closeModal('banModal');
    loadUsers();
}

// v12.10 (2026-05-12) 快速清空次数包(只清表单,不立即写库;
// 用户改完再点保存才生效)
function clearUserCountPack() {
    if (!confirm('确认清空次数包?\n\n这会把"总额 / 已用 / 到期 / 允许的模型"全部归零。\n点确认仅清表单,需要再点"保存"才真正写入数据库。')) return;
    document.getElementById('userEditCountTotal').value   = 0;
    document.getElementById('userEditCountUsed').value    = 0;
    document.getElementById('userEditCountExpired').value = '';
    document.getElementById('userEditCountModels').value  = '';
    showToast('已清空表单(请点击"保存"使其生效)', 'success');
}

/* =========================================================
 * 独立次数包·多桶管理（v19 · 2026-05-26）
 * 操作 user_count_packs 表，与上方单桶字段相互独立。
 * ========================================================= */
let _cpCache = [];   // 当前用户的独立包缓存，编辑时按 id 取回

async function loadUserCountPacks(userId) {
    const box = document.getElementById('userCountPacksList');
    if (!box) return;
    box.innerHTML = '<div style="color:#999;font-size:0.82rem;padding:8px 0;">加载中…</div>';
    const data = await adminApi('user_count_packs.list', { user_id: userId });
    if (!data) { box.innerHTML = '<div style="color:#c00;font-size:0.82rem;">加载失败</div>'; return; }
    _cpCache = data.rows || [];
    renderUserCountPacks();
}

function renderUserCountPacks() {
    const box = document.getElementById('userCountPacksList');
    if (!box) return;
    if (!_cpCache.length) {
        box.innerHTML = '<div style="color:#999;font-size:0.82rem;padding:8px 0;">该用户暂无独立次数包</div>';
        return;
    }
    const now = Math.floor(Date.now() / 1000);
    box.innerHTML = _cpCache.map(p => {
        const total   = Number(p.counts_total || 0);
        const used    = Number(p.counts_used || 0);
        const remain  = Math.max(0, total - used);
        const exp     = Number(p.expired_at || 0);
        const expired = exp > 0 && exp < now;
        const inactive = Number(p.is_active) !== 1;
        let models = [];
        try { models = JSON.parse(p.models || '[]'); } catch (e) { models = []; }
        const modelStr = models.length ? models.join(' / ') : '不限模型';
        // 状态标签
        let badge = '<span class="tag tag-running">启用</span>';
        if (inactive) badge = '<span class="tag tag-stopped">停用</span>';
        else if (expired) badge = '<span class="tag tag-stopped">已过期</span>';
        const expStr = exp > 0 ? fmtTs(exp) : '永久';
        return `
        <div style="border:1px solid rgba(0,0,0,0.1);border-radius:8px;padding:10px 12px;background:#fafafa;">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:6px;">
                <div style="display:flex;align-items:center;gap:8px;min-width:0;">
                    ${badge}
                    <strong style="font-size:0.86rem;color:#111;">${escHtml(p.pack_name || '次数包')}</strong>
                </div>
                <div style="display:flex;gap:6px;flex-shrink:0;">
                    <button class="btn-mini" style="font-size:0.72rem;padding:2px 8px;"
                            onclick="openUserCountPackEditor(${p.id})">编辑</button>
                    <button class="btn-mini danger" style="font-size:0.72rem;padding:2px 8px;"
                            onclick="deleteUserCountPack(${p.id})">删除</button>
                </div>
            </div>
            <div style="font-size:0.78rem;color:#555;line-height:1.7;">
                剩余 <strong style="color:#0a7;">${fmt(remain)}</strong> / 总 ${fmt(total)}（已用 ${fmt(used)}）
                · 到期 ${escHtml(expStr)}<br>
                模型：${escHtml(modelStr)}
                ${p.source_price ? ' · 价 ¥' + escHtml(String(p.source_price)) : ''}
            </div>
        </div>`;
    }).join('');
}

function openUserCountPackEditor(packId) {
    const userId = document.getElementById('userEditId').value;
    if (!userId) { showToast('请先选择用户', 'error'); return; }
    document.getElementById('ucpUserId').value = userId;
    document.getElementById('ucpPackId').value = packId || 0;

    if (packId) {
        const p = _cpCache.find(x => Number(x.id) === Number(packId));
        if (!p) { showToast('未找到该次数包，请刷新', 'error'); return; }
        document.getElementById('ucpModalTitle').textContent = '编辑独立次数包';
        document.getElementById('ucpName').value    = p.pack_name || '';
        document.getElementById('ucpTotal').value   = p.counts_total || 0;
        document.getElementById('ucpUsed').value    = p.counts_used || 0;
        document.getElementById('ucpPrice').value   = p.source_price || 0;
        document.getElementById('ucpExpired').value = p.expired_at ? tsToDatetimeLocal(p.expired_at) : '';
        document.getElementById('ucpModels').value  = p.models && p.models !== '[]' ? p.models : '';
        document.getElementById('ucpActive').value  = Number(p.is_active) === 1 ? '1' : '0';
    } else {
        document.getElementById('ucpModalTitle').textContent = '新增独立次数包';
        document.getElementById('ucpName').value    = '';
        document.getElementById('ucpTotal').value   = 0;
        document.getElementById('ucpUsed').value    = 0;
        document.getElementById('ucpPrice').value   = 0;
        document.getElementById('ucpExpired').value = '';
        document.getElementById('ucpModels').value  = '';
        document.getElementById('ucpActive').value  = '1';
    }
    openModal('ucpModal');
}

async function saveUserCountPack() {
    const userId  = document.getElementById('ucpUserId').value;
    const packId  = document.getElementById('ucpPackId').value;
    if (!userId) return;

    // 模型 JSON 校验（与单桶保存同款）
    let models = document.getElementById('ucpModels').value.trim();
    if (models !== '') {
        try {
            const parsed = JSON.parse(models);
            if (!Array.isArray(parsed)) {
                showToast('「允许的模型」必须是 JSON 数组，例如 ["m1","m2"]', 'error');
                return;
            }
        } catch (e) {
            showToast('「允许的模型」JSON 格式错误：' + e.message, 'error');
            return;
        }
    }

    const total = Number(document.getElementById('ucpTotal').value || 0);
    const used  = Number(document.getElementById('ucpUsed').value || 0);
    if (used > total) {
        showToast('已用次数不能大于总额', 'error');
        return;
    }

    const expStr = document.getElementById('ucpExpired').value;
    const payload = {
        user_id:      userId,
        pack_id:      packId,    // 0 = 新增
        pack_name:    document.getElementById('ucpName').value.trim(),
        counts_total: total,
        counts_used:  used,
        source_price: document.getElementById('ucpPrice').value || 0,
        expired_at:   expStr ? datetimeLocalToTs(expStr) : 0,
        models:       models,    // 空串后端归一成 []
        is_active:    document.getElementById('ucpActive').value,
    };

    const ret = await adminApi('user_count_packs.save', payload);
    if (!ret) return;
    showToast(Number(packId) ? '次数包已更新' : '次数包已新增', 'success');
    closeModal('ucpModal');
    loadUserCountPacks(userId);   // 重新拉列表
}

async function deleteUserCountPack(packId) {
    const userId = document.getElementById('userEditId').value;
    if (!userId || !packId) return;
    const p = _cpCache.find(x => Number(x.id) === Number(packId));
    const name = p ? (p.pack_name || ('#' + packId)) : ('#' + packId);
    if (!confirm(`确认删除独立次数包「${name}」？\n此操作立即生效、不可恢复。`)) return;
    const ok = await adminApi('user_count_packs.delete', { user_id: userId, pack_id: packId });
    if (ok) {
        showToast('次数包已删除', 'success');
        loadUserCountPacks(userId);
    }
}

async function deleteUser() {
    const id = document.getElementById('userEditId').value;
    if (!id) return;
    if (!confirm(`确认要删除 ID=${id} 的用户？\n该用户的实例与人格将一并删除（订单保留）。`)) return;
    const ok = await adminApi('users.delete', { id });
    if (ok) {
        showToast('用户已删除', 'success');
        closeModal('userModal');
        loadUsers();
    }
}

/* =========================================================
 * 实例管理
 * ========================================================= */
let _instPage = 1;
async function loadInstances(page) {
    if (page) _instPage = page;
    const kw = document.getElementById('instKeyword').value.trim();
    const data = await adminApi('instances.list', { keyword: kw, page: _instPage });
    if (!data) return;
    const tbody = document.getElementById('instTableBody');
    if (!data.rows.length) {
        tbody.innerHTML = '<tr><td colspan="9" class="empty-state">暂无数据</td></tr>';
    } else {
        tbody.innerHTML = data.rows.map(i => {
            const statusTag = i.status === '启动'
                ? '<span class="tag tag-running">运行中</span>'
                : '<span class="tag tag-stopped">' + escHtml(i.status) + '</span>';
            return `<tr>
                <td>${i.id}</td>
                <td style="font-family:monospace;font-size:0.78rem;">${escHtml(i.instance_id)}</td>
                <td><strong>${escHtml(i.username||'(已删)')}</strong></td>
                <td style="font-size:0.78rem;color:#555;">${escHtml(i.model)}</td>
                <td>${escHtml(i.persona_name||'未绑定')}</td>
                <td>${statusTag}</td>
                <td>AI ${fmt(i.ai_message_count)} / U ${fmt(i.user_message_count)}</td>
                <td style="font-size:0.72rem;color:#888;">T=${i.temperature ?? '--'}<br>P=${i.presence_penalty ?? '--'}<br>F=${i.frequency_penalty ?? '--'}</td>
                <td>
                    <div class="row-actions">
                        <button class="btn-mini" onclick="forceStopInstance(${i.id})">停止</button>
                        <button class="btn-mini danger" onclick="deleteInstance(${i.id})">删除</button>
                    </div>
                </td>
            </tr>`;
        }).join('');
    }
    renderPagination('instPagination', data.total, data.page, data.size, p => loadInstances(p));
}
const debouncedLoadInstances = debounce(() => loadInstances(1), 300);

async function forceStopInstance(id) {
    if (!confirm(`强制停止实例 ID=${id}？`)) return;
    const ok = await adminApi('instances.force_stop', { id });
    if (ok) { showToast('已停止', 'success'); loadInstances(); }
}

async function deleteInstance(id) {
    if (!confirm(`删除实例 ID=${id}？此操作不可撤销。`)) return;
    const ok = await adminApi('instances.delete', { id });
    if (ok) { showToast('已删除', 'success'); loadInstances(); }
}

/* =========================================================
 * 订单查询
 * ========================================================= */
let _orderPage = 1;
async function loadOrders(page) {
    if (page) _orderPage = page;
    const kw = document.getElementById('orderKeyword').value.trim();
    const status = document.getElementById('orderStatusFilter').value;
    const type = document.getElementById('orderTypeFilter').value;
    const data = await adminApi('orders.list', { keyword: kw, status, type, page: _orderPage });
    if (!data) return;
    const tbody = document.getElementById('orderTableBody');
    if (!data.rows.length) {
        tbody.innerHTML = '<tr><td colspan="8" class="empty-state">暂无数据</td></tr>';
    } else {
        tbody.innerHTML = data.rows.map(o => {
            const statusTag = `<span class="tag tag-${o.status}">${
                {pending:'待支付',success:'已完成',failed:'失败'}[o.status] || o.status
            }</span>`;
            return `<tr>
                <td style="font-family:monospace;font-size:0.78rem;">${escHtml(o.out_trade_no)}</td>
                <td>${escHtml(o.username)}</td>
                <td>${escHtml(o.type)}</td>
                <td>${o.orig_amount != null ? '¥' + Number(o.orig_amount).toFixed(2) : '—'}</td>
                <td>¥${(o.orig_amount != null ? (Math.round(Number(o.orig_amount) * 0.90 * 100) / 100) : Number(o.amount)).toFixed(2)}</td>
                <td>${statusTag}</td>
                <td style="font-size:0.78rem;color:#666;">${fmtTs(o.created_at)}</td>
                <td style="font-size:0.78rem;color:#666;">${o.updated_at ? fmtTs(o.updated_at) : '--'}</td>
            </tr>`;
        }).join('');
    }
    renderPagination('orderPagination', data.total, data.page, data.size, p => loadOrders(p));
}
const debouncedLoadOrders = debounce(() => loadOrders(1), 300);

/* =========================================================
 * 用户统计（只读）
 * ========================================================= */
let _ustatRankPage = 1;

function _ustatPlanTag(plan) {
    return plan === 'pro'
        ? '<span class="tag" style="background:#fef3c7;color:#92400e;">pro</span>'
        : '<span class="tag" style="background:#f3f4f6;color:#6b7280;">free</span>';
}

async function loadUserStats() {
    const d = await adminApi('user_stats.summary');
    if (!d) return;
    const cp = d.count_pack || {}, pro = d.pro || {};

    document.getElementById('ustatGrid').innerHTML = `
        <div class="stat-card">
            <div class="label">用户总数</div>
            <div class="value">${fmt(d.user_total)}</div>
            <div class="delta">pro=${fmt(d.user_pro)}</div>
        </div>
        <div class="stat-card">
            <div class="label">付费用户</div>
            <div class="value">${fmt(d.paying_users)}</div>
            <div class="delta">有成功订单</div>
        </div>
        <div class="stat-card">
            <div class="label">累计充值 · 实收</div>
            <div class="value">¥${Number(d.revenue_all||0).toFixed(2)}</div>
            <div class="delta">本月 ¥${Number(d.revenue_month||0).toFixed(2)}</div>
        </div>
        <div class="stat-card">
            <div class="label">用户余额合计</div>
            <div class="value">¥${Number(d.balance_sum||0).toFixed(2)}</div>
            <div class="delta">待消耗负债</div>
        </div>
        <div class="stat-card">
            <div class="label">次数包 · 可用剩余次数</div>
            <div class="value">${fmt(cp.remaining_counts||0)}</div>
            <div class="delta">${fmt(cp.active_packs||0)} 包 · ${fmt(cp.active_users||0)} 人</div>
        </div>
        <div class="stat-card">
            <div class="label">订阅包 · 可用剩余 token</div>
            <div class="value">${fmt(pro.remaining_tokens||0)}</div>
            <div class="delta">${fmt(pro.active_users||0)} 人</div>
        </div>
    `;

    const cpHtml = cp.table_missing
        ? '<span style="color:#999;">（user_count_packs 表不存在，老库未迁移）</span>'
        : `永久 <b>${fmt(cp.permanent_packs||0)}</b> 包`
          + ` · 未来1天 <b>${fmt(cp.exp_1d_packs||0)}</b> 包 / <b>${fmt(cp.exp_1d_counts||0)}</b> 次`
          + ` · 未来7天 <b style="color:#d97706;">${fmt(cp.exp_7d_packs||0)}</b> 包 / <b style="color:#d97706;">${fmt(cp.exp_7d_counts||0)}</b> 次`
          + ` · 未来30天 <b>${fmt(cp.exp_30d_packs||0)}</b> 包 / <b>${fmt(cp.exp_30d_counts||0)}</b> 次`
          + ` · 已过期未用完 <b style="color:#dc2626;">${fmt(cp.expired_packs||0)}</b> 包 / <b style="color:#dc2626;">${fmt(cp.expired_counts||0)}</b> 次`;
    const proHtml = `永久 <b>${fmt(pro.permanent||0)}</b> 人`
          + ` · 未来1天 <b>${fmt(pro.exp_1d||0)}</b> 人`
          + ` · 未来7天 <b style="color:#d97706;">${fmt(pro.exp_7d||0)}</b> 人`
          + ` · 未来30天 <b>${fmt(pro.exp_30d||0)}</b> 人`
          + ` · 已过期仍有 token <b style="color:#dc2626;">${fmt(pro.expired_with_remain||0)}</b> 人`;
    document.getElementById('ustatExpiry').innerHTML =
        `<div><b>次数包（多桶）：</b>${cpHtml}</div>`
      + `<div><b>订阅包（pro）：</b>${proHtml}</div>`
      + `<div style="margin-top:6px;color:#94a3b8;font-size:.78rem;">「未来 N 天」= 从现在起 N 天内到期且仍有余量的累计数（含更短窗口）。该数偏高说明大量优惠包临近过期，可据此决定是否继续活动。</div>`;

    loadUserStatsRank(1);
    loadUserStatsExpiring();
}

async function loadUserStatsRank(page) {
    if (page) _ustatRankPage = page;
    const metric = document.getElementById('ustatRankMetric').value;
    const d = await adminApi('user_stats.rank', { metric, page: _ustatRankPage });
    if (!d) return;

    // 每个指标的列头 + 主值渲染 + 附加列
    const defs = {
        recharge:        { cols:['#','用户','计划','累计实收','订单数','最近充值'],
                           val:r=>`¥${Number(r.metric_val||0).toFixed(2)}`,
                           extra:r=>[`${fmt(r.order_count||0)} 单`, r.last_at?fmtTs(r.last_at):'--'] },
        invite:          { cols:['#','用户','计划','邀请人数','邀请码','余额'],
                           val:r=>fmt(r.metric_val||0),
                           extra:r=>[escHtml(r.invite_code||'--'), `¥${Number(r.balance||0).toFixed(2)}`] },
        balance:         { cols:['#','用户','计划','余额'],
                           val:r=>`¥${Number(r.metric_val||0).toFixed(2)}`, extra:r=>[] },
        count_remaining: { cols:['#','用户','计划','剩余次数','累计次数','持有包数'],
                           val:r=>fmt(r.metric_val||0),
                           extra:r=>[fmt(r.counts_total||0), `${fmt(r.pack_count||0)} 包`] },
        pro_remaining:   { cols:['#','用户','计划','剩余 token','已用','到期'],
                           val:r=>fmt(r.metric_val||0),
                           extra:r=>[fmt(r.pro_pack_used||0), (Number(r.plan_expired_at)?fmtTs(r.plan_expired_at):'永久')] },
        messages:        { cols:['#','用户','计划','AI 回复数'],
                           val:r=>fmt(r.metric_val||0), extra:r=>[] },
    };
    const def = defs[metric] || defs.recharge;
    document.getElementById('ustatRankHead').innerHTML = def.cols.map(c=>`<th>${c}</th>`).join('');

    const body = document.getElementById('ustatRankBody');
    if (!d.rows.length) {
        body.innerHTML = `<tr><td colspan="${def.cols.length}" class="empty-state">暂无数据</td></tr>`;
    } else {
        const base = (d.page-1)*d.size;
        body.innerHTML = d.rows.map((r,i)=>{
            const extra = def.extra(r).map(x=>`<td style="font-size:.82rem;color:#555;">${x}</td>`).join('');
            return `<tr>
                <td style="color:#94a3b8;">${base+i+1}</td>
                <td>${escHtml(r.username||'--')}</td>
                <td>${_ustatPlanTag(r.plan_type)}</td>
                <td><b>${def.val(r)}</b></td>
                ${extra}
            </tr>`;
        }).join('');
    }
    renderPagination('ustatRankPagination', d.total, d.page, d.size, p=>loadUserStatsRank(p));
}

async function loadUserStatsExpiring() {
    const kind = document.getElementById('ustatExpKind').value;
    const days = document.getElementById('ustatExpDays').value;
    const d = await adminApi('user_stats.expiring', { kind, days });
    if (!d) return;
    const now = d.now || Math.floor(Date.now()/1000);
    const left = (ts)=>{
        if (!ts) return '永久';
        const s = ts - now;
        if (s <= 0) return '<span style="color:#dc2626;">已过期</span>';
        const dd = Math.floor(s/86400), hh = Math.floor((s%86400)/3600);
        return dd>0 ? `${dd}天${hh}时` : `${hh}时`;
    };
    const head = document.getElementById('ustatExpHead');
    const body = document.getElementById('ustatExpBody');

    if (kind === 'pro') {
        head.innerHTML = ['用户','计划','剩余 token','已用','到期时间','剩余时长'].map(c=>`<th>${c}</th>`).join('');
        body.innerHTML = d.rows.length ? d.rows.map(r=>`<tr>
            <td>${escHtml(r.username||'--')}</td>
            <td>${_ustatPlanTag(r.plan_type)}</td>
            <td><b>${fmt(r.remaining||0)}</b></td>
            <td style="color:#777;">${fmt(r.pro_pack_used||0)}</td>
            <td style="font-size:.82rem;">${fmtTs(r.expired_at)}</td>
            <td>${left(Number(r.expired_at))}</td>
        </tr>`).join('') : '<tr><td colspan="6" class="empty-state">该时间段内无到期</td></tr>';
    } else {
        head.innerHTML = ['用户','次数包','剩余 / 总','原价','到期时间','剩余时长'].map(c=>`<th>${c}</th>`).join('');
        body.innerHTML = d.rows.length ? d.rows.map(r=>`<tr>
            <td>${escHtml(r.username||'--')}</td>
            <td>${escHtml(r.pack_name||'--')}</td>
            <td><b>${fmt(r.remaining||0)}</b> / ${fmt(r.counts_total||0)}</td>
            <td style="color:#777;">${r.source_price!=null ? ('¥'+Number(r.source_price).toFixed(2)) : '--'}</td>
            <td style="font-size:.82rem;">${fmtTs(r.expired_at)}</td>
            <td>${left(Number(r.expired_at))}</td>
        </tr>`).join('') : '<tr><td colspan="6" class="empty-state">该时间段内无到期</td></tr>';
    }
}

/* =========================================================
 * 模型定价
 * ========================================================= */
async function loadModels() {
    const data = await adminApi('models.list');
    if (!data) return;
    const tbody = document.getElementById('modelTableBody');
    if (!data.length) {
        tbody.innerHTML = '<tr><td colspan="11" class="empty-state">暂无模型</td></tr>'; return;
    }
    // v8: 能力标签 chip 配色与中文映射,与 console.php 端保持一致
    const TAG_LABEL = { chat:'对话', vision:'识图', thinking:'思考', tools:'工具' };
    const TAG_BG    = { chat:'#f3f4f6', vision:'#ecfeff', thinking:'#fef3c7', tools:'#ede9fe' };
    const TAG_FG    = { chat:'#4b5563', vision:'#0e7490', thinking:'#92400e', tools:'#5b21b6' };
    const TAG_BD    = { chat:'#e5e7eb', vision:'#a5f3fc', thinking:'#fde68a', tools:'#ddd6fe' };
    function renderTagsCell(tagsRaw) {
        // 老库无 tags 字段 → undefined,显示 "—"(灰)
        if (tagsRaw === undefined) {
            return '<span style="color:#bbb" title="数据库尚未启用 tags 字段(请跑 migrate_v8_model_tags.sql)">—</span>';
        }
        const arr = String(tagsRaw || '').split(',').map(t=>t.trim().toLowerCase()).filter(t => TAG_LABEL[t]);
        if (!arr.length) return '<span style="color:#bbb">—</span>';
        return arr.map(t =>
            `<span style="display:inline-block;padding:2px 6px;margin-right:3px;border-radius:4px;`
            + `font-size:0.68rem;font-weight:600;background:${TAG_BG[t]};color:${TAG_FG[t]};`
            + `border:1px solid ${TAG_BD[t]};line-height:1.2;">${TAG_LABEL[t]}</span>`
        ).join('');
    }
    tbody.innerHTML = data.map(m => {
        // display_name 为空兜底显示 model_name，避免空白格子让人摸不着头脑
        const disp = (m.display_name && m.display_name.trim()) ? m.display_name : m.model_name;
        // is_pack_allowed 字段可能不存在(老库未跑 migrate_v6)→ undefined,显示"-"
        const packCell = (m.is_pack_allowed === undefined || m.is_pack_allowed === null)
            ? '<span style="color:#bbb" title="数据库尚未启用订阅包字段">—</span>'
            : (parseInt(m.is_pack_allowed,10)===1
                ? '<span class="tag tag-pro">允许</span>'
                : '<span style="color:#bbb">—</span>');
        // supports_thinking 字段可能不存在(老库未跑 migrate_v7)→ undefined,显示"-"
        const thinkCell = (m.supports_thinking === undefined || m.supports_thinking === null)
            ? '<span style="color:#bbb" title="数据库尚未启用思维链字段(请跑 migrate_v7_model_endpoint.py)">—</span>'
            : (parseInt(m.supports_thinking,10)===1
                ? '<span class="tag tag-pro">支持</span>'
                : '<span style="color:#bbb">—</span>');
        const tagsCell = renderTagsCell(m.tags);
        const protoName = ({
            openai: 'OpenAI',
            anthropic: 'Anthropic',
            gemini: 'Gemini 原生'
        })[String(m.protocol || 'openai').toLowerCase()] || String(m.protocol || 'openai');
        return `
        <tr>
            <td>${m.id}</td>
            <td style="font-family:monospace;">${escHtml(m.model_name)}</td>
            <td>${escHtml(disp)}</td>
            <td><span class="tag tag-pro">${escHtml(protoName)}</span></td>
            <td>${Number(m.input_price).toFixed(4)}</td>
            <td>${Number(m.output_price).toFixed(4)}</td>
            <td>${packCell}</td>
            <td>${thinkCell}</td>
            <td>${tagsCell}</td>
            <td>${m.is_active==1 ? '<span class="tag tag-running">在线</span>' : '<span class="tag tag-stopped">下架</span>'}</td>
            <td>
                <div class="row-actions">
                    <button class="btn-mini" onclick='editModel(${JSON.stringify(m).replace(/'/g,"&#39;")})'>编辑</button>
                    <button class="btn-mini danger" onclick="deleteModel(${m.id})">删除</button>
                </div>
            </td>
        </tr>
    `;}).join('');
}

function openModelModal() {
    document.getElementById('modelModalTitle').textContent = '新增模型';
    document.getElementById('modelEditId').value = 0;
    document.getElementById('modelName').value = '';
    document.getElementById('modelDisplayName').value = '';
    document.getElementById('modelInPrice').value = 0;
    document.getElementById('modelOutPrice').value = 0;
    document.getElementById('modelActive').value = '1';
    document.getElementById('modelPackAllowed').value = '0';
    // v7:端点/Key/协议/思维链 默认值
    document.getElementById('modelEndpoint').value = '';
    document.getElementById('modelApiKey').value = '';
    document.getElementById('modelProtocol').value = 'openai';
    document.getElementById('modelSupportsThinking').value = '0';
    onModelProtocolChange();
    // v8:能力标签默认全不勾
    setModelTagCheckboxes('');
    // v12.11 icon/category
    document.getElementById('modelCategory').value = '';
    _resetModelIconUI();
    openModal('modelModal');
}
function editModel(m) {
    document.getElementById('modelModalTitle').textContent = '编辑模型';
    document.getElementById('modelEditId').value = m.id;
    document.getElementById('modelName').value = m.model_name;
    document.getElementById('modelDisplayName').value = m.display_name || '';
    document.getElementById('modelInPrice').value = m.input_price;
    document.getElementById('modelOutPrice').value = m.output_price;
    document.getElementById('modelActive').value = String(m.is_active);
    document.getElementById('modelPackAllowed').value = String(parseInt(m.is_pack_allowed||0, 10) ? 1 : 0);
    // v7:端点/Key/协议/思维链(老库字段不存在时全部置空 / 默认值)
    document.getElementById('modelEndpoint').value = m.endpoint || '';
    document.getElementById('modelApiKey').value = m.api_key || '';
    document.getElementById('modelProtocol').value = m.protocol || 'openai';
    document.getElementById('modelSupportsThinking').value = String(parseInt(m.supports_thinking||0, 10) ? 1 : 0);
    onModelProtocolChange();
    // v8:能力标签
    setModelTagCheckboxes(m.tags || '');
    // v12.11 icon/category
    document.getElementById('modelCategory').value = m.category || '';
    document.getElementById('modelIconData').value = m.icon || '';
    _renderModelIconPreview(m.icon || '');
    document.getElementById('modelIconFile').value = '';  // reset file picker
    openModal('modelModal');
}

function onModelProtocolChange() {
    const isGemini = document.getElementById('modelProtocol').value === 'gemini';
    const endpoint = document.getElementById('modelEndpoint');
    const thinking = document.getElementById('modelSupportsThinking');
    endpoint.disabled = isGemini;
    endpoint.title = isGemini
        ? 'Gemini 原生端点在 llm_protocol_gemini.py 顶部硬编码'
        : '';
    thinking.disabled = isGemini;
    if (isGemini) thinking.value = '1';
}

/* v12.11 模型图标:文件选择 → base64 + 预览 ─────────────────────── */
function _renderModelIconPreview(dataUri) {
    const el = document.getElementById('modelIconPreview');
    if (!dataUri) {
        el.innerHTML = '无';
        el.style.color = '#888';
        return;
    }
    el.innerHTML = `<img src="${dataUri}" style="width:100%;height:100%;object-fit:cover;">`;
    el.style.color = '';
}
function _resetModelIconUI() {
    document.getElementById('modelIconData').value = '';
    document.getElementById('modelIconFile').value = '';
    _renderModelIconPreview('');
}
function clearModelIcon() {
    _resetModelIconUI();
}
function onModelIconPick(ev) {
    const f = ev.target.files && ev.target.files[0];
    if (!f) return;
    if (f.size > 60 * 1024) {
        showToast('图标文件不能超过 60KB,请压缩后再上传', 'error');
        ev.target.value = '';
        return;
    }
    const reader = new FileReader();
    reader.onload = () => {
        const dataUri = reader.result;
        document.getElementById('modelIconData').value = dataUri;
        _renderModelIconPreview(dataUri);
    };
    reader.onerror = () => showToast('文件读取失败', 'error');
    reader.readAsDataURL(f);
}
/* v8: 标签复选框读写工具 ──────────────────────────────────────── */
function setModelTagCheckboxes(tagsStr) {
    const set = new Set(
        String(tagsStr || '').split(',').map(t => t.trim().toLowerCase()).filter(Boolean)
    );
    document.getElementById('modelTagChat').checked     = set.has('chat');
    document.getElementById('modelTagVision').checked   = set.has('vision');
    document.getElementById('modelTagThinking').checked = set.has('thinking');
    document.getElementById('modelTagTools').checked    = set.has('tools');
}
function getModelTagCheckboxes() {
    const out = [];
    if (document.getElementById('modelTagChat').checked)     out.push('chat');
    if (document.getElementById('modelTagVision').checked)   out.push('vision');
    if (document.getElementById('modelTagThinking').checked) out.push('thinking');
    if (document.getElementById('modelTagTools').checked)    out.push('tools');
    return out.join(',');
}
async function saveModel() {
    const ok = await adminApi('models.save', {
        id: document.getElementById('modelEditId').value,
        model_name: document.getElementById('modelName').value.trim(),
        display_name: document.getElementById('modelDisplayName').value.trim(),
        input_price: document.getElementById('modelInPrice').value,
        output_price: document.getElementById('modelOutPrice').value,
        is_active: document.getElementById('modelActive').value,
        is_pack_allowed: document.getElementById('modelPackAllowed').value,
        // v7
        endpoint: document.getElementById('modelEndpoint').value.trim(),
        api_key: document.getElementById('modelApiKey').value.trim(),
        protocol: document.getElementById('modelProtocol').value,
        supports_thinking: document.getElementById('modelSupportsThinking').value,
        // v8: 能力标签 (逗号分隔)
        tags: getModelTagCheckboxes(),
        // v12.11: 图标(base64) + 分组
        icon: document.getElementById('modelIconData').value,
        category: document.getElementById('modelCategory').value.trim(),
    });
    if (ok) { showToast('已保存', 'success'); closeModal('modelModal'); loadModels(); }
}
async function deleteModel(id) {
    if (!confirm(`删除模型 ID=${id}？`)) return;
    const ok = await adminApi('models.delete', { id });
    if (ok) { showToast('已删除', 'success'); loadModels(); }
}

/* ───────── v5: 批量回填显示名 + 启用订阅包白名单 ───────── */
async function autoFillDisplayNames() {
    if (!confirm('将根据预设建议表自动回填所有【显示名为空】的模型名称。\n已填的不会动。是否继续？')) return;
    const data = await adminApi('models.autofill_display_names');
    if (data === false) return;
    showToast(`已回填 ${data.fixed || 0} 条`, 'success');
    loadModels();
}

async function activatePackWhitelist() {
    if (!confirm('将把订阅包(pack)桶允许的 6 个模型一键激活上架,缺失的自动新增(默认价 0)。是否继续？')) return;
    const data = await adminApi('models.activate_pack_whitelist');
    if (data === false) return;
    showToast(`已激活 ${data.activated || 0},新增 ${data.inserted || 0}`, 'success');
    loadModels();
}

/* =========================================================
 * v5: 订阅包档位管理(pack_tiers)
 * ========================================================= */
async function loadPacks() {
    const data = await adminApi('packs.list');
    if (data === false) return;
    const tbody = document.getElementById('packTierTableBody');
    if (!data || !data.length) {
        tbody.innerHTML = '<tr><td colspan="9" class="empty-state">暂无档位</td></tr>';
        return;
    }
    // v8.4 (2026-05-10):同 loadCountPacks 的 bug 修复 — 用 data-id + 事件委托
    window._packTierRowsCache = {};
    data.forEach(t => { window._packTierRowsCache[String(t.id)] = t; });

    tbody.innerHTML = data.map(t => `
        <tr>
            <td>${escHtml(String(t.id))}</td>
            <td><strong style="color:#d97706">¥${parseFloat(t.price).toFixed(2)}</strong></td>
            <td style="font-family:monospace;">${parseInt(t.tokens, 10).toLocaleString('zh-CN')}</td>
            <td>${parseFloat(t.gift_balance) > 0 ? '¥' + parseFloat(t.gift_balance).toFixed(2) : '<span style="color:#bbb">—</span>'}</td>
            <td>${escHtml(String(t.days))} 天</td>
            <td>${t.label ? `<span class="tag tag-pro">${escHtml(t.label)}</span>` : '<span style="color:#bbb">—</span>'}</td>
            <td>${escHtml(String(t.sort_order))}</td>
            <td>${parseInt(t.is_active,10)===1 ? '<span class="tag tag-running">在售</span>' : '<span class="tag tag-stopped">下架</span>'}</td>
            <td><button class="btn-mini btn-edit-pack-tier" data-id="${escHtml(String(t.id))}">编辑</button></td>
        </tr>
    `).join('');

    tbody.querySelectorAll('.btn-edit-pack-tier').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.getAttribute('data-id');
            const t  = window._packTierRowsCache[id];
            if (t) editPackTier(t);
        });
    });
}

function openPackTierModal() {
    document.getElementById('packTierModalTitle').textContent = '新增档位';
    document.getElementById('packTierEditId').value     = '0';
    document.getElementById('packTierPrice').value      = '';
    document.getElementById('packTierTokens').value     = '';
    document.getElementById('packTierGift').value       = '0';
    document.getElementById('packTierDays').value       = '30';
    document.getElementById('packTierLabel').value      = '';
    document.getElementById('packTierSort').value       = '0';
    document.getElementById('packTierActive').value     = '1';
    document.getElementById('packTierDeleteBtn').style.display = 'none';
    openModal('packTierModal');
}

function editPackTier(t) {
    document.getElementById('packTierModalTitle').textContent = `编辑档位 #${t.id}`;
    document.getElementById('packTierEditId').value     = t.id;
    document.getElementById('packTierPrice').value      = t.price;
    document.getElementById('packTierTokens').value     = t.tokens;
    document.getElementById('packTierGift').value       = t.gift_balance;
    document.getElementById('packTierDays').value       = t.days;
    document.getElementById('packTierLabel').value      = t.label || '';
    document.getElementById('packTierSort').value       = t.sort_order;
    document.getElementById('packTierActive').value     = String(t.is_active);
    document.getElementById('packTierDeleteBtn').style.display = '';
    openModal('packTierModal');
}

async function savePackTier() {
    const payload = {
        id:           parseInt(document.getElementById('packTierEditId').value || '0', 10),
        price:        document.getElementById('packTierPrice').value,
        tokens:       document.getElementById('packTierTokens').value,
        gift_balance: document.getElementById('packTierGift').value,
        days:         document.getElementById('packTierDays').value,
        label:        document.getElementById('packTierLabel').value,
        sort_order:   document.getElementById('packTierSort').value,
        is_active:    document.getElementById('packTierActive').value,
    };
    if (!payload.price || parseFloat(payload.price) < 0.01) return showToast('价格不能小于 0.01', 'error');
    if (!payload.tokens || parseInt(payload.tokens, 10) < 0) return showToast('Token 数不能为负', 'error');

    const ok = await adminApi('packs.save', payload);
    if (ok === false) return;
    showToast('档位已保存', 'success');
    closeModal('packTierModal');
    loadPacks();
}

async function deletePackTier() {
    const id = parseInt(document.getElementById('packTierEditId').value || '0', 10);
    if (!id) return;
    if (!confirm(`确认删除档位 #${id}？删除后该价格的支付会失败。`)) return;
    const ok = await adminApi('packs.delete', { id });
    if (ok === false) return;
    showToast('档位已删除', 'success');
    closeModal('packTierModal');
    loadPacks();
}

/* =========================================================
 * 次数包档位（v7）
 * 与订阅包档位平行；多了一个 allowed_models 多选 checkbox
 * ========================================================= */
let _countPackModels = [];   // 缓存所有可勾选模型，避免每次重画 modal 都拉一次

async function loadCountPacks() {
    const data = await adminApi('count_packs.list');
    if (data === false || !data) return;

    _countPackModels = Array.isArray(data.models) ? data.models : [];

    const tbody = document.getElementById('countPackTableBody');
    const rows  = Array.isArray(data.rows) ? data.rows : [];
    if (!rows.length) {
        tbody.innerHTML = '<tr><td colspan="9" class="empty-state">暂无档位</td></tr>';
        return;
    }

    // ── v8.4 (2026-05-10) bug 修复 ────────────────────────────────────────
    // 旧版用 onclick='editCountPack(${JSON.stringify(t)})' 把整条记录的 JSON
    // 内嵌到 HTML 属性里。只要某条记录的字段(label/allowed_models 等)含特殊
    // 字符(单引号、& 实体字符、HTML 字符),从那条开始 DOM 解析就会被破坏,
    // 后续行不显示——表现为"只能加 N 个,加第 N+1 个就消失"。
    // 修复:用 data-id 属性 + 事件委托,不再把 JSON 塞 HTML。
    // 把行数据缓存到 window 对象,编辑时按 id 取出,完全绕开字符串注入。
    // ─────────────────────────────────────────────────────────────────────
    window._countPackRowsCache = {};
    rows.forEach(t => { window._countPackRowsCache[String(t.id)] = t; });

    tbody.innerHTML = rows.map(t => {
        let am = [];
        try { am = JSON.parse(t.allowed_models || '[]'); } catch (e) { am = []; }
        const modelTags = am.length
            ? am.slice(0, 3).map(m => `<span class="tag" style="background:#e0f2fe;color:#075985;">${escHtml(m)}</span>`).join(' ')
              + (am.length > 3 ? ` <span class="hint" style="color:#999;">+${am.length - 3}</span>` : '')
            : '<span style="color:#bbb">—</span>';

        return `
        <tr>
            <td>${escHtml(String(t.id))}</td>
            <td><strong style="color:#16a34a">¥${parseFloat(t.price).toFixed(2)}</strong></td>
            <td style="font-family:monospace;font-weight:600;">${parseInt(t.counts, 10).toLocaleString('zh-CN')} 次</td>
            <td>${escHtml(String(t.days))} 天</td>
            <td>${modelTags}</td>
            <td>${t.label ? `<span class="tag tag-pro">${escHtml(t.label)}</span>` : '<span style="color:#bbb">—</span>'}</td>
            <td>${escHtml(String(t.sort_order))}</td>
            <td>${parseInt(t.is_active, 10) === 1 ? '<span class="tag tag-running">在售</span>' : '<span class="tag tag-stopped">下架</span>'}</td>
            <td><button class="btn-mini btn-edit-count-pack" data-id="${escHtml(String(t.id))}">编辑</button></td>
        </tr>`;
    }).join('');

    // 事件委托:绑一次,不跟着每行走
    tbody.querySelectorAll('.btn-edit-count-pack').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.getAttribute('data-id');
            const t  = window._countPackRowsCache[id];
            if (t) editCountPack(t);
        });
    });
}

// 一键把「档位最新可用模型」覆盖同步到所有已购买对应价位的用户次数包
async function syncCountPackUserModels(btn) {
    if (!confirm(
        '将每个次数包档位“当前的可用模型”覆盖同步到所有买过对应价位的用户。\n\n'
      + '· 匹配规则：用户购买价 = 档位价（档位价唯一）。\n'
      + '· 同步后用户可用模型与档位完全一致：新增的模型会补上，档位里已删除的模型会被移除。\n'
      + '· 次数、已用次数、有效期均不受影响。\n\n确定执行？'
    )) return;

    let _html = '';
    if (btn) { _html = btn.innerHTML; btn.disabled = true; btn.innerHTML = '同步中…'; }
    const data = await adminApi('count_packs.sync_user_models');
    if (btn) { btn.disabled = false; btn.innerHTML = _html; }
    if (!data) return;   // 出错时 adminApi 已弹 error toast

    const users = Number(data.affected_users || 0);
    const packs = Number(data.affected_packs || 0);

    const bits = [];
    if (data.already)   bits.push(`${data.already} 个已是最新`);
    if (data.unmatched) bits.push(`${data.unmatched} 个无对应档位（已跳过）`);
    const tail = bits.length ? `；另有 ${bits.join('、')}` : '';

    // 顶部 toast（约 2.8s 自动消失）
    showToast(`已同步：影响 ${users} 位用户、更新 ${packs} 个次数包`,
              users > 0 ? 'success' : 'info');

    // 同时在列表上方留一条常驻结果，方便核对受影响人数
    const box = document.getElementById('countPackSyncResult');
    if (box) {
        box.style.display = '';
        box.innerHTML =
            `本次同步<strong>影响了 ${users} 位用户</strong>，共更新 ${packs} 个次数包`
          + (tail ? `<span style="color:#5b7aa6;">${escHtml(tail)}</span>` : '')
          + `<span style="color:#9aa;"> · ${new Date().toLocaleString('zh-CN')}</span>`;
    }
}

function _renderCountPackModelCheckboxes(selected) {
    // v10：每个次数包只绑定一个模型 → 单选 radio。selected: 含 0~1 个 model_name 的数组
    const set = new Set((selected || []).map(s => String(s).trim()));
    const box = document.getElementById('countPackModelsBox');
    if (!_countPackModels.length) {
        box.innerHTML = '<span style="color:#dc2626;">model_pricing 表无在用模型，请先去"模型定价"添加</span>';
        return;
    }
    box.innerHTML = _countPackModels.map(m => `
        <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;">
            <input type="radio" name="cp-model-radio" class="cp-model-radio"
                   value="${escHtml(m.model_name)}"
                   ${set.has(m.model_name) ? 'checked' : ''}>
            <span><code style="font-size:0.78rem;">${escHtml(m.model_name)}</code>
                  ${m.display_name ? `<span style="color:#888;">（${escHtml(m.display_name)}）</span>` : ''}</span>
        </label>
    `).join('');
}

// ── 概率性「无法添加次数包」修复（2026-06-27）──────────────────────────────
// 病根：新增/编辑弹窗里的模型勾选框来自缓存 _countPackModels，而该缓存由切到
//      「次数包」tab 时的 loadCountPacks() 异步填充。若缓存还没回来（刚进页面 /
//      网络慢 / 直接点了「新增档位」），勾选框就画不出来，保存时 checked 为空 →
//      报「至少要勾选 1 个模型」，于是出现“有时能加、有时加不了”的概率现象。
// 修复：打开弹窗前先确保模型清单已就绪（为空就现拉一次），保证勾选框始终可用。
async function _ensureCountPackModels() {
    if (Array.isArray(_countPackModels) && _countPackModels.length) return true;
    const data = await adminApi('count_packs.list');
    if (data && Array.isArray(data.models)) _countPackModels = data.models;
    return Array.isArray(_countPackModels) && _countPackModels.length > 0;
}

async function openCountPackModal() {
    document.getElementById('countPackModalTitle').textContent = '新增档位';
    document.getElementById('countPackEditId').value     = '0';
    document.getElementById('countPackPrice').value      = '';
    document.getElementById('countPackCounts').value     = '';
    document.getElementById('countPackDays').value       = '30';
    document.getElementById('countPackLabel').value      = '';
    document.getElementById('countPackSort').value       = '0';
    document.getElementById('countPackActive').value     = '1';
    document.getElementById('countPackDeleteBtn').style.display = 'none';
    await _ensureCountPackModels();              // ★ 先保证模型清单就绪
    _renderCountPackModelCheckboxes([]);
    openModal('countPackModal');
}

async function editCountPack(t) {
    document.getElementById('countPackModalTitle').textContent = `编辑档位 #${t.id}`;
    document.getElementById('countPackEditId').value     = t.id;
    document.getElementById('countPackPrice').value      = t.price;
    document.getElementById('countPackCounts').value     = t.counts;
    document.getElementById('countPackDays').value       = t.days;
    document.getElementById('countPackLabel').value      = t.label || '';
    document.getElementById('countPackSort').value       = t.sort_order;
    document.getElementById('countPackActive').value     = String(t.is_active);
    document.getElementById('countPackDeleteBtn').style.display = '';

    await _ensureCountPackModels();              // ★ 先保证模型清单就绪
    let am = [];
    try { am = JSON.parse(t.allowed_models || '[]'); } catch (e) {}
    _renderCountPackModelCheckboxes(am);

    openModal('countPackModal');
}

async function saveCountPack() {
    const box = document.getElementById('countPackModelsBox');
    const sel = document.querySelector('#countPackModelsBox .cp-model-radio:checked');
    const checked = sel ? [sel.value] : [];
    if (checked.length === 0) {
        // 区分「没选」与「根本没渲染出选项」(模型清单没加载到)
        const hasRadio = box && box.querySelector('.cp-model-radio');
        return showToast(
            hasRadio ? '请选择 1 个模型'
                     : '模型清单未加载，请关闭弹窗重新打开；若仍为空，请先到「模型定价」添加在用模型',
            'error');
    }

    const payload = {
        id:             parseInt(document.getElementById('countPackEditId').value || '0', 10),
        price:          document.getElementById('countPackPrice').value,
        counts:         document.getElementById('countPackCounts').value,
        days:           document.getElementById('countPackDays').value,
        label:          document.getElementById('countPackLabel').value,
        sort_order:     document.getElementById('countPackSort').value,
        is_active:      document.getElementById('countPackActive').value,
        allowed_models: JSON.stringify(checked),
    };
    if (!payload.price || parseFloat(payload.price) < 0.01) return showToast('价格不能小于 0.01', 'error');
    if (!payload.counts || parseInt(payload.counts, 10) < 1) return showToast('次数必须 ≥ 1', 'error');

    const ok = await adminApi('count_packs.save', payload);
    if (ok === false) return;
    showToast('档位已保存', 'success');
    closeModal('countPackModal');
    loadCountPacks();
}

async function deleteCountPack() {
    const id = parseInt(document.getElementById('countPackEditId').value || '0', 10);
    if (!id) return;
    if (!confirm(`确认删除次数包档位 #${id}？删除后该价格的支付会失败，但已售出的套餐不受影响。`)) return;
    const ok = await adminApi('count_packs.delete', { id });
    if (ok === false) return;
    showToast('档位已删除', 'success');
    closeModal('countPackModal');
    loadCountPacks();
}

/* =========================================================
 * 兑换码 redeem_codes (2026-06-19)
 * ========================================================= */
let _redeemModels = [];   // 缓存可勾选模型(次数类型用)

const _REDEEM_TYPE_NAME = { balance: '余额', token: 'Token 包', count: '次数包' };

function _redeemRewardText(t) {
    const type = String(t.reward_type || '');
    const val  = parseFloat(t.reward_value || 0);
    if (type === 'balance') return `¥${val.toFixed(2)}`;
    if (type === 'token')   return `${Math.round(val).toLocaleString('zh-CN')} tokens`;
    if (type === 'count') {
        let am = [];
        try { am = JSON.parse(t.reward_models || '[]'); } catch (e) {}
        const mtxt = am.length ? `（${am.slice(0,2).map(escHtml).join('、')}${am.length>2?` +${am.length-2}`:''}）` : '';
        return `${Math.round(val).toLocaleString('zh-CN')} 次${mtxt}`;
    }
    return '—';
}

async function loadRedeem() {
    const status = document.getElementById('redeemFilterStatus')?.value || '';
    const kw     = document.getElementById('redeemFilterKw')?.value?.trim() || '';

    const data = await adminApi('redeem.list', { status, kw });
    if (data === false || !data) return;

    _redeemModels = Array.isArray(data.models) ? data.models : [];

    // 汇总
    const s = data.summary || { total: 0, unused: 0, used: 0 };
    const sumEl = document.getElementById('redeemSummary');
    if (sumEl) sumEl.innerHTML = `总数 <strong>${fmt(s.total)}</strong> · 未使用 <strong style="color:#16a34a">${fmt(s.unused)}</strong> · 已使用 <strong style="color:#9ca3af">${fmt(s.used)}</strong>`;

    const tbody = document.getElementById('redeemTableBody');
    const rows  = Array.isArray(data.rows) ? data.rows : [];
    if (!rows.length) {
        tbody.innerHTML = '<tr><td colspan="12" class="empty-state">暂无兑换码</td></tr>';
        syncRedeemBatchBtn();
        const all = document.getElementById('redeemCheckAll'); if (all) all.checked = false;
        return;
    }

    tbody.innerHTML = rows.map(t => {
        const used = String(t.status) === 'used';
        const daysTxt = (t.reward_type === 'balance')
            ? '<span style="color:#bbb">—</span>'
            : `${escHtml(String(t.reward_days))} 天`;
        const statusTag = used
            ? '<span class="tag tag-stopped">已使用</span>'
            : '<span class="tag tag-running">未使用</span>';
        const usedBy = used
            ? (t.used_by_name ? `${escHtml(t.used_by_name)}<span style="color:#bbb">#${escHtml(String(t.used_by||''))}</span>` : `#${escHtml(String(t.used_by||''))}`)
            : '<span style="color:#bbb">—</span>';
        const usedAt = used && t.used_at ? fmtTs(parseInt(t.used_at,10)) : '<span style="color:#bbb">—</span>';
        return `
        <tr>
            <td><input type="checkbox" class="redeem-cbx" value="${escHtml(String(t.id))}" onchange="syncRedeemBatchBtn()"></td>
            <td>${escHtml(String(t.id))}</td>
            <td><code style="font-weight:700;letter-spacing:1px;font-size:0.82rem;">${escHtml(t.code)}</code></td>
            <td><span class="tag tag-pro">${escHtml(_REDEEM_TYPE_NAME[t.reward_type] || t.reward_type)}</span></td>
            <td><strong>${_redeemRewardText(t)}</strong></td>
            <td>${daysTxt}</td>
            <td>${statusTag}</td>
            <td>${usedBy}</td>
            <td style="font-size:0.78rem;color:#6b7280;">${usedAt}</td>
            <td style="font-size:0.74rem;color:#9ca3af;font-family:monospace;">${t.batch_id ? escHtml(t.batch_id) : '—'}</td>
            <td style="font-size:0.78rem;color:#6b7280;">${t.note ? escHtml(t.note) : '<span style="color:#bbb">—</span>'}</td>
            <td><button class="btn-mini danger" onclick="deleteRedeemOne(${parseInt(t.id,10)}, '${escHtml(t.code)}')">删除</button></td>
        </tr>`;
    }).join('');

    const all = document.getElementById('redeemCheckAll'); if (all) all.checked = false;
    syncRedeemBatchBtn();
}

const onRedeemKwInput = debounce(loadRedeem, 350);

function _renderRedeemModelCheckboxes(selected) {
    const set = new Set((selected || []).map(s => String(s).trim()));
    const box = document.getElementById('redeemModelsBox');
    if (!box) return;
    if (!_redeemModels.length) {
        box.innerHTML = '<span style="color:#dc2626;">model_pricing 表无在用模型，请先到「模型定价」添加</span>';
        return;
    }
    box.innerHTML = _redeemModels.map(m => `
        <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;">
            <input type="checkbox" class="redeem-model-cbx" value="${escHtml(m.model_name)}" ${set.has(m.model_name)?'checked':''}>
            <span><code style="font-size:0.78rem;">${escHtml(m.model_name)}</code>
                  ${m.display_name ? `<span style="color:#888;">（${escHtml(m.display_name)}）</span>` : ''}</span>
        </label>
    `).join('');
}

function onRedeemTypeChange() {
    const type      = document.getElementById('redeemType').value;
    const valLabel  = document.getElementById('redeemValueLabel');
    const valHint   = document.getElementById('redeemValueHint');
    const valInput  = document.getElementById('redeemValue');
    const daysGroup = document.getElementById('redeemDaysGroup');
    const modelsGrp = document.getElementById('redeemModelsGroup');

    if (type === 'balance') {
        valLabel.textContent = '金额（元）';
        valHint.textContent  = '每个码到账的余额（元）';
        valInput.step = '0.01'; valInput.placeholder = '例如：10';
        daysGroup.style.display = 'none';
        modelsGrp.style.display = 'none';
    } else if (type === 'token') {
        valLabel.textContent = 'Token 数量';
        valHint.textContent  = '每个码到账的 token 数（例如 1500000）';
        valInput.step = '1'; valInput.placeholder = '例如：1500000';
        daysGroup.style.display = '';
        modelsGrp.style.display = 'none';
    } else { // count
        valLabel.textContent = '次数';
        valHint.textContent  = '每个码到账的可调用次数（例如 100）';
        valInput.step = '1'; valInput.placeholder = '例如：100';
        daysGroup.style.display = '';
        modelsGrp.style.display = '';
        _renderRedeemModelCheckboxes([]);
    }
}

function openRedeemModal() {
    document.getElementById('redeemType').value  = 'balance';
    document.getElementById('redeemCount').value = '10';
    document.getElementById('redeemValue').value = '';
    document.getElementById('redeemDays').value  = '30';
    document.getElementById('redeemNote').value  = '';
    onRedeemTypeChange();   // 复位各分组显隐(模型勾选会在 count 时重画)
    openModal('redeemModal');
}

async function createRedeem() {
    const type  = document.getElementById('redeemType').value;
    const count = parseInt(document.getElementById('redeemCount').value || '0', 10);
    const value = parseFloat(document.getElementById('redeemValue').value || '0');
    const days  = parseInt(document.getElementById('redeemDays').value || '30', 10);
    const note  = document.getElementById('redeemNote').value || '';

    if (!count || count < 1)  return showToast('生成数量至少 1 个', 'error');
    if (count > 2000)         return showToast('单次最多生成 2000 个', 'error');
    if (!value || value <= 0) return showToast('奖励数值必须大于 0', 'error');

    const payload = { reward_type: type, reward_value: value, count, note };
    if (type !== 'balance') payload.reward_days = days;
    if (type === 'count') {
        const models = Array.from(document.querySelectorAll('#redeemModelsBox .redeem-model-cbx:checked')).map(cb => cb.value);
        if (models.length === 0) return showToast('次数类型至少要勾选 1 个模型', 'error');
        payload.reward_models = JSON.stringify(models);
    }

    const data = await adminApi('redeem.create', payload);
    if (data === false || !data) return;

    closeModal('redeemModal');
    // 弹出生成结果(可复制)
    const codes = Array.isArray(data.codes) ? data.codes : [];
    document.getElementById('redeemResultModalSub').innerHTML =
        `批次 <code>${escHtml(data.batch_id || '')}</code> · 共 <strong>${fmt(data.count || codes.length)}</strong> 个 · 类型 ${escHtml(_REDEEM_TYPE_NAME[type] || type)}`;
    document.getElementById('redeemResultCodes').value = codes.join('\n');
    openModal('redeemResultModal');

    showToast(data.message || '生成成功', 'success');
    loadRedeem();
}

function copyRedeemCodes() {
    const ta = document.getElementById('redeemResultCodes');
    if (!ta) return;
    ta.select();
    try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(ta.value).then(
                () => showToast('已复制全部兑换码', 'success'),
                () => { document.execCommand('copy'); showToast('已复制', 'success'); }
            );
        } else {
            document.execCommand('copy');
            showToast('已复制', 'success');
        }
    } catch (e) { showToast('复制失败,请手动选择', 'error'); }
}

async function deleteRedeemOne(id, code) {
    if (!id) return;
    if (!confirm(`确认删除兑换码 ${code}？\n删除后该码将无法再被兑换。`)) return;
    const ok = await adminApi('redeem.delete', { id });
    if (ok === false) return;
    showToast('已删除', 'success');
    loadRedeem();
}

function _selectedRedeemIds() {
    return Array.from(document.querySelectorAll('#redeemTableBody .redeem-cbx:checked')).map(cb => cb.value);
}

function syncRedeemBatchBtn() {
    const btn = document.getElementById('redeemBatchDelBtn');
    if (!btn) return;
    const n = _selectedRedeemIds().length;
    btn.style.display = n > 0 ? '' : 'none';
    btn.innerHTML = `<span class="material-symbols-rounded" style="font-size:16px;vertical-align:middle">delete</span> 删除所选 (${n})`;
}

function toggleRedeemCheckAll(el) {
    document.querySelectorAll('#redeemTableBody .redeem-cbx').forEach(cb => { cb.checked = el.checked; });
    syncRedeemBatchBtn();
}

async function batchDeleteRedeem() {
    const ids = _selectedRedeemIds();
    if (!ids.length) return;
    if (!confirm(`确认删除所选 ${ids.length} 个兑换码？此操作不可恢复。`)) return;
    const ok = await adminApi('redeem.delete', { ids: ids.join(',') });
    if (ok === false) return;
    showToast(`已删除 ${ids.length} 个`, 'success');
    loadRedeem();
}

/* =========================================================
 * 系统配置 system_config
 * ========================================================= */
const CONFIG_GROUPS = {
    platform:  { title: '平台核心 API', keys: ['platform_endpoint','platform_api_key'] },
    embedding: { title: '向量记忆 (Embedding)', keys: ['embedding_endpoint','embedding_api_key','embedding_model'] },
    vision:    { title: '视觉识别 (Vision)', keys: ['vision_endpoint','vision_keys','vision_model','vision_price'] },
    img_gen:   { title: '艺术生图 (DALL·E 等)', keys: ['img_gen_endpoint','img_gen_key','img_gen_model','img_gen_price'] },
    pay:       { title: '支付配置', keys: ['pay_pid','pay_key'] },
    plan:      { title: '套餐参数', keys: [] }, // plan_* 全部归入
    rsa:       { title: 'RSA 密钥', keys: ['rsa_private','rsa_public'] },
    invite:    { title: '邀请奖励', keys: ['invite_upgrade_threshold','invite_milestone_tokens'] },
    other:     { title: '其它配置', keys: [] },
};

const SECRET_KEYS = ['platform_api_key','embedding_api_key','vision_keys','img_gen_key','pay_key','rsa_private'];

let _configCache = [];
async function loadConfigs() {
    const data = await adminApi('config.list');
    if (!data) return;
    _configCache = data.rows;

    // v8.6 (2026-05-10): hydrate 免费通道开关 + 提醒词
    try {
        const fbEnabled = (data.rows.find(r => r.config_key === 'free_channel_blocked') || {}).config_value;
        const fbMessage = (data.rows.find(r => r.config_key === 'free_channel_block_message') || {}).config_value;
        const cb = document.getElementById('freeBlockEnabled');
        const ta = document.getElementById('freeBlockMessage');
        const badge = document.getElementById('freeBlockBadge');
        if (cb) cb.checked = (String(fbEnabled || '').trim() === '1');
        if (ta) ta.value = String(fbMessage || '');
        if (badge) badge.style.display = cb && cb.checked ? 'inline-flex' : 'none';
    } catch (e) {
        console.warn('[free_channel_block] hydrate failed:', e);
    }

    // 分组
    const groupedKeys = {};
    Object.keys(CONFIG_GROUPS).forEach(g => groupedKeys[g] = []);

    data.rows.forEach(row => {
        const key = row.config_key;
        let placed = false;
        for (const [g, def] of Object.entries(CONFIG_GROUPS)) {
            if (def.keys.includes(key) || (g === 'plan' && key.startsWith('plan_'))) {
                groupedKeys[g].push(row);
                placed = true; break;
            }
        }
        if (!placed) groupedKeys.other.push(row);
    });

    const wrap = document.getElementById('configContent');
    let html = '';
    for (const [g, def] of Object.entries(CONFIG_GROUPS)) {
        const rows = groupedKeys[g];
        if (!rows.length && g !== 'other') {
            // 显示空组提供新增入口
            html += `<div class="config-group">
                <h3>${escHtml(def.title)}</h3>
                <div style="color:#888;font-size:0.85rem;">（暂无配置项，请使用顶部「新增配置项」按钮）</div>
            </div>`;
            continue;
        }
        if (!rows.length) continue;

        html += `<div class="config-group"><h3>${escHtml(def.title)}</h3>`;
        rows.forEach(r => {
            const isSecret = SECRET_KEYS.some(p => r.config_key.includes(p)) || r.config_key.includes('private');
            // 多行内容（如 PEM 私钥）必须用 textarea —— input 会把 \n 吃掉，
            // 导致回写数据库时丢失换行，下次启动 RSA.import_key 抛 'Not a valid PEM pre boundary'
            const isMultiline = (r.config_value || '').includes('\n')
                              || r.config_key.includes('rsa_private')
                              || r.config_key.includes('rsa_public');
            const valueAttr = escHtml(r.config_value);
            const origLen   = (r.config_value || '').length;

            let valueInput;
            if (isMultiline) {
                // textarea 保留换行，rows 自适应
                const rows = Math.max(3, Math.min(12, (r.config_value.match(/\n/g) || []).length + 1));
                valueInput = `<textarea data-orig-len="${origLen}" rows="${rows}" style="font-family:ui-monospace,Menlo,monospace;font-size:0.78rem;white-space:pre;">${valueAttr}</textarea>`;
            } else {
                const inputType = isSecret ? 'password' : 'text';
                valueInput = `<input type="${inputType}" data-orig-len="${origLen}" value="${valueAttr}" placeholder="(空)">`;
            }

            html += `<div class="config-row" data-key="${escHtml(r.config_key)}" data-secret="${isSecret ? 1 : 0}" style="${isMultiline ? 'grid-template-columns: 220px 1fr 200px auto; align-items: start;' : ''}">
                <span class="config-key">${escHtml(r.config_key)}${isSecret ? ' <span style="color:#d32f2f">🔒</span>' : ''}</span>
                ${valueInput}
                <input type="text" value="${escHtml(r.remark||'')}" placeholder="备注" class="config-remark" style="font-size:0.78rem;">
                <button class="btn-mini danger" onclick="deleteConfig('${escHtml(r.config_key)}')">删除</button>
            </div>`;
        });
        html += '</div>';
    }
    wrap.innerHTML = html;
}

function addNewConfigKey() {
    const key = prompt('请输入新配置项的 key：\n（建议带分组前缀，如 platform_*, plan_max_*, embedding_*）');
    if (!key) return;
    if (!/^[a-z_][a-z0-9_]*$/.test(key)) {
        showToast('key 仅允许小写字母 / 数字 / 下划线', 'error'); return;
    }
    if (_configCache.some(c => c.config_key === key)) {
        showToast('该 key 已存在', 'error'); return;
    }
    _configCache.push({ config_key: key, config_value: '', remark: '' });
    loadConfigs();  // 直接 reload 会丢，临时插一行
    setTimeout(() => {
        const wrap = document.getElementById('configContent');
        const div = document.createElement('div');
        div.className = 'config-group';
        div.innerHTML = `<h3>新建项</h3>
            <div class="config-row" data-key="${escHtml(key)}">
                <span class="config-key">${escHtml(key)}</span>
                <input type="text" value="" placeholder="(空)">
                <input type="text" value="" placeholder="备注" class="config-remark" style="font-size:0.78rem;">
                <button class="btn-mini">未保存</button>
            </div>`;
        wrap.insertBefore(div, wrap.firstChild);
    }, 200);
}

async function deleteConfig(key) {
    if (!confirm(`确认删除配置项 ${key}？`)) return;
    const ok = await adminApi('config.delete', { config_key: key });
    if (ok) { showToast('已删除', 'success'); loadConfigs(); }
}

// v8.6 (2026-05-10) 免费通道关闭 — 一键保存开关 + 提醒词到 system_config
async function onFreeBlockToggle(enabled) {
    const badge = document.getElementById('freeBlockBadge');
    if (badge) badge.style.display = enabled ? 'inline-flex' : 'none';
    // 不立即提交,等用户点"保存免费通道配置"再统一写库
}

async function saveFreeBlockConfig() {
    const cb = document.getElementById('freeBlockEnabled');
    const ta = document.getElementById('freeBlockMessage');
    if (!cb || !ta) return;
    const enabled = cb.checked ? '1' : '0';
    const msg     = (ta.value || '').trim();

    if (cb.checked && !msg) {
        showToast('开启免费通道关闭时必须填写提醒词', 'error');
        return;
    }
    if (cb.checked && !confirm(
        '确认关闭免费通道?\n\n' +
        '所有走本周免费额度的用户发消息时,服务器都不会请求 AI,会直接回复你填的提醒词。\n' +
        '订阅包用户和余额计费用户不受影响。'
    )) {
        return;
    }

    // 复用现有 config.save 批量接口(POST JSON body)
    const ok = await adminApiJSON('config.save', {
        configs: [
            {
                key:    '',
                value:  enabled,
                remark: '免费通道总开关 (1=已关闭,直接回提醒词;其它=正常请求 AI)',
            },
            {
                key:    '',
                value:  msg,
                remark: '免费通道关闭时给免费用户的提醒词(整段不分段发送)',
            },
        ],
    });
    if (!ok) return;

    showToast(cb.checked ? '免费通道已关闭' : '免费通道已恢复', 'success');
    loadConfigs();  // 刷新展示
}

async function saveAllConfigs() {
    const rows = document.querySelectorAll('#configContent .config-row');
    const configs = [];
    let skippedSecret = 0;

    rows.forEach(r => {
        const key       = r.dataset.key;
        const isSecret  = r.dataset.secret === '1';
        // 兼容 input 与 textarea
        const valueEl   = r.querySelector('input[data-orig-len], textarea[data-orig-len]');
        const remarkEl  = r.querySelector('.config-remark');
        if (!valueEl) return;

        const newValue = valueEl.value;
        const origLen  = parseInt(valueEl.dataset.origLen || '0', 10);

        // ★ 关键保护：密钥字段如果原本有值、用户却清空了 → 跳过这一项不更新
        // 防止误操作把 RSA 私钥这种关键密钥抹空
        if (isSecret && origLen > 0 && newValue.trim() === '') {
            skippedSecret++;
            return;
        }

        configs.push({
            key,
            value: newValue,
            remark: remarkEl ? remarkEl.value : ''
        });
    });

    if (!configs.length && !skippedSecret) {
        showToast('没有配置项', 'error');
        return;
    }

    const ok = await adminApiJSON('config.save', { configs });
    if (ok) {
        const msg = skippedSecret > 0
            ? `已保存 ${configs.length} 项；保护跳过 ${skippedSecret} 项被清空的密钥`
            : '全部配置已保存';
        showToast(msg, 'success');
        loadConfigs();
    }
}

/* =========================================================
 * v11 (2026-05-12) 提示词预设 prompt_presets
 * ========================================================= */
let _presetCache = [];

async function loadPromptPresets() {
    const tbody = document.getElementById('presetTableBody');
    tbody.innerHTML = '<tr><td colspan="7" class="empty-state">加载中...</td></tr>';
    const data = await adminApi('prompt_presets.list');
    if (!data) return;
    _presetCache = data;
    if (!data.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state">还没有预设,点右上角新增一个</td></tr>';
        return;
    }
    tbody.innerHTML = data.map(p => `
        <tr>
            <td>${p.id}</td>
            <td><strong>${escHtml(p.name)}</strong></td>
            <td style="color:#6b7280;">${escHtml(p.description || '—')}</td>
            <td>${p.is_active == 1
                ? '<span class="tag tag-green">启用</span>'
                : '<span class="tag tag-gray">禁用</span>'}</td>
            <td>${p.sort_order}</td>
            <td style="color:#888;font-size:0.78rem;">${p.updated_at
                ? new Date(p.updated_at * 1000).toLocaleString('zh-CN', {hour12:false})
                : '—'}</td>
            <td>
                <button class="btn-mini" onclick="openPresetEditor(${p.id})">编辑</button>
                <button class="btn-mini danger" onclick="deletePreset(${p.id}, '${escHtml(p.name)}')">删除</button>
            </td>
        </tr>
    `).join('');
}

function openPresetEditor(id) {
    const isEdit = !!id;
    const p = isEdit ? _presetCache.find(x => x.id == id) : null;
    if (isEdit && !p) { showToast('预设不存在,请刷新', 'error'); return; }

    document.getElementById('presetEditorTitle').textContent = isEdit ? `编辑预设 #${id}` : '新增预设';
    document.getElementById('presetId').value           = isEdit ? id : '';
    document.getElementById('presetName').value         = p ? p.name : '';
    document.getElementById('presetDesc').value         = p ? (p.description || '') : '';
    document.getElementById('presetSystem').value       = p ? p.system_prompt : '';
    document.getElementById('presetPassive').value      = p ? p.passive_reply_prompt : '';
    document.getElementById('presetProactive').value    = p ? p.proactive_message_prompt : '';
    document.getElementById('presetActive').value       = p ? (p.active_reply_prompt || '') : '';
    document.getElementById('presetIsActive').checked   = p ? (p.is_active == 1) : true;
    document.getElementById('presetSortOrder').value    = p ? (p.sort_order || 0) : 0;
    openModal('presetEditorModal');
}

async function savePresetForm() {
    const id   = parseInt(document.getElementById('presetId').value || '0', 10);
    const name = document.getElementById('presetName').value.trim();
    const desc = document.getElementById('presetDesc').value.trim();
    const sys  = document.getElementById('presetSystem').value;
    const pas  = document.getElementById('presetPassive').value;
    const pro  = document.getElementById('presetProactive').value;
    const act  = document.getElementById('presetActive').value;
    const is_active = document.getElementById('presetIsActive').checked ? 1 : 0;
    const sort_order = parseInt(document.getElementById('presetSortOrder').value, 10) || 0;

    if (!name) return showToast('请填写预设名', 'error');
    if (!sys.trim()) return showToast('请填写系统提示词', 'error');
    if (!pas.trim()) return showToast('请填写被动回复提示词', 'error');
    if (!pro.trim()) return showToast('请填写主动消息提示词', 'error');

    const payload = {
        id, name, description: desc,
        system_prompt: sys,
        passive_reply_prompt: pas,
        proactive_message_prompt: pro,
        active_reply_prompt: act,
        is_active, sort_order,
    };
    const ok = await adminApi('prompt_presets.save', payload);
    if (ok) {
        showToast('已保存', 'success');
        closeModal('presetEditorModal');
        loadPromptPresets();
    }
}

async function deletePreset(id, name) {
    if (!confirm(`确认删除预设「${name}」吗?\n\n引用此预设的实例会自动回退为内置默认。`)) return;
    const ok = await adminApi('prompt_presets.delete', { id });
    if (ok) {
        showToast('已删除', 'success');
        loadPromptPresets();
    }
}

/* =========================================================
 * 工具注册
 * ========================================================= */
async function loadTools() {
    const data = await adminApi('tools.list');
    if (!data) return;
    const tbody = document.getElementById('toolTableBody');
    if (!data.length) {
        tbody.innerHTML = '<tr><td colspan="8" class="empty-state">暂无工具</td></tr>'; return;
    }
    tbody.innerHTML = data.map(t => `
        <tr>
            <td>${t.id}</td>
            <td style="font-family:monospace;">${escHtml(t.tool_name)}</td>
            <td>${escHtml(t.display_name)}</td>
            <td><span class="material-symbols-rounded" style="font-size:18px;color:#555;">${escHtml(t.icon||'extension')}</span> <span style="font-size:0.78rem;color:#888;">${escHtml(t.icon)}</span></td>
            <td>${t.is_core==1 ? '<span class="tag tag-pro">核心</span>' : '普通'}</td>
            <td>${t.is_active==1 ? '<span class="tag tag-running">上架</span>' : '<span class="tag tag-stopped">下架</span>'}</td>
            <td>${t.sort_order}</td>
            <td>
                <div class="row-actions">
                    <button class="btn-mini" onclick='editTool(${JSON.stringify(t).replace(/'/g,"&#39;")})'>编辑</button>
                    <button class="btn-mini danger" onclick="deleteTool(${t.id})">删除</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function openToolModal() {
    document.getElementById('toolModalTitle').textContent = '新增工具';
    document.getElementById('toolEditId').value = 0;
    document.getElementById('toolName').value = '';
    document.getElementById('toolDisplay').value = '';
    document.getElementById('toolDesc').value = '';
    document.getElementById('toolIcon').value = 'extension';
    document.getElementById('toolSort').value = 0;
    document.getElementById('toolActive').value = '1';
    document.getElementById('toolCore').value = '0';
    openModal('toolModal');
}
function editTool(t) {
    document.getElementById('toolModalTitle').textContent = '编辑工具';
    document.getElementById('toolEditId').value = t.id;
    document.getElementById('toolName').value = t.tool_name;
    document.getElementById('toolDisplay').value = t.display_name;
    document.getElementById('toolDesc').value = t.description || '';
    document.getElementById('toolIcon').value = t.icon || 'extension';
    document.getElementById('toolSort').value = t.sort_order || 0;
    document.getElementById('toolActive').value = String(t.is_active);
    document.getElementById('toolCore').value = String(t.is_core);
    openModal('toolModal');
}
async function saveTool() {
    const ok = await adminApi('tools.save', {
        id: document.getElementById('toolEditId').value,
        tool_name: document.getElementById('toolName').value.trim(),
        display_name: document.getElementById('toolDisplay').value.trim(),
        description: document.getElementById('toolDesc').value,
        icon: document.getElementById('toolIcon').value.trim(),
        sort_order: document.getElementById('toolSort').value,
        is_active: document.getElementById('toolActive').value,
        is_core: document.getElementById('toolCore').value,
    });
    if (ok) { showToast('已保存', 'success'); closeModal('toolModal'); loadTools(); }
}
async function deleteTool(id) {
    if (!confirm(`删除工具 ID=${id}？黑名单会一并清理。`)) return;
    const ok = await adminApi('tools.delete', { id });
    if (ok) { showToast('已删除', 'success'); loadTools(); }
}

/* =========================================================
 * 人格市场
 * ========================================================= */
async function loadMarkets() {
    const data = await adminApi('market.list');
    if (!data) return;
    // 全局缓存,供 editMarket 按 id 查找(同 v20 console 的模式,避免 onclick 嵌 JSON)
    window._marketMap = {};
    data.forEach(m => { window._marketMap[m.id] = m; });

    const tbody = document.getElementById('marketTableBody');
    if (!data.length) {
        tbody.innerHTML = '<tr><td colspan="8" class="empty-state">暂无人格</td></tr>'; return;
    }
    tbody.innerHTML = data.map(m => {
        // 上传者展示:有 uploader_user_id 说明用户上传的,显示用户名;否则显示"系统"
        const uploaderTag = m.uploader_user_id > 0
            ? `<span style="color:#0369a1;">${escHtml(m.uploader_username || '#' + m.uploader_user_id)}</span>`
            : '<span style="color:#666;">系统</span>';
        return `
        <tr>
            <td>${m.id}</td>
            <td><img src="${escHtml(m.avatar)}" style="width:32px;height:32px;border-radius:50%;object-fit:cover;border:1px solid #eee;"></td>
            <td><strong>${escHtml(m.name)}</strong></td>
            <td style="font-size:0.8rem;color:#666;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escHtml(m.description||'')}</td>
            <td style="font-size:0.82rem;">${uploaderTag}</td>
            <td>${fmt(m.downloads)}</td>
            <td>${m.is_active==1 ? '<span class="tag tag-running">上架</span>' : '<span class="tag tag-stopped">下架</span>'}</td>
            <td>
                <div class="row-actions">
                    <button class="btn-mini" onclick="editMarket(${m.id})">编辑</button>
                    <button class="btn-mini danger" onclick="deleteMarket(${m.id})">删除</button>
                </div>
            </td>
        </tr>`;
    }).join('');
}

function openMarketModal() {
    document.getElementById('marketModalTitle').textContent = '新增人格';
    document.getElementById('marketEditId').value = 0;
    document.getElementById('marketName').value = '';
    document.getElementById('marketDesc').value = '';
    document.getElementById('marketPrompt').value = '';
    document.getElementById('marketAvatar').value = 'image/logo.png';
    document.getElementById('marketAvatarPreview').src = 'image/logo.png';
    document.getElementById('marketActive').value = '1';
    openModal('marketModal');
}
function editMarket(id) {
    const m = (window._marketMap || {})[id];
    if (!m) {
        showToast('未找到该人格,请刷新后重试', 'error');
        return;
    }
    document.getElementById('marketModalTitle').textContent = '编辑人格';
    document.getElementById('marketEditId').value = m.id;
    document.getElementById('marketName').value = m.name;
    document.getElementById('marketDesc').value = m.description || '';
    document.getElementById('marketPrompt').value = m.system_prompt || '';
    document.getElementById('marketAvatar').value = m.avatar;
    document.getElementById('marketAvatarPreview').src = m.avatar;
    document.getElementById('marketActive').value = String(m.is_active);
    openModal('marketModal');
}

// 与 console.php 一致的 Canvas 头像压缩逻辑
async function handleMarketAvatar(input) {
    const file = input.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { showToast('请选择图片文件', 'error'); input.value=''; return; }
    if (file.size > 5*1024*1024) { showToast('原图过大，请选择 5MB 以内', 'error'); input.value=''; return; }

    try {
        const dataUrl = await new Promise((res, rej) => {
            const r = new FileReader();
            r.onload = () => res(r.result);
            r.onerror = rej;
            r.readAsDataURL(file);
        });
        const img = await new Promise((res, rej) => {
            const im = new Image();
            im.onload = () => res(im);
            im.onerror = () => rej(new Error('图片解析失败'));
            im.src = dataUrl;
        });
        const SIZE = 96;
        const canvas = document.createElement('canvas');
        canvas.width = SIZE; canvas.height = SIZE;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff'; ctx.fillRect(0,0,SIZE,SIZE);
        const minSide = Math.min(img.width, img.height);
        const sx = (img.width - minSide) / 2;
        const sy = (img.height - minSide) / 2;
        ctx.drawImage(img, sx, sy, minSide, minSide, 0, 0, SIZE, SIZE);
        const out = canvas.toDataURL('image/jpeg', 0.85);
        document.getElementById('marketAvatarPreview').src = out;
        document.getElementById('marketAvatar').value = out;
        showToast('头像已就绪，保存后生效', 'success');
    } catch (e) {
        showToast('头像处理失败：' + e.message, 'error');
    } finally {
        input.value = '';
    }
}

async function saveMarket() {
    const ok = await adminApi('market.save', {
        id: document.getElementById('marketEditId').value,
        name: document.getElementById('marketName').value.trim(),
        description: document.getElementById('marketDesc').value,
        system_prompt: document.getElementById('marketPrompt').value,
        avatar: document.getElementById('marketAvatar').value,
        is_active: document.getElementById('marketActive').value,
    });
    if (ok) { showToast('已保存', 'success'); closeModal('marketModal'); loadMarkets(); }
}
async function deleteMarket(id) {
    if (!confirm(`删除人格 ID=${id}？`)) return;
    const ok = await adminApi('market.delete', { id });
    if (ok) { showToast('已删除', 'success'); loadMarkets(); }
}

/* =========================================================
 * 邮件队列
 * ========================================================= */
async function loadEmails() {
    const data = await adminApi('emails.list');
    if (!data) return;
    const tbody = document.getElementById('emailTableBody');
    if (!data.length) {
        tbody.innerHTML = '<tr><td colspan="5" class="empty-state">暂无</td></tr>'; return;
    }
    tbody.innerHTML = data.map(e => {
        const statusMap = {0:['待发送','tag-pending'],1:['成功','tag-success'],2:['失败','tag-failed'],3:['处理中','tag-pending']};
        const [statusName, statusClass] = statusMap[e.status] || ['未知','tag-stopped'];
        return `<tr>
            <td>${e.id}</td>
            <td>${escHtml(e.email)}</td>
            <td style="font-family:monospace;">${escHtml(e.code)}</td>
            <td><span class="tag ${statusClass}">${statusName}</span></td>
            <td style="font-size:0.78rem;color:#666;">${fmtTs(e.created_at)}</td>
        </tr>`;
    }).join('');
}

async function purgeEmails() {
    if (!confirm('清理 7 天前的成功邮件记录？此操作不可撤销。')) return;
    const ok = await adminApi('emails.purge');
    if (ok) { showToast('已清理', 'success'); loadEmails(); }
}

/* =========================================================
 * 用户留言管理（精简版）
 * ========================================================= */
let _msgPage = 1;
/* =========================================================
 * v9.2 (2026-05-11) 鸣谢管理
 * ========================================================= */
async function loadTestimonials() {
    const rows = await adminApi('testimonials.list');
    if (!Array.isArray(rows)) return;
    const tbody = document.getElementById('testimonialBody');
    if (!rows.length) {
        tbody.innerHTML = '<tr><td colspan="8" class="empty-state">暂无数据,点击新增添加第一条</td></tr>';
        return;
    }
    const rowLabel = ['向右滑', '向左滑'];
    tbody.innerHTML = rows.map(r => `
        <tr>
            <td>${r.id}</td>
            <td>
                ${r.avatar_url
                    ? `<img src="${escHtml(r.avatar_url)}" style="width:36px;height:36px;border-radius:50%;object-fit:cover;border:1px solid #e5e7eb;" onerror="this.style.display='none'">`
                    : '<span style="color:#bbb;">—</span>'}
            </td>
            <td style="font-weight:500;">${escHtml(r.name)}</td>
            <td style="color:#555;font-size:0.82rem;max-width:260px;">${escHtml(r.content)}</td>
            <td style="text-align:center;">
                <span class="tag" style="background:#f3f4f6;color:#374151;">${rowLabel[r.row_index] ?? r.row_index}</span>
            </td>
            <td style="text-align:center;">${r.sort_order}</td>
            <td>
                ${parseInt(r.is_active) ? '<span class="tag tag-running">展示</span>' : '<span class="tag tag-stopped">隐藏</span>'}
            </td>
            <td>
                <button class="btn-mini" onclick="openTestimonialForm(${r.id})">编辑</button>
                <button class="btn-mini danger" style="margin-left:4px;" onclick="deleteTestimonial(${r.id})">删除</button>
            </td>
        </tr>
    `).join('');
    // 缓存供编辑用
    window._testimonialCache = {};
    rows.forEach(r => { window._testimonialCache[r.id] = r; });
}

function openTestimonialForm(id) {
    document.getElementById('testimonialModal').style.display = 'flex';
    document.getElementById('tmAvatarFile').value = '';
    if (id && window._testimonialCache && window._testimonialCache[id]) {
        const r = window._testimonialCache[id];
        document.getElementById('testimonialModalTitle').textContent = '编辑鸣谢';
        document.getElementById('tmId').value       = r.id;
        document.getElementById('tmAvatar').value   = r.avatar_url || '';
        document.getElementById('tmName').value     = r.name;
        document.getElementById('tmContent').value  = r.content;
        document.getElementById('tmRowIndex').value = r.row_index;
        document.getElementById('tmSort').value     = r.sort_order;
        document.getElementById('tmActive').value   = r.is_active;
        _tmSetAvatarPreview(r.avatar_url || '');
    } else {
        document.getElementById('testimonialModalTitle').textContent = '新增鸣谢';
        document.getElementById('tmId').value       = '';
        document.getElementById('tmAvatar').value   = '';
        document.getElementById('tmName').value     = '';
        document.getElementById('tmContent').value  = '';
        document.getElementById('tmRowIndex').value = '0';
        document.getElementById('tmSort').value     = '0';
        document.getElementById('tmActive').value   = '1';
        _tmSetAvatarPreview('');
    }
}

function _tmSetAvatarPreview(src) {
    const img = document.getElementById('tmAvatarPreview');
    const ph  = document.getElementById('tmAvatarPlaceholder');
    if (src) {
        img.src = src;
        img.style.display = '';
        ph.style.display  = 'none';
    } else {
        img.src = '';
        img.style.display = 'none';
        ph.style.display  = '';
    }
}

function onTmAvatarChange(input) {
    const file = input.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
        showToast('头像文件不能超过 5 MB', 'error');
        input.value = '';
        return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
            // 压缩到 200×200,base64 结果约 15-30 KB,完全在 LONGTEXT 范围内
            const SIZE = 200;
            const canvas = document.createElement('canvas');
            canvas.width = SIZE; canvas.height = SIZE;
            const ctx = canvas.getContext('2d');
            // 居中裁剪为正方形
            const side = Math.min(img.width, img.height);
            const sx = (img.width  - side) / 2;
            const sy = (img.height - side) / 2;
            ctx.drawImage(img, sx, sy, side, side, 0, 0, SIZE, SIZE);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
            document.getElementById('tmAvatar').value = dataUrl;
            // 预览
            const preview = document.getElementById('tmAvatarPreview');
            const ph = document.getElementById('tmAvatarPlaceholder');
            preview.src = dataUrl;
            preview.style.display = '';
            ph.style.display = 'none';
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

function closeTestimonialForm() {
    document.getElementById('testimonialModal').style.display = 'none';
}

async function saveTestimonial() {
    const id      = document.getElementById('tmId').value;
    const name    = document.getElementById('tmName').value.trim();
    const content = document.getElementById('tmContent').value.trim();
    if (!name)    return showToast('名字不能为空', 'error');
    if (!content) return showToast('内容不能为空', 'error');
    const ok = await adminApi('testimonials.save', {
        id:         id || 0,
        avatar_url: document.getElementById('tmAvatar').value.trim(),
        name, content,
        row_index:  document.getElementById('tmRowIndex').value,
        sort_order: document.getElementById('tmSort').value,
        is_active:  document.getElementById('tmActive').value,
    });
    if (ok) {
        showToast(id ? '已更新' : '已添加', 'success');
        closeTestimonialForm();
        loadTestimonials();
    }
}

async function deleteTestimonial(id) {
    if (!confirm('确认删除这条鸣谢?')) return;
    const ok = await adminApi('testimonials.delete', { id });
    if (ok) { showToast('已删除', 'success'); loadTestimonials(); }
}

/* =========================================================
 * 手机号黑名单 (2026-07-07)
 * 已注销用户手机号 → 注册发码前拦截「已注销用户不得再次注册」
 * ========================================================= */
async function loadPhoneBlacklist() {
    const kwEl  = document.getElementById('pblKeyword');
    const rows  = await adminApi('phone_blacklist.list', { keyword: kwEl ? kwEl.value.trim() : '' });
    if (!Array.isArray(rows)) return;
    const tbody = document.getElementById('phoneBlacklistBody');
    const cnt   = document.getElementById('pblCount');
    if (cnt) cnt.textContent = '共 ' + rows.length + ' 条' + (rows.length >= 500 ? '(仅显示最近 500 条)' : '');
    if (!rows.length) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-state">黑名单为空,点击「添加手机号」加入第一条</td></tr>';
        return;
    }
    tbody.innerHTML = rows.map(r => `
        <tr>
            <td>${r.id}</td>
            <td style="font-family:monospace;font-weight:600;">${escHtml(r.phone)}</td>
            <td style="color:#555;font-size:0.82rem;">${r.reason ? escHtml(r.reason) : '<span style="color:#bbb;">—</span>'}</td>
            <td>${escHtml(r.created_by || '-')}</td>
            <td style="font-size:0.8rem;color:#6b7280;">${r.created_at ? new Date(r.created_at * 1000).toLocaleString() : '-'}</td>
            <td>
                <button class="btn-mini danger" onclick="deletePhoneBlacklist(${r.id}, '${escHtml(r.phone)}')">移除</button>
            </td>
        </tr>
    `).join('');
}

function openPhoneBlacklistForm() {
    document.getElementById('pblPhones').value = '';
    document.getElementById('pblReason').value = '';
    document.getElementById('phoneBlacklistModal').style.display = 'flex';
    setTimeout(() => document.getElementById('pblPhones').focus(), 50);
}

function closePhoneBlacklistForm() {
    document.getElementById('phoneBlacklistModal').style.display = 'none';
}

async function savePhoneBlacklist() {
    const phones = document.getElementById('pblPhones').value.trim();
    const reason = document.getElementById('pblReason').value.trim();
    if (!phones) return showToast('请输入手机号', 'error');
    const data = await adminApi('phone_blacklist.add', { phones, reason });
    if (data) {
        showToast(`已添加 ${data.added} 个` + (data.skipped ? `,${data.skipped} 个已存在`  : ''), 'success');
        closePhoneBlacklistForm();
        loadPhoneBlacklist();
    }
}

async function deletePhoneBlacklist(id, phone) {
    if (!confirm(`确认将 ${phone} 移出黑名单?移出后该手机号将可以正常注册。`)) return;
    const ok = await adminApi('phone_blacklist.delete', { id });
    if (ok) { showToast('已移出黑名单', 'success'); loadPhoneBlacklist(); }
}

/* =========================================================
 * v9.3 (2026-05-11) 预设音色管理
 * ========================================================= */
async function loadPresetVoices() {
    const rows = await adminApi('preset_voices.list');
    if (!Array.isArray(rows)) return;
    const tbody = document.getElementById('presetVoiceBody');
    if (!rows.length) {
        tbody.innerHTML = '<tr><td colspan="5" class="empty-state">暂无预设音色,点击新增添加</td></tr>';
        return;
    }
    tbody.innerHTML = rows.map(r => `
        <tr>
            <td>${r.idx + 1}</td>
            <td style="font-family:monospace;font-size:0.82rem;color:#374151;">${escHtml(r.voice_id)}</td>
            <td>${escHtml(r.name)}</td>
            <td>${parseInt(r.is_active) ? '<span class="tag tag-running">启用</span>' : '<span class="tag tag-stopped">隐藏</span>'}</td>
            <td>
                <button class="btn-mini" onclick="openPresetVoiceForm(${r.idx})">编辑</button>
                <button class="btn-mini danger" style="margin-left:4px;" onclick="deletePresetVoice(${r.idx})">删除</button>
            </td>
        </tr>
    `).join('');
    window._presetVoiceCache = {};
    rows.forEach(r => { window._presetVoiceCache[r.idx] = r; });
}

function openPresetVoiceForm(idx) {
    document.getElementById('presetVoiceModal').style.display = 'flex';
    const r = (idx !== null && idx !== undefined && window._presetVoiceCache) ? window._presetVoiceCache[idx] : null;
    if (r) {
        document.getElementById('pvModalTitle').textContent = '编辑预设音色';
        document.getElementById('pvId').value      = r.idx;
        document.getElementById('pvVoiceId').value = r.voice_id;
        document.getElementById('pvName').value    = r.name;
        document.getElementById('pvActive').value  = r.is_active;
    } else {
        document.getElementById('pvModalTitle').textContent = '新增预设音色';
        document.getElementById('pvId').value      = '';
        document.getElementById('pvVoiceId').value = '';
        document.getElementById('pvName').value    = '';
        document.getElementById('pvActive').value  = '1';
    }
}

function closePresetVoiceForm() {
    document.getElementById('presetVoiceModal').style.display = 'none';
}

async function savePresetVoice() {
    const idx      = document.getElementById('pvId').value;
    const voice_id = document.getElementById('pvVoiceId').value.trim();
    const name     = document.getElementById('pvName').value.trim();
    if (!voice_id) return showToast('voice_id 不能为空', 'error');
    if (!name)     return showToast('显示名不能为空', 'error');
    const ok = await adminApi('preset_voices.save', {
        idx: idx === '' ? -1 : idx,
        voice_id, name,
        is_active: document.getElementById('pvActive').value,
    });
    if (ok) {
        showToast(idx === '' ? '已添加' : '已更新', 'success');
        closePresetVoiceForm();
        loadPresetVoices();
    }
}

async function deletePresetVoice(idx) {
    if (!confirm('确认删除该预设音色?')) return;
    const ok = await adminApi('preset_voices.delete', { idx });
    if (ok) { showToast('已删除', 'success'); loadPresetVoices(); }
}

async function loadMessages(page) {
    if (page) _msgPage = page;
    const data = await adminApi('messages.list', { page: _msgPage });
    if (!data) return;

    // 同步左侧 nav 红点
    const navBadge = document.getElementById('navMsgBadge');
    if ((data.pending || 0) > 0) {
        navBadge.textContent = data.pending > 99 ? '99+' : data.pending;
        navBadge.style.display = 'inline-flex';
    } else {
        navBadge.style.display = 'none';
    }

    const tbody = document.getElementById('msgTableBody');
    if (!data.rows.length) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-state">暂无留言</td></tr>';
    } else {
        tbody.innerHTML = data.rows.map(m => {
            const hasReply = m.replied_at > 0;
            const statusTag = hasReply
                ? '<span class="tag tag-success">已回复</span>'
                : '<span class="tag tag-pending">待回复</span>';
            const replyBlock = hasReply ? `<div class="reply-msg">${escHtml(m.reply)}</div>` : '';

            return `<tr>
                <td>${m.id}</td>
                <td><strong>${escHtml(m.username || '(已删除)')}</strong>
                    <div style="font-size:0.72rem;color:#999;">${escHtml(m.email || '')}</div></td>
                <td><div class="msg-cell-content">
                    <div class="my-msg">${escHtml(m.content)}</div>
                    ${replyBlock}
                </div></td>
                <td style="font-size:0.78rem;color:#666;">${fmtTs(m.created_at)}</td>
                <td>${statusTag}</td>
                <td><button class="btn-mini primary" onclick='openReplyModal(${JSON.stringify(m).replace(/'/g, "&#39;")})'>${hasReply ? '修改' : '回复'}</button></td>
            </tr>`;
        }).join('');
    }
    renderPagination('msgPagination', data.total, data.page, data.size, p => loadMessages(p));
}

function openReplyModal(m) {
    document.getElementById('msgReplyId').value = m.id;
    document.getElementById('msgReplyMeta').textContent =
        `${m.username || '(已删除)'} · ${fmtTs(m.created_at)}`;
    document.getElementById('msgReplyContent').textContent = m.content;
    document.getElementById('msgReplyText').value = m.reply || '';
    openModal('messageReplyModal');
    setTimeout(() => document.getElementById('msgReplyText').focus(), 100);
}

async function submitMessageReply() {
    const id    = document.getElementById('msgReplyId').value;
    const reply = document.getElementById('msgReplyText').value.trim();
    if (!reply) { showToast('回复内容不能为空', 'error'); return; }
    const ok = await adminApi('messages.reply', { id, reply });
    if (ok) {
        showToast('回复已发送', 'success');
        closeModal('messageReplyModal');
        loadMessages();
    }
}


/* =========================================================
 * 论坛管理（分区设置 + 帖子审核）
 * ========================================================= */
let _forumPostPage = 1;

function loadForumAdmin() {
    // 进入时默认显示当前子标签（分区）
    var active = document.querySelector('.fa-subtab.active');
    var sub = active ? active.getAttribute('data-sub') : 'sections';
    switchForumSub(sub);
}

function switchForumSub(sub) {
    document.querySelectorAll('.fa-subtab').forEach(b => b.classList.toggle('active', b.getAttribute('data-sub') === sub));
    document.getElementById('faSubSections').classList.toggle('active', sub === 'sections');
    document.getElementById('faSubPosts').classList.toggle('active', sub === 'posts');
    if (sub === 'sections') loadForumSections();
    else loadForumPosts(1);
}

/* ── 分区 ── */
async function loadForumSections() {
    const d = await adminApi('forum.sections');
    const tbody = document.getElementById('forumSectionBody');
    if (!d) { tbody.innerHTML = '<tr><td colspan="5" class="empty-state">加载失败（请确认已执行 forum_migration.sql）</td></tr>'; return; }
    window._forumSecMap = {};
    if (!d.rows.length) {
        tbody.innerHTML = '<tr><td colspan="5" class="empty-state">还没有分区，点右上角新增</td></tr>';
        return;
    }
    tbody.innerHTML = d.rows.map(s => {
        window._forumSecMap[s.id] = s;
        return `<tr>
            <td>${s.sort_order}</td>
            <td><strong>${escHtml(s.name)}</strong></td>
            <td style="font-size:0.8rem;color:#666;">${escHtml(s.intro || '')}</td>
            <td>${s.post_count}</td>
            <td><div class="row-actions">
                <button class="btn-mini" onclick="openForumSectionEditor(${s.id})">编辑</button>
                <button class="btn-mini danger" onclick="deleteForumSection(${s.id})">删除</button>
            </div></td>
        </tr>`;
    }).join('');
}

function openForumSectionEditor(id) {
    const s = id ? (window._forumSecMap || {})[id] : null;
    document.getElementById('fsEditId').value = id || 0;
    document.getElementById('forumSectionModalTitle').textContent = id ? '编辑分区' : '新增分区';
    document.getElementById('fsName').value  = s ? s.name : '';
    document.getElementById('fsIntro').value = s ? (s.intro || '') : '';
    document.getElementById('fsSort').value  = s ? s.sort_order : 0;
    openModal('forumSectionModal');
}

async function saveForumSection() {
    const id    = document.getElementById('fsEditId').value;
    const name  = document.getElementById('fsName').value.trim();
    const intro = document.getElementById('fsIntro').value.trim();
    const sort  = document.getElementById('fsSort').value || 0;
    if (!name) { showToast('请填写分区名称', 'error'); return; }
    const r = await adminApi('forum.section_save', { id, name, intro, sort_order: sort });
    if (!r) return;
    closeModal('forumSectionModal');
    showToast('分区已保存', 'success');
    loadForumSections();
}

async function deleteForumSection(id) {
    if (!confirm('删除该分区？该分区下的帖子会被移出分区（不会删除帖子）。')) return;
    const r = await adminApi('forum.section_delete', { id });
    if (!r) return;
    showToast('分区已删除', 'success');
    loadForumSections();
}

/* ── 帖子审核 ── */
async function loadForumPosts(page) {
    if (page) _forumPostPage = page;
    const kw = document.getElementById('forumPostKeyword').value.trim();
    const status = document.getElementById('forumPostStatus').value;
    const d = await adminApi('forum.posts', { keyword: kw, status, page: _forumPostPage });
    const tbody = document.getElementById('forumPostBody');
    if (!d) { tbody.innerHTML = '<tr><td colspan="9" class="empty-state">加载失败（请确认已执行 forum_migration.sql）</td></tr>'; return; }

    // 导航小红点
    const badge = document.getElementById('navForumBadge');
    if (badge) {
        if (d.pending > 0) { badge.style.display = ''; badge.textContent = d.pending; }
        else badge.style.display = 'none';
    }

    window._forumPostMap = {};
    if (!d.rows.length) {
        tbody.innerHTML = '<tr><td colspan="9" class="empty-state">暂无帖子</td></tr>';
    } else {
        const statusText = { pending: '待审核', approved: '已通过', rejected: '已驳回' };
        tbody.innerHTML = d.rows.map(p => {
            window._forumPostMap[p.id] = p;
            return `<tr>
                <td>${p.id}</td>
                <td><strong style="cursor:pointer;color:#7367f0;" onclick="openForumPostDetail(${p.id})">${escHtml(p.title)}</strong></td>
                <td style="font-size:0.82rem;">${escHtml(p.username || '(已删除)')}</td>
                <td style="font-size:0.82rem;color:#666;">${escHtml(p.section_name || '(无分区)')}</td>
                <td>${p.image_count || 0}</td>
                <td style="font-size:0.8rem;color:#666;">${p.like_count}/${p.comment_count}</td>
                <td><span class="fa-status-tag ${p.status}">${statusText[p.status] || p.status}</span></td>
                <td style="font-size:0.76rem;color:#666;">${fmtTs(p.created_at)}</td>
                <td><div class="row-actions">
                    <button class="btn-mini primary" onclick="openForumPostDetail(${p.id})">管理</button>
                </div></td>
            </tr>`;
        }).join('');
    }
    renderPagination('forumPostPagination', d.total, d.page, d.size, p => loadForumPosts(p));
}
const debouncedLoadForumPosts = debounce(() => loadForumPosts(1), 300);

async function openForumPostDetail(id) {
    document.getElementById('fpReviewId').value = id;
    document.getElementById('fpRejectReason').value = '';
    const body = document.getElementById('forumPostDetailBody');
    body.innerHTML = '<div class="empty-state" style="padding:40px;text-align:center;color:#999;">加载中...</div>';
    openModal('forumPostModal');
    const p = await adminApi('forum.post_detail', { id });
    if (!p) { body.innerHTML = '<div class="empty-state" style="padding:40px;">加载失败</div>'; return; }
    const statusText = { pending: '待审核', approved: '已通过', rejected: '已驳回' };
    const imgs = (p.images || []).map(src =>
        `<img src="${escHtml(src)}" alt="" onclick="window.open('${escHtml(src)}','_blank')">`
    ).join('');
    document.getElementById('fpRejectReason').value = p.reject_reason || '';
    // 按当前状态调整按钮：已通过→可「撤下」、隐藏「通过」；待审/驳回→正常审核
    const approveBtn = document.getElementById('fpApproveBtn');
    const rejectBtn  = document.getElementById('fpRejectBtn');
    if (p.status === 'approved') {
        approveBtn.style.display = 'none';
        rejectBtn.textContent = '撤下';
    } else if (p.status === 'rejected') {
        approveBtn.style.display = '';
        approveBtn.textContent = '通过';
        rejectBtn.textContent = '更新驳回原因';
    } else { // pending
        approveBtn.style.display = '';
        approveBtn.textContent = '通过';
        rejectBtn.textContent = '驳回';
    }
    body.innerHTML = `
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
            <span class="fa-status-tag ${p.status}">${statusText[p.status] || p.status}</span>
            <span style="font-size:0.82rem;color:#666;">作者：${escHtml(p.username || '(已删除)')} · ${fmtTs(p.created_at)}</span>
        </div>
        <div style="font-size:1.1rem;font-weight:800;color:#111;margin-bottom:8px;">${escHtml(p.title)}</div>
        <div style="font-size:0.92rem;color:#374151;line-height:1.7;white-space:pre-wrap;word-break:break-word;">${escHtml(p.content)}</div>
        ${imgs ? `<div class="fa-detail-imgs">${imgs}</div>` : ''}
    `;
}

async function reviewForumPost(decision) {
    const id = document.getElementById('fpReviewId').value;
    if (!id) return;
    const reason = document.getElementById('fpRejectReason').value.trim();
    if (decision === 'reject' && !reason) { showToast('请填写驳回 / 撤下原因', 'error'); return; }
    const r = await adminApi('forum.post_review', { id, decision, reason });
    if (!r) return;
    closeModal('forumPostModal');
    showToast(decision === 'approve' ? '已通过并公开' : '已撤下（不再公开展示）', 'success');
    loadForumPosts();
}

async function adminDeleteForumPost() {
    const id = document.getElementById('fpReviewId').value;
    if (!id) return;
    if (!confirm('确定删除这篇帖子吗？连同点赞和评论一并删除，不可恢复。')) return;
    const r = await adminApi('forum.post_delete', { id });
    if (!r) return;
    closeModal('forumPostModal');
    showToast('帖子已删除', 'success');
    loadForumPosts();
}


/* =========================================================
 * 分页器
 * ========================================================= */
const _paginationCallbacks = {};
function renderPagination(elId, total, page, size, onChange) {
    _paginationCallbacks[elId] = onChange;
    const el = document.getElementById(elId);
    const totalPage = Math.max(1, Math.ceil(total / size));
    el.innerHTML = `
        <button ${page<=1?'disabled':''} onclick="_paginationCallbacks['${elId}'](${page-1})">上一页</button>
        <span>第 ${page} / ${totalPage} 页 · 共 ${total} 条</span>
        <button ${page>=totalPage?'disabled':''} onclick="_paginationCallbacks['${elId}'](${page+1})">下一页</button>
    `;
}

/* =========================================================
 * v8.4 (2026-05-10) 限时抽奖管理
 * ========================================================= */
async function loadLottery() {
    const data = await adminApi('lottery.list_entries');
    if (!data) return;

    // 把奖品配置缓存全局,后面 render 中奖名单 / 报名名单都要查 prize 详情
    window._lotteryPrizes = Array.isArray(data.prizes) ? data.prizes : [];
    const prizeById = {};
    window._lotteryPrizes.forEach(p => { prizeById[p.id] = p; });

    // 概览卡
    document.getElementById('lotteryActiveId').textContent     = data.lottery_id || '--';
    document.getElementById('lotteryEntryCount').textContent   = (data.entry_count   ?? 0).toLocaleString('zh-CN');
    document.getElementById('lotteryWinnerCount').textContent  = (data.winner_count  ?? 0).toLocaleString('zh-CN');
    document.getElementById('lotteryAwardedCount').textContent = (data.awarded_count ?? 0).toLocaleString('zh-CN');

    // 开奖时间(unix 秒 → 北京时间字符串)
    let expired = false;
    if (data.deadline_ts) {
        const d = new Date(data.deadline_ts * 1000);
        const pad = n => String(n).padStart(2, '0');
        const txt = `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} `
                  + `${pad(d.getHours())}:${pad(d.getMinutes())}`;
        expired = Date.now() / 1000 >= data.deadline_ts;
        document.getElementById('lotteryDeadline').innerHTML = txt
            + (expired ? ' <span class="tag tag-stopped" style="margin-left:6px;">已截止</span>'
                       : ' <span class="tag tag-running" style="margin-left:6px;">进行中</span>');
    }

    // 开奖按钮的可见性 ── 三态
    const drawBtn   = document.getElementById('lotteryDrawBtn');
    const redrawBtn = document.getElementById('lotteryRedrawBtn');
    const isDrawn   = !!data.is_drawn;
    if (isDrawn) {
        // 已开奖 → 显示重新开奖按钮(红色危险)
        drawBtn.style.display   = 'none';
        redrawBtn.style.display = '';
    } else if (expired && (data.entry_count || 0) > 0) {
        // 已截止 + 有报名 + 未开奖 → 显示立即开奖按钮
        drawBtn.style.display   = '';
        redrawBtn.style.display = 'none';
    } else {
        // 未截止 / 没人报名 → 都隐藏
        drawBtn.style.display   = 'none';
        redrawBtn.style.display = 'none';
    }

    // ── 中奖名单(开奖后才展示,按奖项分组) ─────────────────────────────
    const winnersBlock = document.getElementById('lotteryWinnersBlock');
    const winnersGrid  = document.getElementById('lotteryWinnersGrid');
    const winnersByPrize = data.winners_by_prize || {};
    if (isDrawn) {
        winnersBlock.style.display = '';
        winnersGrid.innerHTML = window._lotteryPrizes.map(p => {
            const list = winnersByPrize[p.id] || [];
            const userChips = list.length
                ? list.map(u =>
                    `<span class="tag" style="background:#fff;border:1px solid #e5e7eb;color:#111;padding:2px 8px;font-size:0.78rem;">`
                    + `<code style="font-size:0.75rem;color:#6b7280;">#${u.user_id}</code> ${escHtml(u.username || '--')}`
                    + (u.awarded ? ' <span style="color:#16a34a;">✓</span>' : '')
                    + `</span>`
                  ).join(' ')
                : '<span style="color:#bbb;">无人中奖(报名人数可能不足)</span>';
            return `
            <div style="border:1px solid #e5e7eb;border-radius:10px;padding:12px 16px;background:#fff;">
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
                    <span class="material-symbols-rounded" style="font-size:22px;color:${p.color};">${p.icon}</span>
                    <div style="flex:1;min-width:0;">
                        <div style="font-weight:600;color:#111;">${escHtml(p.name)} <span style="color:${p.color};font-weight:500;">${escHtml(p.detail)}</span></div>
                        <div style="font-size:0.78rem;color:#6b7280;margin-top:2px;">奖项 ID: <code>${escHtml(p.id)}</code> · 计划 ${p.winners} 人 · 实际中奖 ${list.length} 人</div>
                    </div>
                </div>
                <div style="display:flex;flex-wrap:wrap;gap:6px;">${userChips}</div>
            </div>`;
        }).join('');
    } else {
        winnersBlock.style.display = 'none';
        winnersGrid.innerHTML = '';
    }

    // ── 报名名单 ───────────────────────────────────────────────────────
    const tbody = document.getElementById('lotteryTableBody');
    const rows  = Array.isArray(data.rows) ? data.rows : [];
    if (!rows.length) {
        tbody.innerHTML = '<tr><td colspan="8" class="empty-state">暂无报名</td></tr>';
        return;
    }

    tbody.innerHTML = rows.map(r => {
        let timeStr = '--';
        if (r.created_at) {
            const d = new Date(Number(r.created_at) * 1000);
            const pad = n => String(n).padStart(2, '0');
            timeStr = `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} `
                    + `${pad(d.getHours())}:${pad(d.getMinutes())}`;
        }

        let winnerCell = '<span style="color:#bbb">—</span>';
        if (parseInt(r.is_winner, 10) === 1) {
            const p = prizeById[r.prize_id];
            if (p) {
                winnerCell = `<span class="tag" style="background:${p.color}20;color:${p.color};border:1px solid ${p.color}40;font-size:0.74rem;">`
                           + `<span class="material-symbols-rounded" style="font-size:13px;vertical-align:middle;">${p.icon}</span> `
                           + `${escHtml(p.name)} ${escHtml(p.detail)}`
                           + `</span>`;
            } else {
                winnerCell = '<span class="tag tag-pro">已中奖</span>';
            }
        }

        return `
        <tr>
            <td>${r.id}</td>
            <td>${r.user_id}</td>
            <td>${escHtml(r.username || '--')}</td>
            <td>¥${parseFloat(r.balance_at || 0).toFixed(2)}</td>
            <td>${parseInt(r.invites_at || 0, 10)}</td>
            <td style="font-family:ui-monospace,Menlo,monospace;font-size:0.78rem;color:#666;">${escHtml(r.ip || '--')}</td>
            <td>${timeStr}</td>
            <td>${winnerCell}</td>
        </tr>`;
    }).join('');
}

async function drawLottery(force) {
    if (force) {
        if (!confirm('⚠ 重新开奖会清空当前中奖结果并重新随机抽人,确认继续吗?')) return;
    } else {
        if (!confirm('确定要立即开奖吗?\n服务端会随机抽取中奖名单,本操作将记入数据库。')) return;
    }
    const data = await adminApi('lottery.draw', { force: force ? 1 : 0 });
    if (!data) return;
    showToast(
        `开奖完成:报名 ${data.entry_count} 人,实际中奖 ${data.total_winners_actual}/${data.total_winners_needed}`,
        'success'
    );
    loadLottery();
}


/* =========================================================
 * 公告管理（v2 新增）
 * ========================================================= */
/* =========================================================
 * 首页鸣谢管理 (v9.2 · 2026-05-10)
 * ========================================================= */
let _testimonialEditId = 0;


async function loadAnnouncement() {
    const data = await adminApi('announcement.get');
    if (!data) return;
    const ta   = document.getElementById('annContent');
    const prev = document.getElementById('annPreview');
    const ver  = document.getElementById('annVersion');
    const at   = document.getElementById('annUpdatedAt');

    ta.value = data.content || '';
    prev.innerHTML = data.content || '<span style="color:#999;">（无公告，留空保存可清空）</span>';
    ver.textContent = data.version || '0';
    at.textContent  = data.updated_at ? fmtTs(data.updated_at) : '--';

    // 编辑时实时预览
    ta.oninput = () => {
        prev.innerHTML = ta.value || '<span style="color:#999;">（空）</span>';
    };
}

async function saveAnnouncement() {
    const content = document.getElementById('annContent').value;
    if (!confirm('确认发布？所有用户下次进入控制台时会重新弹出公告。')) return;
    const res = await adminApi('announcement.update', { content });
    if (!res) return;
    showToast('公告已发布', 'success');
    // 刷新版本号显示
    loadAnnouncement();
}

/* =========================================================
 * 推广视频审核（v2.1 新增）
 * ========================================================= */
const debouncedLoadVideos = debounce(() => loadVideos(1), 300);

async function loadVideos(page) {
    const status = document.getElementById('videoStatusFilter').value;
    const kw     = document.getElementById('videoUserKw').value.trim();
    const data   = await adminApi('videos.list', {
        status,
        username: kw,
        page:     page || 1,
        size:     20,
    });
    if (!data) return;

    // 红点
    const badge = document.getElementById('navVidBadge');
    const pcnt  = parseInt(data.pending_count || 0, 10);
    if (pcnt > 0) {
        badge.textContent = pcnt > 99 ? '99+' : pcnt;
        badge.style.display = 'inline-block';
    } else {
        badge.style.display = 'none';
    }

    const rows = data.videos || [];
    const tb = document.getElementById('videoTbody');
    if (!rows.length) {
        tb.innerHTML = '<tr><td colspan="6" class="empty-hint">暂无视频</td></tr>';
        document.getElementById('videoPagination').innerHTML = '';
        return;
    }

    const labels = { pending:'待审核', approved:'已通过', rejected:'已拒绝', rewarded:'已奖励+包' };
    const tagCls = { pending:'tag-pending', approved:'tag-success', rejected:'tag-danger', rewarded:'tag-pro' };

    tb.innerHTML = rows.map(v => {
        const dateStr = v.created_at ? new Date(parseInt(v.created_at)*1000).toLocaleString('zh-CN', {hour12:false}) : '--';
        const userInfo = `<div><strong>${escHtml(v.username || '?')}</strong></div><div style="font-size:0.72rem; color:#888;">ID ${v.user_id}</div>`;
        const urlBlock = `<a href="${escHtml(v.video_url)}" target="_blank" rel="noopener" style="word-break:break-all;color:#1565c0;">${escHtml(v.video_url)}</a>` +
            (v.platform ? `<div style="font-size:0.72rem;color:#888;margin-top:2px;">平台：${escHtml(v.platform)}</div>` : '') +
            (v.description ? `<div style="font-size:0.78rem;color:#555;margin-top:4px;">${escHtml(v.description)}</div>` : '') +
            (v.status === 'rejected' && v.reject_reason
                ? `<div style="font-size:0.72rem; color:#c62828; margin-top:6px; padding:4px 8px; background:#fff5f5; border-radius:4px;">拒绝原因：${escHtml(v.reject_reason)}</div>`
                : '') +
            (v.status === 'rewarded' && parseFloat(v.gift_pack_amt) > 0
                ? `<div style="font-size:0.72rem; color:#5a3a99; margin-top:6px; padding:4px 8px; background:#f3e5f5; border-radius:4px;">已赠送 ¥${parseFloat(v.gift_pack_amt).toFixed(2)} 档订阅包</div>`
                : '');

        // 操作按钮：根据状态决定
        let actions = '';
        if (v.status === 'pending') {
            actions = `
                <button class="btn-mini primary" onclick="reviewVideo(${v.id}, 'approve')">通过</button>
                <button class="btn-mini" style="color:#c62828; border-color:#ffcdd2;" onclick="reviewVideo(${v.id}, 'reject')">拒绝</button>
                <button class="btn-mini" style="color:#5a3a99; border-color:#d1c4e9;" onclick="giftPackForVideo(${v.id})">赠包</button>`;
        } else if (v.status === 'approved') {
            actions = `<button class="btn-mini" style="color:#5a3a99; border-color:#d1c4e9;" onclick="giftPackForVideo(${v.id})">补送订阅包</button>`;
        } else {
            actions = `<span style="color:#999; font-size:0.78rem;">已处理</span>`;
        }

        return `<tr>
            <td>${v.id}</td>
            <td>${userInfo}</td>
            <td>${urlBlock}</td>
            <td><span class="tag ${tagCls[v.status] || ''}">${labels[v.status] || v.status}</span></td>
            <td><div style="font-size:0.78rem;">${dateStr}</div></td>
            <td>${actions}</td>
        </tr>`;
    }).join('');

    renderPagination('videoPagination', data.total, data.page, data.size, p => loadVideos(p));
}

async function reviewVideo(id, action) {
    let payload = { id, review_action: action };
    if (action === 'reject') {
        const reason = prompt('请填写拒绝原因（用户会在控制台看到）：');
        if (reason === null) return;             // 取消
        if (!reason.trim()) return showToast('拒绝原因不能为空', 'error');
        payload.reject_reason = reason.trim();
    } else {
        if (!confirm('确认通过？将立即给该用户 +20 万 Token / 周永久。')) return;
    }
    const ok = await adminApi('videos.review', payload);
    if (ok === false) return;
    showToast(action === 'approve' ? '已通过' : '已拒绝', 'success');
    loadVideos();
}

async function giftPackForVideo(id) {
    const pack = prompt('请选择档位送出（输入数字）：\n  9.9  → 150 万 Token\n  15.9 → 250 万 + ¥3.9 余额\n  29.9 → 500 万 + ¥6.66\n  39.9 → 800 万 + ¥8.88\n  49.9 → 1200 万 + ¥12.99\n\n直接回车 / 取消则不操作：');
    if (pack === null) return;
    const trimmed = (pack || '').trim();
    if (!['9.9','15.9','29.9','39.9','49.9'].includes(trimmed)) {
        return showToast('档位非法（应为 9.9 / 15.9 / 29.9 / 39.9 / 49.9）', 'error');
    }
    if (!confirm(`确认送 ¥${trimmed} 档订阅包？(token 累加 + 30 天叠期)`)) return;
    const ok = await adminApi('videos.gift_pack', { id, pack_amt: trimmed });
    if (ok === false) return;
    showToast(`已送 ¥${trimmed} 档`, 'success');
    loadVideos();
}

/* 快速调整用户额度（小用户管理） */
async function quickAdjustUser() {
    const key       = document.getElementById('quickUserKey').value.trim();
    const add_bonus = parseInt(document.getElementById('quickAddBonus').value || '0', 10);
    const gift_pack = document.getElementById('quickGiftPack').value;
    const result    = document.getElementById('quickAdjustResult');

    if (!key) return showToast('请填写用户名 / ID', 'error');
    if (!add_bonus && (!gift_pack || gift_pack === '0')) {
        return showToast('未填写任何调整项', 'error');
    }
    if (!confirm(`确认对用户 [${key}] 执行调整？`)) return;

    const data = await adminApi('users.quick_adjust', {
        user_key:         key,
        add_bonus_weekly: add_bonus,
        gift_pack_amt:    gift_pack,
    });
    if (!data) {
        result.innerHTML = '';
        return;
    }
    showToast('已应用', 'success');
    result.innerHTML = `<span style="color:#2e7d32;">✓ 用户 <strong>${escHtml(data.username)}</strong> (ID ${data.user_id}) 已应用：${escHtml((data.applied || []).join(' / '))}</span>`;

    // 重置输入
    document.getElementById('quickAddBonus').value = '';
    document.getElementById('quickGiftPack').value = '0';
}

/* =========================================================
 * 启动
 * ========================================================= */
document.addEventListener('DOMContentLoaded', () => {
    const initialTab = (location.hash || '#dashboard').slice(1);
    if (document.getElementById('tab-' + initialTab)) {
        switchTab(initialTab);
    } else {
        switchTab('dashboard');
    }

    // v2.1：进入页面时刷一次推广视频 pending 红点（不打开 tab）
    adminApi('videos.list', { status: 'pending', size: 1, page: 1 }).then(data => {
        if (!data) return;
        const badge = document.getElementById('navVidBadge');
        const pcnt  = parseInt(data.pending_count || 0, 10);
        if (badge && pcnt > 0) {
            badge.textContent = pcnt > 99 ? '99+' : pcnt;
            badge.style.display = 'inline-block';
        }
    });
});

/* =========================================================
 * 实时监控（v2.2）
 *   - 1 秒一次轮询 admin.php?action=monitor.snapshot
 *   - 卡片：队列 / 活跃 worker / DB pool / MySQL 全局连接
 *   - 表格：每个活跃 worker 的实例 / 用户 / 阶段 / 已运行 ms
 *   - 终端：main.py 的 stdout 日志（含 print）
 * ========================================================= */
let _monTimer = null;
let _monLastTs = 0;

function stopMonitorPolling() {
    if (_monTimer) { clearTimeout(_monTimer); _monTimer = null; }
}

function _msFmt(ms) {
    if (ms < 1000) return ms + ' ms';
    if (ms < 60000) return (ms / 1000).toFixed(2) + ' s';
    return Math.floor(ms / 60000) + 'm ' + Math.floor((ms % 60000) / 1000) + 's';
}

function _msColor(ms) {
    if (ms < 1500)   return '#16a34a';   // 绿
    if (ms < 8000)   return '#0891b2';   // 青（LLM 思考正常区间）
    if (ms < 30000)  return '#d97706';   // 橙
    return '#dc2626';                    // 红：怀疑卡死
}

function _stageBadge(stage) {
    // 给一些常见阶段配色，让人一眼看出 worker 卡在哪一步
    const map = {
        'dequeued':           ['#9ca3af', '出队'],
        'fetch_send_config':  ['#6b7280', '查发送配置'],
        'query_user':         ['#6b7280', '查 user'],
        'image_decrypt':      ['#7c3aed', '图片解密'],
        'image_analyze':      ['#7c3aed', '图片识别'],
        'voice_decrypt':      ['#0891b2', '语音解密'],
        'voice_transcribe':   ['#0891b2', '语音转写'],
        'llm_thinking':       ['#2563eb', 'LLM 思考'],
        'sending_wx':         ['#16a34a', '发送至微信'],
    };
    if (map[stage]) {
        const [c, label] = map[stage];
        return `<span style="display:inline-block;padding:2px 8px;border-radius:10px;font-size:0.72rem;background:${c}1a;color:${c};">${label}</span>`;
    }
    if (stage && stage.startsWith('tool:')) {
        const name = stage.slice(5);
        return `<span style="display:inline-block;padding:2px 8px;border-radius:10px;font-size:0.72rem;background:#f59e0b1a;color:#b45309;">工具·${escHtml(name)}</span>`;
    }
    return `<span style="color:#999;">${escHtml(stage || '--')}</span>`;
}

function _statCard(label, value, sub, color) {
    return `
        <div class="stat-card">
            <div class="label">${escHtml(label)}</div>
            <div class="value" ${color ? `style="color:${color};"` : ''}>${value}</div>
            <div class="delta">${sub || ''}</div>
        </div>`;
}

async function loadMonitor() {
    const data = await adminApi('monitor.snapshot');
    if (!data) {
        // 网络/PHP 异常 → 不再排队下一次，防止狂打
        stopMonitorPolling();
        return;
    }

    const alertBox = document.getElementById('monAlert');

    // ── main.py 未运行的提示 ─────────────────────────────────────────
    if (!data.available) {
        alertBox.style.display = 'block';
        alertBox.innerHTML = `
            <strong>⚠ 没拿到运行时快照：</strong>${escHtml(data.reason || '未知原因')}
            ${data.mysql && data.mysql.max
              ? `<br>MySQL 当前连接 <strong>${data.mysql.now}</strong>/<strong>${data.mysql.max}</strong>（历史峰值 ${data.mysql.max_used}）`
              : ''}
        `;
        document.getElementById('monStatGrid').innerHTML = '';
        document.getElementById('monWorkerTbody').innerHTML =
            '<tr><td colspan="5" class="empty-hint">main.py 未上报，等待中…</td></tr>';
    } else {
        // ── 上报新鲜度告警（>5s 视为 main.py 卡了） ─────────────────
        if ((data.snapshot_age || 0) >= 5) {
            alertBox.style.display = 'block';
            alertBox.innerHTML = `
                <strong>⚠ 快照陈旧：</strong>已 ${data.snapshot_age} 秒未更新，
                main.py 可能卡死或网络异常，请检查进程。
            `;
        } else {
            alertBox.style.display = 'none';
        }

        // ── 顶部卡片 ────────────────────────────────────────────────
        const grid     = document.getElementById('monStatGrid');
        const queueLen = data.queue_size || 0;
        const aw       = data.active_workers || 0;
        const tw       = data.total_workers || 0;
        const wPct     = tw > 0 ? Math.round(aw / tw * 100) : 0;

        const poolUsed = data.pool_used || 0;
        const poolSize = data.pool_size || 0;
        const poolMax  = data.pool_max || 0;

        const m = data.mysql || {};
        const mNow = m.now || 0, mMax = m.max || 0;
        const mPct = mMax > 0 ? Math.round(mNow / mMax * 100) : 0;
        // 数据库连接 > 80% 时报警色
        const mColor = mPct > 90 ? '#dc2626' : (mPct > 75 ? '#d97706' : null);

        grid.innerHTML = [
            _statCard('队列任务', queueLen, queueLen > 0 ? '有积压' : '空闲',
                      queueLen > 50 ? '#dc2626' : (queueLen > 10 ? '#d97706' : null)),
            _statCard('活跃 Worker', `${aw} / ${tw}`, `占用 ${wPct}%`,
                      wPct > 90 ? '#dc2626' : (wPct > 70 ? '#d97706' : null)),
            _statCard('aiomysql 池', `${poolUsed} / ${poolSize}`, `上限 ${poolMax}`),
            _statCard('MySQL 全局连接', `${mNow} / ${mMax}`,
                      `历史峰值 ${m.max_used || 0}`, mColor),
            _statCard('失败重试队列', data.pending_failed || 0,
                      (data.pending_failed || 0) > 0 ? '有挂起消息' : '无',
                      (data.pending_failed || 0) > 5 ? '#d97706' : null),
            _statCard('快照新鲜度', (data.snapshot_age || 0) + ' s', '< 2s 为正常',
                      (data.snapshot_age || 0) >= 3 ? '#d97706' : '#16a34a'),
        ].join('');

        // ── Worker 表 ────────────────────────────────────────────────
        const tbody = document.getElementById('monWorkerTbody');
        const workers = Array.isArray(data.workers) ? data.workers : [];
        document.getElementById('monWorkerHint').textContent =
            workers.length === 0 ? '所有 worker 空闲' : `共 ${workers.length} 个活跃`;

        if (workers.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="empty-hint">所有 worker 空闲</td></tr>';
        } else {
            tbody.innerHTML = workers.map(w => `
                <tr>
                    <td><code>#${w.wid}</code>${w.pro ? ' <span style="color:#7c3aed;font-size:0.72rem;">主动</span>' : ''}</td>
                    <td><code>${w.db_id}</code></td>
                    <td style="font-family:monospace;font-size:0.78rem;color:#555;">${escHtml(String(w.uid || '').slice(0, 24))}</td>
                    <td>${_stageBadge(w.stage)}</td>
                    <td style="text-align:right;font-family:monospace;color:${_msColor(w.ms)};font-weight:600;">
                        ${_msFmt(w.ms)}
                    </td>
                </tr>
            `).join('');
        }

        // ── 日志（增量追加，避免每秒整页重排） ────────────────────────
        const logs = Array.isArray(data.logs) ? data.logs : [];
        const box = document.getElementById('monLogBox');
        const auto = document.getElementById('monAutoScroll').checked;

        // 只渲染比上次更新的部分，按 ts 严格大于
        const fresh = logs.filter(l => (l.ts || 0) > _monLastTs);
        if (fresh.length > 0) {
            // 第一次进来全量渲染；之后只追加
            if (_monLastTs === 0) {
                box.innerHTML = logs.map(_logLineHtml).join('');
            } else {
                box.insertAdjacentHTML('beforeend', fresh.map(_logLineHtml).join(''));
            }
            _monLastTs = fresh[fresh.length - 1].ts;

            // 控制行数（DOM 太多会卡）
            const MAX_DOM_LINES = 800;
            while (box.children.length > MAX_DOM_LINES) box.removeChild(box.firstChild);

            if (auto) box.scrollTop = box.scrollHeight;
        }
        document.getElementById('monLogCount').textContent = box.children.length + ' 行';
    }

    // ── 排队下一次 ────────────────────────────────────────────────
    if (document.getElementById('monAuto').checked) {
        _monTimer = setTimeout(loadMonitor, 1000);
    }
}

function _logLineHtml(l) {
    const d  = new Date((l.ts || 0) * 1000);
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    const ss = String(d.getSeconds()).padStart(2, '0');
    const msg = String(l.msg || '');
    // v15.0:解析 [分片N] 前缀作为分片号(默认 0)
    let shard = '0';
    let body = msg;
    const m = msg.match(/^\[分片(\d+)\]\s*(.*)$/);
    if (m) { shard = m[1]; body = m[2]; }
    // 简易高亮:[xxx] 标签着色
    const colored = escHtml(body).replace(
        /^(\[[^\]]+\])(\s*\[[^\]]+\])?/,
        (m, a, b) => {
            let html = `<span style="color:#8b7fff;font-weight:600;">${a}</span>`;
            if (b) html += `<span style="color:#a855f7;font-weight:600;">${b}</span>`;
            return html;
        }
    );
    // 报错行整段红色
    const isErr = /(\[异常\]|\[超时\]|\[错误\]|Error|Exception|Traceback)/i.test(body);
    const errStyle = isErr ? ' style="color:#dc2626;"' : '';
    const shardTag = `<span class="log-shard-tag">#${shard}</span>`;
    return `<div data-shard="${shard}"${errStyle}><span style="color:#94a3b8;">${hh}:${mm}:${ss}</span> ${shardTag}${colored}</div>`;
}

/* =========================================================
 * 紧急公告广播（v2.2）
 *   - 触发：admin -> announce.broadcast，PHP 写 system_config 任务行 + 启动 python 子进程
 *   - 进度：1 秒拉一次 announce.progress，画进度条+错误列表
 *   - 完成 / 出错后停止轮询，保留最后一帧
 * ========================================================= */
let _annTimer = null;

function stopAnnouncePolling() {
    if (_annTimer) { clearTimeout(_annTimer); _annTimer = null; }
}

function loadAnnounce() {
    // 切换到本页时：绑定字数统计 + 拉一次最近一次进度
    const ta = document.getElementById('annText');
    const cc = document.getElementById('annCharCount');
    if (ta && !ta._bound) {
        ta._bound = true;
        ta.addEventListener('input', () => {
            cc.textContent = ta.value.length;
            // 1000 字硬上限警告
            cc.style.color = ta.value.length > 1000 ? '#dc2626' : '#888';
        });
    }
    refreshAnnounceProgress(true);
}

async function confirmBroadcast() {
    const text = document.getElementById('annText').value.trim();
    if (!text) {
        showToast('请输入公告内容', 'error');
        return;
    }
    if (text.length > 1000) {
        showToast('内容过长（>1000 字）', 'error');
        return;
    }

    // 二次确认（这操作不能撤销）
    const preview = text.length > 60 ? text.slice(0, 60) + '…' : text;
    const ok1 = confirm(
        '即将向所有在线实例的全体历史用户广播以下内容：\n\n'
        + '"' + preview + '"\n\n'
        + '速率 3 条/秒，整个过程不可中断。\n确认继续？'
    );
    if (!ok1) return;

    const data = await adminApi('announce.broadcast', { text });
    if (!data) return;

    const tip = document.getElementById('annLaunchTip');
    tip.style.display = 'block';
    if (data.launched) {
        tip.innerHTML = `
            <div style="background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46;
                        padding:10px 14px;border-radius:8px;font-size:0.85rem;">
                ✅ 任务已派发（job_id: <code>${escHtml(data.job_id)}</code>），下方将自动跟踪进度。
            </div>`;
    } else {
        tip.innerHTML = `
            <div style="background:#fef9c3;border:1px solid #fde68a;color:#854d0e;
                        padding:10px 14px;border-radius:8px;font-size:0.85rem;">
                ⚠ 任务行已写入但 PHP 无法启动子进程，请到服务器上手动执行：<br>
                <code style="display:block;margin-top:6px;background:#fff;padding:6px 10px;border-radius:6px;
                             font-size:0.78rem;word-break:break-all;">${escHtml(data.launch_msg)}</code>
            </div>`;
    }

    // 立刻开始拉进度
    refreshAnnounceProgress(true);
}

async function refreshAnnounceProgress(immediate) {
    const data = await adminApi('announce.progress');
    if (!data) { stopAnnouncePolling(); return; }

    const panel = document.getElementById('annProgressPanel');
    if (!data.available) {
        panel.style.display = 'none';
        return;
    }
    panel.style.display = 'block';

    const total = data.total || 0;
    const done  = data.done  || 0;
    const okC   = data.ok    || 0;
    const fail  = data.fail  || 0;
    const pct   = total > 0 ? Math.round(done / total * 100) : 0;

    // 卡片
    document.getElementById('annStatGrid').innerHTML = [
        _statCard('状态', _annStatusLabel(data.status, data.stale_secs),
                  data.job_id ? ('job ' + escHtml(data.job_id.slice(-12))) : '',
                  data.status === 'error' ? '#dc2626' :
                  data.status === 'done'  ? '#16a34a' : null),
        _statCard('总目标', total, total === 0 ? '尚未加载' : ''),
        _statCard('已发送', `${done} / ${total}`, pct + '%'),
        _statCard('成功 / 失败', `${okC} / ${fail}`, fail > 0 ? '部分失败' : '',
                  fail > 0 ? '#d97706' : null),
    ].join('');

    document.getElementById('annBar').style.width = pct + '%';
    document.getElementById('annProgText').textContent = `进度 ${done}/${total} (${pct}%)`;
    document.getElementById('annStatusText').textContent =
        data.finished_at ? `结束于 ${fmtTs(data.finished_at)}` :
        (data.started_at ? `开始于 ${fmtTs(data.started_at)}` : '');

    // 错误表
    const errs = Array.isArray(data.errors) ? data.errors : [];
    document.getElementById('annErrCount').textContent = `(${errs.length})`;
    const tb = document.getElementById('annErrTbody');
    if (errs.length === 0) {
        tb.innerHTML = '<tr><td colspan="3" class="empty-hint">暂无失败</td></tr>';
    } else {
        tb.innerHTML = errs.slice(-50).reverse().map(e => `
            <tr>
                <td><code>${escHtml(String(e.db_id || ''))}</code></td>
                <td style="font-family:monospace;font-size:0.78rem;color:#555;">${escHtml(String(e.uid || ''))}</td>
                <td style="color:#b91c1c;">${escHtml(String(e.err || ''))}</td>
            </tr>
        `).join('');
    }

    // 决定下一次轮询
    const running = ['pending', 'loading', 'running'].includes(data.status);
    if (running) {
        _annTimer = setTimeout(() => refreshAnnounceProgress(false), 1000);
    } else {
        stopAnnouncePolling();   // done / error → 停
    }
}

function _annStatusLabel(s, stale) {
    const map = {
        'pending': '排队中',
        'loading': '加载目标',
        'running': '广播中',
        'done':    '已完成',
        'error':   '失败',
    };
    let label = map[s] || s || '--';
    if (s && ['pending', 'loading', 'running'].includes(s) && (stale || 0) > 30) {
        label += '（疑似僵死）';
    }
    return label;
}
</script>

<script>

// ═══════════════════════════════════════════════════════════════════
// v14.0 (2026-05-19) 520 抽奖管理
// ═══════════════════════════════════════════════════════════════════
let _l520CurSubTab = 'balance';

async function loadLottery520() {
    try {
        const data = await adminApi('lottery_520_list', { tab: _l520CurSubTab });
        // 更新统计
        const s = data.stats;
        document.getElementById('l520StatBalPending').textContent     = s.balance.pending;
        document.getElementById('l520StatBalPaid').textContent        = s.balance.paid;
        document.getElementById('l520StatCashPending').textContent    = s.cash.pending;
        document.getElementById('l520StatCashPaid').textContent       = s.cash.paid;
        document.getElementById('l520StatMilkteaPending').textContent = s.milktea.pending;
        document.getElementById('l520StatMilkteaPaid').textContent    = s.milktea.paid;
        document.getElementById('l520StatThanksTotal').textContent    = (s.thanks.pending + s.thanks.paid);

        renderLottery520Table(data.rows);
    } catch (e) {
        document.getElementById('l520TableWrap').innerHTML =
            '<div style="text-align:center; padding:40px; color:#c00;">加载失败:' + escHtml(e.message) + '</div>';
    }
}

function renderLottery520Table(rows) {
    if (!rows || !rows.length) {
        document.getElementById('l520TableWrap').innerHTML =
            '<div style="text-align:center; padding:60px; color:#aaa;">还没有这类中奖记录</div>';
        return;
    }
    const tab = _l520CurSubTab;
    let html = '<table><thead><tr>'
             + '<th>记录 #</th>'
             + '<th>用户</th>';
    if (tab === 'balance') {
        html += '<th>金额</th>';
    } else if (tab === 'cash') {
        html += '<th>金额</th><th>支付宝手机号</th><th>实名</th>';
    } else {
        html += '<th>中奖时间(凭证)</th>';
    }
    html += '<th>状态</th><th>操作</th></tr></thead><tbody>';

    for (const r of rows) {
        const isPaid = r.status === 'paid';
        html += `<tr class="${isPaid ? 'l520-paid' : ''}" data-id="${r.id}">`;
        html += `<td>#${r.id}</td>`;
        html += `<td><strong>${escHtml(r.username || '(已注销?)')}</strong>`
              + ` <span style="opacity:0.5; font-size:11px;">· uid=${r.user_id}</span></td>`;

        if (tab === 'balance') {
            html += `<td><span class="l520-badge l520-badge-type">¥${Number(r.prize_amount).toFixed(2)}</span>`
                  + ` <span style="opacity:0.6; font-size:11px; margin-left:6px;">${r.prize_type === 'balance_520' ? '520 档' : '188 档'}</span></td>`;
        } else if (tab === 'cash') {
            html += `<td><span class="l520-badge l520-badge-type">¥${Number(r.prize_amount).toFixed(2)}</span></td>`;
            if (r.phone) {
                html += `<td><span class="l520-phone">${escHtml(r.phone)}</span>`
                      + ` <button class="l520-copy-btn" onclick="l520Copy('${escHtml(r.phone)}')">复制</button></td>`;
            } else {
                html += `<td><span style="opacity:0.5;">未填</span></td>`;
            }
            if (r.realname) {
                html += `<td>${escHtml(r.realname)} <button class="l520-copy-btn" onclick="l520Copy('${escHtml(r.realname)}')">复制</button></td>`;
            } else {
                html += `<td><span style="opacity:0.5;">未填</span></td>`;
            }
        } else {
            html += `<td><span class="l520-phone">${escHtml(r.created_at)}</span>`
                  + `<div style="font-size:11px; opacity:0.6; margin-top:2px;">用户加群 1075389450 截图核对</div></td>`;
        }

        // 状态
        if (isPaid) {
            html += `<td><span class="l520-badge l520-badge-paid">已发放${r.paid_at ? ' · ' + escHtml(r.paid_at) : ''}</span></td>`;
        } else {
            html += `<td><span class="l520-badge l520-badge-pending">待处理</span></td>`;
        }

        // 操作
        html += '<td>';
        if (isPaid) {
            html += `<button class="btn btn-secondary" style="padding:4px 10px;font-size:11px;" onclick="markLottery520Unpaid(${r.id})">撤回</button>`;
        } else {
            if (tab === 'balance') {
                const amt = Number(r.prize_amount).toFixed(2);
                html += `<button class="btn btn-primary" style="padding:4px 12px;font-size:11px;" `
                      + `onclick="markLottery520Paid(${r.id}, '一键加余额 ¥${amt} 给 ${escHtml(r.username)}?')">一键加余额</button>`;
            } else if (tab === 'cash') {
                const disabled = (!r.phone || !r.realname) ? 'disabled title="用户还没填手机号/实名"' : '';
                html += `<button class="btn btn-primary" style="padding:4px 12px;font-size:11px;" ${disabled} `
                      + `onclick="markLottery520Paid(${r.id}, '确认已通过支付宝转账 ¥5.20 给 ${escHtml(r.phone || '')}?')">标记已转</button>`;
            } else {
                html += `<button class="btn btn-primary" style="padding:4px 12px;font-size:11px;" `
                      + `onclick="markLottery520Paid(${r.id}, '确认已发奶茶券给 ${escHtml(r.username)}?')">标记已发</button>`;
            }
        }
        html += '</td></tr>';
    }
    html += '</tbody></table>';
    document.getElementById('l520TableWrap').innerHTML = html;
}

function switchLottery520Sub(name) {
    _l520CurSubTab = name;
    document.querySelectorAll('.l520-subtab').forEach(t => {
        const active = t.dataset.sub === name;
        t.classList.toggle('active', active);
        t.style.color = active ? '#b04e5c' : '#888';
    });
    loadLottery520();
}

async function markLottery520Paid(id, confirmMsg) {
    if (!confirm(confirmMsg)) return;
    try {
        await adminApi('lottery_520_mark_paid', { id });
        showToast('已标记', 'info');
        loadLottery520();
    } catch (e) { showToast('失败: ' + e.message, 'error'); }
}

async function markLottery520Unpaid(id) {
    if (!confirm('撤回这条记录?如果是余额奖,会同步扣回用户余额。')) return;
    try {
        await adminApi('lottery_520_mark_unpaid', { id });
        showToast('已撤回', 'info');
        loadLottery520();
    } catch (e) { showToast('失败: ' + e.message, 'error'); }
}

function l520Copy(text) {
    navigator.clipboard.writeText(text).then(
        () => showToast('已复制: ' + text, 'info'),
        () => showToast('复制失败', 'error')
    );
}

// 在 switchTab 切到 lottery_520 时自动加载
(function() {
    const _origSwitchTab = window.switchTab;
    window.switchTab = function(name) {
        const ret = _origSwitchTab.apply(this, arguments);
        if (name === 'lottery_520') loadLottery520();
        return ret;
    };
})();
</script>
</body>
</html>
