"""
================================================================================
data/llm_protocol_anthropic.py · Anthropic /v1/chat/completions 协议适配器
================================================================================
2026-05-31  v2 重写:从 /v1/messages 原生协议改为 /v1/chat/completions
                  OpenAI 兼容层 (官方文档对齐, 不再自行拟造翻译规则)
2026-05-13  v1 初版,走 /v1/messages 原生协议(已废弃)

【为什么改】
之前 v1 走 Anthropic 原生 /v1/messages,本文件需要做两层翻译
  (a) 请求 OpenAI→Anthropic: messages/system/tools/image/tool_choice 全部要转
  (b) 响应 Anthropic→OpenAI: content blocks → choices[0].message
两边都是大段适配代码,易错且容易跟官方协议漂移。

Anthropic 官方提供了 OpenAI SDK 兼容层(/v1/chat/completions),格式跟 OpenAI
完全一致,绝大多数翻译代码可以删掉。本次重写对齐此官方端点。

【官方文档】(本次重写依据,所有规则都来自官方,不自创)
  https://platform.claude.com/docs/en/api/openai-sdk
  https://docs.anthropic.com/en/api/openai-sdk
  https://docs.claude.com/en/api/openai-sdk

【关键事实(官方文档原文)】
  端点:   POST https://api.anthropic.com/v1/chat/completions
  鉴权:   Authorization: Bearer <ANTHROPIC_API_KEY>
          ── 不再需要 x-api-key + anthropic-version
  请求体: 标准 OpenAI Chat Completions 格式
  响应:   标准 OpenAI choices[].message 格式

  字段支持(官方表格列出, 摘要):
    ✅ 支持: model, max_tokens, max_completion_tokens, stream, stream_options,
            top_p, parallel_tool_calls, stop, temperature(>1 截到1), n(=1),
            tools, tool_choice, messages[]
    ❌ Ignored(发了不报错但不生效):
            reasoning_effort   ← ⚠ 关键:OpenAI 通用的 reasoning_effort 在这里
                                  是被忽略的, 思考必须用 thinking 字段
            response_format    ← 用 native API 的 Structured Outputs 才能强 JSON
            presence_penalty, frequency_penalty, seed, logprobs, metadata,
            audio, logit_bias, store, user, modalities, prediction, service_tier
    ⚠ 限制:
            audio 输入直接被丢弃
            strict 函数调用约束被忽略(JSON schema 不保证)
            prompt caching 不支持(原生 API 才有)

  系统消息处理(官方原文):
    "system/developer messages are hoisted and concatenated to the beginning
     of the conversation, as Anthropic only supports a single initial system
     message. ... taken and concatenated together with a single newline (\\n)
     in between them"
    ── 兼容层自动处理, chat.py 在 messages[0] 放 system 即可, 多条会被拼起来

  扩展思考(官方原文):
    "enable extended thinking capabilities by adding the thinking parameter"
    OpenAI SDK 用 extra_body={"thinking": {"type":"enabled","budget_tokens":N}}
    raw JSON 里就是顶级 thinking 字段。
    ⚠ "the OpenAI SDK doesn't return Claude's detailed thought process"
       ── 思考会增强模型能力, 但响应里看不到 reasoning_content。
       想要详细思维链文本必须走原生 /v1/messages, 此适配器拿不到。

  图片(vision):
    用 OpenAI 标准 image_url 格式 — Anthropic 兼容层接受 data URI 和 http URL:
      {"type": "image_url",
       "image_url": {"url": "data:image/jpeg;base64,<b64>"}}
      {"type": "image_url",
       "image_url": {"url": "https://example.com/cat.jpg"}}
    chat.py 上游已经构造的就是这种格式, 直接透传即可。
    本文件额外做一个兼容: 如果上游误传了 Anthropic-native 的
    {"type":"image","source":{"type":"base64",...}} 块, 会反向翻译成 image_url。

【与 v1 (原生 /v1/messages) 的差异 — 全部本次去掉的复杂度】
  端点路径:    /v1/messages       →  /v1/chat/completions
  鉴权:        x-api-key 三件套   →  Authorization: Bearer (与 OpenAI 一致)
  system:      顶级字段           →  messages 数组里 role=system (自动 hoist)
  max_tokens:  必填(同 v1)
  工具协议:    Anthropic input_schema → OpenAI function.parameters
  tool 结果:   user.content[tool_result] → role=tool 标准 OpenAI
  图片格式:    image.source.base64 → image_url data URI
  响应:        content blocks 翻译 → 直通(已经是 OpenAI 形式)
  思维链返回:  thinking 块抽文本   →  ❌ 兼容层不返回, extract_reasoning 通常 None

【公开接口】(签名与 v1 完全一致, chat.py 0 改动)
  resolve_endpoint(model_endpoint, platform_endpoint)
  supports_thinking_by_prefix(model)
  build_headers(api_key)
  build_payload(model, messages, ..., supports_thinking=None)
  parse_response(resp_json)
  extract_reasoning(resp_json)
  assistant_message_for_replay(message)
================================================================================
"""
from __future__ import annotations
import re
from typing import Any


# ─────────────────────────────────────────────────────────────────────────────
# 思维链前缀兜底白名单
# 官方文档 Extended thinking 一节列出: 当前所有 Claude 4.x 与 3.7 Sonnet 支持
# thinking 字段。DB supports_thinking 字段缺失时回退此白名单。
# ─────────────────────────────────────────────────────────────────────────────
_THINKING_PREFIXES: tuple[str, ...] = (
    "claude-opus-4",      # 4.x 全系列 (4 / 4.1 / 4.5 / 4.6 / 4.7 / 4.8)
    "claude-sonnet-4",    # 4.x 全系列
    "claude-haiku-4",     # 4.5 起
    "claude-3-7-sonnet",  # 3.7 Sonnet
)


# ─────────────────────────────────────────────────────────────────────────────
# 端点选择 + 自动补全 (对齐 /v1/chat/completions)
# ─────────────────────────────────────────────────────────────────────────────
def resolve_endpoint(model_endpoint: str | None, platform_endpoint: str | None) -> str:
    """
    端点选择 + 自动补全 — Anthropic OpenAI 兼容层版本。

    规则:
      1. 模型自有端点优先, 否则用全局兜底
      2. 自动补全:
         - 已经以 /chat/completions 结尾  → 不动
         - 以 /messages 结尾(旧 v1 配置) → 自动替换为 /chat/completions
                                            (本次协议改版的迁移路径)
         - 剥尾部 / 后以 /v1 结尾         → 补 /chat/completions
         - 其他形式                       → 视为特殊端点, 原样返回

    例:
      "https://api.anthropic.com/v1"          → "https://api.anthropic.com/v1/chat/completions"
      "https://api.anthropic.com/v1/messages" → "https://api.anthropic.com/v1/chat/completions"
                                                 ↑ 自动迁移旧配置
      "https://api.anthropic.com/v1/chat/completions" → 原样
      "https://yunwu.ai/anthropic/v1"         → "https://yunwu.ai/anthropic/v1/chat/completions"
    """
    raw = (model_endpoint or "").strip() or (platform_endpoint or "").strip()
    if not raw:
        return ""
    if raw.endswith("/chat/completions"):
        return raw
    # 旧 v1 (Anthropic 原生 /v1/messages) 配置自动迁移到 OpenAI 兼容层
    if raw.endswith("/messages"):
        return raw[: -len("/messages")] + "/chat/completions"
    stripped = raw.rstrip("/")
    if stripped.endswith("/v1"):
        return stripped + "/chat/completions"
    return raw


def supports_thinking_by_prefix(model: str) -> bool:
    """模型是否支持扩展思考 — DB 字段缺失时回退前缀匹配。"""
    model_lower = (model or "").lower().strip()
    return any(
        model_lower == p or model_lower.startswith(p)
        for p in _THINKING_PREFIXES
    )


# ─────────────────────────────────────────────────────────────────────────────
# 请求头 — OpenAI 兼容层使用标准 Bearer 鉴权
# ─────────────────────────────────────────────────────────────────────────────
def build_headers(api_key: str) -> dict:
    """
    Anthropic /v1/chat/completions 鉴权头(与 OpenAI 完全一致):
      Authorization: Bearer <key>
      Content-Type: application/json

    ⚠ 不再使用 x-api-key + anthropic-version — 那是原生 /v1/messages 才需要。
    """
    return {
        "Authorization": f"Bearer {api_key or ''}",
        "Content-Type": "application/json",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 内部:图片内容块标准化 (Anthropic-native → OpenAI image_url 兜底)
# ─────────────────────────────────────────────────────────────────────────────
_DATA_URI_RE = re.compile(r"^data:(image/[a-zA-Z0-9.+-]+);base64,(.+)$", re.DOTALL)


def _normalize_image_block(blk: dict) -> dict:
    """
    把任意图像块统一成 OpenAI 标准 image_url 格式。

    输入可能形态:
      OpenAI 原生(chat.py 上游正常构造的):
        {"type": "image_url", "image_url": {"url": "data:image/...;base64,..."}}
        {"type": "image_url", "image_url": {"url": "https://..."}}
      Anthropic-native(老 v1 残留, 或上游误传):
        {"type": "image", "source": {"type": "base64",
                                     "media_type": "image/jpeg",
                                     "data": "<base64>"}}
        {"type": "image", "source": {"type": "url",
                                     "url": "https://..."}}

    输出: 统一的 OpenAI image_url 块, 兼容层认得。
    """
    if not isinstance(blk, dict):
        return blk

    # 已经是 OpenAI 格式 → 直接返回
    if blk.get("type") == "image_url":
        return blk

    # Anthropic-native image → 反向翻译
    if blk.get("type") == "image":
        src = blk.get("source") or {}
        src_type = src.get("type")
        if src_type == "base64":
            media_type = src.get("media_type") or "image/jpeg"
            data = src.get("data") or ""
            return {
                "type": "image_url",
                "image_url": {"url": f"data:{media_type};base64,{data}"},
            }
        if src_type == "url":
            return {
                "type": "image_url",
                "image_url": {"url": src.get("url") or ""},
            }

    return blk


def _normalize_message_content(content: Any) -> Any:
    """
    标准化 messages[i].content:
      - 字符串 → 原样
      - list[block] → 对每个 block, 如果是图像块(image/image_url)走
        _normalize_image_block, 其他块原样保留
      - 其他(None 等) → 原样

    其他块(text/tool_result/refusal/...) 不动 — OpenAI SDK 兼容层认 OpenAI 标准格式,
    chat.py 上游本来就构造的就是 OpenAI 标准, 直接透传。
    """
    if isinstance(content, list):
        return [_normalize_image_block(b) if isinstance(b, dict) else b
                for b in content]
    return content


def _normalize_messages(messages: list) -> list:
    """
    把 chat.py 维护的 messages 数组标准化为 OpenAI 兼容层认得的形态。

    主要工作:
      1. 图片块格式纠偏(Anthropic-native → image_url)
      2. 丢掉 _anthropic_content 内部字段(本协议不再使用 Anthropic 原生 content 块)
      3. 丢掉 reasoning_content / thinking 等思考字段
         ── 兼容层不返回思考块, 也不接受历史思考块回放, 与 OpenAI 协议一致

    其他字段(role/content/tool_calls/tool_call_id/name)全部透传。
    """
    out = []
    for msg in messages:
        if not isinstance(msg, dict):
            continue

        # 只保留 OpenAI 标准字段, 丢掉 Anthropic 原生残留字段
        cleaned: dict = {}
        for key in ("role", "content", "tool_calls", "tool_call_id", "name", "refusal"):
            if key in msg:
                cleaned[key] = msg[key]

        # 标准化 content 里的图像块
        if "content" in cleaned:
            cleaned["content"] = _normalize_message_content(cleaned["content"])

        out.append(cleaned)
    return out


# ─────────────────────────────────────────────────────────────────────────────
# 请求体构造
# ─────────────────────────────────────────────────────────────────────────────
def build_payload(
    model: str,
    messages: list,
    temperature: float = 0.9,
    presence_penalty: float = 0.4,    # 兼容层 Ignored, 不下发
    frequency_penalty: float = 0.5,   # 兼容层 Ignored, 不下发
    tools: list | None = None,
    enable_thinking: bool = True,
    supports_thinking: bool | None = None,
    tool_choice: str | dict | None = None,
    prompt_cache_key: str | None = None,  # Anthropic /v1/chat/completions 不支持, 不下发
) -> dict:
    """
    构造 /v1/chat/completions 请求体(对齐 Anthropic OpenAI 兼容层官方文档)。

    参数(与 OpenAI 适配器同签名, chat.py 无需改动调用方):
      model              Claude 模型名 (claude-opus-4-8, claude-sonnet-4-6, ...)
      messages           OpenAI 风格 messages 数组(role/content/tool_calls/...)
                          ── system 消息放在数组里即可, 兼容层会自动 hoist 拼接
      temperature        采样温度。注意 >1 会被兼容层截到 1。
      presence_penalty   ⚠ 官方文档明确 Ignored, 本函数不下发
      frequency_penalty  ⚠ 官方文档明确 Ignored, 本函数不下发
      tools              OpenAI function calling tools, 透传
      enable_thinking    实例层面是否启用扩展思考
      supports_thinking  模型层面是否支持思考(DB 字段, None 走前缀兜底)
      tool_choice        OpenAI tool_choice, 透传 ("none"/"auto"/"required"/{...})

    思维链(extended thinking)下发规则:
      官方文档原文: 通过 thinking={"type":"enabled","budget_tokens":N} 启用。
        - budget_tokens 必须 ≥1024 且 < max_tokens
        - 启用时 max_tokens 抬到 16384 (budget 8192 + 输出 8192)
        - 启用时 temperature 强制 1.0 (Anthropic 限制 thinking 模式)

      ⚠ 不要下发 reasoning_effort —— 官方明确 Ignored, 发了没用还占字节。
      ⚠ 兼容层不返回思考内容 —— enable_thinking=True 能提升模型能力,
         但 extract_reasoning() 抽不到文本。要看思维链请用原生 /v1/messages。

    不下发的字段(官方文档列为 Ignored, 发了浪费 token):
      reasoning_effort, response_format, presence_penalty, frequency_penalty,
      seed, logprobs, metadata, store, user, modalities, top_logprobs,
      service_tier, prediction, audio, logit_bias
    """
    # 模型层是否支持思考: DB 字段优先, 缺失则前缀白名单兜底
    if supports_thinking is None:
        model_supports_thinking = supports_thinking_by_prefix(model)
    else:
        model_supports_thinking = bool(supports_thinking)

    # temperature 兼容层会截到 1, 这里提前 clamp 避免无意义的请求体差异
    temp_safe = float(temperature)
    if temp_safe > 1.0:
        temp_safe = 1.0
    if temp_safe < 0.0:
        temp_safe = 0.0

    payload: dict = {
        "model": model,
        "messages": _normalize_messages(messages),
        "temperature": temp_safe,
    }

    # 默认 max_tokens (Anthropic 必填, 不下发会被拒)
    max_tokens = 8192

    # 扩展思考开关 — 官方文档原文格式 thinking={type:enabled, budget_tokens:N}
    if model_supports_thinking and enable_thinking:
        # budget_tokens 必须 < max_tokens, 这里 8192 + 8192 = 16384 正好分两半
        payload["thinking"] = {"type": "enabled", "budget_tokens": 8192}
        max_tokens = 16384
        # 官方文档: thinking 启用时 temperature 必须 1.0
        payload["temperature"] = 1.0

    payload["max_tokens"] = max_tokens

    # 工具透传 (OpenAI 标准格式 — 与 OpenAI Chat Completions 完全一致)
    if tools:
        payload["tools"] = tools
        # tool_choice 透传 — OpenAI 兼容层认 OpenAI 标准:
        #   "auto" / "none" / "required"
        #   {"type":"function","function":{"name":"X"}}
        # None 时不下发, 让默认 auto 行为生效, 同时避免触发缓存失效
        if tool_choice is not None:
            payload["tool_choice"] = tool_choice

    # ⚠ 不下发 presence_penalty/frequency_penalty/reasoning_effort —
    #    官方文档明确这些字段 Ignored。
    _ = presence_penalty   # 显式忽略, 防 linter 报参数未使用
    _ = frequency_penalty

    # 2026-07-12: prompt_cache_key 同样不下发。本文件开头 docstring 已经
    # 引用官方文档确认 —— /v1/chat/completions 兼容层不支持 prompt caching
    # (原生 /v1/messages 才有, 走的是 cache_control 显式断点机制, 跟 OpenAI
    # 这种 hash 前缀 + prompt_cache_key 的自动缓存完全是两套不同设计)。
    # 这里只是接收该参数以保持跟 llm_protocol_openai.build_payload 同签名,
    # 让 chat.py 能对两个协议无差别调用, 不需要 if m_protocol=="anthropic"
    # 这种分支。
    _ = prompt_cache_key

    return payload


# ─────────────────────────────────────────────────────────────────────────────
# 响应解析:OpenAI 兼容层返回的就是 OpenAI 格式, 基本直通
# ─────────────────────────────────────────────────────────────────────────────
def parse_response(resp_json: dict) -> dict:
    """
    /v1/chat/completions 响应解析。

    兼容层返回标准 OpenAI Chat Completions 结构:
      {
        "id": "msg_...",
        "object": "chat.completion",
        "created": <unix_ts>,
        "model": "claude-...",
        "choices": [{
            "index": 0,
            "message": {
                "role": "assistant",
                "content": "正文 / null",
                "tool_calls": [{
                    "id": "...",
                    "type": "function",
                    "function": {"name": "...", "arguments": "<JSON 串>"}
                }]
            },
            "finish_reason": "stop"|"tool_calls"|"length"|...
        }],
        "usage": {
            "prompt_tokens": N,
            "completion_tokens": M,
            "total_tokens": N+M
        }
      }

    本函数职责:
      1. 主路径 — 已经是 OpenAI 结构, 几乎直通, 仅做轻量字段补全
      2. 兜底 — 万一上游返了 Anthropic-native(老 yunwu 代理 / 配置错路由),
         也能把 content blocks 翻译成 choices 形式，供 chat.py 统一校验

    chat.py 拿到的永远是 OpenAI choices 形式。
    """
    if not isinstance(resp_json, dict):
        return {
            "choices": [{"message": {"role": "assistant", "content": ""},
                         "finish_reason": None}],
            "usage": {},
        }

    # 主路径: 已经是 OpenAI Chat Completions 格式 → 直通
    if "choices" in resp_json:
        # 透传, 但保证 usage 是 dict (chat.py 计费逻辑要读它)
        if not isinstance(resp_json.get("usage"), dict):
            resp_json = dict(resp_json)
            resp_json["usage"] = {}
        return resp_json

    # 兜底路径: Anthropic-native content blocks 格式 (理论不应出现 ——
    # 兼容层端点不会返回这种格式 —— 但旧 yunwu/litellm 代理可能转发原生响应,
    # 这里防御性翻译, 避免 chat.py 在 /v1/chat/completions 路由下也能拿到
    # 已知响应 → OpenAI choices 形态)
    content_blocks = resp_json.get("content") or []
    if isinstance(content_blocks, list) and content_blocks:
        text_parts: list[str] = []
        thinking_parts: list[str] = []
        tool_calls: list[dict] = []
        import json as _json
        for blk in content_blocks:
            if not isinstance(blk, dict):
                continue
            t = blk.get("type")
            if t == "text":
                tx = blk.get("text", "")
                if isinstance(tx, str):
                    text_parts.append(tx)
            elif t == "thinking":
                th = blk.get("thinking", "")
                if isinstance(th, str):
                    thinking_parts.append(th)
            elif t == "tool_use":
                tool_calls.append({
                    "id": blk.get("id") or "",
                    "type": "function",
                    "function": {
                        "name": blk.get("name") or "",
                        "arguments": _json.dumps(
                            blk.get("input") or {}, ensure_ascii=False
                        ),
                    },
                })
        message: dict = {
            "role": "assistant",
            "content": "\n".join(text_parts).strip(),
        }
        if tool_calls:
            message["tool_calls"] = tool_calls
        if thinking_parts:
            message["reasoning_content"] = "\n".join(thinking_parts).strip()

        usage_anth = resp_json.get("usage") or {}
        in_t = int(usage_anth.get("input_tokens", 0) or 0)
        out_t = int(usage_anth.get("output_tokens", 0) or 0)
        return {
            "choices": [{
                "message": message,
                "finish_reason": resp_json.get("stop_reason"),
            }],
            "usage": {
                "prompt_tokens": in_t,
                "completion_tokens": out_t,
                "total_tokens": in_t + out_t,
            },
            "stop_reason": resp_json.get("stop_reason"),
        }

    # 完全无法识别的结构 — 返回最小有效形态让 chat.py 走重试
    return {
        "choices": [{"message": {"role": "assistant", "content": ""},
                     "finish_reason": None}],
        "usage": {},
    }


def extract_reasoning(resp_json: dict) -> str | None:
    """
    从响应抽思维链文本。

    ⚠ 官方文档明确: /v1/chat/completions 兼容层"不返回 Claude 的详细思维过程"。
       所以大多数情况此函数返回 None — 即便 thinking 是开启的。
       想拿到思维链文本必须走原生 /v1/messages(本适配器不再支持)。

    本函数仍保留:
      1. 兜底 — 部分第三方代理(litellm/openrouter)会把思考块塞进
         choices[0].message.reasoning_content, 这里能抽出来
      2. parse_response 兜底分支翻译时塞的 reasoning_content
    """
    if not isinstance(resp_json, dict):
        return None
    # 1) OpenAI 形式 — choices[0].message.reasoning_content / reasoning / thinking
    try:
        msg = resp_json["choices"][0]["message"]
        if isinstance(msg, dict):
            for key in ("reasoning_content", "reasoning", "thinking", "thought"):
                v = msg.get(key)
                if isinstance(v, str) and v.strip():
                    return v
                if isinstance(v, dict):
                    inner = v.get("content") or v.get("text") or v.get("thinking")
                    if isinstance(inner, str) and inner.strip():
                        return inner
    except (KeyError, IndexError, TypeError):
        pass
    return None


# ─────────────────────────────────────────────────────────────────────────────
# 多轮工具循环:回放 assistant 消息
# ─────────────────────────────────────────────────────────────────────────────
def assistant_message_for_replay(message: dict) -> dict:
    """
    把 LLM 响应里的 assistant message 转成 messages 列表里可回放的格式。

    ⚠ 与 OpenAI 协议保持一致:不回放 reasoning_content / thinking 等字段。
       原因:
       1. /v1/chat/completions 兼容层本来就不返回思考块, 拿不到也没法回放
       2. 即便用 parse_response 兜底翻译填了 reasoning_content, 历史 assistant
          轮里带这个字段会让某些聚合层判定"思考已经给过了", 下一轮跳过思考 ——
          表现为"第二轮思维链永远空"(OpenAI 适配器修过的同款 bug)
       3. OpenAI 官方语义: o系思考是服务端的, 不应在后续请求里回放;
          Anthropic 兼容层走的就是 OpenAI 语义, 同理。

    返回的 dict 进入 chat.py 维护的 messages 数组, 下次 build_payload 时被
    _normalize_messages 标准化后下发。
    """
    if not isinstance(message, dict):
        return {"role": "assistant", "content": ""}

    content = message.get("content")
    tool_calls = message.get("tool_calls") or []

    # content 可以是 None(只有 tool_calls 时), OpenAI 协议允许
    replay = {
        "role": "assistant",
        "content": content if (content is None or isinstance(content, str)) else None,
    }
    if tool_calls:
        replay["tool_calls"] = tool_calls

    # ⚠ 不回放 reasoning_content / reasoning / thinking / thought / _anthropic_content
    # 详见函数 docstring 的解释。
    return replay
