"""
wechat_poller.py — 严格对齐 openclaw-weixin@2.4.2 spec 的长轮询消息接收器

参考文档:
  - package_all_code.md, monitor.ts
  - 接口路径:    /ilink/bot/getupdates
  - 常量来源:    monitor.ts L6126-L6129

核心 spec (与之前 main.py 内嵌实现的关键差异):
  1. 客户端 ReadTimeout = **正常长轮询超时**,不计入失败
     (官方: AbortError → return {ret:0, msgs:[]} → 直接重试)
  2. 使用 resp.longpolling_timeout_ms 动态调整下一次 timeout
  3. 检查 resp.ret 与 resp.errcode (HTTP 200 不代表业务成功)
  4. errcode == -14 (SESSION_EXPIRED) 单独处理 — 停止轮询,触发重新扫码
  5. 失败 3 次连续 → backoff 30s;否则 backoff 2s
  6. 请求头: Content-Type, AuthorizationType, X-WECHAT-UIN, Authorization
  7. body.base_info.channel_version = "2.4.2"

接口:
  poller = WeChatPoller(client, base_url, token, initial_buf, db_id, ...)
  stop_reason = await poller.run()
  # stop_reason ∈ {"normal", "token_invalid", "session_expired"}
"""
import asyncio
import random
import time
import httpx

from typing import Any, Awaitable, Callable, Optional


# ── 官方常量(monitor.ts L6126-6129, types.ts L2106, package.json) ──
DEFAULT_LONG_POLL_TIMEOUT_MS = 35_000
MAX_CONSECUTIVE_FAILURES     = 3
BACKOFF_DELAY_MS             = 30_000
RETRY_DELAY_MS               = 2_000
SESSION_EXPIRED_ERRCODE      = -14
CHANNEL_VERSION              = "2.4.2"   # 与 npm package openclaw-weixin 版本同步

# ── 客户端 timeout 余量 ──
# 服务端 hold N ms 后返回空响应;客户端 timeout 必须 > N + 网络 RTT,
# 否则客户端先 abort 会留下半连接。给 5s 余量。
CLIENT_TIMEOUT_MARGIN_S = 5.0

# ── 停止原因 ──
STOP_NORMAL          = "normal"            # is_running 变 False
STOP_TOKEN_INVALID   = "token_invalid"     # 401 且确认是当前 token
STOP_SESSION_EXPIRED = "session_expired"   # errcode == -14
STOP_CLIENT_DEAD     = "client_dead"       # v?? (2026-05-18) httpx client 被外部
                                            # aclose 后,poller.client 仍指向旧(已关)
                                            # client 形成僵尸。退出后由 main.py
                                            # run_loop 的 respawn 机制(L2236)
                                            # 用当前 BotInstance.client(新 client)
                                            # 重建 poller。


def _random_wechat_uin() -> str:
    """匹配官方 randomWechatUin() — 10 位随机数字字符串。"""
    return str(random.randint(10**9, 10**10 - 1))


class WeChatPoller:
    """
    长轮询消息接收器。每个 BotInstance 一次只跑一个 WeChatPoller。

    构造参数全部必填,失败处理通过 callback 解耦:
      - on_messages(msgs):         收到一批消息时触发(msgs 为官方 WeixinMessage 列表)
      - on_buf_advance(new_buf):   游标推进时触发,调用方负责持久化到 DB
      - on_token_invalid():        401 时触发,返回 bool — True=真失效需清 token,
                                    False=DB 已有新 token,直接退出
      - on_log(text):              写实例日志(fire-and-forget,不应抛异常)
      - on_client_reset(reason):   连接池失效时调用方重建 httpx client(可选)

    callback 均为 async。WeChatPoller 不直接 import utils/db,保持纯净。
    """

    def __init__(
        self,
        *,
        client: httpx.AsyncClient,
        base_url: str,
        token: str,
        initial_buf: str,
        db_id: int,
        is_running: Callable[[], bool],
        on_messages: Callable[[list], Awaitable[None]],
        on_buf_advance: Callable[[str], Awaitable[None]],
        on_token_invalid: Callable[[], Awaitable[bool]],
        on_log: Callable[[str], Awaitable[None]],
        on_client_reset: Optional[Callable[[str], Awaitable[None]]] = None,
    ):
        self.client          = client
        self.base_url        = base_url.rstrip('/')
        self.token           = token
        self.buf             = initial_buf or ""
        self.db_id           = db_id
        self._is_running     = is_running
        self.on_messages     = on_messages
        self.on_buf_advance  = on_buf_advance
        self.on_token_invalid = on_token_invalid
        self.on_log          = on_log
        self.on_client_reset = on_client_reset

        # 运行时状态
        self._next_timeout_ms : int           = DEFAULT_LONG_POLL_TIMEOUT_MS
        self._consec_failures : int           = 0
        self._last_log_kind   : Optional[str] = None
        self._started_at      : float         = 0.0

    # ─── 私有辅助 ──────────────────────────────────────────────────────

    def _headers(self) -> dict:
        """匹配 monitor.ts buildHeaders()。"""
        return {
            "Content-Type":      "application/json",
            "AuthorizationType": "ilink_bot_token",
            "X-WECHAT-UIN":      _random_wechat_uin(),
            "Authorization":     f"Bearer {self.token}",
        }

    def _body(self) -> dict:
        """匹配 monitor.ts getUpdates 请求体。"""
        return {
            "get_updates_buf": self.buf,
            "base_info":       {"channel_version": CHANNEL_VERSION},
        }

    def _client_timeout(self) -> httpx.Timeout:
        """根据服务端建议的 longpolling_timeout_ms 构造 httpx Timeout。

        关键:只把 read 设为长 timeout,connect/write/pool 保持短。
        否则一旦 connect 阶段卡住 35s 才报错,会显著拖慢恢复。
        """
        read_s = (self._next_timeout_ms / 1000.0) + CLIENT_TIMEOUT_MARGIN_S
        return httpx.Timeout(read=read_s, connect=15.0, write=10.0, pool=10.0)

    async def _log_once(self, kind: str, msg: str) -> None:
        """连续同类日志去重打印,避免一旦异常洪水般刷屏。"""
        if kind != self._last_log_kind:
            print(f"[poll] db_id={self.db_id} {msg}", flush=True)
            try:
                await self.on_log(f"[监听] {msg[:200]}")
            except Exception:
                pass
            self._last_log_kind = kind

    async def _on_failure(self, kind: str, msg: str) -> None:
        """
        失败时计数 + 退避。
        匹配官方 monitor.ts L6188-6199 / L6236-6247。
        """
        self._consec_failures += 1
        await self._log_once(
            kind,
            f"{msg} ({self._consec_failures}/{MAX_CONSECUTIVE_FAILURES})"
        )
        if self._consec_failures >= MAX_CONSECUTIVE_FAILURES:
            await self._log_once(
                "backoff",
                f"连续 {MAX_CONSECUTIVE_FAILURES} 次失败,退避 {BACKOFF_DELAY_MS // 1000}s"
            )
            self._consec_failures = 0
            await asyncio.sleep(BACKOFF_DELAY_MS / 1000.0)
        else:
            await asyncio.sleep(RETRY_DELAY_MS / 1000.0)

    async def _on_success(self) -> None:
        """成功一次时重置失败计数 + 异常日志去重缓存。"""
        if self._consec_failures > 0:
            await self._log_once(
                "recovered",
                f"长轮询已恢复(之前连续 {self._consec_failures} 次失败)"
            )
            self._consec_failures = 0
        self._last_log_kind = None

    # ─── 主循环 ──────────────────────────────────────────────────────────

    async def run(self) -> str:
        """
        阻塞运行直到 is_running() 变 False 或致命错误。
        返回值:
          "normal"          — is_running 变 False
          "token_invalid"   — 401 且 on_token_invalid() 返回 True
          "session_expired" — errcode == -14
        """
        self._started_at = time.time()
        await self.on_log(
            f"[监听] WeChatPoller 启动 token=***{self.token[-4:]} "
            f"buf_len={len(self.buf)} long_poll={self._next_timeout_ms}ms"
        )

        url = f"{self.base_url}/getupdates"

        while self._is_running():
            # ── 1. 发出 POST,捕获各类网络异常 ───────────────────────────
            try:
                res = await self.client.post(
                    url,
                    json=self._body(),
                    headers=self._headers(),
                    timeout=self._client_timeout(),
                )
            except httpx.ReadTimeout:
                # ★ 官方 spec: 客户端 timeout = 正常长轮询超时,不计入失败
                #   等价于 monitor.ts L1918-1921 的 AbortError 分支:
                #     return { ret: 0, msgs: [], get_updates_buf: previous };
                #   → 直接重试,buf 不变
                continue
            except (httpx.ConnectError, httpx.ConnectTimeout, httpx.PoolTimeout) as e:
                await self._on_failure("conn", f"连接失败 {type(e).__name__}: {e}")
                continue
            except (httpx.RemoteProtocolError, httpx.WriteError) as e:
                # 协议层错误:连接池可能已脏,触发外部重建
                await self._on_failure("proto", f"协议错误 {type(e).__name__}: {e}")
                if self.on_client_reset:
                    try:
                        await self.on_client_reset(f"{type(e).__name__}")
                    except Exception:
                        pass
                    # v?? (2026-05-18) 关键修复:on_client_reset 在 BotInstance 层
                    # 把 self.client 替换成新对象,但本 poller 的 self.client 引用
                    # 仍指向旧的(已 aclose)client(Python 引用,不会自动跟随)。
                    # 继续循环会导致下一轮 .post() 抛 RuntimeError 永远刷屏,
                    # 实例彻底听不到入向消息。
                    # 退出本协程,BotInstance.run_loop 的 msg_task.done() 检测后
                    # 自动用最新的 self.client 重启 _message_loop + 新 poller。
                    return STOP_CLIENT_DEAD
                continue
            except asyncio.CancelledError:
                raise
            except Exception as e:
                # v?? (2026-05-18) 兜底:RuntimeError("Cannot send a request, as
                # the client has been closed") 会落入这里。这是上一轮 on_client_reset
                # 已被调用但 poller.self.client 没跟着换的后果(理论上被上面的
                # RemoteProtocolError 分支提前 return 拦掉,这里是双保险)。
                if isinstance(e, RuntimeError) and "client has been closed" in str(e):
                    await self._on_failure(
                        "client_closed",
                        "httpx client 已关闭,退出本协程等待 BotInstance 重建"
                    )
                    return STOP_CLIENT_DEAD
                import traceback as _tb
                _tb.print_exc()
                await self._on_failure("unknown", f"未预料异常 {type(e).__name__}: {e}")
                continue

            # ── 2. HTTP 层处理 ─────────────────────────────────────────
            sc = res.status_code

            if sc == 401:
                # 401 → 由调用方判断是真失效还是旧实例残留(DB 已有新 token)
                really_invalid = True
                try:
                    really_invalid = bool(await self.on_token_invalid())
                except Exception:
                    pass
                if really_invalid:
                    await self.on_log("[监听] token 失效(401),停止轮询等待重新登录")
                    return STOP_TOKEN_INVALID
                # 旧实例残留 — DB 已有新 token,本协程直接退出
                await self.on_log("[监听] 401 但 DB 已换 token,本协程为旧实例,退出")
                return STOP_NORMAL

            if 500 <= sc < 600:
                await self._on_failure(f"http_{sc}", f"服务器 HTTP {sc}(可能在维护)")
                continue

            if sc != 200:
                await self._on_failure(
                    f"http_{sc}",
                    f"非预期 HTTP {sc}: {res.text[:200]!r}"
                )
                continue

            # ── 3. 解析 JSON ───────────────────────────────────────────
            try:
                data = res.json()
            except Exception as e:
                await self._on_failure(
                    "json",
                    f"JSON 解析失败 {type(e).__name__}: {e},原文前 200 字: {res.text[:200]!r}"
                )
                continue

            # ── 4. 业务层错误检查 (monitor.ts L6175-6201) ─────────────
            ret     = data.get("ret",     0)
            errcode = data.get("errcode", 0)
            errmsg  = data.get("errmsg",  "") or ""
            is_api_error = (ret not in (0, None)) or (errcode not in (0, None))

            if is_api_error:
                # 会话过期:停止轮询,让上层走重扫码流程
                if ret == SESSION_EXPIRED_ERRCODE or errcode == SESSION_EXPIRED_ERRCODE:
                    await self.on_log(
                        f"[监听] 会话过期 ret={ret} errcode={errcode},停止轮询等待重新登录"
                    )
                    return STOP_SESSION_EXPIRED
                await self._on_failure(
                    f"api_{ret}_{errcode}",
                    f"业务错误 ret={ret} errcode={errcode} msg={errmsg}"
                )
                continue

            # ── 5. 成功路径 ───────────────────────────────────────────
            # 5.1 更新下次 timeout (monitor.ts L6171-6174)
            new_timeout = data.get("longpolling_timeout_ms")
            if isinstance(new_timeout, (int, float)) and new_timeout > 0:
                self._next_timeout_ms = int(new_timeout)

            # 5.2 重置失败状态
            await self._on_success()

            # 5.3 推进游标 (monitor.ts L6204-6208)
            new_buf = data.get("get_updates_buf")
            if isinstance(new_buf, str) and new_buf and new_buf != self.buf:
                self.buf = new_buf
                try:
                    await self.on_buf_advance(new_buf)
                except Exception as e:
                    print(
                        f"[poll] db_id={self.db_id} on_buf_advance 异常: "
                        f"{type(e).__name__}: {e}", flush=True
                    )

            # 5.4 派发消息 (monitor.ts L6209-6228)
            msgs = data.get("msgs") or []
            if msgs:
                try:
                    await self.on_messages(msgs)
                except Exception as e:
                    import traceback as _tb
                    _tb.print_exc()
                    print(
                        f"[poll] db_id={self.db_id} on_messages 异常: "
                        f"{type(e).__name__}: {e}", flush=True
                    )

        return STOP_NORMAL