"""config.py — 语音通话 WebSocket 服务配置 (硬编码版, 调试用).

为了排除环境变量没正确传入的问题, 关键 key 直接写在文件里.
环境变量仍然优先 — 一旦想用环境变量, 改回 export 即可.
"""
import asyncio
import os

# ── 进程级锁: TTS SDK 仍从 dashscope.api_key 模块全局读取 key，必须保护
#    “设置 api_key → 同步合成”这个组合。ASR 已改用实例级 api_key，不再参与此锁。
DASHSCOPE_KEY_LOCK = asyncio.Lock()


def _env(key: str, default: str = '') -> str:
    return os.environ.get(key, default)


def _env_int(key: str, default: int) -> int:
    v = os.environ.get(key, '')
    try:
        return int(v) if v else default
    except ValueError:
        return default


# ============================================================
# 硬编码 (调试用; 上线后建议改回环境变量)
# ============================================================
# 与 A 端 api_voice_call.php 的 VOICE_WS_SECRET 必须完全一致!
WS_SECRET = _env('VOICE_WS_SECRET') or 'REMOVED_WS_SECRET'

# DashScope API key
DASHSCOPE_API_KEY = _env('DASHSCOPE_API_KEY') or 'sk-REMOVED-ROTATE-THIS-KEY'
# ============================================================


# ─── 监听 (nginx 反代到这里; 推荐 127.0.0.1) ──────────────────────────────
WS_HOST = _env('VOICE_WS_HOST', '127.0.0.1')
WS_PORT = _env_int('VOICE_WS_PORT', 5000)

# ─── 并发上限 / 空闲超时 ─────────────────────────────────────────────────
MAX_CONNECTIONS  = _env_int('VOICE_MAX_CONNECTIONS', 100)
IDLE_TIMEOUT_SEC = _env_int('VOICE_IDLE_TIMEOUT', 120)

# ─── ASR / TTS 模型 ───────────────────────────────────────────────────────
ASR_MODEL    = _env('VOICE_ASR_MODEL', 'qwen3-asr-flash-realtime')
ASR_WS_URL   = _env('VOICE_ASR_WS_URL',
                    'wss://dashscope.aliyuncs.com/api-ws/v1/realtime')
ASR_LANGUAGE = _env('VOICE_ASR_LANGUAGE', 'zh')

TTS_MODEL       = _env('VOICE_TTS_MODEL', 'cosyvoice-v3.5-plus')
TTS_WS_BASE_URL = _env('VOICE_TTS_WS_URL',
                       'wss://dashscope.aliyuncs.com/api-ws/v1/inference')

# ─── 标识 ────────────────────────────────────────────────────────────────
SERVER_NAME = _env('VOICE_SERVER_NAME', 'voice-prod-01')


def assert_ready() -> None:
    """启动自检 — 缺关键配置抛 RuntimeError, main.py 那边会捕获并打警告."""
    missing = []
    if not WS_SECRET or WS_SECRET.startswith('CHANGE_ME'):
        missing.append('WS_SECRET (config.py 顶部硬编码或 export VOICE_WS_SECRET)')
    if not DASHSCOPE_API_KEY:
        missing.append('DASHSCOPE_API_KEY (config.py 顶部硬编码或 export)')
    if missing:
        raise RuntimeError('配置缺失:\n  - ' + '\n  - '.join(missing))
