"""Weixin iLink media helpers aligned with Tencent/openclaw-weixin.

The wire format deliberately follows the official plugin implementation:
AES-128-ECB with PKCS7 padding, ``no_need_thumb=true``, CDN POST upload,
and ``base64(utf8(hex(aes_key)))`` in outbound media messages.
"""
from __future__ import annotations

import asyncio
import base64
import binascii
import hashlib
import os
import random
import re
import time
import urllib.parse
from dataclasses import dataclass
from typing import Any

import httpx
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

import utils


API_BASE_URL = "https://ilinkai.weixin.qq.com"
CDN_BASE_URL = "https://novac2c.cdn.weixin.qq.com/c2c"
APP_VERSION = "2.4.6"
CLIENT_VERSION = str((2 << 16) | (4 << 8) | 6)
APP_ID = "bot"
# Tencent/openclaw-weixin 当前默认值；仅用于可观测性，不参与鉴权或路由。
BOT_AGENT = "OpenClaw"
MAX_IMAGE_BYTES = 25 * 1024 * 1024
CDN_UPLOAD_ATTEMPTS = 3
# context_token 只能由用户上行消息刷新。官方仓库的实测问题表明它会在
# 长时间无上行后失效；主动消息提前留出安全余量，避免调用模型后才发现
# 微信已经不允许向该会话下发。
PROACTIVE_CONTEXT_MAX_AGE_SECONDS = 36 * 60 * 60
WECHAT_CONTACT_UID_SUFFIX = "@im.wechat"


class WeixinMediaError(RuntimeError):
    pass


@dataclass(frozen=True)
class TextSendAttempt:
    """一次微信文本下发的结构化结果。"""

    success: bool
    error: str | None = None
    retryable: bool = False
    context_expired: bool = False
    ret: Any = None
    status_code: int | None = None
    retry_after: float | None = None


def is_wechat_contact_uid(uid: Any) -> bool:
    """Return whether an ``instance_contacts`` uid belongs to WeChat.

    ``instance_contacts`` predates the QQ channel.  QQ contact ids are now
    deliberately namespaced as ``qq:<account>:<openid>`` and must never be
    selected by a WeChat-only proactive sender.
    """

    return str(uid or "").strip().lower().endswith(WECHAT_CONTACT_UID_SUFFIX)


def common_headers(token: str | None = None) -> dict[str, str]:
    headers = {
        "Content-Type": "application/json",
        "AuthorizationType": "ilink_bot_token",
        "X-WECHAT-UIN": utils.generate_x_wechat_uin(),
        "iLink-App-Id": APP_ID,
        "iLink-App-ClientVersion": CLIENT_VERSION,
    }
    clean_token = (token or "").strip()
    if clean_token:
        headers["Authorization"] = f"Bearer {clean_token}"
    return headers


def base_info() -> dict[str, str]:
    return {"channel_version": APP_VERSION, "bot_agent": BOT_AGENT}


def build_cdn_upload_url(upload_param: str, filekey: str) -> str:
    # urllib.quote defaults to safe='/' while JS encodeURIComponent (official
    # implementation) encodes '/'.  The parameters are opaque and must be
    # encoded in full or a proportion of CDN URLs become invalid.
    encoded_param = urllib.parse.quote(str(upload_param), safe="")
    encoded_filekey = urllib.parse.quote(str(filekey), safe="")
    return (
        f"{CDN_BASE_URL}/upload?encrypted_query_param={encoded_param}"
        f"&filekey={encoded_filekey}"
    )


def build_cdn_download_url(encrypted_query_param: str) -> str:
    encoded = urllib.parse.quote(str(encrypted_query_param), safe="")
    return f"{CDN_BASE_URL}/download?encrypted_query_param={encoded}"


def decode_aes_key(value: Any) -> bytes:
    """Accept both encodings observed by the official plugin.

    Incoming images may contain raw 32-char hex in ImageItem.aeskey,
    base64(raw 16 bytes), or base64(32 ASCII hex chars).
    """
    if isinstance(value, bytes):
        if len(value) == 16:
            return value
        try:
            value = value.decode("ascii")
        except UnicodeDecodeError as exc:
            raise WeixinMediaError("AES 密钥不是有效 ASCII/Base64") from exc
    if not isinstance(value, str) or not value.strip():
        raise WeixinMediaError("缺少图片 AES 密钥")
    clean = value.strip()
    if re.fullmatch(r"[0-9a-fA-F]{32}", clean):
        return bytes.fromhex(clean)
    try:
        decoded = base64.b64decode(clean, validate=True)
    except (ValueError, binascii.Error) as exc:
        raise WeixinMediaError("图片 AES 密钥 Base64 格式无效") from exc
    if len(decoded) == 16:
        return decoded
    if len(decoded) == 32:
        try:
            hex_text = decoded.decode("ascii")
        except UnicodeDecodeError:
            hex_text = ""
        if re.fullmatch(r"[0-9a-fA-F]{32}", hex_text):
            return bytes.fromhex(hex_text)
    raise WeixinMediaError(
        f"图片 AES 密钥长度无效：Base64 解码后为 {len(decoded)} 字节"
    )


def detect_image_extension(data: bytes) -> str | None:
    if data.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return ".gif"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return ".webp"
    if data.startswith(b"BM"):
        return ".bmp"
    return None


def validate_image_bytes(data: bytes, *, label: str = "图片") -> str:
    if not isinstance(data, (bytes, bytearray)) or not data:
        raise WeixinMediaError(f"{label}内容为空")
    if len(data) > MAX_IMAGE_BYTES:
        raise WeixinMediaError(
            f"{label}过大：{len(data) / 1024 / 1024:.1f}MB，最大 25MB"
        )
    ext = detect_image_extension(bytes(data))
    if not ext:
        raise WeixinMediaError(f"{label}不是受支持的 JPEG/PNG/GIF/WebP/BMP 文件")
    return ext


def encrypt_media(plaintext: bytes, aes_key: bytes) -> bytes:
    if len(aes_key) != 16:
        raise WeixinMediaError("AES-128 密钥必须为 16 字节")
    return AES.new(aes_key, AES.MODE_ECB).encrypt(pad(plaintext, AES.block_size))


def decrypt_media(ciphertext: bytes, aes_key: bytes) -> bytes:
    if not ciphertext or len(ciphertext) % AES.block_size:
        raise WeixinMediaError("微信 CDN 图片密文为空或长度不是 16 的倍数")
    try:
        padded = AES.new(aes_key, AES.MODE_ECB).decrypt(ciphertext)
        return unpad(padded, AES.block_size)
    except ValueError as exc:
        raise WeixinMediaError("微信 CDN 图片解密失败：密钥或填充无效") from exc


def _json_object(response: httpx.Response, label: str) -> dict[str, Any]:
    try:
        data = response.json()
    except Exception as exc:
        preview = (response.text or "")[:160]
        raise WeixinMediaError(f"{label} 返回了非法 JSON：{preview}") from exc
    if not isinstance(data, dict):
        raise WeixinMediaError(f"{label} 返回格式不是对象")
    return data


def _check_business_result(data: dict[str, Any], label: str) -> None:
    # getUploadUrl success responses in the official protocol may omit ret.
    # When present, however, a non-zero value is an explicit failure.
    ret = data.get("ret")
    if ret not in (None, 0, "0"):
        raise WeixinMediaError(
            f"{label} 失败：ret={ret} errmsg={data.get('errmsg') or data.get('message') or ''}"
        )


async def latest_context_record(pool, db_id: int, uid: str) -> tuple[str, int]:
    """读取会话凭据及其最后一次用户上行时间；数据库异常交给调用方处理。"""

    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT context_token, last_seen FROM instance_contacts "
                "WHERE db_id=%s AND uid=%s LIMIT 1",
                (db_id, uid),
            )
            row = await cur.fetchone()
    if isinstance(row, dict):
        return str(row.get("context_token") or ""), int(row.get("last_seen") or 0)
    if row:
        return str(row[0] or ""), int(row[1] or 0)
    return "", 0


async def latest_context_token(pool, db_id: int, uid: str) -> str:
    try:
        token, _ = await latest_context_record(pool, db_id, uid)
        return token
    except Exception:
        return ""


async def invalidate_context_record(
    pool,
    db_id: int,
    uid: str,
    context_token: str,
) -> None:
    """Forget exactly one context token after WeChat rejects it as expired.

    The conditional token match is important: a new inbound message may have
    refreshed the row while a slow proactive generation was still running.
    In that case this stale worker must not erase the new credential.
    """

    clean_token = str(context_token or "").strip()
    if not clean_token or not is_wechat_contact_uid(uid):
        return
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "UPDATE instance_contacts SET context_token='', last_seen=0 "
                "WHERE db_id=%s AND uid=%s AND context_token=%s",
                (db_id, uid, clean_token),
            )
        await conn.commit()


def proactive_context_is_fresh(
    context_token: str,
    last_seen: int | float,
    *,
    now: int | float | None = None,
    max_age_seconds: int = PROACTIVE_CONTEXT_MAX_AGE_SECONDS,
) -> bool:
    """主动下发只能使用近期用户上行产生的非空 context_token。"""

    if not str(context_token or "").strip():
        return False
    try:
        seen_at = float(last_seen)
    except (TypeError, ValueError):
        return False
    current = float(time.time() if now is None else now)
    age = max(0.0, current - seen_at)
    return seen_at > 0 and age <= max(1, int(max_age_seconds))


async def send_text_attempt(
    client: httpx.AsyncClient,
    token: str,
    uid: str,
    text: str,
    *,
    context_token: str = "",
    client_id: str | None = None,
) -> TextSendAttempt:
    """按腾讯官方 wire format 执行一次文本下发，不在内部盲目重试。"""

    msg = {
        "from_user_id": "",
        "to_user_id": uid,
        "client_id": client_id or utils.generate_client_id(),
        "message_type": 2,
        "message_state": 2,
        "item_list": [{"type": 1, "text_item": {"text": text}}],
    }
    clean_context = str(context_token or "").strip()
    if clean_context:
        msg["context_token"] = clean_context
    try:
        response = await client.post(
            f"{API_BASE_URL}/ilink/bot/sendmessage",
            json={"msg": msg, "base_info": base_info()},
            headers=common_headers(token),
            timeout=15.0,
        )
    except Exception as exc:
        return TextSendAttempt(
            False,
            f"{type(exc).__name__}: {str(exc)[:120]}",
            retryable=True,
        )

    status = int(response.status_code)
    if status != 200:
        preview = (response.text or "").strip()[:160]
        retryable = status in (408, 425, 429) or 500 <= status <= 599
        retry_after = None
        if status == 429:
            try:
                retry_after = max(0.0, float(response.headers.get("retry-after") or 0))
            except (TypeError, ValueError):
                retry_after = None
        return TextSendAttempt(
            False,
            f"HTTP {status} body={preview!r}",
            retryable=retryable,
            status_code=status,
            retry_after=retry_after,
        )
    try:
        data = response.json()
    except Exception:
        return TextSendAttempt(
            False,
            "微信发送响应不是合法 JSON",
            retryable=True,
            status_code=status,
        )
    if not isinstance(data, dict):
        return TextSendAttempt(
            False,
            "微信发送响应格式无效",
            retryable=True,
            status_code=status,
        )

    ret = data.get("ret")
    if ret not in (None, 0, "0"):
        errmsg = str(data.get("errmsg") or data.get("message") or "").strip()
        context_expired = (
            bool(clean_context)
            and str(ret) == "-2"
            and (not errmsg or "prepare failed" in errmsg.lower())
        )
        if context_expired:
            error = "微信会话凭据已过期，需用户先发来一条消息后才能恢复发送"
        else:
            error = f"ret={ret} errmsg={errmsg}"
        # HTTP 已明确返回业务拒绝。重复同一个请求不会恢复，且可能刷屏。
        return TextSendAttempt(
            False,
            error,
            retryable=False,
            context_expired=context_expired,
            ret=ret,
            status_code=status,
        )
    return TextSendAttempt(True, status_code=status)


async def send_text(
    client: httpx.AsyncClient,
    token: str,
    uid: str,
    text: str,
    *,
    context_token: str = "",
) -> None:
    msg = {
        "from_user_id": "",
        "to_user_id": uid,
        "client_id": utils.generate_client_id(),
        "message_type": 2,
        "message_state": 2,
        "item_list": [{"type": 1, "text_item": {"text": text}}],
    }
    if context_token:
        msg["context_token"] = context_token
    await _send_message_payload(client, token, msg)


async def _send_message_payload(
    client: httpx.AsyncClient,
    token: str,
    msg: dict[str, Any],
) -> dict[str, Any]:
    """Send once, then retry without a rejected context token when safe."""

    async def _post(one_msg: dict[str, Any]) -> dict[str, Any]:
        response = await client.post(
            f"{API_BASE_URL}/ilink/bot/sendmessage",
            json={"msg": one_msg, "base_info": base_info()},
            headers=common_headers(token),
            timeout=15.0,
        )
        if response.status_code != 200:
            raise WeixinMediaError(
                f"sendMessage HTTP {response.status_code}: {(response.text or '')[:160]}"
            )
        return _json_object(response, "sendMessage")

    data = await _post(msg)
    try:
        _check_business_result(data, "sendMessage")
        return data
    except WeixinMediaError:
        # Async image generation may outlive the context token. A retry is safe only
        # after Weixin explicitly rejected the first request; network ambiguity is
        # intentionally not retried here to avoid duplicate delivery.
        if not msg.get("context_token"):
            raise
        retry_msg = dict(msg)
        retry_msg.pop("context_token", None)
        retry_msg["client_id"] = utils.generate_client_id()
        retry_data = await _post(retry_msg)
        _check_business_result(retry_data, "sendMessage")
        return retry_data


async def upload_and_send_image(
    client: httpx.AsyncClient,
    token: str,
    uid: str,
    image_bytes: bytes,
    *,
    context_token: str = "",
) -> dict[str, Any]:
    validate_image_bytes(image_bytes, label="待发送图片")
    raw_size = len(image_bytes)
    raw_md5 = hashlib.md5(image_bytes).hexdigest()
    filekey = os.urandom(16).hex()
    aes_key = os.urandom(16)
    ciphertext = encrypt_media(image_bytes, aes_key)

    request_body = {
        "filekey": filekey,
        "media_type": 1,
        "to_user_id": uid,
        "rawsize": raw_size,
        "rawfilemd5": raw_md5,
        "filesize": len(ciphertext),
        "no_need_thumb": True,
        "aeskey": aes_key.hex(),
        "base_info": base_info(),
    }
    response = await client.post(
        f"{API_BASE_URL}/ilink/bot/getuploadurl",
        json=request_body,
        headers=common_headers(token),
        timeout=30.0,
    )
    if response.status_code != 200:
        raise WeixinMediaError(
            f"getUploadUrl HTTP {response.status_code}: {(response.text or '')[:160]}"
        )
    upload_info = _json_object(response, "getUploadUrl")
    _check_business_result(upload_info, "getUploadUrl")
    full_url = str(upload_info.get("upload_full_url") or "").strip()
    upload_param = upload_info.get("upload_param")
    if full_url:
        upload_url = full_url
    elif isinstance(upload_param, str) and upload_param:
        upload_url = build_cdn_upload_url(upload_param, filekey)
    else:
        raise WeixinMediaError("getUploadUrl 未返回 upload_full_url 或 upload_param")

    download_param = ""
    last_error: Exception | None = None
    for attempt in range(1, CDN_UPLOAD_ATTEMPTS + 1):
        try:
            cdn_response = await client.post(
                upload_url,
                content=ciphertext,
                headers={"Content-Type": "application/octet-stream"},
                timeout=60.0,
            )
            if 400 <= cdn_response.status_code < 500:
                err = cdn_response.headers.get("x-error-message") or (
                    cdn_response.text or ""
                )[:160]
                raise WeixinMediaError(
                    f"CDN 上传客户端错误 {cdn_response.status_code}: {err}"
                )
            if cdn_response.status_code != 200:
                raise RuntimeError(f"CDN 上传 HTTP {cdn_response.status_code}")
            download_param = str(
                cdn_response.headers.get("x-encrypted-param") or ""
            ).strip()
            if not download_param:
                raise RuntimeError("CDN 响应缺少 x-encrypted-param")
            break
        except WeixinMediaError:
            raise
        except Exception as exc:
            last_error = exc
            if attempt < CDN_UPLOAD_ATTEMPTS:
                await asyncio.sleep(0.5 * attempt)
    if not download_param:
        error_detail = (
            str(last_error).strip()
            if last_error is not None else "未知错误"
        )
        if not error_detail and last_error is not None:
            error_detail = type(last_error).__name__
        raise WeixinMediaError(
            f"CDN 上传连续 {CDN_UPLOAD_ATTEMPTS} 次失败：{error_detail}"
        )

    aes_key_field = base64.b64encode(aes_key.hex().encode("ascii")).decode("ascii")
    msg = {
        "from_user_id": "",
        "to_user_id": uid,
        "client_id": utils.generate_client_id(),
        "message_type": 2,
        "message_state": 2,
        "item_list": [{
            "type": 2,
            "image_item": {
                "media": {
                    "encrypt_query_param": download_param,
                    "aes_key": aes_key_field,
                    "encrypt_type": 1,
                },
                "mid_size": len(ciphertext),
            },
        }],
    }
    if context_token:
        msg["context_token"] = context_token
    await _send_message_payload(client, token, msg)
    return {
        "filekey": filekey,
        "raw_size": raw_size,
        "cipher_size": len(ciphertext),
        "download_param": download_param,
    }


async def download_and_decrypt_image_bytes(
    client: httpx.AsyncClient,
    image_item: dict[str, Any],
) -> tuple[bytes, str]:
    media = image_item.get("media") or {}
    if not isinstance(media, dict):
        raise WeixinMediaError("图片 media 字段格式无效")
    full_url = str(media.get("full_url") or "").strip()
    encrypted_param = str(media.get("encrypt_query_param") or "").strip()
    if not full_url:
        if not encrypted_param:
            raise WeixinMediaError("找不到图片下载地址或 encrypt_query_param")
        full_url = build_cdn_download_url(encrypted_param)
    aes_key = decode_aes_key(image_item.get("aeskey") or media.get("aes_key"))
    response = await client.get(full_url, timeout=60.0, follow_redirects=True)
    if response.status_code != 200:
        raise WeixinMediaError(
            f"微信 CDN 图片下载 HTTP {response.status_code}: {(response.text or '')[:120]}"
        )
    if len(response.content) > MAX_IMAGE_BYTES + AES.block_size:
        raise WeixinMediaError("微信 CDN 图片超过 25MB 上限")
    plaintext = decrypt_media(response.content, aes_key)
    extension = validate_image_bytes(plaintext, label="解密后的图片")
    return plaintext, extension
