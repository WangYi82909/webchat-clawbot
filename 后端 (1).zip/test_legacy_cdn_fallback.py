import base64
import unittest

import httpx

from skills import generate_image


def _response(status=200, *, json_data=None, headers=None):
    request = httpx.Request("POST", "https://example.test")
    return httpx.Response(
        status,
        request=request,
        json=json_data,
        headers=headers,
    )


class FakeClient:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    async def post(self, url, **kwargs):
        self.calls.append((url, kwargs))
        return self.responses.pop(0)


class LegacyCdnFallbackTests(unittest.IsolatedAsyncioTestCase):
    async def test_image_sender_uses_previous_wire_format(self):
        client = FakeClient([
            _response(json_data={"upload_param": "opaque/value+"}),
            _response(headers={"x-encrypted-param": "download-param"}),
            _response(json_data={"ret": 0}),
        ])
        image = b"\x89PNG\r\n\x1a\n" + b"payload" * 20
        await generate_image._stable_upload_and_send_image(
            client, "token", "wx-user", image
        )

        self.assertEqual(len(client.calls), 3)
        upload = client.calls[0][1]["json"]
        self.assertEqual(upload["media_type"], 1)
        self.assertTrue(upload["no_need_thumb"])
        self.assertEqual(upload["base_info"]["channel_version"], "2.4.2")
        self.assertEqual(upload["base_info"]["bot_agent"], "PyWeixinBot/1.0")
        self.assertIn("encrypted_query_param=opaque/value%2B", client.calls[1][0])

        message = client.calls[2][1]["json"]["msg"]
        self.assertEqual(message["context_token"], "")
        image_item = message["item_list"][0]["image_item"]
        encoded_key = image_item["media"]["aes_key"]
        self.assertRegex(base64.b64decode(encoded_key).decode(), r"^[0-9a-f]{32}$")
        self.assertGreater(image_item["mid_size"], len(image))


if __name__ == "__main__":
    unittest.main()
