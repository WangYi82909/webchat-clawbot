import unittest

import chat


class LegacyToolHistoryCompatibilityTests(unittest.TestCase):
    def test_old_pending_record_remains_readable_without_writeback(self):
        stored = chat._make_msg(
            "assistant",
            "稍后给你看。",
            message_id="legacy-message",
            tool_executions=[{
                "execution_id": "legacy-execution",
                "name": "generate_image",
                "params": {"prompt": "小猫"},
                "status": "pending",
                "created_at": 1,
            }],
        )
        rendered = chat._flatten_for_llm(stored)
        self.assertIn("结果未回写，执行状态未知", rendered["content"])

    def test_new_sync_record_is_completed_before_history_is_saved(self):
        execution = chat._new_tool_execution(
            "send_emoji",
            {"emoji_id": 7},
            status="completed",
            success=True,
            result="表情包已发送。",
        )
        self.assertEqual(execution["status"], "completed")
        self.assertTrue(execution["success"])
        self.assertEqual(execution["result"], "表情包已发送。")


if __name__ == "__main__":
    unittest.main()
