#!/usr/bin/env bash
# Cloud Love 后端一键依赖安装（Debian / Ubuntu）
# 可重复执行；虚拟环境固定放在后端目录的 .venv 中。

set -Eeuo pipefail

WORKDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="${WORKDIR}/.venv"
REQUIREMENTS="${WORKDIR}/requirements.txt"

if [ ! -f "$REQUIREMENTS" ]; then
    echo "错误：未找到依赖清单 ${REQUIREMENTS}" >&2
    exit 1
fi

if ! command -v apt-get >/dev/null 2>&1; then
    echo "错误：此安装脚本面向 Debian/Ubuntu，当前系统没有 apt-get。" >&2
    exit 1
fi

SUDO=()
if [ "$(id -u)" -ne 0 ]; then
    if ! command -v sudo >/dev/null 2>&1; then
        echo "错误：请使用 root 运行，或先安装 sudo。" >&2
        exit 1
    fi
    SUDO=(sudo)
fi

echo "[1/5] 安装 Python、编译工具与 ffmpeg..."
"${SUDO[@]}" apt-get update
"${SUDO[@]}" env DEBIAN_FRONTEND=noninteractive apt-get install -y \
    python3 python3-venv python3-pip python3-dev \
    build-essential libffi-dev libssl-dev ffmpeg ca-certificates

echo "[2/5] 检查 Python 版本..."
python3 - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit(
        f"当前 Python {sys.version.split()[0]}，Cloud Love 后端要求 Python 3.10 或更高版本。"
    )
print("Python", sys.version.split()[0])
PY

echo "[3/5] 创建或复用虚拟环境 ${VENV_DIR}..."
if [ ! -x "${VENV_DIR}/bin/python" ]; then
    python3 -m venv "$VENV_DIR"
fi

echo "[4/5] 安装 Python 依赖..."
"${VENV_DIR}/bin/python" -m pip install --upgrade pip setuptools wheel
"${VENV_DIR}/bin/python" -m pip install --upgrade -r "$REQUIREMENTS"
"${VENV_DIR}/bin/python" -m pip check

echo "[5/5] 验证核心依赖..."
"${VENV_DIR}/bin/python" - <<'PY'
import aiomysql
import dashscope
import httpx
import pilk
import pymysql
import websockets
from Crypto.Cipher import AES
from pydub import AudioSegment

print("核心 Python 依赖导入正常")
PY

chmod +x "${WORKDIR}/start_shards.sh"

echo
echo "安装完成。启动命令："
echo "  cd '${WORKDIR}' && ./start_shards.sh start"
echo "查看状态："
echo "  cd '${WORKDIR}' && ./start_shards.sh status"
