"""data/websocker — 实时语音通话服务 (嵌入式).

由 data/main.py 在启动时通过 asyncio.create_task 拉起, 与微信 bot 主循环
共享同一个进程和同一个 aiomysql pool. nginx 把 /ws 反代到本服务监听的端口.

模块:
    config.py        配置 (env vars)
    auth.py          HMAC token 校验 + 加载 user + 解析音色 ID
    asr.py           实时语音识别 (dashscope qwen3-asr-flash-realtime)
    tts.py           语音合成 (dashscope cosyvoice-v3.5-plus + 用户音色)
    chat_bridge.py   调用 chat.generate_reply 的桥接 (deploy_type='voice')
    server.py        WS 服务主入口

业务链:
    PCM in -> ASR -> chat.generate_reply -> TTS -> mp3 out
"""
