"""
Gemini 原生 ``models.generateContent`` 协议适配器。

这里的网络请求体始终是 Gemini 原生结构：``systemInstruction``、
``contents``、``generationConfig``、``tools/functionDeclarations``、
``functionCall/functionResponse`` 和 ``inlineData``。文件末端把原生响应整理成
chat.py 已有的内部统一结构，只是本地业务适配，不会把上游请求转换为 OpenAI
协议。

官方依据：
  https://ai.google.dev/api/generate-content
  https://ai.google.dev/gemini-api/docs/generate-content/thinking
  https://ai.google.dev/gemini-api/docs/generate-content/function-calling
  https://ai.google.dev/gemini-api/docs/generate-content/caching
  https://ai.google.dev/gemini-api/docs/image-understanding?hl=zh-cn
  https://ai.google.dev/gemini-api/docs/video-understanding?hl=zh-cn
"""
from __future__ import annotations

import copy
import json
import re
from typing import Any
from urllib.parse import quote


# 模型没有配置独立端点时使用的默认中转。
# 模型定价中配置了独立 Gemini 原生端点时仍优先使用该端点。
GEMINI_GENERATE_CONTENT_ENDPOINT = (
    "https://mixed.strai.life/v1beta/models/{model}:generateContent"
)
GEMINI_MAX_OUTPUT_TOKENS = 16384
GEMINI_THINKING_LEVEL = "HIGH"

# generateContent 内联视频请求的官方总上限是 20 MB（视频、文本、system 等全部
# 计算在内）。Base64 会把体积放大约 4/3，因此这里把原始视频限制为 12 MiB，
# 给历史、提示词、工具定义和 JSON 留足余量。更大的视频必须依赖上游 Files API；
# 当前 OpenLux 中转未提供稳定的 Files 上传端点，不能伪造 fileUri。
GEMINI_INLINE_VIDEO_MAX_BYTES = 12 * 1024 * 1024
GEMINI_VIDEO_MIME_BY_EXTENSION = {
    ".mp4": "video/mp4",
    ".mpeg": "video/mpeg",
    ".mov": "video/mov",
    ".avi": "video/avi",
    ".flv": "video/x-flv",
    ".mpg": "video/mpg",
    ".webm": "video/webm",
    ".wmv": "video/wmv",
    ".3gp": "video/3gpp",
    ".3gpp": "video/3gpp",
}
GEMINI_SUPPORTED_VIDEO_MIME_TYPES = frozenset(
    GEMINI_VIDEO_MIME_BY_EXTENSION.values()
)

# OpenLux 中转没有已验证可用的 POST /v1beta/cachedContents 资源接口。本适配器只依赖
# Gemini 2.5+ 自动隐式缓存，并从 usageMetadata.cachedContentTokenCount 读取命中量。


_DATA_URI_RE = re.compile(
    r"^data:([a-zA-Z0-9.+-]+/[a-zA-Z0-9.+-]+);base64,(.+)$",
    re.DOTALL,
)
_THINKING_PREFIXES = ("gemini-2.5", "gemini-3")


def is_explicit_native_media_model(model: str) -> bool:
    """Gemini 协议下，模型 ID 任意位置含 gemini 即具备原生媒体能力。"""
    return "gemini" in (model or "").strip().lower()


def resolve_endpoint(
    model_endpoint: str | None = None,
    platform_endpoint: str | None = None,
    *,
    model: str = "",
) -> str:
    """解析 Gemini 原生 ``generateContent`` 端点。

    Gemini 优先使用 ``model_pricing.endpoint``。后台推荐填写完整模板
    ``https://host/v1beta/models/{model}:generateContent``；也兼容完整请求地址、
    ``.../v1beta`` 基址和 ``.../models`` 基址。模型未配置独立端点时才使用
    默认中转。平台全局 endpoint 通常是 OpenAI ``/v1``，不能用于原生协议。
    """
    del platform_endpoint
    clean_model = (model or "").strip()
    if clean_model.startswith("models/"):
        clean_model = clean_model[len("models/") :]
    if not clean_model:
        return ""
    encoded_model = quote(clean_model, safe="-._")

    custom = (model_endpoint or "").strip()
    if custom:
        if "{model}" in custom:
            return custom.replace("{model}", encoded_model)

        stripped = custom.rstrip("/")
        if stripped.endswith(":generateContent"):
            return stripped
        if stripped.endswith("/models"):
            return f"{stripped}/{encoded_model}:generateContent"
        if stripped.endswith("/v1beta"):
            return f"{stripped}/models/{encoded_model}:generateContent"

        # 特殊网关可能使用非标准完整路径；后台填写什么就原样请求什么。
        return custom

    return GEMINI_GENERATE_CONTENT_ENDPOINT.format(model=encoded_model)


def build_headers(api_key: str) -> dict[str, str]:
    """Gemini 中转请求头，沿用原来的 Bearer 鉴权位置。"""
    return {
        "Authorization": f"Bearer {api_key or ''}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def supports_thinking_by_prefix(model: str) -> bool:
    """Gemini 2.5/3 系列思考模型兜底判断。"""
    value = (model or "").strip().lower()
    return any(value.startswith(prefix) for prefix in _THINKING_PREFIXES)


def _text_part(text: Any) -> dict[str, str] | None:
    if not isinstance(text, str) or text == "":
        return None
    return {"text": text}


def _openai_block_to_gemini(block: Any) -> dict[str, Any] | None:
    """把 chat.py 内部内容块整理为 Gemini Part，保留原始媒体字节。"""
    if not isinstance(block, dict):
        return _text_part(str(block))

    block_type = str(block.get("type") or "")
    if block_type == "text":
        return _text_part(block.get("text"))

    if block_type == "image_url":
        image_url = block.get("image_url")
        url = image_url.get("url") if isinstance(image_url, dict) else image_url
        if not isinstance(url, str) or not url:
            return None
        match = _DATA_URI_RE.match(url)
        if match:
            mime_type, data = match.groups()
            return {
                "inlineData": {
                    "mimeType": mime_type,
                    "data": data,
                }
            }
        # generateContent 的 fileData 使用 Files API URI；保留远程 URI，交给
        # OpenLux/上游校验。当前微信主链路实际使用的是上面的 base64 分支。
        return {"fileData": {"mimeType": "image/jpeg", "fileUri": url}}

    if block_type == "input_audio":
        audio = block.get("input_audio") or {}
        if not isinstance(audio, dict) or not audio.get("data"):
            return None
        fmt = str(audio.get("format") or "wav").lower()
        mime = {
            "wav": "audio/wav",
            "mp3": "audio/mpeg",
            "m4a": "audio/mp4",
            "ogg": "audio/ogg",
            "webm": "audio/webm",
        }.get(fmt, f"audio/{fmt}")
        return {"inlineData": {"mimeType": mime, "data": audio["data"]}}

    if block_type == "video":
        # chat.py 只会在 model_pricing.protocol=gemini 时构造此内部块。出网前
        # 在本协议边界转换为 generateContent 原生 Part，不经过 OpenAI 协议。
        data = block.get("data")
        mime_type = str(
            block.get("mime_type") or block.get("mimeType") or "video/mp4"
        ).strip().lower()
        if (
            not isinstance(data, str)
            or not data
            or mime_type not in GEMINI_SUPPORTED_VIDEO_MIME_TYPES
        ):
            return None
        return {
            "inlineData": {
                "mimeType": mime_type,
                "data": data,
            }
        }

    if block_type == "video_url":
        # 兼容调用方可能传入的 data URI 形式；普通公网 URL 不是 Gemini Files
        # API 生成的 fileUri，不能冒充 fileData，故只接受 data URI。
        video_url = block.get("video_url")
        url = video_url.get("url") if isinstance(video_url, dict) else video_url
        match = _DATA_URI_RE.match(url) if isinstance(url, str) else None
        if not match:
            return None
        mime_type, data = match.groups()
        mime_type = mime_type.lower()
        if mime_type not in GEMINI_SUPPORTED_VIDEO_MIME_TYPES:
            return None
        return {"inlineData": {"mimeType": mime_type, "data": data}}

    # 已经是 Gemini 原生 Part 时原样保留。
    if any(
        key in block
        for key in (
            "inlineData",
            "fileData",
            "functionCall",
            "functionResponse",
            "executableCode",
            "codeExecutionResult",
        )
    ):
        return copy.deepcopy(block)
    return None


def _content_parts(content: Any) -> list[dict[str, Any]]:
    if isinstance(content, str):
        part = _text_part(content)
        return [part] if part else []
    if isinstance(content, list):
        parts: list[dict[str, Any]] = []
        for block in content:
            part = _openai_block_to_gemini(block)
            if part:
                parts.append(part)
        return parts
    if content is not None:
        return [{"text": str(content)}]
    return []


def _function_response_content(message: dict[str, Any]) -> dict[str, Any]:
    native = message.get("_gemini_function_response")
    if isinstance(native, dict):
        response = copy.deepcopy(native)
    else:
        name = str(message.get("name") or "")
        result = message.get("content")
        response = {
            "name": name,
            "response": {"result": result},
        }
        call_id = str(message.get("tool_call_id") or "")
        if call_id:
            response["id"] = call_id
    parts: list[dict[str, Any]] = [{"functionResponse": response}]
    followup = message.get("_gemini_followup_instruction")
    if isinstance(followup, str) and followup.strip():
        parts.append({"text": followup})
    return {"role": "user", "parts": parts}


def _has_function_call(content: Any) -> bool:
    """仅函数调用续轮需要回放带 thoughtSignature 的原始 Content。"""
    if not isinstance(content, dict):
        return False
    parts = content.get("parts")
    return isinstance(parts, list) and any(
        isinstance(part, dict) and isinstance(part.get("functionCall"), dict)
        for part in parts
    )


def _merge_function_response_contents(
    current: dict[str, Any], incoming: dict[str, Any]
) -> None:
    """把同一模型轮次的并行函数结果合成一个 user Content。

    Gemini 要求 functionResponse 与前一条 model.functionCall 紧邻，且并行
    调用的响应顺序与调用顺序一致。说明文字统一放在所有响应之后。
    """
    current_parts = current.get("parts")
    incoming_parts = incoming.get("parts")
    if not isinstance(current_parts, list) or not isinstance(incoming_parts, list):
        return
    current_responses = [
        part for part in current_parts
        if isinstance(part, dict) and "functionResponse" in part
    ]
    current_other = [
        part for part in current_parts
        if not (isinstance(part, dict) and "functionResponse" in part)
    ]
    incoming_responses = [
        part for part in incoming_parts
        if isinstance(part, dict) and "functionResponse" in part
    ]
    incoming_other = [
        part for part in incoming_parts
        if not (isinstance(part, dict) and "functionResponse" in part)
    ]
    current["parts"] = (
        current_responses + incoming_responses + current_other + incoming_other
    )


def _messages_to_native(
    messages: list,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    """保持消息顺序构建 systemInstruction + contents。"""
    system_parts: list[dict[str, str]] = []
    contents: list[dict[str, Any]] = []
    leading_system = True
    previous_was_tool = False

    for raw in messages or []:
        if not isinstance(raw, dict):
            continue
        role = str(raw.get("role") or "user").lower()

        # Gemini 3 工具调用要求把模型返回的 Part（包括 thoughtSignature）原样
        # 放回历史，因此这一分支绝不拆分、合并或重建 parts。
        native_content = raw.get("_gemini_content")
        if isinstance(native_content, dict) and _has_function_call(native_content):
            contents.append(copy.deepcopy(native_content))
            leading_system = False
            previous_was_tool = False
            continue

        if role == "tool":
            function_content = _function_response_content(raw)
            if previous_was_tool and contents and contents[-1].get("role") == "user":
                _merge_function_response_contents(contents[-1], function_content)
            else:
                contents.append(function_content)
            leading_system = False
            previous_was_tool = True
            continue

        if role == "system" and leading_system:
            for part in _content_parts(raw.get("content")):
                text = part.get("text")
                if isinstance(text, str) and text:
                    system_parts.append({"text": text})
            continue

        leading_system = False
        previous_was_tool = False
        parts = _content_parts(raw.get("content"))
        if not parts:
            continue
        if role == "assistant":
            native_role = "model"
        else:
            native_role = "user"
            if role == "system":
                # generateContent 只有一个顶级 systemInstruction。工具循环中追加的
                # 动态系统纠正文案必须留在原位置，故作为带标记的 user 文本发送。
                first = parts[0]
                if isinstance(first.get("text"), str):
                    first["text"] = "[SYSTEM]\n" + first["text"]
        contents.append({"role": native_role, "parts": parts})

    system_instruction = (
        {"parts": system_parts} if system_parts else None
    )
    return system_instruction, contents


def _clean_schema(value: Any) -> Any:
    """移除 Gemini FunctionDeclaration 不接受的 JSON Schema 装饰字段。"""
    if isinstance(value, list):
        return [_clean_schema(item) for item in value]
    if not isinstance(value, dict):
        return value
    unsupported = {
        "$schema",
        "$id",
        "additionalProperties",
        "examples",
        "default",
        "title",
        "strict",
    }
    return {
        key: _clean_schema(item)
        for key, item in value.items()
        if key not in unsupported
    }


def _native_tools(tools: list | None) -> list[dict[str, Any]]:
    declarations: list[dict[str, Any]] = []
    for item in tools or []:
        if not isinstance(item, dict):
            continue
        function = item.get("function") if item.get("type") == "function" else item
        if not isinstance(function, dict):
            continue
        name = str(function.get("name") or "").strip()
        if not name:
            continue
        declaration: dict[str, Any] = {"name": name}
        description = function.get("description")
        if isinstance(description, str) and description:
            declaration["description"] = description
        parameters = function.get("parameters")
        if isinstance(parameters, dict):
            declaration["parameters"] = _clean_schema(parameters)
        declarations.append(declaration)
    return [{"functionDeclarations": declarations}] if declarations else []


def _tool_config(tool_choice: str | dict | None) -> dict[str, Any]:
    config: dict[str, Any] = {"mode": "AUTO"}
    if tool_choice == "none":
        config["mode"] = "NONE"
    elif tool_choice == "required":
        config["mode"] = "ANY"
    elif isinstance(tool_choice, dict):
        function = tool_choice.get("function") or {}
        name = str(function.get("name") or "").strip()
        if name:
            config = {"mode": "ANY", "allowedFunctionNames": [name]}
    return {"functionCallingConfig": config}


def _thinking_config(model: str) -> dict[str, Any]:
    # includeThoughts 强制开启，保证上游返回可展示的思考摘要。Gemini 3 用
    # thinkingLevel；2.5 用 thinkingBudget=-1（动态预算）。未知 Gemini 型号只
    # 发 includeThoughts，让模型使用自身默认预算，避免跨代参数报 400。
    result: dict[str, Any] = {"includeThoughts": True}
    model_lower = (model or "").lower()
    if model_lower.startswith("gemini-3"):
        result["thinkingLevel"] = GEMINI_THINKING_LEVEL
    elif model_lower.startswith("gemini-2.5"):
        result["thinkingBudget"] = -1
    return result


def build_payload(
    model: str,
    messages: list,
    temperature: float = 1.1,
    presence_penalty: float = 0.15,
    frequency_penalty: float = 0.25,
    tools: list | None = None,
    enable_thinking: bool = True,
    supports_thinking: bool | None = None,
    tool_choice: str | dict | None = None,
    prompt_cache_key: str | None = None,
    cached_content: str | None = None,
) -> dict[str, Any]:
    """构建纯 Gemini GenerateContentRequest。"""
    # cached_content 只为保持与旧调用签名兼容；OpenLux 未启用显式缓存资源，
    # 因此绝不把它注入请求体。
    # mixed 的 Gemini 原生路由会把 presencePenalty / frequencyPenalty 判为
    # 请求参数无效（HTTP 400）。参数保留在函数签名中只是兼容 chat.py 和其它
    # 协议的统一调用口径，Gemini 出网请求不得携带。
    del (
        presence_penalty,
        frequency_penalty,
        enable_thinking,
        supports_thinking,
        prompt_cache_key,
        cached_content,
    )
    system_instruction, contents = _messages_to_native(messages)
    generation_config: dict[str, Any] = {
        "temperature": max(0.0, min(2.0, float(temperature))),
        "maxOutputTokens": GEMINI_MAX_OUTPUT_TOKENS,
        "thinkingConfig": _thinking_config(model),
    }
    payload: dict[str, Any] = {
        "contents": contents,
        "generationConfig": generation_config,
    }
    if system_instruction:
        payload["systemInstruction"] = system_instruction

    native_tools = _native_tools(tools)
    if native_tools:
        payload["tools"] = native_tools
        payload["toolConfig"] = _tool_config(tool_choice)

    # Gemini 2.5 不强制 function calling thoughtSignature。当前中转站会偶发
    # 返回无法在下一轮通过校验的损坏签名，因此 2.5 在发送前主动省略签名，
    # 避免产生 400；Gemini 3 仍按官方要求原样保留并严格回放。
    if (model or "").lower().startswith("gemini-2.5"):
        payload = without_thought_signatures(payload)
    return payload


def _as_int(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


def parse_response(resp_json: dict) -> dict:
    """把 Gemini 原生响应整理成 chat.py 的内部统一响应结构。"""
    if not isinstance(resp_json, dict):
        return {"choices": [], "usage": {}}

    candidates = resp_json.get("candidates")
    if not isinstance(candidates, list) or not candidates:
        usage_native = resp_json.get("usageMetadata") or {}
        if not isinstance(usage_native, dict):
            usage_native = {}
        return {
            "choices": [],
            "usage": {
                "prompt_tokens": _as_int(usage_native.get("promptTokenCount")),
                "completion_tokens": _as_int(usage_native.get("candidatesTokenCount")),
                "reasoning_tokens": _as_int(usage_native.get("thoughtsTokenCount")),
                "cached_tokens": _as_int(usage_native.get("cachedContentTokenCount")),
                "_gemini_usage_metadata": copy.deepcopy(usage_native),
            },
            "prompt_feedback": copy.deepcopy(resp_json.get("promptFeedback") or {}),
            "_gemini_native_response": resp_json,
        }
    candidate = candidates[0]
    if not isinstance(candidate, dict):
        candidate = {}
    content_native = candidate.get("content")
    if not isinstance(content_native, dict):
        content_native = {"role": "model", "parts": []}
    parts = content_native.get("parts")
    if not isinstance(parts, list):
        parts = []

    answer_parts: list[str] = []
    thought_parts: list[str] = []
    tool_calls: list[dict[str, Any]] = []
    inline_data: list[dict[str, Any]] = []
    for index, part in enumerate(parts):
        if not isinstance(part, dict):
            continue
        text = part.get("text")
        if isinstance(text, str) and text:
            if part.get("thought") is True:
                thought_parts.append(text)
            else:
                answer_parts.append(text)
        call = part.get("functionCall")
        if isinstance(call, dict):
            name = str(call.get("name") or "").strip()
            if name:
                args = call.get("args")
                if not isinstance(args, dict):
                    args = {}
                native_call_id = call.get("id")
                normalized_call: dict[str, Any] = {
                    # 业务层需要一个稳定 ID；但这个内部占位 ID 绝不能伪装成
                    # Gemini 原生 ID 回传，否则会改变签名所覆盖的函数调用。
                    "id": str(native_call_id or f"gemini_call_{index}"),
                    "type": "function",
                    "function": {
                        "name": name,
                        "arguments": json.dumps(
                            args,
                            ensure_ascii=False,
                            separators=(",", ":"),
                        ),
                    },
                }
                if native_call_id is not None and str(native_call_id):
                    normalized_call["_gemini_native_id"] = str(native_call_id)
                tool_calls.append(normalized_call)
        inline = part.get("inlineData")
        if isinstance(inline, dict):
            inline_data.append(copy.deepcopy(inline))

    message: dict[str, Any] = {
        "role": "assistant",
        "content": "\n".join(answer_parts).strip(),
    }
    if thought_parts:
        message["reasoning_content"] = "\n".join(thought_parts).strip()
    if tool_calls:
        message["tool_calls"] = tool_calls
        # 仅函数调用的同一轮续请求需要原样回放全部 Part 和 thoughtSignature。
        # 普通文本多轮只保存正文，避免把过期签名跨轮、跨缓存或跨模型复用。
        message["_gemini_content"] = copy.deepcopy(content_native)
    if inline_data:
        message["_gemini_inline_data"] = inline_data

    usage_native = resp_json.get("usageMetadata") or {}
    if not isinstance(usage_native, dict):
        usage_native = {}
    prompt_tokens = _as_int(usage_native.get("promptTokenCount"))
    candidate_tokens = _as_int(usage_native.get("candidatesTokenCount"))
    thought_tokens = _as_int(usage_native.get("thoughtsTokenCount"))
    cached_tokens = _as_int(usage_native.get("cachedContentTokenCount"))
    usage = {
        "prompt_tokens": prompt_tokens,
        "completion_tokens": candidate_tokens,
        "total_tokens": _as_int(usage_native.get("totalTokenCount")),
        # Gemini 原生 candidatesTokenCount 不含 thoughtsTokenCount。只放外层
        # reasoning_tokens，让现有计费器按两笔相加；不能伪装成 OpenAI 的
        # completion_tokens_details（该字段语义是 completion 已包含 reasoning）。
        "reasoning_tokens": thought_tokens,
        "prompt_tokens_details": {"cached_tokens": cached_tokens},
        "cached_tokens": cached_tokens,
        "cache_read_input_tokens": cached_tokens,
        "_gemini_usage_metadata": copy.deepcopy(usage_native),
    }

    return {
        "id": str(resp_json.get("responseId") or ""),
        "model": str(resp_json.get("modelVersion") or ""),
        "choices": [
            {
                "index": 0,
                "message": message,
                "finish_reason": str(candidate.get("finishReason") or ""),
                "safety_ratings": copy.deepcopy(candidate.get("safetyRatings") or []),
            }
        ],
        "usage": usage,
        "prompt_feedback": copy.deepcopy(resp_json.get("promptFeedback") or {}),
        "_gemini_native_response": resp_json,
    }


def extract_reasoning(resp_json: dict) -> str | None:
    """读取 includeThoughts 返回的思考摘要。"""
    try:
        value = resp_json["choices"][0]["message"].get("reasoning_content")
    except (KeyError, IndexError, TypeError, AttributeError):
        return None
    return value.strip() if isinstance(value, str) and value.strip() else None


def assistant_message_for_replay(message: dict) -> dict:
    """保留 Gemini 模型原始 Content，尤其是函数调用 thoughtSignature。"""
    if not isinstance(message, dict):
        return {"role": "assistant", "content": ""}
    replay: dict[str, Any] = {
        "role": "assistant",
        "content": message.get("content") if isinstance(message.get("content"), str) else "",
    }
    native_content = message.get("_gemini_content")
    if isinstance(native_content, dict) and _has_function_call(native_content):
        replay["_gemini_content"] = copy.deepcopy(native_content)
    return replay


def tool_result_message(
    tool_call: dict,
    result: Any,
    *,
    success: bool = True,
    instruction: str = "",
) -> dict[str, Any]:
    """构造供下一次 build_payload 生成原生 functionResponse 的内部消息。"""
    function = tool_call.get("function") if isinstance(tool_call, dict) else {}
    if not isinstance(function, dict):
        function = {}
    name = str(function.get("name") or "")
    call_id = str(tool_call.get("id") or "") if isinstance(tool_call, dict) else ""
    native_call_id = (
        str(tool_call.get("_gemini_native_id") or "")
        if isinstance(tool_call, dict)
        else ""
    )
    native_response: dict[str, Any] = {
        "name": name,
        "response": {"success": bool(success), "result": result},
    }
    if native_call_id:
        native_response["id"] = native_call_id
    return {
        "role": "tool",
        "name": name,
        "tool_call_id": call_id,
        "content": str(result),
        "_gemini_function_response": native_response,
        "_gemini_followup_instruction": instruction,
    }


def without_thought_signatures(payload: dict[str, Any]) -> dict[str, Any]:
    """返回移除 contents 内思考签名的副本，供 Gemini 2.5 单次容错。

    Gemini 2.5 的函数调用签名可省略。仅当上游明确返回
    ``Corrupted thought signature`` 时使用；正常请求始终保留原始签名。
    """
    cloned = copy.deepcopy(payload)

    def _strip(value: Any) -> None:
        if isinstance(value, dict):
            value.pop("thoughtSignature", None)
            value.pop("thought_signature", None)
            for child in value.values():
                _strip(child)
        elif isinstance(value, list):
            for child in value:
                _strip(child)

    contents = cloned.get("contents")
    if isinstance(contents, list):
        _strip(contents)
    return cloned
