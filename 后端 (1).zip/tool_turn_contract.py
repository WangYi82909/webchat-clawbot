"""统一判定一轮文本与工具调用的组合是否合法。"""

TEXT_ONLY = "text_only"
TOOL_ONLY = "tool_only"
EMPTY = "empty"
TOOL_WITH_TEXT = "tool_with_text"


def classify(has_text: bool, tool_calls) -> str:
    """所有工具均为同步工具；这里只关心本轮是否包含工具调用。"""
    has_tools = bool(tool_calls)
    if not has_tools:
        return TEXT_ONLY if has_text else EMPTY
    return TOOL_WITH_TEXT if has_text else TOOL_ONLY


def is_valid(state: str) -> bool:
    return state in {TEXT_ONLY, TOOL_ONLY}
