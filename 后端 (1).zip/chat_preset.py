"""
chat_preset.py — v11 (2026-05-12) 提示词预设系统

职责：
  1. 按 preset_id 从 prompt_presets 表读模板
  2. preset_id 为空 → 自动取第一条 is_active=1 的预设(让所有用户默认走 admin
     管理的"系统默认预设",而不是 chat.py 里硬编码的旧模板)
  3. 把 {persona} / {user_persona} / {emojis} / {current_time} / {user_text} /
     {emotion_state} 占位符替换为实际值
     (emotion_state 由 user_personas.emotion_state 提供,每个人格独立维护,
      chat.py 在调用本模块前已通过 persona.get_persona_prompt 读出来,
      作为 substitute_vars 的关键字参数传入。)
  4. 表不存在 / 所有预设都被禁用 → 返回 None,调用方退回 chat.py 内置默认

热重载策略 (2026-05-12 修改):
  - 不再做进程内缓存,每次调用都新鲜 SELECT
  - 单行 PK 查询非常便宜(< 1ms),admin 改完 prompt 下一条消息立刻生效
  - 实例选择切换也是热的(chat.py 每次都重读 inst_config 拿到最新 preset_id)

变量替换用字符串 .replace 而非 str.format,容忍模板里带其它花括号(JSON 示例等)。
"""
from typing import Optional


# 表存在性探测:命中过一次"表不存在"就别再尝试,节省 SQL 往返
_PRESET_TABLE_MISSING = False


async def load_preset(pool, preset_id: Optional[int]) -> Optional[dict]:
    """
    返回:
      dict {id, name, system_prompt, passive_reply_prompt,
            proactive_message_prompt, active_reply_prompt}
      或 None (表不存在 / 没有任何可用预设)

    重要:preset_id 为 None / 0 / 空 → 自动 fallback 到第一条 is_active=1 的预设
        这样部署完迁移、admin 留着默认预设的情况下,所有用户(即使 instances.preset_id
        为 NULL)也会自动走默认预设,无需手动 UPDATE 所有实例。
    """
    global _PRESET_TABLE_MISSING
    if _PRESET_TABLE_MISSING:
        return None

    # 归一化 preset_id:None / 0 / 空 都视为"用默认"
    try:
        pid = int(preset_id) if preset_id else 0
    except (TypeError, ValueError):
        pid = 0

    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                if pid > 0:
                    # 指定预设:优先取指定的;取不到或被禁用则继续走默认 fallback
                    await cur.execute(
                        "SELECT id, name, system_prompt, passive_reply_prompt, "
                        "       proactive_message_prompt, active_reply_prompt, is_active "
                        "FROM prompt_presets WHERE id=%s",
                        (pid,)
                    )
                    row = await cur.fetchone()
                    if row and row.get("is_active"):
                        return row
                    # 指定的预设找不到或被禁用 → 落到下面取默认

                # 默认:取最小 sort_order 的启用预设
                await cur.execute(
                    "SELECT id, name, system_prompt, passive_reply_prompt, "
                    "       proactive_message_prompt, active_reply_prompt "
                    "FROM prompt_presets "
                    "WHERE is_active=1 "
                    "ORDER BY sort_order ASC, id ASC LIMIT 1"
                )
                row = await cur.fetchone()
                return row  # 可能是 None (所有预设都被禁用)
    except Exception as e:
        msg = str(e)
        if "prompt_presets" in msg and ("doesn't exist" in msg or "Table" in msg):
            _PRESET_TABLE_MISSING = True
            return None
        # 其它 DB 错误:静默退回内置,日志由调用方写
        return None


def substitute_vars(template: str,
                    persona: str = "",
                    user_persona: str = "",
                    emojis: str = "",
                    current_time: str = "",
                    user_text: str = "",
                    emotion_state: str = "") -> str:
    """
    把模板里的 {var} 占位符替换为实际值。
    传入 None 或空字符串都视为空。
    用简单 .replace 而非 str.format,容忍模板里带其它花括号(JSON 示例等)。

    v13 (2026-05-13) 新增 {emotion_state}:当前人格的情绪状态,来自
    user_personas.emotion_state,由 chat.py 通过 persona.get_persona_prompt
    读出后透传进来。每条消息新鲜读,AI 调 update_emotion_state 工具改完
    后下条消息立即生效,无缓存。
    """
    if not template:
        return ""
    out = template
    out = out.replace("{persona}",       persona       or "")
    out = out.replace("{user_persona}",  user_persona  or "")
    out = out.replace("{emojis}",        emojis        or "")
    out = out.replace("{current_time}",  current_time  or "")
    out = out.replace("{user_text}",     user_text     or "")
    out = out.replace("{emotion_state}", emotion_state or "")
    return out
