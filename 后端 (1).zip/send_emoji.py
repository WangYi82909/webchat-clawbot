"""ASYNC Weixin emoji delivery using the shared official media pipeline."""
from __future__ import annotations

import base64
import json

import utils
import weixin_media


NAME = "send_emoji"
DESCRIPTION = (
    "异步发送一个表情包到微信，表达你自己的情绪并贴合当前语境。系统提示词不提供"
    "表情包清单；emoji_id 必须来自本次工具链中 get_emoji_list 返回的真实 ID，"
    "禁止猜测或编造。尚未查询时先调用 get_emoji_list；调用本工具的同一轮必须"
    "输出非空文字。"
)
PARAMETERS = {
    "type": "object",
    "properties": {
        "emoji_id": {
            "type": "integer",
            "description": "本次 get_emoji_list 查询结果中真实存在的整数 ID。",
            "minimum": 1,
        }
    },
    "required": ["emoji_id"],
    "additionalProperties": False,
}
USAGE = '{"emoji_id": 123}'
MODE = "ASYNC"


def _safe_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


async def _notify_failure(client, token: str, uid: str, context_token: str) -> None:
    try:
        await weixin_media.send_text(
            client, token, uid, "表情没能发出去，请稍后再试", context_token=context_token
        )
    except Exception:
        pass


async def run(params: dict, pool, db_id, uid, bot_instance) -> dict:
    emoji_id = _safe_int(params.get("emoji_id") if isinstance(params, dict) else None)
    if emoji_id is None or emoji_id <= 0:
        return {"success": False, "message": "emoji_id 必须是正整数。"}

    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT emojis_json, wx_token FROM instances WHERE id=%s", (db_id,)
            )
            row = await cur.fetchone()
    if not row or not row.get("wx_token"):
        return {"success": False, "message": "无法获取当前机器人的微信 Token。"}
    token = utils.decrypt_data(row["wx_token"])
    if not token:
        return {"success": False, "message": "当前机器人的微信 Token 解密失败。"}
    context_token = str(params.get("_context_token") or "")
    if not context_token:
        context_token = await weixin_media.latest_context_token(pool, db_id, uid)

    raw = row.get("emojis_json") or ""
    try:
        decoded = json.loads(raw) if isinstance(raw, str) else raw
    except Exception as exc:
        await _notify_failure(bot_instance.client, token, uid, context_token)
        return {"success": False, "message": f"表情包配置 JSON 损坏: {str(exc)[:80]}"}
    emojis = decoded if isinstance(decoded, list) else []
    target = next(
        (
            item for item in emojis
            if isinstance(item, dict)
            and _safe_int(item.get("id") if item.get("id") is not None else item.get("emoji_id")) == emoji_id
        ),
        None,
    )
    if not target:
        await _notify_failure(bot_instance.client, token, uid, context_token)
        return {"success": False, "message": f"emoji_id={emoji_id} 不存在。"}
    encoded = target.get("base64_data")
    if not isinstance(encoded, str) or not encoded.strip():
        await _notify_failure(bot_instance.client, token, uid, context_token)
        return {"success": False, "message": "该表情包图片数据为空。"}
    if "," in encoded:
        encoded = encoded.split(",", 1)[1]
    try:
        image_bytes = base64.b64decode(encoded, validate=True)
        weixin_media.validate_image_bytes(image_bytes, label="表情包")
    except Exception as exc:
        await _notify_failure(bot_instance.client, token, uid, context_token)
        return {"success": False, "message": f"表情包图片数据损坏: {str(exc)[:100]}"}

    try:
        await weixin_media.upload_and_send_image(
            bot_instance.client,
            token,
            uid,
            image_bytes,
            context_token=context_token,
        )
        return {"success": True, "message": "表情包已发送。"}
    except Exception as exc:
        await _notify_failure(bot_instance.client, token, uid, context_token)
        return {"success": False, "message": f"表情发送失败: {str(exc)[:140]}"}
