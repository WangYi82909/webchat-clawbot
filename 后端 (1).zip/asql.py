"""
导出本地 webchat 数据库的所有表结构(不含数据)到一个 SQL 文件。

用法:
    python export_schema.py

会生成: schema_dump.sql

生成的文件可以一键导入新数据库:
    mysql -uroot -p < schema_dump.sql

依赖:
    pip install pymysql
"""

import sys
import datetime

try:
    import pymysql
except ImportError:
    print("缺少 pymysql, 请先安装:  pip install pymysql")
    sys.exit(1)


# ─── 连接配置 ─────────────────────────────────────────────────────────
HOST     = "127.0.0.1"
PORT     = 3306
USER     = "webchat"
PASSWORD = ""
DATABASE = "webchat"   # 要导出的源数据库名

# ─── 输出文件 ─────────────────────────────────────────────────────────
OUTPUT_FILE = "schema_dump.sql"


def main():
    print(f"连接 {HOST}:{PORT} 数据库 {DATABASE} ...")
    conn = pymysql.connect(
        host=HOST,
        port=PORT,
        user=USER,
        password=PASSWORD,
        database=DATABASE,
        charset="utf8mb4",
    )

    lines = []
    # 文件头
    lines.append(f"-- ======================================================================")
    lines.append(f"-- {DATABASE} 数据库结构导出 (仅表结构, 不含数据)")
    lines.append(f"-- 生成时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"-- 源: {USER}@{HOST}:{PORT}/{DATABASE}")
    lines.append(f"-- ")
    lines.append(f"-- 一键导入新数据库:")
    lines.append(f"--   mysql -u root -p < {OUTPUT_FILE}")
    lines.append(f"-- 或在 mysql 客户端里:")
    lines.append(f"--   source {OUTPUT_FILE};")
    lines.append(f"-- ======================================================================")
    lines.append("")
    lines.append("SET NAMES utf8mb4;")
    lines.append("SET FOREIGN_KEY_CHECKS = 0;")
    lines.append("SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';")
    lines.append("")
    lines.append(f"CREATE DATABASE IF NOT EXISTS `{DATABASE}` "
                 f"DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
    lines.append(f"USE `{DATABASE}`;")
    lines.append("")

    try:
        with conn.cursor() as cur:
            # 找出所有表
            cur.execute(
                "SELECT TABLE_NAME, TABLE_TYPE "
                "FROM information_schema.TABLES "
                "WHERE TABLE_SCHEMA=%s "
                "ORDER BY TABLE_NAME",
                (DATABASE,),
            )
            rows = cur.fetchall()

            tables = []
            views  = []
            for name, ttype in rows:
                if ttype == "VIEW":
                    views.append(name)
                else:
                    tables.append(name)

            print(f"找到 {len(tables)} 张表, {len(views)} 个视图")

            # ── 导出表 ──────────────────────────────────────────────
            for tbl in tables:
                print(f"  导出表: {tbl}")
                cur.execute(f"SHOW CREATE TABLE `{tbl}`")
                row = cur.fetchone()
                # row = (table_name, "CREATE TABLE ...")
                create_sql = row[1]

                lines.append("-- ----------------------------------------------------------------------")
                lines.append(f"-- 表: {tbl}")
                lines.append("-- ----------------------------------------------------------------------")
                lines.append(f"DROP TABLE IF EXISTS `{tbl}`;")
                lines.append(create_sql + ";")
                lines.append("")

            # ── 导出视图(如果有) ──────────────────────────────────
            for v in views:
                print(f"  导出视图: {v}")
                cur.execute(f"SHOW CREATE VIEW `{v}`")
                row = cur.fetchone()
                create_sql = row[1]
                lines.append("-- ----------------------------------------------------------------------")
                lines.append(f"-- 视图: {v}")
                lines.append("-- ----------------------------------------------------------------------")
                lines.append(f"DROP VIEW IF EXISTS `{v}`;")
                lines.append(create_sql + ";")
                lines.append("")

            # ── 导出触发器(如果有) ────────────────────────────────
            cur.execute(
                "SELECT TRIGGER_NAME FROM information_schema.TRIGGERS "
                "WHERE TRIGGER_SCHEMA=%s",
                (DATABASE,),
            )
            trig_rows = cur.fetchall()
            if trig_rows:
                print(f"找到 {len(trig_rows)} 个触发器, 一并导出")
                for (tn,) in trig_rows:
                    cur.execute(f"SHOW CREATE TRIGGER `{tn}`")
                    r = cur.fetchone()
                    # r[2] 是 CREATE TRIGGER 语句
                    lines.append(f"-- 触发器: {tn}")
                    lines.append("DELIMITER $$")
                    lines.append(r[2] + "$$")
                    lines.append("DELIMITER ;")
                    lines.append("")

    finally:
        conn.close()

    # 文件尾
    lines.append("SET FOREIGN_KEY_CHECKS = 1;")
    lines.append("")
    lines.append(f"-- 导出结束。共 {len(tables)} 表, {len(views)} 视图。")

    out_path = OUTPUT_FILE
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"\n完成! 文件: {out_path}")
    print(f"      共 {len(tables)} 张表, {len(views)} 个视图")
    print(f"\n导入新库的命令(示例):")
    print(f"  mysql -u root -p < {out_path}")


if __name__ == "__main__":
    main()