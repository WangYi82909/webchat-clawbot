import base64
import os
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

import httpx

import weixin_media


def response(status=200, *, json_data=None, content=b"", headers=None, text=None):
    request = httpx.Request("POST", "https://example.test")
    if json_data is not None:
        return httpx.Response(status, request=request, json=json_data, headers=headers)
    return httpx.Response(
        status,
        request=request,
        content=content if text is None else text.encode(),
        headers=headers,
    )


class FakeClient:
    def __init__(self, posts=None, gets=None):
        self.posts = list(posts or [])
        self.gets = list(gets or [])
        self.post_calls = []
        self.get_calls = []

    async def post(self, url, **kwargs):
        self.post_calls.append((url, kwargs))
        value = self.posts.pop(0)
        if isinstance(value, Exception):
            raise value
        return value

    async def get(self, url, **kwargs):
        self.get_calls.append((url, kwargs))
        value = self.gets.pop(0)
        if isinstance(value, Exception):
            raise value
        return value


class WeixinMediaTests(unittest.IsolatedAsyncioTestCase):
    def test_main_ai_text_path_uses_structured_official_sender(self):
        source = (Path(__file__).resolve().parent / "main.py").read_text(
            encoding="utf-8"
        )
        start = source.index("async def _send_text_chunks(")
        end = source.index("async def _send_wx_text(", start)
        sender = source[start:end]
        self.assertIn("weixin_media.send_text_attempt(", sender)
        self.assertNotIn("for attempt in range", sender)
        self.assertNotIn("pending_failed", sender)
        self.assertNotIn('"iLink-App-ClientVersion": "1"', sender)
        self.assertNotIn('"context_token": context_token or ""', sender)

    async def test_text_attempt_uses_official_wire_format(self):
        client = FakeClient(posts=[response(json_data={"ret": 0})])
        result = await weixin_media.send_text_attempt(
            client, "token", "uid", "hello", context_token="ctx", client_id="cid"
        )
        self.assertTrue(result.success)
        _, kwargs = client.post_calls[0]
        self.assertEqual(kwargs["json"]["msg"]["client_id"], "cid")
        self.assertEqual(kwargs["json"]["msg"]["context_token"], "ctx")
        self.assertEqual(
            kwargs["json"]["base_info"]["channel_version"],
            weixin_media.APP_VERSION,
        )
        self.assertEqual(
            kwargs["headers"]["iLink-App-ClientVersion"],
            weixin_media.CLIENT_VERSION,
        )
        self.assertEqual(kwargs["headers"]["iLink-App-Id"], "bot")

    async def test_prepare_failed_is_terminal_expired_context(self):
        client = FakeClient(posts=[
            response(json_data={"ret": -2, "errmsg": "prepare failed"})
        ])
        result = await weixin_media.send_text_attempt(
            client, "token", "uid", "hello", context_token="stale"
        )
        self.assertFalse(result.success)
        self.assertFalse(result.retryable)
        self.assertTrue(result.context_expired)
        self.assertIn("用户先发来一条消息", result.error)
        self.assertEqual(len(client.post_calls), 1)

    async def test_http_500_is_retryable(self):
        client = FakeClient(posts=[response(status=500, text="temporary")])
        result = await weixin_media.send_text_attempt(
            client, "token", "uid", "hello", context_token="ctx"
        )
        self.assertFalse(result.success)
        self.assertTrue(result.retryable)

    def test_proactive_context_freshness_requires_recent_nonempty_token(self):
        now = int(time.time())
        self.assertTrue(
            weixin_media.proactive_context_is_fresh("ctx", now - 60, now=now)
        )
        self.assertFalse(
            weixin_media.proactive_context_is_fresh("", now - 60, now=now)
        )
        self.assertFalse(
            weixin_media.proactive_context_is_fresh(
                "ctx",
                now - weixin_media.PROACTIVE_CONTEXT_MAX_AGE_SECONDS - 1,
                now=now,
            )
        )

    def test_wechat_contact_selector_excludes_qq_namespace(self):
        self.assertTrue(weixin_media.is_wechat_contact_uid("u123@im.wechat"))
        self.assertFalse(weixin_media.is_wechat_contact_uid("qq:1:openid"))
        self.assertFalse(weixin_media.is_wechat_contact_uid(""))

    def test_decode_aes_key_accepts_all_official_encodings(self):
        key = bytes(range(16))
        hex_text = key.hex()
        self.assertEqual(weixin_media.decode_aes_key(hex_text), key)
        self.assertEqual(
            weixin_media.decode_aes_key(base64.b64encode(key).decode()), key
        )
        self.assertEqual(
            weixin_media.decode_aes_key(
                base64.b64encode(hex_text.encode("ascii")).decode()
            ),
            key,
        )

    def test_cdn_url_encodes_opaque_slashes(self):
        url = weixin_media.build_cdn_upload_url("a/b+c=", "f/k")
        self.assertIn("encrypted_query_param=a%2Fb%2Bc%3D", url)
        self.assertIn("filekey=f%2Fk", url)

    def test_encrypt_decrypt_round_trip_and_image_validation(self):
        plaintext = b"\x89PNG\r\n\x1a\n" + b"payload" * 20
        key = os.urandom(16)
        ciphertext = weixin_media.encrypt_media(plaintext, key)
        self.assertEqual(weixin_media.decrypt_media(ciphertext, key), plaintext)
        self.assertEqual(weixin_media.validate_image_bytes(plaintext), ".png")

    async def test_upload_and_send_image_checks_wire_format(self):
        image = b"\x89PNG\r\n\x1a\n" + b"payload" * 20
        client = FakeClient(posts=[
            response(json_data={"ret": 0, "upload_param": "opaque/value+"}),
            response(headers={"x-encrypted-param": "download-param"}),
            response(json_data={"ret": 0}),
        ])
        result = await weixin_media.upload_and_send_image(
            client, "token", "wx-user", image, context_token="ctx"
        )
        self.assertEqual(result["raw_size"], len(image))
        self.assertEqual(len(client.post_calls), 3)
        get_upload_body = client.post_calls[0][1]["json"]
        self.assertEqual(get_upload_body["media_type"], 1)
        self.assertTrue(get_upload_body["no_need_thumb"])
        self.assertEqual(len(get_upload_body["aeskey"]), 32)
        self.assertIn("opaque%2Fvalue%2B", client.post_calls[1][0])
        send_body = client.post_calls[2][1]["json"]
        msg = send_body["msg"]
        self.assertEqual(msg["context_token"], "ctx")
        image_item = msg["item_list"][0]["image_item"]
        decoded_key = base64.b64decode(image_item["media"]["aes_key"])
        self.assertEqual(len(decoded_key), 32)
        self.assertRegex(decoded_key.decode("ascii"), r"^[0-9a-f]{32}$")
        self.assertEqual(image_item["mid_size"], result["cipher_size"])

    async def test_upload_retries_server_error(self):
        image = b"\xff\xd8\xff" + b"jpeg" * 30
        client = FakeClient(posts=[
            response(json_data={"upload_full_url": "https://cdn.test/upload"}),
            response(status=500, text="temporary"),
            response(headers={"x-encrypted-param": "ok"}),
            response(json_data={"ret": 0}),
        ])
        with patch("weixin_media.asyncio.sleep", new=AsyncMock()):
            result = await weixin_media.upload_and_send_image(
                client, "token", "uid", image
            )
        self.assertEqual(result["download_param"], "ok")
        self.assertEqual(len(client.post_calls), 4)

    async def test_upload_retries_when_success_response_misses_download_header(self):
        image = b"\x89PNG\r\n\x1a\n" + b"payload" * 20
        client = FakeClient(posts=[
            response(json_data={"upload_param": "up"}),
            response(headers={}),
            response(headers={"x-encrypted-param": "ok-after-retry"}),
            response(json_data={"ret": 0}),
        ])
        with patch("weixin_media.asyncio.sleep", new=AsyncMock()):
            result = await weixin_media.upload_and_send_image(
                client, "token", "uid", image
            )
        self.assertEqual(result["download_param"], "ok-after-retry")
        self.assertEqual(len(client.post_calls), 4)

    async def test_send_business_failure_is_not_success(self):
        image = b"GIF89a" + b"gif" * 30
        client = FakeClient(posts=[
            response(json_data={"upload_param": "up"}),
            response(headers={"x-encrypted-param": "dl"}),
            response(json_data={"ret": -1, "errmsg": "denied"}),
        ])
        with self.assertRaisesRegex(weixin_media.WeixinMediaError, "denied"):
            await weixin_media.upload_and_send_image(client, "token", "uid", image)

    async def test_expired_context_retries_once_without_context(self):
        client = FakeClient(posts=[
            response(json_data={"ret": -14, "errmsg": "context token expired"}),
            response(json_data={"ret": 0}),
        ])
        await weixin_media.send_text(
            client, "token", "uid", "done", context_token="old-context"
        )
        self.assertEqual(len(client.post_calls), 2)
        first_msg = client.post_calls[0][1]["json"]["msg"]
        second_msg = client.post_calls[1][1]["json"]["msg"]
        self.assertEqual(first_msg["context_token"], "old-context")
        self.assertNotIn("context_token", second_msg)
        self.assertNotEqual(first_msg["client_id"], second_msg["client_id"])

    async def test_download_inbound_base64_hex_key(self):
        plaintext = b"\xff\xd8\xff" + b"picture" * 20
        key = os.urandom(16)
        encrypted = weixin_media.encrypt_media(plaintext, key)
        client = FakeClient(gets=[response(content=encrypted)])
        data, ext = await weixin_media.download_and_decrypt_image_bytes(
            client,
            {
                "media": {
                    "full_url": "https://cdn.test/download",
                    "aes_key": base64.b64encode(key.hex().encode()).decode(),
                }
            },
        )
        self.assertEqual(data, plaintext)
        self.assertEqual(ext, ".jpg")


if __name__ == "__main__":
    unittest.main()
