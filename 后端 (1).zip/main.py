"""
main.py — WebChat 主消息引擎（v2 · 2026-05-06）

修改说明：
1. 语音识别（transcribe_audio_auto）与图片识别（analyze_image_auto）扣费时
   补充两条临时日志（add_temp_log），让用户在前端实时看到扣费记录：
     - 第 1 条：扣费动作 + 模式 + 金额（4 位精度）
     - 第 2 条：本次费用对应的服务名称
   原 print 调试输出保留。
2. 余额扣费金额最小颗粒固定 4 位小数（与 billing.py v2 对齐），不再出现
   0.000090082 之类的极小数字导致前端展示不友好。
3. 主消息流转 / debounce / worker / proactive / login_flow / message_loop
   全部保持原行为，未做改动。
"""
import asyncio
import httpx
import aiomysql
import json
import time
import re
import os
import base64
import binascii
import hashlib
import urllib.parse
import random
import threading
import resource
import tempfile
from collections import deque
from decimal import Decimal
from Crypto.Cipher import AES
import utils
import wechat_poller  # v12 (2026-05-12) 长轮询消息接收器,严格对齐官方 spec
import weixin_media   # 官方 openclaw-weixin 媒体加解密、上传和格式校验


async def _has_active_platinum(pool, user_id: int) -> bool:
    """白金会员统一计费旁路。字段尚未迁移时安全按普通用户处理。"""
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT platinum_expires_at FROM users WHERE id=%s LIMIT 1",
                    (int(user_id),),
                )
                row = await cur.fetchone()
        value = row.get("platinum_expires_at") if hasattr(row, "get") else (row[0] if row else 0)
        return int(value or 0) > int(time.time())
    except Exception:
        return False
import chat
import llm_protocol_openai as proto_openai
import llm_protocol_gemini as proto_gemini
import dynamic_mind  # per-db_id dynamic state and proactive scheduling gate
import period_care   # 「让 Ta 更懂你」经期关怀模块（随 main 加载，按消息触发）
import qqbot_worker  # QQ C2C 数据库管理器（仅主分片，主动消息关闭）

# ── chat.generate_reply 签名探测 (2026-05-09) ────────────────────────────────
# 用 inspect 一次性看它支不支持 image_paths(v8.1 多模态识图直连引入的参数)。
# 如果 chat.py 未升级到 v8.1,老签名不认识 image_paths,我们这里降级处理:
#   旧 chat → main 完全走外部 vision API 路径,与 v8 之前行为完全一致。
# 这样 main.py 与 chat.py 的部署可以错开,不会因为只升级一个就 500。
import inspect as _inspect
try:
    _CHAT_GR_SUPPORTS_IMAGE_PATHS = (
        "image_paths" in _inspect.signature(chat.generate_reply).parameters
    )
except Exception:
    _CHAT_GR_SUPPORTS_IMAGE_PATHS = False
print(
    f"[就绪] chat.generate_reply 多模态参数 image_paths 支持: "
    f"{'是 (v8.1+)' if _CHAT_GR_SUPPORTS_IMAGE_PATHS else '否 (老版本,识图走外部 API)'}",
    flush=True,
)
# ── chat.generate_reply 音频参数探测 (2026-06-14) ────────────────────────────
# 同理探测 audio_paths(doubao 原生音频直连引入)。chat.py 未升级时降级:
#   doubao 语音也走外部 STT(transcribe_audio_auto),与新功能上线前行为一致,
#   保证 main.py 与 chat.py 部署可错开,不会因单边升级导致语音被静默丢弃。
try:
    _CHAT_GR_SUPPORTS_AUDIO_PATHS = (
        "audio_paths" in _inspect.signature(chat.generate_reply).parameters
    )
except Exception:
    _CHAT_GR_SUPPORTS_AUDIO_PATHS = False
print(
    f"[就绪] chat.generate_reply 多模态参数 audio_paths 支持: "
    f"{'是 (doubao 原生音频直连)' if _CHAT_GR_SUPPORTS_AUDIO_PATHS else '否 (老版本,语音走外部 STT)'}",
    flush=True,
)
# Gemini 原生视频参数探测。部署不同步时 fail closed：不下载视频、不把视频
# 静默当成文本，而是明确提示用户升级后端。
try:
    _CHAT_GR_SUPPORTS_VIDEO_PATHS = (
        "video_paths" in _inspect.signature(chat.generate_reply).parameters
    )
except Exception:
    _CHAT_GR_SUPPORTS_VIDEO_PATHS = False
print(
    f"[就绪] chat.generate_reply 原生视频参数 video_paths 支持: "
    f"{'是' if _CHAT_GR_SUPPORTS_VIDEO_PATHS else '否'}",
    flush=True,
)
import subprocess, sys

# ── 启动即抬高 fd 上限 ─────────────────────────────────────────────────────
# 背景：systemd / login 默认给进程 soft=1024，N 个 BotInstance × httpx 池
# 很容易撑爆，表现为 [Errno 24] Too many open files。
# 这里在 import 阶段就抬，使后面 aiomysql/httpx 创建时已经在新上限下。
try:
    _fd_soft, _fd_hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    _fd_target = min(262144, _fd_hard)
    if _fd_soft < _fd_target:
        resource.setrlimit(resource.RLIMIT_NOFILE, (_fd_target, _fd_hard))
        print(f"[启动] fd soft limit: {_fd_soft} → {_fd_target} (hard={_fd_hard})", flush=True)
    else:
        print(f"[启动] fd limits: soft={_fd_soft} hard={_fd_hard}", flush=True)
except Exception as _e:
    print(f"[启动] 调整 fd 上限失败（继续启动）: {_e}", flush=True)

# ── 运行时监控状态（admin 实时监控页用） ─────────────────────────────────
# runtime_logs   : 最近 N 行 stdout 输出（含 print），供 admin 命令行日志面板。
# worker_states  : { worker_id: {'started_at': monotonic, 'db_id', 'uid', 'stage'} }
#                  仅在 worker 处理任务期间有键，处理完即删，方便统计活跃度。
# _runtime_log_lock : 保护 runtime_logs 跨线程 append/iter（asyncio.to_thread 场景）。
RUNTIME_LOG_MAXLEN     = 500
RUNTIME_LOG_LINE_MAX   = 800   # 单行字符上限（前端显示+DB 存储双保险）
runtime_logs           = deque(maxlen=RUNTIME_LOG_MAXLEN)
worker_states          = {}
_runtime_log_lock      = threading.Lock()

class _TeeStdout:
    """
    包一层 sys.stdout：原样写终端，同时把每一行追加到 runtime_logs。
    设计要点：
      1) 不丢失原行为（self.real.write/flush 始终调用）。
      2) 按 \\n 切分缓冲，避免半行入库；超长行截断到 RUNTIME_LOG_LINE_MAX。
      3) 用 threading.Lock 保护 deque：to_thread 里的 print 也不会冲突。
    """
    def __init__(self, real):
        self.real = real
        self._buf = ""
    def write(self, s):
        try:
            self.real.write(s)
        except Exception:
            pass
        if not s:
            return
        self._buf += s
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            line = line.rstrip("\r")
            if not line:
                continue
            if len(line) > RUNTIME_LOG_LINE_MAX:
                line = line[:RUNTIME_LOG_LINE_MAX] + "…"
            with _runtime_log_lock:
                runtime_logs.append({"ts": time.time(), "msg": line})
    def flush(self):
        try:
            self.real.flush()
        except Exception:
            pass
    def isatty(self):
        try: return self.real.isatty()
        except Exception: return False
    def fileno(self):
        return self.real.fileno()

# 安装 tee：放在所有 import 之后、首次 print 之前
sys.stdout = _TeeStdout(sys.stdout)
sys.stderr = _TeeStdout(sys.stderr)

def _wstage(worker_id: int, stage: str, detail: str = ""):
    """更新 Worker 阶段，并保留最近轨迹供 admin 点击查看。"""
    st = worker_states.get(worker_id)
    if st is not None:
        now_mono = time.monotonic()
        stage = str(stage or 'processing')[:80]
        detail = str(detail or '')[:240]
        previous = st.get('stage', '')
        if previous != stage:
            stage_started = st.get('stage_started_at', now_mono)
            history = st.setdefault('stage_history', [])
            if previous:
                history.append({
                    'stage': previous,
                    'detail': st.get('detail', ''),
                    'ms': max(0, int((now_mono - stage_started) * 1000)),
                })
                del history[:-8]
            st['stage'] = stage
            st['stage_started_at'] = now_mono
        st['detail'] = detail
        st['updated_at'] = now_mono

import pilk
from pydub import AudioSegment

subprocess.Popen([sys.executable, os.path.join(os.path.dirname(__file__), 'emoji.py')])

DB_CONFIG = {
    'host': '127.0.0.1',
    'port': 3306,
    'user': 'webchat',
    'password': '',
    'db': 'webchat',
    'autocommit': True
}

# ════════════════════════════════════════════════════════════════════════
# 多进程分片配置（2026 多核改造）
# ────────────────────────────────────────────────────────────────────────
# 单个 Python 进程受 GIL 限制只能用 1 个核。3000+ 微信实例靠单进程跑不动,
# 改为启动 SHARD_TOTAL 个 main.py 进程,每个进程认领一部分实例:
#       某实例归属进程 = 实例ID % SHARD_TOTAL
# 取模分片的好处:新增实例无需重启 —— 实例加载循环每轮扫库时,
#   id%SHARD_TOTAL==SHARD_INDEX 的新实例会被对应进程自动接管(动态分配)。
#
# 由启动脚本通过环境变量传入:
#   SHARD_INDEX  本进程编号 0 .. SHARD_TOTAL-1
#   SHARD_TOTAL  进程总数(由启动脚本指定；低配置服务器当前默认 2)
# 未设置时回退到「单进程模式」(SHARD_TOTAL=1, SHARD_INDEX=0),行为同改造前。
# ════════════════════════════════════════════════════════════════════════
try:
    SHARD_TOTAL = max(1, int(os.environ.get('SHARD_TOTAL', '1')))
except ValueError:
    SHARD_TOTAL = 1
try:
    SHARD_INDEX = int(os.environ.get('SHARD_INDEX', '0'))
except ValueError:
    SHARD_INDEX = 0
if not (0 <= SHARD_INDEX < SHARD_TOTAL):
    print(f"[启动][致命] SHARD_INDEX={SHARD_INDEX} 必须在 0..{SHARD_TOTAL-1} 之间", flush=True)
    raise SystemExit(1)

# 0 号进程额外负责「全局唯一服务」(webchat_server / 语音 WS / 监控快照),
# 其余进程只跑微信 bot 业务,避免多进程抢占端口、抢写监控快照。
IS_PRIMARY_SHARD = (SHARD_INDEX == 0)

print(f"[启动] 多进程分片: 本进程 SHARD_INDEX={SHARD_INDEX} / "
      f"SHARD_TOTAL={SHARD_TOTAL}{'  [主进程]' if IS_PRIMARY_SHARD else ''}",
      flush=True)

BASE_URL     = "https://ilinkai.weixin.qq.com/ilink/bot"
CDN_BASE_URL = "https://novac2c.cdn.weixin.qq.com/c2c"

task_queue         = asyncio.Queue()
active_workers     = 0
global_worker_count = 500   # 默认值；admin 在 system_config.worker_threads 里可覆盖
user_message_buffers = {}

# 全局存储主动消息的计时器字典，按 (db_id, uid) 隔离
proactive_timers = {}
# 主动计时器可能刚 claim 并入队，随后用户恰好发言；此时取消一个已结束的
# timer 已无法移除队列项。记录最近真实到场时间，worker 在调用模型前做最后
# 一道竞态门控。实例固定归属同一 shard，因此这里不需要跨进程共享。
recent_user_activity = {}
_proactive_switch_errors_logged = set()
_mind_entitlement_errors_logged = set()


def _cancel_proactive_timers_for_dbid(db_id):
    """A mind is keyed by db_id, so only its latest contact may own a timer."""
    for timer_key in list(proactive_timers):
        if timer_key[0] != db_id:
            continue
        task = proactive_timers.pop(timer_key, None)
        if task is not None and not task.done():
            task.cancel()


async def _dynamic_mind_proactive_enabled(pool, db_id: int) -> bool:
    """Read the instance switch, gated by the paid 心潮 entitlement.

    ``proactive_enabled`` was added after some existing deployments.  Its
    missing-column/error fallback intentionally remains ``True`` for backward
    compatibility, but the paid entitlement check is always fail-closed.
    """
    if not await _has_mind_entitlement(pool, db_id):
        return False
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT proactive_enabled FROM instances WHERE id=%s",
                    (db_id,),
                )
                row = await cur.fetchone()
        value = row.get("proactive_enabled") if isinstance(row, dict) else (row[0] if row else None)
        _proactive_switch_errors_logged.discard(db_id)
        return True if value is None else bool(int(value))
    except Exception as exc:
        # 老库可能还没有该字段；与旧行为一致，异常时默认开，
        # 但打一条可诊断日志。
        if db_id not in _proactive_switch_errors_logged:
            _proactive_switch_errors_logged.add(db_id)
            print(
                f"[心潮·开关] 查 proactive_enabled 失败 db_id={db_id}: "
                f"{type(exc).__name__}: {exc}",
                flush=True,
            )
        return True


async def _has_mind_entitlement(pool, db_id: int) -> bool:
    """Return whether an instance's owner has purchased 心潮.

    The purchase site and this service share the ``users`` table.  Any missing
    field/table, missing relationship, NULL, malformed value, or query error
    is treated as *not purchased* (fail-closed), so an API/DB issue cannot
    accidentally expose the paid dynamic-mind features.
    """
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT u.mind_purchased "
                    "FROM instances i "
                    "INNER JOIN users u ON u.id = i.user_id "
                    "WHERE i.id=%s LIMIT 1",
                    (db_id,),
                )
                row = await cur.fetchone()
        value = row.get("mind_purchased") if isinstance(row, dict) else (row[0] if row else None)
        if isinstance(value, bool):
            entitled = value
        elif isinstance(value, (int, Decimal)):
            entitled = value == 1
        elif isinstance(value, str):
            entitled = value.strip() == "1"
        else:
            entitled = False
        _mind_entitlement_errors_logged.discard(db_id)
        return bool(entitled)
    except Exception as exc:
        if db_id not in _mind_entitlement_errors_logged:
            _mind_entitlement_errors_logged.add(db_id)
            print(
                f"[心潮·权益] 校验失败 db_id={db_id}: "
                f"{type(exc).__name__}: {exc}（按未购买处理）",
                flush=True,
            )
        return False

async def _dynamic_mind_config(pool, db_id: int) -> dict:
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute("SELECT dream_probability FROM instances WHERE id=%s", (db_id,))
                row = await cur.fetchone()
        value = row.get("dream_probability") if isinstance(row, dict) else (row[0] if row else None)
        return {"dream_probability": 0.35 if value is None else max(0.0, min(1.0, float(value)))}
    except Exception:
        return {"dream_probability": 0.35}

async def cleanup_file_delayed(file_path: str, delay: int):
    await asyncio.sleep(delay)
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
            print(f"[系统任务] 自动清理过期文件成功: {file_path}")
    except Exception as e:
        print(f"[系统任务] 自动清理文件失败: {e}")

def silk_to_mp3(silk_path: str, mp3_path: str):
    pcm_path = silk_path + ".pcm"
    pilk.decode(silk_path, pcm_path)
    audio = AudioSegment.from_raw(pcm_path, sample_width=2, frame_rate=24000, channels=1)
    audio.export(mp3_path, format="mp3")
    os.remove(pcm_path)


def mp3_to_silk(mp3_path: str):
    """把 mp3 转成微信可播放的 SILK(24kHz 单声道 16bit)。返回 (silk_path, duration_ms)。
    与收到语音时的 silk_to_mp3 完全对称: 那边 pilk.decode(silk->pcm), 这边 pilk.encode(pcm->silk)。
    tencent=True 生成带微信版本头(0x02)的 SILK, 与解码侧看到的 '02 23 21 53 49 4c 4b 5f 56 33' 对齐。"""
    pcm_path  = mp3_path + ".pcm"
    silk_path = mp3_path + ".silk"
    audio = AudioSegment.from_file(mp3_path)
    audio = audio.set_frame_rate(24000).set_channels(1).set_sample_width(2)
    duration_ms = len(audio)                 # pydub 长度即毫秒数, 作为 playtime
    audio.export(pcm_path, format="raw")     # 裸 PCM, 供 pilk 编码
    pilk.encode(pcm_path, silk_path, pcm_rate=24000, tencent=True)
    try:
        os.remove(pcm_path)
    except OSError:
        pass
    return silk_path, duration_ms


async def download_and_decrypt_voice(client: httpx.AsyncClient, voice_item: dict) -> str:
    """
    完全回退到 v8.4 之前的原始版本(2026-05-10):
      用户反馈我之前 v8.5/v8.5.1/v8.5.2 的修改是错误方向,
      原版本来就工作正常,只是偶发接口波动失败,
      被我改完反而变成稳定失败。
    
    保留的唯一改动:解密后打印 1 行 hex,方便排查偶发失败时
    到底是接口返回错误密文,还是 SILK 协议格式问题。
    """
    media = voice_item.get("media", {})
    full_url = media.get("full_url")
    aes_key_b64 = media.get("aes_key")
    
    if not full_url or not aes_key_b64:
        print("未找到语音的下载地址或解密密钥")
        return ""
        
    try:
        print(f"正在下载语音密文...")
        res = await client.get(full_url)
        encrypted_data = res.content
        
        decoded_key = base64.b64decode(aes_key_b64)
        key = binascii.unhexlify(decoded_key) if len(decoded_key) == 32 else decoded_key
        
        cipher = AES.new(key, AES.MODE_ECB)
        plaintext = cipher.decrypt(encrypted_data)
        silk_data = plaintext[:-plaintext[-1]]
        
        # ── 唯一新增 ── 解密后打印明文前 16 字节 hex,排查接口偶发失败用
        # 正常 SILK 数据应该看到 23 21 53 49 4c 4b 5f 56 33 (#!SILK_V3) 或
        # 02 23 21 53 49 4c 4b 5f 56 33 (微信版本字节 + #!SILK_V3)
        print(f"[诊断] 密文长度={len(encrypted_data)}, 明文头 16 字节 hex={plaintext[:16].hex()}")
        
        ts = int(time.time())
        rnd = random.randint(1000, 9999)
        silk_path = f"received_voice_{ts}_{rnd}.silk"
        mp3_path = f"received_voice_{ts}_{rnd}.mp3"
        
        with open(silk_path, "wb") as f:
            f.write(silk_data)
            
        print("正在将 SILK 转码为 MP3...")
        await asyncio.to_thread(silk_to_mp3, silk_path, mp3_path)
        print(f"语音解密并转码成功: {mp3_path}")
        
        if os.path.exists(silk_path):
            os.remove(silk_path)
            
        return mp3_path
        
    except Exception as e:
        print(f"[底层通道] 语音下载或解密转码异常: {e}")
        return ""

async def transcribe_audio_auto(mp3_path: str, pool, db_id: int, user_id: int) -> str:
    voice_price = 0.0500  # 4 位精度，与 billing.py v2 对齐
    platinum_active = await _has_active_platinum(pool, user_id)
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute("SELECT balance FROM users WHERE id=%s", (user_id,))
            u_row   = await cur.fetchone()
            balance = float(u_row['balance']) if u_row else 0.0

    if not platinum_active and balance < voice_price:
        await utils.add_temp_log(
            pool, db_id,
            f"[听语音] 余额不足（¥{balance:.4f} < ¥{voice_price:.4f}），已拦截"
        )
        return "【系统提示：该用户发送了一条语音，但其账户余额不足以支付识别费用。请遵循人设委婉告知用户余额不足，无法听取语音。】"

    url = "https://api.openlux.ai/v1/audio/transcriptions"
    api_key = ""
    model = "gpt-4o-transcribe"

    try:
        print(f"[后台语音组件] [实例 {db_id}] 正在识别语音...")
        async with httpx.AsyncClient(timeout=120.0) as stt_client:
            with open(mp3_path, "rb") as audio_file:
                files = {"file": ("voice.mp3", audio_file, "audio/mpeg")}
                data = {"model": model}
                headers = {"Authorization": f"Bearer {api_key}"}

                res = await stt_client.post(url, headers=headers, data=data, files=files)
                res.raise_for_status()
                transcribed_text = res.json().get("text", "")

                if transcribed_text:
                    if platinum_active:
                        await utils.add_temp_log(
                            pool, db_id,
                            f"[白金会员] 语音识别不计费，识别长度 {len(transcribed_text)} 字"
                        )
                        return f"用户刚刚发送了一条语音消息，内容是“{transcribed_text}”。"
                    async with pool.acquire() as conn:
                        async with conn.cursor() as cur:
                            await cur.execute(
                                "UPDATE users SET balance = GREATEST(0, balance - %s) WHERE id=%s",
                                (Decimal(str(voice_price)), user_id)
                            )
                        await conn.commit()
                    # 用户视角的两条扣费日志
                    await utils.add_temp_log(
                        pool, db_id,
                        f"[扣费] 语音识别按量计费：扣 ¥{voice_price:.4f}（余额计费）"
                    )
                    await utils.add_temp_log(
                        pool, db_id,
                        f"[听语音] 已成功识别用户语音，长度 {len(transcribed_text)} 字"
                    )
                    print(f"[后台语音组件] [实例 {db_id}] 语音识别成功，已执行计费扣除：{voice_price:.4f} 元。")
                    return f"用户刚刚发送了一条语音消息，内容是“{transcribed_text}”。"
                else:
                    return "【系统提示：该用户发送了一条语音，但识别内容为空。】"

    except Exception as e:
        print(f"[后台语音组件] [实例 {db_id}] 语音识别异常: {e}")
        await utils.add_temp_log(pool, db_id, f"[听语音] 接口异常：{str(e)[:80]}")
        return "【系统提示：识别语音接口返回异常失败，请遵循人设回复告知用户你现在听不了这条语音。】"

async def download_and_decrypt_image(client: httpx.AsyncClient, image_item: dict) -> str:
    try:
        print(f"正在从 CDN 下载图片密文...")
        decrypted, extension = await weixin_media.download_and_decrypt_image_bytes(
            client, image_item
        )
        # 使用系统临时目录和原子生成的唯一文件名，避免多进程同毫秒/同随机数
        # 覆盖图片，也避免工作目录不可写导致“已解密但无法交给模型”。
        fd, filename = tempfile.mkstemp(prefix="weixin-image-", suffix=extension)
        with os.fdopen(fd, "wb") as f:
            f.write(decrypted)
        print(f"图片已成功解密并保存到临时目录: {filename}")
        return filename

    except Exception as e:
        print(f"[底层通道] 图片下载或解密异常: {e}")
        return ""


class VideoTooLargeError(ValueError):
    """微信视频可下载，但超过 Gemini generateContent 的安全内联上限。"""


def _decode_weixin_video_aes_key(aes_key_b64: str) -> bytes:
    """兼容微信 CDN 的 raw-16 和 base64(hex-32) 两种 AES key 编码。"""
    try:
        decoded = base64.b64decode(aes_key_b64, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError("视频 AES 密钥不是有效的 Base64") from exc
    if len(decoded) == 16:
        return decoded
    if len(decoded) == 32 and re.fullmatch(rb"[0-9a-fA-F]{32}", decoded):
        return binascii.unhexlify(decoded)
    raise ValueError("视频 AES 密钥长度无效")


async def download_and_decrypt_video(
    client: httpx.AsyncClient,
    video_item: dict,
) -> str:
    """下载微信 VIDEO(type=5) 并以 AES-128-ECB/PKCS#7 解密为 MP4。"""
    media = (video_item or {}).get("media") or {}
    full_url = media.get("full_url")
    encrypt_query_param = media.get("encrypt_query_param") or ""
    aes_key_b64 = media.get("aes_key") or ""
    if not full_url and encrypt_query_param:
        full_url = (
            f"{CDN_BASE_URL}/download?encrypted_query_param="
            f"{urllib.parse.quote(encrypt_query_param)}"
        )
    if not full_url or not aes_key_b64:
        raise ValueError("视频缺少下载地址或解密密钥")

    try:
        reported_size = int(video_item.get("video_size") or 0)
    except (TypeError, ValueError):
        reported_size = 0
    # video_size 通常是补齐后的密文长度，最多比明文多一个 AES block。
    if reported_size > proto_gemini.GEMINI_INLINE_VIDEO_MAX_BYTES + AES.block_size:
        raise VideoTooLargeError("视频超过 Gemini 内联大小限制")

    key = _decode_weixin_video_aes_key(aes_key_b64)
    # 流式读取并在密文阶段限流，避免 video_size 缺失/伪造时把超大响应整体装入内存。
    encrypted_limit = proto_gemini.GEMINI_INLINE_VIDEO_MAX_BYTES + AES.block_size
    encrypted_buffer = bytearray()
    async with client.stream("GET", full_url, timeout=120.0) as response:
        response.raise_for_status()
        async for chunk in response.aiter_bytes():
            encrypted_buffer.extend(chunk)
            if len(encrypted_buffer) > encrypted_limit:
                raise VideoTooLargeError("视频超过 Gemini 内联大小限制")
    ciphertext = bytes(encrypted_buffer)
    if not ciphertext or len(ciphertext) % AES.block_size != 0:
        raise ValueError("视频密文长度无效")

    plaintext = AES.new(key, AES.MODE_ECB).decrypt(ciphertext)
    pad_len = plaintext[-1]
    if not (1 <= pad_len <= AES.block_size):
        raise ValueError("视频 PKCS#7 填充无效")
    if plaintext[-pad_len:] != bytes([pad_len]) * pad_len:
        raise ValueError("视频 PKCS#7 填充不完整")
    plaintext = plaintext[:-pad_len]
    if not plaintext:
        raise ValueError("视频解密后为空")
    if len(plaintext) > proto_gemini.GEMINI_INLINE_VIDEO_MAX_BYTES:
        raise VideoTooLargeError("视频超过 Gemini 内联大小限制")

    filename = f"received_video_{int(time.time())}_{random.randint(1000, 9999)}.mp4"
    with open(filename, "wb") as video_file:
        video_file.write(plaintext)
    return filename

async def analyze_image_auto(image_path: str, pool, db_id: int, user_id: int) -> str:
    import base64 as b64mod
    platinum_active = await _has_active_platinum(pool, user_id)
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT config_key, config_value FROM system_config "
                "WHERE config_key IN ('vision_price', 'vision_endpoint', 'vision_keys', 'vision_model')"
            )
            rows   = await cur.fetchall()
            config = {r['config_key']: r['config_value'] for r in rows}

            await cur.execute("SELECT balance FROM users WHERE id=%s", (user_id,))
            u_row   = await cur.fetchone()
            balance = float(u_row['balance']) if u_row else 0.0

    vision_price = round(float(config.get('vision_price', 0.1)), 4)  # 4 位精度

    if not platinum_active and balance < vision_price:
        await utils.add_temp_log(
            pool, db_id,
            f"[看图] 余额不足（¥{balance:.4f} < ¥{vision_price:.4f}），已拦截"
        )
        return "【系统提示：该用户发送了一张图片，但其账户余额不足以支付识图费用。请遵循人设委婉告知用户余额不足，无法查看照片。】"

    raw_ep = config.get('vision_endpoint', 'https://ai.gitee.com/v1').strip()
    if "chat/completions" not in raw_ep:
        vision_endpoint = raw_ep.rstrip("/") + "/v1/chat/completions" if "v1" not in raw_ep else raw_ep.rstrip("/") + "/chat/completions"
    else:
        vision_endpoint = raw_ep

    vision_model = config.get('vision_model', 'Qwen2-VL-72B')
    keys_str     = config.get('vision_keys', '')
    keys         = [k.strip() for k in keys_str.split(',') if k.strip()]

    if not keys:
        return "【系统提示：服务器未配置识图 API 密钥，识别图片失败。请遵循人设回复。】"

    with open(image_path, "rb") as f:
        image_bytes = f.read()
    try:
        image_ext = weixin_media.validate_image_bytes(image_bytes, label="待识别图片")
    except Exception:
        image_ext = os.path.splitext(image_path)[1].lower()
    image_mime = {
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
        ".gif": "image/gif", ".webp": "image/webp", ".bmp": "image/bmp",
    }.get(image_ext, "image/jpeg")
    base64_image = b64mod.b64encode(image_bytes).decode('utf-8')

    payload = {
        "model": vision_model,
        "messages": [
            {
                "role": "system",
                "content": "You are a helpful and harmless assistant. You should think step-by-step."
            },
            {
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": f"data:{image_mime};base64,{base64_image}"}},
                    {"type": "text", "text": "请用中文详细描述这张图片的所有细节。"}
                ]
            }
        ],
        "stream": False,
        "max_tokens": 1024,
        "temperature": 0.2,
        "top_p": 1,
        "top_k": -1,
        "frequency_penalty": 1.2
    }

    last_error = ""
    for attempt in range(5):
        key     = keys[attempt % len(keys)]
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        try:
            print(f"[后台识图组件] [实例 {db_id}] 正在提取画面特征 (尝试 {attempt+1}/5)...")
            async with httpx.AsyncClient(timeout=120.0) as vision_client:
                res  = await vision_client.post(vision_endpoint, json=payload, headers=headers)
                res.raise_for_status()
                data    = res.json()
                content = data.get("choices", [{}])[0].get("message", {}).get("content", "")

                if content:
                    if platinum_active:
                        await utils.add_temp_log(
                            pool, db_id,
                            f"[白金会员] 图片识别不计费，描述长度 {len(content)} 字"
                        )
                        return (
                            f"【系统提示：该用户向你发送了一张图片，底层视觉组件返回的内容如下】\n"
                            f"{content}\n"
                            f"(请结合上下文及上述图片内容自然地给出你的回复)"
                        )
                    async with pool.acquire() as conn:
                        async with conn.cursor() as cur:
                            await cur.execute(
                                "UPDATE users SET balance = GREATEST(0, balance - %s) WHERE id=%s",
                                (Decimal(str(vision_price)), user_id)
                            )
                        await conn.commit()
                    # 用户视角的两条扣费日志
                    await utils.add_temp_log(
                        pool, db_id,
                        f"[扣费] 图片识别按量计费：扣 ¥{vision_price:.4f}（余额计费）"
                    )
                    await utils.add_temp_log(
                        pool, db_id,
                        f"[看图] 已成功提取画面特征，描述长度 {len(content)} 字"
                    )
                    print(f"[后台识图组件] [实例 {db_id}] 识图成功，已执行计费扣除：{vision_price:.4f} 元。")
                    return (
                        f"【系统提示：该用户向你发送了一张图片，底层视觉组件返回的内容如下】\n"
                        f"{content}\n"
                        f"(请结合上下文及上述图片内容自然地给出你的回复)"
                    )

        except Exception as e:
            last_error = str(e)
            print(f"[后台识图组件] [实例 {db_id}] 第 {attempt+1} 次请求异常: {last_error}，切换下一 Key...")
            await asyncio.sleep(1.0)

    return f"【系统提示：识别图片失败（连续报错：{last_error}），请遵循人设回复告知用户你现在看不了这张图片。】"


# =============================================================================
# 平均回复延迟统计 (2026-05-08 新增)
#   - 记录单位：毫秒;一轮 = 用户消息进入到 AI 即将发出第一条回复的间隔
#   - 限速、思考、工具循环、重试都被自然计入(这正是用户感知的延迟)
#   - 主动消息(is_proactive=True)与无回复轮次不计
#   - 仅保留每个实例最近 _LATENCY_KEEP 轮,避免历史拖累平均值
# =============================================================================
_LATENCY_KEEP = 20

async def _record_reply_latency(pool, db_id: int, latency_ms: int) -> None:
    """异步写入一轮回复延迟到 instances.recent_latencies(JSON 数组)。"""
    if latency_ms < 0:
        return
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT recent_latencies FROM instances WHERE id=%s", (db_id,)
                )
                row = await cur.fetchone()
                arr = []
                if row:
                    raw = row.get("recent_latencies") if isinstance(row, dict) else row[0]
                    if raw:
                        try:
                            parsed = json.loads(raw)
                            if isinstance(parsed, list):
                                arr = [int(x) for x in parsed if isinstance(x, (int, float))]
                        except Exception:
                            arr = []
                arr.append(int(latency_ms))
                if len(arr) > _LATENCY_KEEP:
                    arr = arr[-_LATENCY_KEEP:]
                await cur.execute(
                    "UPDATE instances SET recent_latencies=%s WHERE id=%s",
                    (json.dumps(arr), db_id),
                )
            await conn.commit()
    except Exception as e:
        # 延迟统计失败不能影响主流程,仅打印
        print(f"[延迟统计] 写入失败 db_id={db_id}: {e}")


async def _send_text_chunks(
    bot_instance, uid, context_token, text, wx_token_plain,
    split_rule, ignore_punc, pool,
):
    """按分段规则发送文本；每段只请求一次，不进行发送重试。"""
    # 发送层最后一道通道隔离：此函数只允许由微信 BotInstance 调用。
    # QQ 的回复由 QQBotWorker 使用自己的 access_token + openid 发送；若
    # 误把 QQ 适配器传进来，宁可记录并失败，也不能拿 instances.wx_token
    # 拼到 QQ 消息上。
    channel = str(getattr(bot_instance, "tool_channel", "wechat") or "wechat").strip().lower()
    if channel != "wechat":
        error = f"发送通道不匹配（当前={channel}，微信发送器拒绝处理）"
        try:
            await utils.add_temp_log(pool, bot_instance.db_id, f"[发送失败] {error}")
        except Exception:
            pass
        return False, error, False
    if not wx_token_plain:
        error = "微信发送凭据为空"
        try:
            await utils.add_temp_log(pool, bot_instance.db_id, f"[发送失败] {error}")
        except Exception:
            pass
        return False, error, False
    chunks = (
        [text] if split_rule == "\x00"
        else utils.split_text(text, split_rule, ignore_punc)
    )
    first_chunk = True
    for chunk in chunks:
        if not chunk:
            continue
        if not first_chunk:
            await asyncio.sleep(2.0)
        first_chunk = False

        result = await weixin_media.send_text_attempt(
            bot_instance.client,
            wx_token_plain,
            uid,
            chunk,
            context_token=context_token,
            client_id=utils.generate_client_id(),
        )
        if result.success:
            continue

        error = result.error or "未知发送错误"
        if result.context_expired and context_token:
            try:
                await weixin_media.invalidate_context_record(
                    pool, bot_instance.db_id, uid, context_token
                )
            except Exception as exc:
                print(
                    f"[发送] 失效微信会话凭据写回失败 db_id={bot_instance.db_id}: "
                    f"{type(exc).__name__}: {exc}",
                    flush=True,
                )
        try:
            await utils.add_temp_log(
                pool, bot_instance.db_id,
                f"[发送失败] 用户 {uid[:24]} chunk={chunk[:60]!r} 错误: {error}",
            )
        except Exception:
            pass
        return False, error, False

    return True, None, False


async def _send_wx_text(
    bot_instance, uid, context_token, text, pool, wx_token_plain,
    split_rule, ignore_punc,
):
    """发送最终文字一次；失败只记日志，不挂起、不延迟重发。"""
    success, _error, _retryable = await _send_text_chunks(
        bot_instance, uid, context_token, text,
        wx_token_plain, split_rule, ignore_punc, pool,
    )
    return success
# ============================================================
# 微信语音回复 (语音会员 · 2026-07)
#   用户在语音通话页开启「同时用于微信」后, voice_members.wechat_enabled=1。
#   微信收到消息、AI 产生回复后, 用该用户的克隆音色把回复合成 mp3, 发到微信。
#   合成走同进程 websocker.tts + 平台硬编码 DashScope key, 不额外计费。
#   任何一步失败都会返回 False, 由调用方回退为普通文本发送 —— 绝不丢消息。
# ============================================================
# 站点公网根 (与 api_voice_call.php 的 WS 域名同源); 语音 mp3 需可公网访问供微信侧拉取
VOICE_PUBLIC_BASE = "https://cl2.webchat.asia"
VOICE_OUT_DIR     = "voice_out"          # 文件系统: data/voice_out/ (main.py 与 data 同级)
VOICE_OUT_URLPATH = "data/voice_out"     # 对外 URL 路径 = 域名 + /data/voice_out/xxx.mp3


async def _load_wx_voice_setting(pool, owner_user_id):
    """读【实例所有者 = 控制台账号】的微信语音设置。返回 (enabled, voice_id, reason)。
    ★ 关键: 用控制台 user_id(整数) 查, 不是微信 wxid ——
       voice_members 按控制台账号建行; 微信侧 uid 是 'xxx@im.wechat' 字符串,
       旧代码对它做 int() 会抛异常被吞掉, 导致永远判定为未开启、语音永不发送。
    三者同时满足才启用: 会员未过期 + wechat_enabled=1 + voice_id 非空。"""
    try:
        oid = int(owner_user_id)
    except (TypeError, ValueError):
        return (False, "", f"owner_user_id 非法({owner_user_id!r})")
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT voice_expired_at, voice_id, wechat_enabled "
                    "FROM voice_members WHERE user_id=%s LIMIT 1",
                    (oid,),
                )
                row = await cur.fetchone()
    except Exception as e:
        return (False, "", f"查 voice_members 异常: {type(e).__name__}")
    if not row:
        return (False, "", "该账号无语音会员记录")
    exp = int(row.get("voice_expired_at") or 0)
    vid = str(row.get("voice_id") or "").strip()
    on  = int(row.get("wechat_enabled") or 0) == 1
    if not on:
        return (False, vid, "「同时用于微信」开关未开")
    if not vid:
        return (False, "", "尚未克隆音色(voice_id 为空)")
    # 白金会员包含语音通话；已有音色记录时，白金有效期覆盖已过期的普通语音会员。
    if exp <= int(time.time()) and not await _has_active_platinum(pool, oid):
        return (False, vid, "语音会员已过期")
    return (True, vid, "")


def _gc_voice_out(out_dir, max_age=3600):
    """清理 data/voice_out/ 下超过 max_age 秒的旧 mp3, 防止累积。"""
    try:
        now = time.time()
        for fn in os.listdir(out_dir):
            fp = os.path.join(out_dir, fn)
            if os.path.isfile(fp) and (now - os.path.getmtime(fp)) > max_age:
                try: os.remove(fp)
                except Exception: pass
    except Exception:
        pass


async def _tts_reply_to_mp3(text, voice_id):
    """用平台 key + 用户音色把文本合成 mp3 字节。失败返回 None。"""
    try:
        import websocker.tts as _vtts
        import websocker.config as _vcfg
        return await _vtts.synthesize(text, voice_id, _vcfg.DASHSCOPE_API_KEY)
    except Exception as e:
        print(f"[微信语音] TTS 合成失败, 回退文本: {e}", flush=True)
        return None


async def _wx_upload_media(client, wx_token_plain, data_bytes, to_user, media_type):
    """按官方协议把媒体上传到微信 CDN(AES-128-ECB + PKCS7)。返回
    {download_param, aeskey(bytes), cipher_size} 或 None。media_type: 1图 2视频 3文件 4语音。
    流程: getuploadurl 拿上传地址 -> 上传密文 -> 从响应头 x-encrypted-param 拿下载参数。"""
    rawsize  = len(data_bytes)
    md5hex   = hashlib.md5(data_bytes).hexdigest()
    cipher_size = ((rawsize + 1 + 15) // 16) * 16      # PKCS7 后长度(整块时补满一整块)
    filekey  = os.urandom(16).hex()                    # 32 位十六进制串
    aeskey   = os.urandom(16)                          # 16 字节原始密钥

    headers = {
        "Authorization": f"Bearer {wx_token_plain}",
        "AuthorizationType": "ilink_bot_token",
        "iLink-App-ClientVersion": "1",
        "iLink-App-Id": "bot",
        "X-WECHAT-UIN": utils.generate_x_wechat_uin(),
        "Content-Type": "application/json",
    }
    body = {
        "filekey": filekey,
        "media_type": media_type,
        "to_user_id": to_user,
        "rawsize": rawsize,
        "rawfilemd5": md5hex,
        "filesize": cipher_size,
        "no_need_thumb": True,
        "aeskey": aeskey.hex(),
        "base_info": {"channel_version": "webchat-main", "bot_agent": "webchat/1.0"},
    }
    try:
        r = await client.post(f"{BASE_URL}/getuploadurl", json=body, headers=headers, timeout=30)
        if r.status_code != 200:
            print(f"[微信语音] getuploadurl HTTP {r.status_code}: {(r.text or '')[:160]}", flush=True)
            return None
        resp = r.json()
    except Exception as e:
        print(f"[微信语音] getuploadurl 异常 {type(e).__name__}: {str(e)[:120]}", flush=True)
        return None

    full  = (resp.get("upload_full_url") or "").strip()
    param = resp.get("upload_param")
    if full:
        upload_url = full
    elif param:
        upload_url = (f"{CDN_BASE_URL}/upload?encrypted_query_param="
                      f"{urllib.parse.quote(param)}&filekey={urllib.parse.quote(filekey)}")
    else:
        print(f"[微信语音] getuploadurl 未返回上传地址: {resp}", flush=True)
        return None

    # AES-128-ECB + PKCS7(与收语音的解密 plaintext[:-plaintext[-1]] 对称)
    padlen = 16 - (rawsize % 16)            # 1..16
    padded = data_bytes + bytes([padlen]) * padlen
    ciphertext = AES.new(aeskey, AES.MODE_ECB).encrypt(padded)
    try:
        ru = await client.post(upload_url, content=ciphertext,
                               headers={"Content-Type": "application/octet-stream"}, timeout=60)
        if ru.status_code != 200:
            print(f"[微信语音] CDN 上传 HTTP {ru.status_code}: {(ru.text or '')[:160]}", flush=True)
            return None
        dparam = ru.headers.get("x-encrypted-param")
        if not dparam:
            print("[微信语音] CDN 响应缺少 x-encrypted-param 头", flush=True)
            return None
    except Exception as e:
        print(f"[微信语音] CDN 上传异常 {type(e).__name__}: {str(e)[:120]}", flush=True)
        return None

    return {"download_param": dparam, "aeskey": aeskey, "cipher_size": cipher_size}


async def _charge_wx_tts(pool, owner_user_id, nchars):
    """微信语音文件的合成按字数从会员(owner)余额扣: ¥8/万字。GREATEST 兜底不为负。"""
    if not nchars or nchars <= 0:
        return
    if await _has_active_platinum(pool, int(owner_user_id)):
        print(f"[微信语音] 白金会员 TTS 不计费 owner={owner_user_id} 字数={nchars}", flush=True)
        return
    cost = round(nchars * 8.0 / 10000.0, 4)
    if cost <= 0:
        return
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute("UPDATE users SET balance = GREATEST(0, balance - %s) WHERE id=%s", (cost, int(owner_user_id)))
            await conn.commit()
        print(f"[微信语音] TTS 计费 owner={owner_user_id} 字数={nchars} 扣 ¥{cost}", flush=True)
    except Exception as e:
        print(f"[微信语音] TTS 计费失败(不影响发送): {e}", flush=True)


async def _maybe_send_wx_voice(bot_instance, uid, context_token, text, pool, wx_token_plain, owner_user_id):
    """开启微信语音时: 清洗文本 -> DashScope 合成 mp3 -> 以【文件(FileItem type=4)】发到微信。
    这是【补发】的一份语音文件 —— 调用方已先发出文本, 这里再补一份 mp3 文件,
    做到「文本 + 语音都发给用户」。返回 True=已补发, False=这步失败(不影响文本)。
    ★ 关键(与项目原有 send_voice 工具一致): iLink 协议里 mp3 不是语音气泡
       (VoiceItem 只收 SILK/Opus), 必须作为【文件附件 FileItem, media_type=3】下发。
       之前用 SILK+VoiceItem 是错的, 所以一直发不出来。
    · owner_user_id: 实例所有者的控制台 user_id(整数), 用于查语音会员设置(不是微信 wxid)。
    合成不额外计费(只有对话按原规则计费)。任一步失败都安全返回 False, 不抛出。"""
    enabled, voice_id, reason = await _load_wx_voice_setting(pool, owner_user_id)
    if not enabled:
        print(f"[微信语音] 不补发语音 (owner={owner_user_id}): {reason}", flush=True)
        return False

    clean = _clean_tts_text(text)
    if not clean:
        print("[微信语音] 清洗 emoji/括号后文本为空, 跳过语音", flush=True)
        return False
    print(f"[微信语音] 开始合成 (owner={owner_user_id}, voice_id={voice_id}, {len(clean)}字)", flush=True)

    try:
        mp3 = await _ws_synthesize(voice_id, clean)
    except Exception as e:
        print(f"[微信语音] 合成失败, 回退(文本已发): {type(e).__name__}: {str(e)[:140]}", flush=True)
        return False
    if not mp3:
        print("[微信语音] 合成返回空音频", flush=True)
        return False

    # 语音合成计费: ¥8/万字, 从会员余额扣 (合成成功才扣)
    await _charge_wx_tts(pool, owner_user_id, len(clean))

    filename = (clean[:40].strip() or "voice") + ".mp3"     # 文件名 = 文本(截断) + .mp3
    ok, err = await _send_wx_file_mp3(bot_instance, mp3, filename, wx_token_plain, str(uid))
    if not ok:
        print(f"[微信语音] 文件发送失败: {err}", flush=True)
        return False
    print(f"[微信语音] 已发送语音文件 {filename!r} ({len(mp3)}B mp3) 给 {str(uid)[:16]}", flush=True)
    return True


def _clean_tts_text(raw_text):
    """去掉 emoji / 括号旁白 / markdown 标记 —— 这些 TTS 会读错或跳过。
    与项目原有 send_voice 工具的清洗规则完全一致。"""
    import re as _re
    text = raw_text or ""
    text = _re.sub(r"[(\uFF08][^)\uFF09]*[)\uFF09]", "", text)   # (半/全角) 及内容
    text = _re.sub(r"\u3010[^\u3011]*\u3011", "", text)           # 【】
    text = _re.sub(r"\[[^\]]*\]", "", text)                        # []
    text = _re.sub(r"\{[^}]*\}", "", text)                         # {}
    text = _re.sub(r"\*+([^*]+)\*+", r"\1", text)
    text = _re.sub(r"_+([^_]+)_+", r"\1", text)
    text = _re.sub(r"`+([^`]+)`+", r"\1", text)
    text = _re.sub(r"~+([^~]+)~+", r"\1", text)
    text = _re.sub(r"^#+\s*", "", text, flags=_re.MULTILINE)
    text = _re.sub(
        r"["
        r"\U0001F300-\U0001FAFF"
        r"\U00002600-\U000027BF"
        r"\U0001F000-\U0001F02F"
        r"\U0001F100-\U0001F1FF"
        r"\U00002700-\U000027BF"
        r"\U0001F600-\U0001F64F"
        r"\U0001F680-\U0001F6FF"
        r"]", "", text)
    text = _re.sub(r"\s+", " ", text).strip()
    if len(text) > 500:
        text = text[:500]
    return text


async def _ws_synthesize(voice_id, text, model=None):
    """DashScope WS TTS -> mp3 字节。直接照搬项目原有 send_voice 工具(已验证可用),
    显式请求 format=mp3, 避免 SDK 默认格式不确定。依赖 websockets 库(原工具已在用)。"""
    import asyncio, json as _json, uuid
    try:
        import websockets
    except ImportError:
        raise RuntimeError("需要 pip install websockets")
    import websocker.config as _vc
    api_key   = _vc.DASHSCOPE_API_KEY
    model     = model or getattr(_vc, "TTS_MODEL", "cosyvoice-v3.5-plus")
    DS_WS_URL = "wss://dashscope.aliyuncs.com/api-ws/v1/inference"

    task_id = uuid.uuid4().hex
    headers = {"Authorization": f"bearer {api_key}", "X-DashScope-DataInspection": "enable"}
    audio_chunks, finished, error_msg = [], False, None

    try:
        ws_ctx = websockets.connect(DS_WS_URL, additional_headers=headers, max_size=None, open_timeout=15)
    except TypeError:
        ws_ctx = websockets.connect(DS_WS_URL, extra_headers=headers, max_size=None, open_timeout=15)

    async with ws_ctx as ws:
        await ws.send(_json.dumps({
            "header": {"action": "run-task", "task_id": task_id, "streaming": "duplex"},
            "payload": {"task_group": "audio", "task": "tts", "function": "SpeechSynthesizer",
                        "model": model,
                        "parameters": {"text_type": "PlainText", "voice": voice_id, "format": "mp3",
                                       "sample_rate": 22050, "volume": 50, "rate": 1, "pitch": 1},
                        "input": {}},
        }, ensure_ascii=False))
        sent_input = False
        deadline = asyncio.get_event_loop().time() + 60
        while asyncio.get_event_loop().time() < deadline and not finished:
            try:
                msg = await asyncio.wait_for(ws.recv(), timeout=5)
            except asyncio.TimeoutError:
                continue
            if isinstance(msg, bytes):
                audio_chunks.append(msg)
            else:
                evt = _json.loads(msg)
                event = evt.get("header", {}).get("event", "")
                if event == "task-started" and not sent_input:
                    await ws.send(_json.dumps({
                        "header": {"action": "continue-task", "task_id": task_id, "streaming": "duplex"},
                        "payload": {"input": {"text": text}}}, ensure_ascii=False))
                    await ws.send(_json.dumps({
                        "header": {"action": "finish-task", "task_id": task_id, "streaming": "duplex"},
                        "payload": {"input": {}}}, ensure_ascii=False))
                    sent_input = True
                elif event == "task-finished":
                    finished = True
                elif event == "task-failed":
                    error_msg = evt.get("header", {}).get("error_message") or _json.dumps(evt)
                    break
    if error_msg:
        raise RuntimeError("task-failed: " + str(error_msg))
    return b"".join(audio_chunks)


async def _send_wx_file_mp3(bot_instance, mp3_bytes, filename, wx_token_plain, to_user_id):
    """把 mp3 作为【文件附件 FileItem(type=4)】发到微信。直接照搬项目原有 send_voice 工具
    验证可用的 iLink v2.4.3 协议: getuploadurl(media_type=3) -> AES-128-ECB/PKCS7 -> CDN
    -> sendmessage(file_item)。成功 (True, None); 失败 (False, 原因)。"""
    import hashlib, secrets, base64 as _b64, random as _rnd, urllib.parse as _up, asyncio as _asyncio
    from Crypto.Cipher import AES as _AES
    from Crypto.Util.Padding import pad as _pad

    CLIENT_VER = ((2 & 0xFF) << 16) | ((4 & 0xFF) << 8) | (3 & 0xFF)   # 132099 = v2.4.3
    base_info  = {"channel_version": "2.4.3", "bot_agent": "webchat"}

    raw_size = len(mp3_bytes)
    raw_md5  = hashlib.md5(mp3_bytes).hexdigest()
    aes_key  = secrets.token_bytes(16)
    aes_hex  = aes_key.hex()
    filekey  = secrets.token_hex(16)
    ciphertext_size = ((raw_size + 1 + 15) // 16) * 16

    x_uin = _b64.b64encode(str(_rnd.getrandbits(32)).encode("utf-8")).decode("ascii")

    def _hdrs():
        return {
            "Authorization":           f"Bearer {wx_token_plain}",
            "AuthorizationType":       "ilink_bot_token",
            "iLink-App-Id":            "bot",
            "iLink-App-ClientVersion": str(CLIENT_VER),
            "X-WECHAT-UIN":            x_uin,
            "Content-Type":            "application/json",
        }

    # 1) getuploadurl (media_type=3 FILE)
    try:
        r = await bot_instance.client.post(
            f"{BASE_URL}/getuploadurl",
            json={"filekey": filekey, "media_type": 3, "to_user_id": to_user_id,
                  "rawsize": raw_size, "rawfilemd5": raw_md5, "filesize": ciphertext_size,
                  "no_need_thumb": True, "aeskey": aes_hex, "base_info": base_info},
            headers=_hdrs(), timeout=15)
        if r.status_code != 200:
            return False, f"getuploadurl HTTP {r.status_code}: {(r.text or '')[:160]}"
        j = r.json()
    except Exception as e:
        return False, f"getuploadurl 异常: {type(e).__name__}: {str(e)[:120]}"
    if j.get("ret", 0) != 0:
        return False, f"getuploadurl ret={j.get('ret')} errmsg={j.get('errmsg')}"

    upload_full_url = (j.get("upload_full_url") or "").strip() or None
    upload_param    = j.get("upload_param")
    if not upload_full_url and not upload_param:
        return False, "getuploadurl 未返回上传地址"

    # 2) AES-128-ECB + PKCS7
    ciphertext = _AES.new(aes_key, _AES.MODE_ECB).encrypt(_pad(mp3_bytes, _AES.block_size))
    if len(ciphertext) != ciphertext_size:
        return False, f"密文大小不一致 expected={ciphertext_size} actual={len(ciphertext)}"

    # 3) CDN 上传 (最多 3 次)
    cdn_url = upload_full_url or (
        f"{CDN_BASE_URL}/upload?encrypted_query_param={_up.quote(upload_param)}&filekey={_up.quote(filekey)}")
    encrypt_query_param, last_err = None, None
    for attempt in range(1, 4):
        try:
            r = await bot_instance.client.post(
                cdn_url, content=ciphertext,
                headers={"Content-Type": "application/octet-stream"}, timeout=60)
            if 400 <= r.status_code < 500:
                return False, f"CDN 客户端错误 {r.status_code}: {(r.text or '')[:160]}"
            if r.status_code != 200:
                last_err = f"CDN {r.status_code}"; continue
            encrypt_query_param = r.headers.get("x-encrypted-param")
            if not encrypt_query_param:
                return False, "CDN 响应缺 x-encrypted-param"
            break
        except Exception as e:
            last_err = f"{type(e).__name__}: {str(e)[:120]}"
        if attempt < 3:
            await _asyncio.sleep(0.5 * attempt)
    if not encrypt_query_param:
        return False, f"CDN 3 次上传失败: {last_err}"

    # 4) sendmessage(file_item). aes_key 字段 = base64(utf8(hex串))
    aes_key_field = _b64.b64encode(aes_hex.encode("utf-8")).decode("ascii")
    msg = {
        "from_user_id": "", "to_user_id": to_user_id,
        "client_id": f"webchat-{secrets.token_hex(12)}",
        "message_type": 2, "message_state": 2,
        "item_list": [{
            "type": 4,
            "file_item": {
                "media": {"encrypt_query_param": encrypt_query_param,
                          "aes_key": aes_key_field, "encrypt_type": 1},
                "file_name": filename, "len": str(raw_size),
            },
        }],
    }
    try:
        r = await bot_instance.client.post(
            f"{BASE_URL}/sendmessage",
            json={"msg": msg, "base_info": base_info}, headers=_hdrs(), timeout=15)
        if r.status_code != 200:
            return False, f"sendmessage HTTP {r.status_code}: {(r.text or '')[:160]}"
        j = r.json()
    except Exception as e:
        return False, f"sendmessage 异常: {type(e).__name__}: {str(e)[:120]}"
    if j.get("ret", 0) != 0:
        return False, f"sendmessage ret={j.get('ret')} errmsg={j.get('errmsg')}"
    return True, None


# ==============================================================================
# 用户消息合并(debounce)·v8 · 2026-05-08
# ==============================================================================
# 在窗口期内连发的消息合并为一条,刷新计时,窗口到点 flush 入 worker 队列。
#
# 数据结构:
#   _merge_buckets[(db_id, uid)] = {
#       "contents": [...],     累积的文本(每条用户消息原样追加,顺序保持)
#       "images":   [...],     累积的图片(用户连发图片时也合并入同一轮)
#       "voices":   [...],     累积的语音
#       "videos":   [...],     累积的视频
#       "ctx_token": str,      最后一条消息的 ctx_token(透传给 worker)
#       "task":     asyncio.Task  当前等待计时器,有新消息时取消并重启
#   }
#
# 并发安全:_merge_lock 保护字典读写,window 内 flush 与新消息插入不会打架。
#
# 实例配置缓存:每条消息进来都查一次 DB 取 merge_enabled / merge_window_seconds,
#   开销可忽略(单行索引查询);好处是 admin 改了配置立即生效,无缓存失效问题。
# ==============================================================================
_merge_buckets: dict = {}
_merge_lock = asyncio.Lock()


async def _fetch_merge_config(pool, db_id):
    """读 instances 表的合并开关与窗口秒数。字段不存在(老库未跑 v8)→ 视为关闭。"""
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT merge_enabled, merge_window_seconds FROM instances WHERE id=%s",
                    (db_id,),
                )
                row = await cur.fetchone()
        if not row:
            return False, 8
        enabled = int(row.get("merge_enabled") or 0) == 1
        window  = int(row.get("merge_window_seconds") or 8)
        # 防御性夹紧:1~60 秒,避免管理员误填超大值导致用户感知"消息丢失"
        window = max(1, min(60, window))
        return enabled, window
    except Exception:
        # 字段不存在(老库未跑 v8 迁移)→ 静默回退到"关闭"
        return False, 8


async def _flush_merge_bucket(key, bot_instance, window: int):
    """合并桶定时器协程:等满 window 秒后把累积内容 flush 到 worker 队列。"""
    try:
        await asyncio.sleep(window)
        # 时间到 → 加锁取出整桶内容,清空,入队
        async with _merge_lock:
            bucket = _merge_buckets.pop(key, None)
        if not bucket:
            return
        contents = bucket["contents"]
        images   = bucket["images"]
        voices   = bucket["voices"]
        videos   = bucket["videos"]
        ctx_token = bucket["ctx_token"]
        if not (contents or images or voices or videos):
            return  # 防御:空桶不打扰 worker
        merged_preview = " | ".join(contents)[:80]
        print(
            f"[消息合并] 实例 {bot_instance.db_id} 用户 {key[1]} 窗口({window}s)结束,"
            f"flush:文本{len(contents)}条 图片{len(images)} 语音{len(voices)} 视频{len(videos)} "
            f"→ {merged_preview!r}"
        )
        await task_queue.put((bot_instance, key[1], contents, ctx_token, images, voices, videos, False))
    except asyncio.CancelledError:
        # 新消息进来取消旧任务是预期路径,不报错
        pass


async def _enqueue_with_merge(
    bot_instance, uid, content, ctx_token, image_item, voice_item, video_item,
    window: int,
):
    """合并模式:进桶/刷新计时;不直接入 worker 队列。"""
    key = (bot_instance.db_id, uid)
    async with _merge_lock:
        bucket = _merge_buckets.get(key)
        if bucket is None:
            # 首次入桶
            bucket = {
                "contents": [],
                "images":   [],
                "voices":   [],
                "videos":   [],
                "ctx_token": ctx_token,
                "task":     None,
            }
            _merge_buckets[key] = bucket
        else:
            # 已有桶:取消上一轮等待任务,本次新消息会重启计时
            if bucket["task"] and not bucket["task"].done():
                bucket["task"].cancel()
        # 累积内容
        if content:
            bucket["contents"].append(content)
        if image_item:
            bucket["images"].append(image_item)
        if voice_item:
            bucket["voices"].append(voice_item)
        if video_item:
            bucket["videos"].append(video_item)
        bucket["ctx_token"] = ctx_token  # 用最新一条的 token,wx 协议要求最新
        # 启动新计时器
        bucket["task"] = asyncio.create_task(
            _flush_merge_bucket(key, bot_instance, window)
        )
    print(
        f"[消息合并] 实例 {bot_instance.db_id} 用户 {uid} 入桶/刷新计时({window}s),"
        f"当前累积:文本{len(bucket['contents'])}条 图片{len(bucket['images'])} "
        f"语音{len(bucket['voices'])} 视频{len(bucket['videos'])}"
    )

async def proactive_timer_task(pool, bot_instance, uid, context_token):
    """由持久化心潮状态决定等待时间和是否真正触发主动消息。"""
    try:
        while True:
            # 心潮现为付费权益。计时器可能在退款/撤销后仍短暂留在内存中，
            # 因此在读取状态前先做一次 fail-closed 校验，避免未购买用户
            # 继续驱动动态心智。
            if not await _has_mind_entitlement(pool, bot_instance.db_id):
                return
            delay_seconds = await dynamic_mind.get_proactive_delay(
                pool, bot_instance.db_id
            )
            # 连续两次主动消息没有用户回应时，状态机会把 next 置空；
            # 下一次用户真实到场后 prepare_turn 会重新安排。
            if delay_seconds is None:
                return
            await asyncio.sleep(max(1.0, float(delay_seconds)))
            # 管理员可能在计时器等待期间关掉开关；触发前再读一次。
            if not await _dynamic_mind_proactive_enabled(pool, bot_instance.db_id):
                return
            # 再靠近 claim 点复核一次权益，缩小退款/撤销与状态 claim 的竞态窗口。
            if not await _has_mind_entitlement(pool, bot_instance.db_id):
                return
            mind_config = await _dynamic_mind_config(pool, bot_instance.db_id)
            decision = await dynamic_mind.claim_proactive(pool, bot_instance.db_id, dream_probability=mind_config["dream_probability"])
            if decision.get("allowed"):
                await utils.add_temp_log(
                    pool, bot_instance.db_id,
                    f"[心潮·主动触发] reason={decision.get('reason')}"
                )
                # claim 会写入一次性 pending 标记。若入队后用户先发来消息，
                # 用户到场会清除该标记，chat.prepare_turn 将取消这次主动回复。
                await task_queue.put(
                    (bot_instance, uid, [""], context_token, [], [], [], True)
                )
                return
            if decision.get("delay_seconds") is None:
                return
            # 状态在 claim 中已经重排；下一轮从数据库读取准确时间。
    except asyncio.CancelledError:
        pass
    except Exception as exc:
        print(
            f"[心潮·主动计时器] db_id={bot_instance.db_id} "
            f"{type(exc).__name__}: {exc}",
            flush=True,
        )
    finally:
        timer_key = (bot_instance.db_id, uid)
        if proactive_timers.get(timer_key) is asyncio.current_task():
            proactive_timers.pop(timer_key, None)


async def dynamic_mind_proactive_scanner_task(pool, running_tasks: dict):
    """Durable fallback for restarts and lost in-memory proactive timers."""
    while True:
        await asyncio.sleep(30)
        try:
            # 该映射只用于 claim→入队的竞态保护，超过窗口即无价值。
            # 定期清理，避免长期服务中按联系人无界增长。
            activity_cutoff = time.monotonic() - 600
            for activity_key, seen_at in list(recent_user_activity.items()):
                if seen_at < activity_cutoff:
                    recent_user_activity.pop(activity_key, None)
            candidates = await dynamic_mind.list_due_proactive(pool, limit=300)
            for item in candidates:
                db_id = item["db_id"]
                # 购买权益可能在候选项被扫描出来后被撤销；逐实例校验，
                # 未购买时不 claim，也不入队主动任务。
                if not await _has_mind_entitlement(pool, db_id):
                    _cancel_proactive_timers_for_dbid(db_id)
                    continue
                task_info = running_tasks.get(db_id)
                if not task_info:
                    continue  # another shard owns this instance
                bot_instance = task_info.get("bot")
                if not bot_instance or not bot_instance.is_running:
                    continue
                if not await _dynamic_mind_proactive_enabled(pool, db_id):
                    continue
                # ``instance_contacts`` 同时被 QQ 用作历史联系人记录，但 QQ
                # 不支持主动推送，且其 uid 没有微信会话凭据。这里只能选最近
                # 一条带有效凭据的微信联系人，不能因 QQ 最新发言误投到微信。
                async with pool.acquire() as conn:
                    async with conn.cursor() as cur:
                        await cur.execute(
                            "SELECT uid, context_token FROM instance_contacts "
                            "WHERE db_id=%s AND uid LIKE %s "
                            "AND COALESCE(context_token, '') <> '' "
                            "ORDER BY last_seen DESC LIMIT 1",
                            (db_id, "%@im.wechat"),
                        )
                        contact = await cur.fetchone()
                if not contact:
                    continue
                uid = contact.get("uid") if isinstance(contact, dict) else contact[0]
                context_token = (
                    contact.get("context_token", "")
                    if isinstance(contact, dict)
                    else (contact[1] if len(contact) > 1 else "")
                )
                # 配置/联系人读取期间权益可能发生变化；claim 前再次
                # fail-closed 校验，确保未购买不会占用心潮 pending 状态。
                if not await _has_mind_entitlement(pool, db_id):
                    continue
                mind_config = await _dynamic_mind_config(pool, db_id)
                decision = await dynamic_mind.claim_proactive(pool, db_id, dream_probability=mind_config["dream_probability"])
                if not decision.get("allowed"):
                    continue
                await utils.add_temp_log(
                    pool, db_id,
                    f"[心潮·持久调度] reason={decision.get('reason')} uid={uid[:20]}"
                )
                await task_queue.put(
                    (bot_instance, uid, [""], context_token, [], [], [], True)
                )
        except Exception as exc:
            print(
                f"[心潮·持久调度] {type(exc).__name__}: {exc}",
                flush=True,
            )

async def handle_incoming_message_debounced(
    bot_instance, uid, content, ctx_token, image_item, voice_item, video_item,
):
    key = (bot_instance.db_id, uid)

    # 必须早于取消 timer 和消息合并：只要真实上行已到达，本轮主动消息就应让路。
    recent_user_activity[key] = time.monotonic()

    # 用户主动发言，立即打断主动消息计时器
    _cancel_proactive_timers_for_dbid(bot_instance.db_id)
        # v8.3:删掉"已打断主动消息计时器"日志,这是内部状态机切换,无业务可见性需求

    # v8:实例可配置消息合并(merge_enabled=1)。开启后窗口期内连发合并入一桶,
    # 窗口到点才入 worker 队列;关闭则保持原行为(立即入队)。
    merge_enabled, merge_window = await _fetch_merge_config(bot_instance.pool, bot_instance.db_id)

    if merge_enabled:
        await _enqueue_with_merge(
            bot_instance, uid, content, ctx_token,
            image_item, voice_item, video_item, merge_window,
        )
        return

    # 默认路径（消息合并关闭）：立即响应。
    contents = [content] if content else []
    images   = [image_item] if image_item else []
    voices   = [voice_item] if voice_item else []
    videos   = [video_item] if video_item else []
    await task_queue.put((
        bot_instance, uid, contents, ctx_token, images, voices, videos,
        False,
    ))

async def _check_user_ban(pool, user_id: int):
    """
    查询该平台用户(实例所有者)是否处于「管理员手动封禁」状态。

    返回:
      - None              → 未封禁(或封禁已到期 / user_bans 表尚不存在)
      - 非空字符串(原因)  → 正在封禁中,字符串即为要回复给微信好友的文案(封禁原因)

    判定规则(与 admin / console 完全一致):
        is_banned = 1 且 (banned_until = 0 永久  或  banned_until > now 未到期)
    banned_until 已过的记录读时即视为「自动解封」,这里不写库,下一条消息就恢复正常。
    user_bans 表从未创建过(没封过任何人)时静默当作未封禁,绝不阻断正常消息流。
    """
    if not user_id:
        return None
    try:
        now = int(time.time())
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT reason FROM user_bans "
                    "WHERE user_id=%s AND is_banned=1 "
                    "AND (banned_until=0 OR banned_until>%s) LIMIT 1",
                    (user_id, now),
                )
                row = await cur.fetchone()
    except Exception as e:
        # 表不存在 / 查询异常 → 一律按「未封禁」处理,封禁功能绝不能拖垮主消息流
        emsg = str(e)
        if "user_bans" not in emsg and "doesn't exist" not in emsg:
            print(f"[封禁检查] 查询异常(已忽略,按未封禁处理) uid={user_id}: {emsg[:120]}", flush=True)
        return None
    if not row:
        return None
    reason = (row.get("reason") if isinstance(row, dict) else row[0]) or ""
    reason = reason.strip()
    if not reason:
        reason = "该账号已被封禁，服务暂时不可用。"
    return reason


async def message_worker(worker_id, pool):
    global active_workers
    while True:
        (
            bot_instance, uid, contents_list, context_token,
            images_list, voices_list, videos_list, is_proactive,
        ) = await task_queue.get()

        # claim→入队 与 用户真实上行可能在毫秒级交错。45 分钟是心潮允许的
        # 最短主动间隔，所以 5 分钟竞态窗口不会误杀正常的下一次主动触发。
        if is_proactive:
            # QQ 与微信共享同一套 chat/人设/记忆，但 QQ 当前没有主动消息
            # 能力。防御队列中的历史脏项，绝不能拿 QQ openid 调微信接口。
            if not weixin_media.is_wechat_contact_uid(uid):
                try:
                    await utils.add_temp_log(
                        pool, bot_instance.db_id,
                        f"[心潮·主动取消] 非微信联系人不执行微信主动消息 uid={str(uid)[:28]}",
                    )
                except Exception:
                    pass
                task_queue.task_done()
                continue
            # 任务从队列取出到 worker 执行之间可能发生退款/撤销；这里是
            # 调用模型前的最后一道权益门控。未购买时静默丢弃，不发送，
            # 也不让统一回复协议补发“……” 。
            if not await _has_mind_entitlement(pool, bot_instance.db_id):
                try:
                    await utils.add_temp_log(
                        pool, bot_instance.db_id,
                        "[心潮·权益] 主动任务出队时未购买，静默丢弃",
                    )
                except Exception:
                    pass
                task_queue.task_done()
                continue
            _recent_real_user = recent_user_activity.get((bot_instance.db_id, uid))
            if _recent_real_user is not None and time.monotonic() - _recent_real_user < 300:
                try:
                    await utils.add_temp_log(
                        pool, bot_instance.db_id,
                        "[心潮·主动取消] 用户刚刚真实到场，丢弃已入队的主动任务"
                    )
                except Exception:
                    pass
                task_queue.task_done()
                continue
            # 主动 AI 不能凭空刷新 context_token。出队时重新读取最近一次用户
            # 上行产生的凭据，避免计时器持有旧值；明显过期则在调用模型前暂停。
            try:
                latest_context, context_last_seen = await weixin_media.latest_context_record(
                    pool, bot_instance.db_id, uid
                )
            except Exception as context_exc:
                # 数据库瞬时异常不能误判凭据过期；保留队列随附的 token 继续。
                print(
                    f"[心潮·会话检查] db_id={bot_instance.db_id} "
                    f"{type(context_exc).__name__}: {context_exc}",
                    flush=True,
                )
            else:
                if not weixin_media.proactive_context_is_fresh(
                    latest_context, context_last_seen
                ):
                    try:
                        await dynamic_mind.suspend_proactive_until_user(
                            pool, bot_instance.db_id
                        )
                    except Exception as suspend_exc:
                        print(
                            f"[心潮·主动暂停] 状态写入失败：{type(suspend_exc).__name__}: "
                            f"{suspend_exc}",
                            flush=True,
                        )
                    try:
                        await utils.add_temp_log(
                            pool, bot_instance.db_id,
                            "[心潮·主动暂停] 微信会话凭据已过期，等待用户再次发言后恢复",
                        )
                    except Exception:
                        pass
                    task_queue.task_done()
                    continue
                context_token = latest_context

        # v12.14: 把当前 uid 写进 contextvar, 让 add_temp_log 自动加 uid 前缀
        # 解决: 同一个 bot 服务多个微信好友时, 日志在前端混杂无法区分谁是谁
        utils.current_uid_var.set(uid)
        utils.current_kind_var.set('proactive' if is_proactive else 'main')

        active_workers += 1
        _t_start = time.monotonic()
        worker_states[worker_id] = {
            'started_at': _t_start,
            'stage_started_at': _t_start,
            'db_id': bot_instance.db_id,
            'uid':   uid,
            'stage': 'dequeued',
            'detail': '消息已出队，准备开始处理',
            'stage_history': [],
            'is_proactive': bool(is_proactive),
        }
        # v8.3:用户期望的"被激活"日志
        _kind = "主动" if is_proactive else "被动"
        print(
            f"[Worker-{worker_id}] ▶ 实例 {bot_instance.db_id} 用户 {uid} "
            f"({_kind}{', 含图片' if images_list else ''}{', 含语音' if voices_list else ''}"
            f"{', 含视频' if videos_list else ''})",
            flush=True,
        )

        try:
            _wstage(worker_id, 'fetch_send_config')
            wx_token_plain, split_rule, ignore_punc = await utils._fetch_send_config(pool, bot_instance.db_id)
            if not wx_token_plain:
                continue

            _wstage(worker_id, 'query_user')
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute("SELECT user_id FROM instances WHERE id=%s", (bot_instance.db_id,))
                    row_u   = await cur.fetchone()
                    user_id = row_u['user_id'] if row_u else 0

            # ── 账号封禁拦截(管理员手动封禁)─────────────────────────────
            # 实例所有者被封禁时:不再调用大模型,被动消息直接用「封禁原因」回复,
            # 主动消息则整条跳过(避免给被封账号继续提供 AI 服务)。
            # 封禁到期自动失效(_check_user_ban 读时判定),无需重启实例。
            _wstage(worker_id, 'ban_check')
            _ban_reason = await _check_user_ban(pool, user_id)
            if _ban_reason is not None:
                if not is_proactive and uid:
                    # 不切分,封禁原因整段原样发送(split_rule 用 \x00,任何文本都不含此字符)
                    await _send_wx_text(
                        bot_instance, uid, context_token,
                        _ban_reason, pool, wx_token_plain,
                        '\x00', False,
                    )
                    await utils.add_temp_log(
                        pool, bot_instance.db_id,
                        "[封禁] 所有者账号处于封禁中,已用封禁原因直接回复(未调用大模型)"
                    )
                else:
                    await utils.add_temp_log(
                        pool, bot_instance.db_id,
                        "[封禁] 所有者账号处于封禁中,跳过本次主动消息(未调用大模型)"
                    )
                continue

            # 三类原生媒体路径统一在分支外初始化，主动消息保持空列表。
            inline_vision_paths: list[str] = []
            inline_audio_paths: list[str] = []
            inline_video_paths: list[str] = []

            if not is_proactive:
                # ── Gemini 原生视频理解 ──────────────────────────────────
                # 唯一能力开关是 model_pricing.protocol=gemini；模型名称完全动态，
                # 不写死 2.5 Pro，也不检查 gemini-* 前缀或 tags。
                if videos_list:
                    if not _CHAT_GR_SUPPORTS_VIDEO_PATHS:
                        await _send_wx_text(
                            bot_instance, uid, context_token,
                            "当前后端尚未完整启用视频理解，请更新后再试。",
                            pool, wx_token_plain, split_rule, ignore_punc,
                        )
                        continue

                    try:
                        async with pool.acquire() as conn:
                            async with conn.cursor() as cur:
                                await cur.execute(
                                    "SELECT i.model, COALESCE(mp.protocol, 'openai') AS model_protocol "
                                    "FROM instances i LEFT JOIN model_pricing mp "
                                    "ON mp.model_name=i.model WHERE i.id=%s",
                                    (bot_instance.db_id,),
                                )
                                _video_model_row = await cur.fetchone()
                        _video_model = (
                            (_video_model_row and _video_model_row.get("model")) or ""
                        ).strip()
                        _video_protocol = (
                            (_video_model_row and _video_model_row.get("model_protocol"))
                            or "openai"
                        ).strip().lower()
                    except Exception as _video_config_error:
                        print(
                            f"[看视频] 模型协议查询失败: "
                            f"{type(_video_config_error).__name__}",
                            flush=True,
                        )
                        _video_model = ""
                        _video_protocol = "openai"

                    if _video_protocol != "gemini":
                        await utils.add_temp_log(
                            pool, bot_instance.db_id,
                            f"[看视频] 当前模型未配置Gemini协议，已提示用户切换"
                        )
                        await _send_wx_text(
                            bot_instance, uid, context_token,
                            "当前模型不支持原生视频理解，请切换到后台协议设为 Gemini 的模型后再发送视频。",
                            pool, wx_token_plain, split_rule, ignore_punc,
                        )
                        continue

                    await utils.add_temp_log(
                        pool, bot_instance.db_id,
                        f"[看视频] 使用当前Gemini协议模型 {_video_model}"
                    )
                    _video_total_bytes = 0
                    _video_too_large = False
                    for video_source in videos_list:
                        _downloaded_now = not isinstance(video_source, str)
                        try:
                            _wstage(worker_id, 'video_decrypt')
                            if _downloaded_now:
                                video_path = await download_and_decrypt_video(
                                    bot_instance.client, video_source
                                )
                                asyncio.create_task(
                                    cleanup_file_delayed(video_path, 600)
                                )
                            else:
                                video_path = video_source
                                if not os.path.isfile(video_path):
                                    raise ValueError("视频文件已过期")

                            video_size = os.path.getsize(video_path)
                            if (
                                _video_total_bytes + video_size
                                > proto_gemini.GEMINI_INLINE_VIDEO_MAX_BYTES
                            ):
                                _video_too_large = True
                                if _downloaded_now:
                                    try:
                                        os.remove(video_path)
                                    except OSError:
                                        pass
                                break
                            _video_total_bytes += video_size
                            inline_video_paths.append(video_path)
                        except VideoTooLargeError:
                            _video_too_large = True
                            break
                        except Exception as _video_error:
                            print(
                                f"[看视频] 下载或解密失败: "
                                f"{type(_video_error).__name__}: {str(_video_error)[:80]}",
                                flush=True,
                            )
                            contents_list.append(
                                "【系统提示：用户发送了一段视频，但微信 CDN 下载或解密失败。】"
                            )

                    if _video_too_large:
                        await utils.add_temp_log(
                            pool, bot_instance.db_id,
                            "[看视频] 视频超过原生内联大小限制"
                        )
                        await _send_wx_text(
                            bot_instance, uid, context_token,
                            "视频太大，当前中转站的 Gemini 原生请求无法内联处理，请压缩或截短到 12 MB 以内后重试。",
                            pool, wx_token_plain, split_rule, ignore_punc,
                        )
                        continue

                # ─────────────────────────────────────────────────────────────
                # v8 · 2026-05-09:多模态识图直连
                # 在调外部 vision API 前,先看实例当前主模型是否标记 vision 标签
                # (或老库前缀白名单兜底)。若是 → 跳过外部识图,把本地解密的 jpg
                # 路径透传给 chat.generate_reply,由主模型多模态调用消化。
                # token 计费走主模型 usage,无需外部 vision_price 单独扣费。
                #
                # 不满足:走老路径——外部 vision API 识别后把描述拼进 contents_list。
                # ─────────────────────────────────────────────────────────────
                main_model_supports_vision = False
                if images_list:
                    # ─── 原生识图前置判定 ──────────────────────────────────────
                    # gitee 外部 vision API(analyze_image_auto)是 v8 之前的遗留兜底,
                    # 现已弃用。Gemini 家族按“协议 + ID 包含”判断，不再要求模型 ID
                    # 以 gemini 开头，因此 [ais]gemini-* 等路由 ID 也可直接看图。
                    # 用户发图但主模型不在支持范围时,
                    # 直接给用户回一条提示让其切换模型, 然后 continue 跳过本轮处理,
                    # 不再调外部 vision API、不再走 chat.generate_reply。
                    try:
                        async with pool.acquire() as conn:
                            async with conn.cursor() as cur:
                                await cur.execute(
                                    "SELECT i.model, COALESCE(mp.protocol, 'openai') AS model_protocol "
                                    "FROM instances i LEFT JOIN model_pricing mp "
                                    "ON mp.model_name=i.model WHERE i.id=%s",
                                    (bot_instance.db_id,),
                                )
                                _r = await cur.fetchone()
                                _main_model = (_r and _r.get("model")) or ""
                                _main_protocol = (
                                    (_r and _r.get("model_protocol")) or "openai"
                                ).strip().lower()
                    except Exception as _e_q:
                        print(f"[Worker-{worker_id}] 查询主模型失败: {_e_q}", flush=True)
                        _main_model = ""
                        _main_protocol = "openai"

                    _ml = _main_model.lower().strip()
                    _gemini_named_native_vision = (
                        chat._is_gemini_named_native_vision_model(
                            _main_model, _main_protocol
                        )
                    )

                    if not (
                        _gemini_named_native_vision
                        or _ml.startswith("claude-")
                        or _ml.startswith("doubao-")
                    ):
                        await utils.add_temp_log(
                            pool, bot_instance.db_id,
                            f"[看图] 主模型 {_main_model or '<未配置>'} 不在识图白名单"
                            f"(Gemini 需使用 OpenAI/Gemini 协议且 ID 含 gemini), "
                            f"已提示用户切换, 本轮终止"
                        )
                        try:
                            await _send_wx_text(
                                bot_instance, uid, context_token,
                                "抱歉,当前模型不支持识别图片,请切换为 gemini、claude 或 doubao 系列模型后再发送图片~",
                                pool, wx_token_plain, split_rule, ignore_punc,
                            )
                        except Exception as _e_send:
                            print(
                                f"[Worker-{worker_id}] 发送'模型不支持识图'提示失败: {_e_send}",
                                flush=True,
                            )
                        # 解密下载的本地 jpg 还没产生(下载循环在下方), 没有清理负担。
                        # 直接 continue 进下一轮, 外层 finally 会清理 active_workers
                        # / worker_states / task_done()。
                        continue
                    # ─── 拦截结束, 以下确认直连能力 ───────────────────────────

                    # v8.1 兼容关:chat.generate_reply 签名不支持 image_paths(部署不同步)
                    # 直接禁用直连模式,所有图片都走外部 vision API。
                    if not _CHAT_GR_SUPPORTS_IMAGE_PATHS:
                        main_model_supports_vision = False
                    else:
                        try:
                            # 主模型已在拦截段查到 _main_model, 这里只查 tags
                            async with pool.acquire() as conn:
                                async with conn.cursor() as cur:
                                    # tags 字段可能不存在(老库) → try/except 降级
                                    try:
                                        await cur.execute(
                                            "SELECT tags FROM model_pricing WHERE model_name=%s",
                                            (_main_model,)
                                        )
                                        _t = await cur.fetchone()
                                        _tags = ((_t and _t.get("tags")) or "").lower()
                                    except Exception:
                                        _tags = ""
                            # 判定:DB tags 含 vision → 直走主模型;
                            # tags 字段空(老库未迁移) → 用 chat 模块的前缀兜底
                            if "vision" in _tags:
                                main_model_supports_vision = True
                            elif not _tags:
                                try:
                                    main_model_supports_vision = chat._model_supports_vision_by_prefix(
                                        _main_model, _main_protocol
                                    )
                                except Exception:
                                    main_model_supports_vision = False
                        except Exception as _e_check:
                            print(f"[Worker-{worker_id}] 多模态能力检测失败,降级走外部 vision API: {_e_check}")
                            main_model_supports_vision = False

                    # 路由前缀不影响 Gemini 家族判断；该规则优先于 vision tag。
                    if _CHAT_GR_SUPPORTS_IMAGE_PATHS and _gemini_named_native_vision:
                        main_model_supports_vision = True

                for image_item in images_list:
                    _wstage(worker_id, 'image_decrypt')
                    image_path = await download_and_decrypt_image(bot_instance.client, image_item)
                    if image_path:
                        if main_model_supports_vision:
                            # 直连模式:暂不删图,透传给 chat;chat 调用结束后再清理。
                            inline_vision_paths.append(image_path)
                            await utils.add_temp_log(
                                pool, bot_instance.db_id,
                                f"[看图·直接看] 主模型支持 vision,跳过外部 API,图片直接进 user 消息"
                            )
                        else:
                            _wstage(worker_id, 'image_analyze')
                            vision_result = await analyze_image_auto(image_path, pool, bot_instance.db_id, user_id)
                            contents_list.append(vision_result)
                            try: os.remove(image_path)
                            except: pass
                    else:
                        contents_list.append("【系统提示：用户确实发送了一张图片，但是由于微信 CDN 阻断导致下载或解密失败。】")

                # ─── doubao 原生音频直连判定 (2026-06-14) ───────────────────
                # 业务需求: 主模型为 doubao-* 时, 语音不再走外部 STT
                # (transcribe_audio_auto), 而是把原始音频以 OpenAI input_audio 形式
                # 直接塞进 /chat/completions 请求, 由 doubao 原生理解音频。
                # token 计费随主模型 usage 自然返回(与识图直连一致), 不再单独扣
                # voice_price。chat.py 未升级(无 audio_paths 形参)时降级回外部 STT,
                # 避免语音被静默丢弃。
                main_model_supports_audio = False
                if voices_list and _CHAT_GR_SUPPORTS_AUDIO_PATHS:
                    try:
                        async with pool.acquire() as conn:
                            async with conn.cursor() as cur:
                                await cur.execute(
                                    "SELECT model FROM instances WHERE id=%s",
                                    (bot_instance.db_id,)
                                )
                                _ra = await cur.fetchone()
                                _audio_main_model = (_ra and _ra.get("model")) or ""
                    except Exception as _e_qa:
                        print(f"[Worker-{worker_id}] 查询主模型(音频判定)失败: {_e_qa}", flush=True)
                        _audio_main_model = ""
                    main_model_supports_audio = _audio_main_model.lower().strip().startswith("doubao-")
                    if main_model_supports_audio:
                        await utils.add_temp_log(
                            pool, bot_instance.db_id,
                            f"[听语音] 主模型 {_audio_main_model} 为 doubao 系, 启用原生音频直连"
                            f"(跳过外部 STT, token 随主模型计费)"
                        )

                for voice_item in voices_list:
                    _wstage(worker_id, 'voice_decrypt')
                    mp3_path = await download_and_decrypt_voice(bot_instance.client, voice_item)
                    if mp3_path:
                        # 600s 延迟清理: 远大于下方 generate_reply 的 500s 超时,
                        # 保证 doubao 直连读盘时音频仍在; 外部 STT 路径同样适用。
                        asyncio.create_task(cleanup_file_delayed(mp3_path, 600))
                        if main_model_supports_audio:
                            # doubao 原生音频直连: 不转写、不单独计费, 透传给 chat。
                            inline_audio_paths.append(mp3_path)
                            await utils.add_temp_log(
                                pool, bot_instance.db_id,
                                f"[听语音·直接听] 主模型支持原生音频, 跳过外部 STT, 音频直接进 user 消息"
                            )
                        else:
                            _wstage(worker_id, 'voice_transcribe')
                            voice_result = await transcribe_audio_auto(mp3_path, pool, bot_instance.db_id, user_id)
                            contents_list.append(voice_result)
                    else:
                        contents_list.append("【系统提示：用户确实发送了一条语音，但是由于微信 CDN 阻断导致下载或解密失败。】")

                content = "\n\n".join([c for c in contents_list if c])
                # v8:用户只发了图片+主模型支持 vision 时,contents_list 是空的
                # (图片走了 inline_vision_paths 直连,没拼描述文本)。
                # 给个引导文本兜底,免得 content 空被 continue 掉、图片白下了。
                if not content and inline_vision_paths:
                    content = "(用户发来一张图片,请你看图回复)"
                # 同理: 用户只发了语音 + doubao 原生音频直连时 contents_list 也是空的。
                if not content and inline_audio_paths:
                    content = "(用户发来一条语音,请你听语音回复)"
                if not content and inline_video_paths:
                    content = "(用户发来一段视频,请结合画面、语音和屏幕文字回复)"
                if not content:
                    continue
                # v8.3:删掉 "完整请求内容" 大段 print,worker 入口已有激活日志
            else:
                content = ""
                # v8.3:删掉"进入主动消息生成流"刷屏 print(主动模式上方激活日志已标"主动")

            # 计时起点:用户消息真正进入 AI 思考流之前
            #  - throttle / 限速 sleep / 工具循环 / 多次 LLM 重试 全部自然计入
            #  - 这是「用户感知的等待时长」,不是单次 LLM 调用耗时
            _latency_t0 = time.monotonic()

            _wstage(worker_id, 'llm_thinking')
            # v8: 仅当主模型支持识图时 inline_vision_paths 非空,否则保持老路径
            _vision_paths_to_pass = inline_vision_paths if not is_proactive else None
            # 2026-06-14: 仅当主模型 doubao-* 时 inline_audio_paths 非空,否则走外部 STT
            _audio_paths_to_pass = inline_audio_paths if not is_proactive else None
            # 仅 protocol=gemini 时该列表非空；由当前选中的模型原生理解。
            _video_paths_to_pass = inline_video_paths if not is_proactive else None
            # v8.1 兼容: 老 chat.py 不认识 image_paths,按签名探测条件传参
            _gr_kwargs = dict(
                context_token=context_token,
                is_proactive=is_proactive,
                tool_channel="wechat",
                stage_callback=(
                    lambda stage, detail="": _wstage(worker_id, stage, detail)
                ),
            )
            if _CHAT_GR_SUPPORTS_IMAGE_PATHS:
                _gr_kwargs["image_paths"] = _vision_paths_to_pass
            if _CHAT_GR_SUPPORTS_AUDIO_PATHS:
                _gr_kwargs["audio_paths"] = _audio_paths_to_pass
            if _CHAT_GR_SUPPORTS_VIDEO_PATHS:
                _gr_kwargs["video_paths"] = _video_paths_to_pass
            # ── v12.1 (2026-05-12) 正在输入指示器 ──
            # 严格按 openclaw-weixin@2.4.2 spec: AI 生成完成后 finally 显式 stop()
            # 不再依赖 chat.py 内部的 task.cancel + CancelledError 处理(那套需要
            # new httpx.AsyncClient 每次 50-100ms 启动,慢且容易漏发 status:2)。
            # 主动消息没有用户在等输入,不显示 typing。
            typing_ctrl = None
            if not is_proactive and uid:
                try:
                    wx_token_for_typing, _, _ = await utils._fetch_send_config(pool, bot_instance.db_id)
                except Exception:
                    wx_token_for_typing = None
                if wx_token_for_typing:
                    import typing_controller
                    typing_ctrl = typing_controller.TypingController(
                        client=bot_instance.client,
                        base_url=BASE_URL,
                        wx_token=wx_token_for_typing,
                        uid=uid,
                        context_token=context_token,
                        db_id=bot_instance.db_id,
                    )
                    # start 是 async,需要 await(getconfig 拿 ticket);
                    # 失败也无所谓,stop 时是 no-op
                    try:
                        await typing_ctrl.start()
                    except Exception as _e:
                        print(
                            f"[typing] db_id={bot_instance.db_id} start 异常: {_e}",
                            flush=True,
                        )
                        typing_ctrl = None

            # ── 「让 Ta 更懂你」经期关怀注入 ──────────────────────────
            # 在调 generate_reply 之前检查:用户开了开关 → 返回一段关怀文本,
            # 拼到用户本轮消息 content 最前面(作为 user 消息的一部分,
            # 必定进入 user_prompt 发给 LLM,不会被 chat.py 的 system 过滤跳过)。
            # 没开 → 返回空串,content 不变,完全走原逻辑。
            # 仅被动消息触发。失败不影响主流程。
            if not is_proactive:
                try:
                    _care_prefix = await period_care.maybe_build_care_prefix(
                        pool, bot_instance.db_id, user_id)
                    if _care_prefix:
                        content = _care_prefix + (content or "")
                except Exception as _care_exc:
                    print(f"[关怀] 注入调用异常(已忽略): {_care_exc}", flush=True)

            try:
                reply_json, is_error = await asyncio.wait_for(
                    chat.generate_reply(pool, bot_instance, uid, content, **_gr_kwargs),
                    timeout=900.0
                )
            finally:
                # ★ 关键:AI 一返回(成功或异常)立即 stop typing,在 send_wx_text 之前
                # 用户视感:typing 指示器消失 → 紧接着收到回复
                if typing_ctrl is not None:
                    try:
                        await typing_ctrl.stop()
                    except Exception as _e:
                        print(
                            f"[typing] db_id={bot_instance.db_id} stop 异常: {_e}",
                            flush=True,
                        )
                # 主模型直连模式下,图片在 chat 内部已读完 base64 进内存,
                # 这里统一清理本地临时 jpg(无论调用成功失败)
                for _ip in (_vision_paths_to_pass or []):
                    try:
                        if _ip and os.path.isfile(_ip):
                            os.remove(_ip)
                    except Exception:
                        pass

            reply_text_raw = reply_json.get("reply", "")
            reply_text     = (
                reply_text_raw.strip()
                if isinstance(reply_text_raw, str)
                else ""
            )
            # chat.py 在最终一次模型请求前已实时查库，并把那一刻实际塞进请求体的
            # 分段配置随结果带回。发送时必须用同一份，不能继续使用调用 AI 之前
            # _fetch_send_config 读到的旧值，否则后台修改配置时会出现边界错位。
            if not is_error and "_live_split_rule" in reply_json:
                _reply_split_rule = reply_json.get("_live_split_rule")
                _reply_split_rule = (
                    "" if _reply_split_rule is None else str(_reply_split_rule)
                )
                if _reply_split_rule:
                    # utils.split_text 能识别字面量 \\n；真实换行先转回该形式，
                    # 避免其 strip() 把规则本身清空。
                    split_rule = (
                        _reply_split_rule
                        .replace("\r\n", "\\n")
                        .replace("\r", "\\n")
                        .replace("\n", "\\n")
                    )
                else:
                    split_rule = "\x00"
                ignore_punc = bool(reply_json.get("_live_ignore_punctuation", False))
            # 捕获底层的生命周期阻断信号
            stop_proactive = reply_json.get("stop_proactive", False)
            # v8.6 (2026-05-10): 免费通道关闭时,chat 端会带 _no_split_send=True
            # 让我们整段发送,不按 split_rule 切分,保证提醒词原样到达。
            no_split_send  = bool(reply_json.get("_no_split_send"))

            # ── 统一回复协议 · 发送层最后防线 ────────────────────────────
            # chat 正常完成后只允许:
            #   1) 非空文本
            #   2) stop_proactive 生命周期休眠
            #   3) 明确标记 _allow_silent 的非 AI 业务拦截
            # 其余空 reply 一律转成非空文本,防止未来某条异常/兼容路径再次造成
            # “已读不回”。有 deny_reason 时优先发人话原因；否则用最小标点兜底。
            # 心智门控取消的主动任务必须真正静默，不能被下面的
            # “空回复保底”转成“……”发给用户。
            allow_silent = bool(
                reply_json.get("_allow_silent")
                or reply_json.get("_mind_skip_proactive")
            )
            if not reply_text and not stop_proactive and not allow_silent:
                deny_text = reply_json.get("deny_reason")
                reply_text = (
                    deny_text.strip()
                    if isinstance(deny_text, str) and deny_text.strip()
                    else "消息未发出，请查看日志"
                )
                try:
                    await utils.add_temp_log(
                        pool, bot_instance.db_id,
                        "[统一回复协议] 发送层拦截意外空 reply，已转换为非空文本"
                    )
                except Exception:
                    pass

            # 仅在「用户主动触发 + 真有回复 + 非错误轮次」时记录一轮延迟
            # 主动消息没有「用户等待」概念,无回复轮次也不应稀释平均值
            if reply_text and not is_proactive and not is_error:
                _latency_ms = int((time.monotonic() - _latency_t0) * 1000)
                asyncio.create_task(_record_reply_latency(pool, bot_instance.db_id, _latency_ms))

            text_delivered = False
            if reply_text:
                # v8.3:删掉"完整 AI 响应"刷屏 print(实例日志栏已有 final_reply 摘要)
                _wstage(worker_id, 'sending_wx', '模型回复已生成，正在发送至微信')
                # 语音会员「同时用于微信」: 文本和语音【都】发给用户 (不再二选一)。
                # 先发文本 —— 低延迟, 用户第一时间看到回复; 再补一条语音。
                # 语音(TTS+转码+上传)较慢, 放文本之后不拖慢文本, 且语音失败也不影响已送达的文本。
                if is_error:
                    text_delivered = await _send_wx_text(
                        bot_instance, uid, context_token,
                        reply_text, pool, wx_token_plain,
                        '\n', False
                    )
                elif no_split_send:
                    # v8.6 免费通道关闭提醒:整段发送
                    # split_rule 用 \x00,任何文本里都没这个字符 → split_text 不会切
                    text_delivered = await _send_wx_text(
                        bot_instance, uid, context_token,
                        reply_text, pool, wx_token_plain,
                        '\x00', False,
                    )
                else:
                    text_delivered = await _send_wx_text(
                        bot_instance, uid, context_token,
                        reply_text, pool, wx_token_plain,
                        split_rule, ignore_punc,
                    )

                if is_proactive and not text_delivered:
                    # 即使凭据年龄仍在安全窗内，服务端也可能提前判定失效。
                    # 发送失败后暂停后续主动消息，等用户新上行刷新 token。
                    try:
                        await dynamic_mind.suspend_proactive_until_user(
                            pool, bot_instance.db_id
                        )
                    except Exception:
                        pass

                # 文本已发送 → 若开启微信语音, 再补发一条语音 (文本 + 语音都到用户)
                # 用控制台 user_id(整数) 查会员设置, 不是微信 wxid(uid)。
                if not is_error and text_delivered:
                    try:
                        await _maybe_send_wx_voice(
                            bot_instance, uid, context_token, reply_text, pool, wx_token_plain,
                            user_id
                        )
                    except Exception as _ve:
                        print(f"[微信语音] 顶层异常(文本已发送, 仅语音未补): {_ve}", flush=True)

            # 【生命周期】决策后续计时器逻辑
            key = (bot_instance.db_id, uid)
            if stop_proactive:
                # 保留:这是 AI 主动决定休眠的重要事件
                print(f"[生命周期] 实例 {bot_instance.db_id} 用户 {uid}: 主动消息连续 2 轮未回应,计时器休眠", flush=True)
                _cancel_proactive_timers_for_dbid(bot_instance.db_id)
            else:
                # ── 实例级"主动回复"开关(实验性功能) ─────────────────────
                # proactive_enabled=0 → 不启动心智调度,等同于实例从不主动搭话。
                # 旧实例字段缺失时默认为开；显式的 0 必须保持为关。
                proactive_on = await _dynamic_mind_proactive_enabled(
                    pool, bot_instance.db_id
                )

                if not proactive_on:
                    # v8.3:实例关闭主动回复是配置事件,不打 stdout(每条消息都会进这里会刷屏)
                    _cancel_proactive_timers_for_dbid(bot_instance.db_id)
                else:
                    # 不再生成 10-120 分钟随机数。下一次时间已经由当前驱动力、
                    # 疲惫/睡眠、安静时段和“连续主动未回应次数”写入数据库。
                    _cancel_proactive_timers_for_dbid(bot_instance.db_id)
                    try:
                        _mind_delay = await dynamic_mind.get_proactive_delay(
                            pool, bot_instance.db_id
                        )
                    except Exception as _mind_timer_error:
                        _mind_delay = None
                        print(
                            f"[心潮·主动重排] db_id={bot_instance.db_id} "
                            f"{type(_mind_timer_error).__name__}: {_mind_timer_error}",
                            flush=True,
                        )
                    if _mind_delay is not None:
                        proactive_timers[key] = asyncio.create_task(
                            proactive_timer_task(
                                pool, bot_instance, uid, context_token
                            )
                        )

        except asyncio.TimeoutError:
            print(f"[任务队列] [超时] Worker-{worker_id} 处理实例 {bot_instance.db_id} 超时", flush=True)
        except Exception as e:
            # 修复 (2026-05-09):异常时打完整 traceback,定位根因
            # 旧版只打 str(e),像 'image_paths' 这种 TypeError 看不到调用栈,排查极慢
            import traceback as _tb
            print(
                f"[任务队列] [异常] Worker-{worker_id} 实例 {bot_instance.db_id} 报错: "
                f"{type(e).__name__}: {e}",
                flush=True,
            )
            _tb.print_exc()
            try:
                await utils.add_temp_log(
                    pool, bot_instance.db_id,
                    f"[后台进程·出错] {type(e).__name__}: {str(e)[:200]}"
                )
            except Exception: pass
        finally:
            _elapsed_ms = int((time.monotonic() - _t_start) * 1000)
            active_workers -= 1
            worker_states.pop(worker_id, None)
            task_queue.task_done()
            # v8.3:用户期望的"结束"日志
            print(f"[Worker-{worker_id}] ✓ 实例 {bot_instance.db_id} 用户 {uid} 完成 ({_elapsed_ms}ms)", flush=True)

async def manual_push_worker(pool, running_tasks: dict):
    """
    v12.7 (2026-05-12) 手动推送 worker。
    每 3s 扫一次 manual_push_queue,把 status=0 的任务交给对应实例的 BotInstance 发出去。
    复用 _send_wx_text(切片 + 重试),失败的标记为 status=2 留错误信息。

    设计要点:
    - 直接走 _send_wx_text,继承重试/分段/失败队列,跟 AI 回复路径一致
    - 老库未跑 migrate_v12_7 → 表不存在 → 静默跳过(class flag 记一次后不再尝试)
    - 不阻塞主消息流:每个任务串行,但每 3s 才扫一次,QPS 极低
    """
    table_missing = False
    print("[manual_push] worker 启动", flush=True)
    while True:
        await asyncio.sleep(3)
        if table_missing:
            await asyncio.sleep(60)   # 已知没表,降频检查防止刷
            continue
        try:
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT id, db_id, uid, context_token, content "
                        "FROM manual_push_queue WHERE status=0 "
                        "ORDER BY id ASC LIMIT 20"
                    )
                    tasks = await cur.fetchall() or []
        except Exception as e:
            msg = str(e)
            if 'manual_push_queue' in msg and ("doesn't exist" in msg or "Table" in msg):
                table_missing = True
                print(
                    "[manual_push] 表不存在(请跑 migration_v12_7_manual_push.sql),后续静默跳过",
                    flush=True,
                )
            else:
                print(f"[manual_push] 查询队列异常: {type(e).__name__}: {msg[:120]}", flush=True)
            continue

        if not tasks:
            continue

        for t in tasks:
            push_id = t['id']
            db_id   = t['db_id']
            uid     = t['uid']
            ctx_tok = t['context_token'] or ''
            content = t['content']

            # v12.14: 设 contextvar, 让 add_temp_log 自动加 uid 前缀
            utils.current_uid_var.set(uid)
            utils.current_kind_var.set('manual_push')

            # 找正在跑的 BotInstance(复用其 httpx client 和发送基础设施)
            bot_info  = running_tasks.get(db_id)
            bot_inst  = bot_info['bot'] if bot_info else None
            if not bot_inst:
                # 实例没在跑 → 标失败
                try:
                    async with pool.acquire() as conn:
                        async with conn.cursor() as cur:
                            await cur.execute(
                                "UPDATE manual_push_queue SET status=2, "
                                "       error_msg='实例未启动,无法推送', sent_at=%s "
                                "WHERE id=%s",
                                (int(time.time()), push_id),
                            )
                        await conn.commit()
                except Exception as e:
                    print(f"[manual_push] 标失败异常 id={push_id}: {e}", flush=True)
                continue

            # 拉取 token / 分段规则
            try:
                wx_token_plain, split_rule, ignore_punc = await utils._fetch_send_config(pool, db_id)
            except Exception as e:
                wx_token_plain = None
                err_str = f"读 wx_token 失败: {str(e)[:80]}"
            if not wx_token_plain:
                try:
                    async with pool.acquire() as conn:
                        async with conn.cursor() as cur:
                            await cur.execute(
                                "UPDATE manual_push_queue SET status=2, "
                                "       error_msg=%s, sent_at=%s WHERE id=%s",
                                ('wx_token 缺失或解密失败,请重新扫码', int(time.time()), push_id),
                            )
                        await conn.commit()
                except Exception: pass
                continue

            # 直接取得一次发送的真实结果，便于后台立即反馈。
            try:
                success, err_str, _retryable = await _send_text_chunks(
                    bot_inst, uid, ctx_tok, content,
                    wx_token_plain, split_rule, ignore_punc, pool,
                )
                if success:
                    new_status = 1
                    err_msg    = ''
                    # ── v12.7 关键:发送成功后等同于"AI 自己说了这句话",对齐 ─
                    # chat.py 在 _send_wx_text 成功后做的几件事(L2629-2646):
                    #   1. history.append({assistant, content}) + save_context
                    #   2. _embed_and_save_turn(向量入库,供 RAG)
                    #   3. UPDATE instances SET ai_message_count += 1
                    # 任何一步失败都不阻断:已经发出去了,DB 副作用是 best-effort
                    #
                    # v12.10 (2026-05-12) 修正并发覆盖 bug:
                    #   原代码 get_context + append + save_context 在并发场景下
                    #   会被 chat.py 同期写覆盖(read-modify-write 不是原子)。
                    #   改用 utils.append_to_context — 在 _save_locks 锁内重新
                    #   读 DB + append + 写,保证不丢失。
                    try:
                        await utils.append_to_context(pool, db_id, [
                            {"role": "assistant", "content": content, "ts": int(time.time())}
                        ], uid=uid)
                    except Exception as _hist_e:
                        print(
                            f"[manual_push] id={push_id} 写 history 失败: "
                            f"{type(_hist_e).__name__}: {_hist_e}",
                            flush=True,
                        )

                    # 向量入库 + 计数:走 chat.py 的私有函数,保持完全一致
                    try:
                        import chat as _chat
                        async with pool.acquire() as conn:
                            async with conn.cursor() as cur:
                                await cur.execute(
                                    "SELECT persona_id FROM instances WHERE id=%s",
                                    (db_id,),
                                )
                                _row = await cur.fetchone()
                        _persona_id = (_row or {}).get('persona_id')
                        await _chat._embed_and_save_turn(
                            pool, db_id, _persona_id, "assistant", content
                        )
                    except Exception as _emb_e:
                        print(
                            f"[manual_push] id={push_id} 向量入库失败(不影响发送): "
                            f"{type(_emb_e).__name__}: {_emb_e}",
                            flush=True,
                        )

                    try:
                        async with pool.acquire() as conn:
                            async with conn.cursor() as cur:
                                await cur.execute(
                                    "UPDATE instances SET "
                                    "  ai_message_count = ai_message_count + 1 "
                                    "WHERE id=%s",
                                    (db_id,),
                                )
                            await conn.commit()
                    except Exception as _cnt_e:
                        print(
                            f"[manual_push] id={push_id} 计数 +1 失败(不影响发送): "
                            f"{type(_cnt_e).__name__}: {_cnt_e}",
                            flush=True,
                        )
                else:
                    new_status = 2
                    err_msg    = f'发送失败: {err_str or "未知错误"}'
            except Exception as e:
                new_status = 2
                err_msg    = f"发送异常: {type(e).__name__}: {str(e)[:160]}"
                print(f"[manual_push] id={push_id} 发送异常: {err_msg}", flush=True)

            # 回写状态
            try:
                async with pool.acquire() as conn:
                    async with conn.cursor() as cur:
                        await cur.execute(
                            "UPDATE manual_push_queue SET status=%s, error_msg=%s, sent_at=%s "
                            "WHERE id=%s",
                            (new_status, err_msg[:500], int(time.time()), push_id),
                        )
                    await conn.commit()
            except Exception as e:
                print(f"[manual_push] 回写状态异常 id={push_id}: {e}", flush=True)

            # 写实例日志栏
            try:
                if new_status == 1:
                    await utils.add_temp_log(
                        pool, db_id,
                        f"[手动发送] 已发送给 {uid[:24]}: {content[:80]}{'...' if len(content)>80 else ''}"
                    )
                else:
                    await utils.add_temp_log(
                        pool, db_id,
                        f"[手动发送][失败] {uid[:24]}: {err_msg[:120]}"
                    )
            except Exception: pass


# ============================================================================
# 节日推送 (holiday broadcast) · 简化版 worker  (2026-06-29 · 修正取用户来源)
# ----------------------------------------------------------------------------
# 思路:后台下发一条指令(broadcast_commands 一行) → main 把它扇成逐实例-逐联系人
#   队列(broadcast_queue) → 各分片只消费【自己那部分实例】,生成人设问候并主动发出。
#   分片本身就是平均分流,所以这里不做任何并发限速。下发不可撤回;进度写回指令行。
#
# ★ 关键:要发给谁,来自 instance_contacts 表(main 每条入向消息都会 UPSERT
#   (db_id, uid, context_token, last_seen, msg_count))。这也是"紧急公告广播"
#   发给"历史交互过的全部 uid"用的同一张表。不是 instances.uid。
#   contact_filter:all_contacts=全部历史联系人;top_contact=每实例 msg_count 最大的 1 个。
#
# 队列项状态:0 待发  2 处理中  1 已发  9 失败
# 指令状态:  0 待派发  1 进行中  2 已完成
# ============================================================================

BROADCAST_TICK_SEC       = 3
# 旧版每分片一次并发 20 条；13 分片会瞬间打出最多 260 个带长上下文的模型
# 请求，并紧接着突发微信下发，极易同时触发模型端和微信端 429。广播属于后台
# 任务，稳定性优先，改为每分片逐条消费。
BROADCAST_DRAIN_BATCH    = 1
BROADCAST_STALE_SEC      = 1800
BROADCAST_GEN_RETRIES    = 6
BROADCAST_RETRY_MAX_SEC  = 120.0

_bc_gen_http_client = None


def _bc_get_http_client():
    global _bc_gen_http_client
    if _bc_gen_http_client is None or _bc_gen_http_client.is_closed:
        _bc_gen_http_client = httpx.AsyncClient(
            timeout=httpx.Timeout(connect=10.0, read=90.0, write=20.0, pool=10.0),
            limits=httpx.Limits(max_connections=50, max_keepalive_connections=20, keepalive_expiry=60),
        )
    return _bc_gen_http_client


async def broadcast_worker(pool, running_tasks: dict):
    table_missing = False
    print("[broadcast] 节日推送 worker 启动 (instance_contacts 版)", flush=True)
    while True:
        await asyncio.sleep(BROADCAST_TICK_SEC)
        if table_missing:
            await asyncio.sleep(60)
            continue
        try:
            if IS_PRIMARY_SHARD:
                await _bc_dispatch_new_commands(pool)
                await _bc_recover_and_finalize(pool)
            await _bc_drain_queue(pool, running_tasks)
        except Exception as e:
            msg = str(e)
            if (('broadcast_commands' in msg) or ('broadcast_queue' in msg)) and \
               (("doesn't exist" in msg) or ("Table" in msg)):
                table_missing = True
                print("[broadcast] 表不存在(建表 / 或让 PHP 自愈),后续静默跳过", flush=True)
            else:
                print(f"[broadcast] tick 异常: {type(e).__name__}: {msg[:160]}", flush=True)


# ── 主分片:把新指令扇成逐联系人队列(取自 instance_contacts)──────────────────
# users.region 是后加的列(地区功能)。缓存探测一次:不存在则地区筛选自动跳过,
# 老库/未跑迁移也不会因 "Unknown column 'region'" 报错。
_bc_users_region_col = None  # None=未探测, True/False=探测结果

async def _bc_has_region_col(pool) -> bool:
    global _bc_users_region_col
    if _bc_users_region_col is not None:
        return _bc_users_region_col
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute("SHOW COLUMNS FROM users LIKE 'region'")
                _bc_users_region_col = bool(await cur.fetchone())
    except Exception:
        _bc_users_region_col = False
    return _bc_users_region_col


async def _bc_dispatch_new_commands(pool):
    now = int(time.time())
    region_ok = await _bc_has_region_col(pool)   # 先探测,避免下面嵌套 acquire
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            # SELECT * 一次读齐:contact_filter / region_filter 都是陆续加的列,
            # 用 .get() 取,缺列自动降级,不因列名不存在而整条查询失败。
            await cur.execute(
                "SELECT * FROM broadcast_commands WHERE status=0 ORDER BY id ASC LIMIT 5")
            cmds = await cur.fetchall() or []

            for c in cmds:
                cid = c['id']
                # 原子抢占:只有 0→1 成功那次扇出
                await cur.execute(
                    "UPDATE broadcast_commands SET status=1, dispatched_at=%s WHERE id=%s AND status=0",
                    (now, cid))
                if cur.rowcount != 1:
                    continue

                scope   = (c.get('scope') or 'active')
                cfilter = (c.get('contact_filter') or 'all_contacts')
                target_ids = [int(p) for p in str(c.get('target_db_ids') or '').replace('，', ',').split(',')
                              if p.strip().isdigit()]
                try:
                    max_inst = int(c.get('max_instances') or 0)
                except Exception:
                    max_inst = 0

                # 地区筛选:region_filter 为空 / 'all' / '__all__' → 不限地区(老行为);
                # 否则按逗号分隔的地区 token 过滤;token '__none__' = 未知(未填写/不愿透露)。
                region_raw = str(c.get('region_filter') or '').replace('，', ',').strip()
                region_tokens = [t.strip() for t in region_raw.split(',') if t.strip()]
                want_region = bool(region_tokens) and region_raw.lower() not in ('all', '__all__')

                # 1) 目标实例集(scope / 定向 / 限量 / 地区)
                wi, pi = [], []
                if scope != 'all':
                    wi.append("status='启动'")
                if target_ids:
                    wi.append("id IN (" + ",".join(["%s"] * len(target_ids)) + ")")
                    pi.extend(target_ids)
                if want_region and region_ok:
                    real = [t for t in region_tokens if t != '__none__']
                    inc_unknown = '__none__' in region_tokens
                    subs, subp = [], []
                    if real:
                        subs.append("region IN (" + ",".join(["%s"] * len(real)) + ")")
                        subp.extend(real)
                    if inc_unknown:
                        subs.append("(region IS NULL OR region='' OR region='__none__')")
                    if subs:
                        wi.append("user_id IN (SELECT id FROM users WHERE " + " OR ".join(subs) + ")")
                        pi.extend(subp)
                sql_i = "SELECT id FROM instances"
                if wi:
                    sql_i += " WHERE " + " AND ".join(wi)
                sql_i += " ORDER BY id ASC"
                if max_inst > 0:
                    sql_i += " LIMIT %s"
                    pi.append(max_inst)
                await cur.execute(sql_i, tuple(pi))
                db_ids = [r['id'] for r in (await cur.fetchall() or [])]

                # 2) 从 instance_contacts 取这些实例【历史交互过的 uid】,逐块入队
                total = 0
                CHUNK = 300
                for k in range(0, len(db_ids), CHUNK):
                    sub = db_ids[k:k + CHUNK]
                    ph = ",".join(["%s"] * len(sub))
                    await cur.execute(
                        "SELECT db_id, uid, context_token, msg_count "
                        "FROM instance_contacts WHERE db_id IN (" + ph + ") "
                        "AND uid LIKE %s AND COALESCE(context_token, '') <> '' "
                        "ORDER BY db_id ASC, msg_count DESC",
                        tuple(sub) + ("%@im.wechat",),
                    )
                    contacts = await cur.fetchall() or []

                    tuples = []
                    if cfilter == 'top_contact':
                        seen = set()
                        for r in contacts:
                            d = r['db_id']
                            if d in seen:
                                continue
                            seen.add(d)
                            if r.get('uid'):
                                tuples.append((cid, d, r['uid'], r.get('context_token') or '', now))
                    else:  # all_contacts
                        for r in contacts:
                            if r.get('uid'):
                                tuples.append((cid, r['db_id'], r['uid'], r.get('context_token') or '', now))

                    if tuples:
                        await cur.executemany(
                            "INSERT INTO broadcast_queue "
                            "(command_id, db_id, uid, context_token, status, created_at) "
                            "VALUES (%s,%s,%s,%s,0,%s)", tuples)
                        await conn.commit()
                        total += len(tuples)

                await cur.execute("UPDATE broadcast_commands SET total=%s WHERE id=%s", (total, cid))
                await conn.commit()
                print(f"[broadcast] 指令#{cid} 下发:命中实例 {len(db_ids)} 个 → 入队 {total} 条 "
                      f"(scope={scope} filter={cfilter} region={region_raw or 'all'})", flush=True)


# ── 主分片:卡死回收 + 完成判定 + 进度回写(空指令也能正常收尾,不会卡 0/0)──────
async def _bc_recover_and_finalize(pool):
    now = int(time.time())
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "UPDATE broadcast_queue SET status=9, error_msg='处理超时(进程可能中断),不重发' "
                "WHERE status=2 AND sent_at>0 AND sent_at < %s", (now - BROADCAST_STALE_SEC,))
            await conn.commit()

            await cur.execute("SELECT id FROM broadcast_commands WHERE status=1")
            for r in (await cur.fetchall() or []):
                cid = r['id']
                await cur.execute(
                    "SELECT SUM(status=1) AS sent, SUM(status=9) AS failed, "
                    "       SUM(status IN (0,2)) AS pending, COUNT(*) AS total "
                    "FROM broadcast_queue WHERE command_id=%s", (cid,))
                s = await cur.fetchone() or {}
                sent = int(s.get('sent') or 0)
                failed = int(s.get('failed') or 0)
                pending = int(s.get('pending') or 0)
                total = int(s.get('total') or 0)
                # pending==0 即收尾:既覆盖"全部发完",也覆盖"0 个联系人"的空指令
                if pending == 0:
                    await cur.execute(
                        "UPDATE broadcast_commands SET status=2, sent=%s, failed=%s, total=%s, finished_at=%s "
                        "WHERE id=%s AND status=1", (sent, failed, total, now, cid))
                else:
                    await cur.execute(
                        "UPDATE broadcast_commands SET sent=%s, failed=%s WHERE id=%s",
                        (sent, failed, cid))
            await conn.commit()


# ── 各分片:消费本分片实例的队列项(生成 + 发送)。每分片严格逐条消费 ──────────
async def _bc_drain_queue(pool, running_tasks):
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT q.id, q.db_id, q.uid, q.context_token, c.prompt, c.model_override "
                "FROM broadcast_queue q JOIN broadcast_commands c ON c.id=q.command_id "
                "WHERE q.status=0 AND c.status=1 AND (q.db_id %% %s = %s) "
                "ORDER BY q.id ASC LIMIT %s",
                (SHARD_TOTAL, SHARD_INDEX, BROADCAST_DRAIN_BATCH))
            rows = await cur.fetchall() or []
    if not rows:
        return
    client = _bc_get_http_client()
    # 不再 asyncio.gather 突发请求。分片编号提供固定错峰，随机抖动避免所有
    # 进程在同一秒醒来，共享上游 key 时也不会形成整齐的请求尖峰。
    await asyncio.sleep((SHARD_INDEX % 8) * 0.35 + random.uniform(0.15, 0.85))
    for row in rows:
        await _bc_process_one(pool, running_tasks, client, row)


async def _bc_process_one(pool, running_tasks, client, r):
    qid = r['id']
    db_id = r['db_id']
    uid = r['uid']
    ctx = r.get('context_token') or ''
    now = int(time.time())

    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "UPDATE broadcast_queue SET status=2, sent_at=%s WHERE id=%s AND status=0",
                (now, qid))
            claimed = (cur.rowcount == 1)
        await conn.commit()
    if not claimed:
        return

    utils.current_uid_var.set(uid)
    utils.current_kind_var.set('holiday_broadcast')

    bot_info = running_tasks.get(db_id)
    bot_inst = bot_info['bot'] if bot_info else None
    if not bot_inst:
        await _bc_q_done(pool, qid, 9, '实例未启动,无法发送', None)
        return

    # 队列中的 context_token 是指令扇出时的快照，排队期间用户可能又发过消息。
    # 生成前重新读取最新记录；若记录已明显超过主动会话安全期，则不要携带
    # 已知陈旧 token，直接走无 context 的官方兼容下发路径。
    try:
        latest_ctx, latest_seen = await weixin_media.latest_context_record(pool, db_id, uid)
        if latest_ctx:
            ctx = latest_ctx
        if not weixin_media.proactive_context_is_fresh(ctx, latest_seen):
            ctx = ''
    except Exception as context_exc:
        print(
            f"[broadcast] 刷新会话凭据失败 qid={qid}: "
            f"{type(context_exc).__name__}: {str(context_exc)[:100]}",
            flush=True,
        )

    text, err = await _bc_generate_greeting(
        pool, client, db_id, uid, r['prompt'], r.get('model_override') or ''
    )
    if not text:
        await _bc_q_done(pool, qid, 9, err or '生成失败', None)
        return

    try:
        wx_token_plain, split_rule, ignore_punc = await utils._fetch_send_config(pool, db_id)
    except Exception as e:
        await _bc_q_done(pool, qid, 9, f'读 wx_token 失败: {str(e)[:80]}', text)
        return
    if not wx_token_plain:
        await _bc_q_done(pool, qid, 9, 'wx_token 缺失或解密失败', text)
        return

    try:
        success, serr, _retryable = await _send_text_chunks(
            bot_inst, uid, ctx, text, wx_token_plain, split_rule, ignore_punc, pool)
    except Exception as e:
        success, serr, _retryable = False, f'{type(e).__name__}: {str(e)[:120]}', False

    if success:
        await _bc_q_done(pool, qid, 1, '', text)
        try:
            await utils.append_to_context(pool, db_id, [
                {"role": "assistant", "content": text, "ts": int(time.time())}], uid=uid)
        except Exception:
            pass
        try:
            async with pool.acquire() as c2:
                async with c2.cursor() as cu:
                    await cu.execute(
                        "UPDATE instances SET ai_message_count = ai_message_count + 1 WHERE id=%s", (db_id,))
                await c2.commit()
        except Exception:
            pass
        try:
            await utils.add_temp_log(pool, db_id, f"[节日推送] 已发送 → {uid[:24]}: {text[:60]}")
        except Exception:
            pass
    else:
        await _bc_q_done(pool, qid, 9, f'发送失败: {serr or "未知"}', text)
        try:
            await utils.add_temp_log(pool, db_id, f"[节日推送][失败] {uid[:24]}: {(serr or '')[:100]}")
        except Exception:
            pass


async def _bc_q_done(pool, qid, status, err, content):
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                if content is None:
                    await cur.execute(
                        "UPDATE broadcast_queue SET status=%s, error_msg=%s WHERE id=%s",
                        (status, (err or '')[:500], qid))
                else:
                    await cur.execute(
                        "UPDATE broadcast_queue SET status=%s, error_msg=%s, content=%s WHERE id=%s",
                        (status, (err or '')[:500], content, qid))
            await conn.commit()
    except Exception as e:
        print(f"[broadcast] 回写队列 #{qid} 失败: {e}", flush=True)


# ── 生成:携带联系人上下文、不计费、不污染历史的专用问候生成 ────────────────
def _bc_context_messages(history):
    """取统一 60 轮真实对话，转换为广播生成请求可直接使用的 messages。"""
    messages = []
    for item in history or []:
        if not isinstance(item, dict) or item.get("llm_only"):
            continue
        role = str(item.get("role") or "").strip().lower()
        content = item.get("content")
        if role not in {"user", "assistant"} or not isinstance(content, str):
            continue
        content = content.strip()
        if content:
            messages.append({"role": role, "content": content})
    return messages[-(chat.UNIFIED_CONTEXT_TURNS * 2):]


async def _bc_generate_greeting(pool, client, db_id, uid, prompt, model_override):
    import persona
    try:
        persona_text, _ = await persona.get_persona_prompt(pool, db_id)
    except Exception as e:
        return "", f"读人设失败: {type(e).__name__}: {str(e)[:80]}"
    if not persona_text:
        persona_text = "你是一个温柔体贴的人。"

    # 节日推送是针对具体联系人生成，必须读取该 (实例, 联系人) 的独立历史，
    # 才能承接最近话题和情绪；窗口与普通聊天一致，固定为 60 轮。
    try:
        history = await utils.get_context(pool, db_id, uid=uid)
    except Exception:
        history = []
    context_messages = _bc_context_messages(history)

    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute("SELECT model FROM instances WHERE id=%s", (db_id,))
            irow = await cur.fetchone() or {}
            model = (model_override or '').strip() or (irow.get('model') or '').strip()
            if not model:
                return "", "实例未配置 model 且未指定统一模型"
            await cur.execute(
                "SELECT config_key, config_value FROM system_config "
                "WHERE config_key IN ('platform_endpoint','platform_api_key')")
            scfg = {r['config_key']: r['config_value'] for r in (await cur.fetchall() or [])}
            await cur.execute(
                "SELECT endpoint AS ep, api_key AS ak, protocol AS proto "
                "FROM model_pricing WHERE model_name=%s", (model,))
            mrow = await cur.fetchone() or {}

    p_endpoint = (scfg.get('platform_endpoint') or '').strip()
    p_key = (scfg.get('platform_api_key') or '').strip()
    api_key = (mrow.get('ak') or '').strip() or p_key
    raw_ep = (mrow.get('ep') or '').strip() or p_endpoint
    proto = (mrow.get('proto') or 'openai').strip().lower()
    if not raw_ep or not api_key:
        return "", f"模型 {model} 缺 endpoint 或 api_key"
    if proto == 'anthropic':
        return "", f"模型 {model} 是 anthropic 协议,主动消息生成暂未适配"
    if "chat/completions" not in raw_ep:
        ep = raw_ep.rstrip("/") + ("/chat/completions" if "/v1" in raw_ep else "/v1/chat/completions")
    else:
        ep = raw_ep

    # 关键:不再把内容写死成"节日问候"。下面这条【指令】就是管理员想发的内容
    # (节日祝福、提醒、通知、关心……都可能),忠实照它的意思写,内容以指令为准。
    sys_p = (
        f"{persona_text}\n\n"
        "【现在的任务】你就是上面这个人。下面这条『指令』写的就是你这次要主动发给 TA 的内容,"
        "可能是祝福、提醒、通知、关心或其它任何事。请你用自己的口吻,把指令要表达的意思自然地说给 TA。\n"
        "要求:严格按指令的意思来写——指令让传达什么就传达什么,不要自作主张改成节日祝福、"
        "也不要添加与指令无关的内容;结合上面的最近对话承接双方正在聊的事和情绪,避免重复已经说过的话;"
        "像平时发微信一样自然、口语化,长度别太长;"
        "只输出这条消息本身,不要任何前后缀、解释、引号,也不要 JSON 或 markdown。"
    )
    messages = [{"role": "system", "content": sys_p}]
    messages.extend(context_messages)
    messages.append({"role": "user", "content": f"【指令】{prompt}"})
    payload = {
        "model": model,
        "messages": messages,
        "temperature": 0.9, "max_tokens": 400, "stream": False,
    }
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

    last_err = ""
    for attempt in range(BROADCAST_GEN_RETRIES):
        try:
            resp = await client.post(ep, json=payload, headers=headers)
            if resp.status_code in (429, 500, 502, 503, 504):
                last_err = f"HTTP {resp.status_code}"
                if attempt + 1 >= BROADCAST_GEN_RETRIES:
                    break
                retry_after = 0.0
                try:
                    retry_after = float(resp.headers.get("retry-after") or 0)
                except (TypeError, ValueError):
                    retry_after = 0.0
                delay = retry_after or min(
                    BROADCAST_RETRY_MAX_SEC,
                    5.0 * (2 ** attempt),
                )
                delay += random.uniform(0.5, 2.0)
                print(
                    f"[broadcast] 模型生成 {last_err}，{delay:.1f}s 后重试 "
                    f"({attempt + 1}/{BROADCAST_GEN_RETRIES}) db_id={db_id}",
                    flush=True,
                )
                await asyncio.sleep(delay)
                continue
            resp.raise_for_status()
            data = resp.json()
            text = ((data.get("choices") or [{}])[0].get("message", {}).get("content") or "").strip()
            text = text.strip().strip('「」"“”').strip()
            if not text:
                return "", "生成内容为空"
            return text, ""
        except Exception as e:
            last_err = f"{type(e).__name__}: {str(e)[:100]}"
            if attempt + 1 < BROADCAST_GEN_RETRIES:
                await asyncio.sleep(min(20.0, 1.5 * (2 ** attempt)))
    return "", f"生成失败(重试{BROADCAST_GEN_RETRIES}次): {last_err}"


async def proactive_scanner_task(pool, running_tasks: dict):
    # v8.3: 删除"扫描器启动"打印,健康路径完全静默
    while True:
        await asyncio.sleep(10)
        try:
            due_messages = await utils.get_due_proactive_messages(pool)
            for msg in due_messages:
                db_id   = msg['db_id']
                uid     = msg['uid']
                content = msg['content']
                ctx_tok = msg.get('context_token', '')

                # v12.14: 设 contextvar, 让 add_temp_log 自动加 uid 前缀
                utils.current_uid_var.set(uid)
                utils.current_kind_var.set('proactive_scan')

                task_info = running_tasks.get(db_id)
                if not task_info:
                    continue

                bot_instance = task_info["bot"]
                if not bot_instance.is_running:
                    continue

                wx_token_plain, split_rule, ignore_punc = await utils._fetch_send_config(pool, db_id)
                if not wx_token_plain:
                    continue

                await utils.add_temp_log(pool, db_id, f"主动消息到期推送 -> uid:{uid}")
                await _send_wx_text(
                    bot_instance, uid, ctx_tok,
                    content, pool, wx_token_plain,
                    split_rule, ignore_punc
                )

                # v12.10 安全 append(原 get + append + save 在并发下会丢失更新)
                await utils.append_to_context(pool, db_id, [
                    {"role": "assistant", "content": content, "ts": int(time.time())}
                ], uid=uid)

        except Exception as e:
            print(f"[扫描器] [异常] 扫描报错: {e}")

class BotInstance:
    # 单实例 httpx 客户端的连接上限（避免 N 实例 × 默认 100 的 fd 失控）
    # 该实例所有并发动作（长轮询 / 发消息 / 上行下载 / 撤回）共享这 30 个槽位。
    HTTPX_LIMITS = httpx.Limits(
        max_connections=30,
        max_keepalive_connections=10,
        keepalive_expiry=120.0,   # v8.2 (2026-05-09):30s → 120s,凌晨低流量时
                                   # 太短的 keepalive 会让每次轮询都要重连 TLS,
                                   # 中间盒 NAT 也容易切连接。
    )

    # v8.3 (2026-05-09):分开 connect / read / write / pool 超时。
    # 这是 client 的"默认"值,具体接口的 timeout 仍以 .post(timeout=...) 显式
    # 传入为准 — 官方各接口的预期 timeout (长轮询 40s, 二维码 20s, sendtyping
    # 5-10s) 不在这里改,这里只兜底。
    HTTPX_TIMEOUT = httpx.Timeout(
        connect=15.0,      # 建连(含 DNS+TLS)给足 15s,凌晨网络抖动常见
        read=45.0,         # 默认 read,各接口若没显式 timeout 才会用到
        write=10.0,        # 上行 payload 不大,10s 够了
        pool=10.0,         # 从连接池等可用连接的最大时长
    )

    # v11 (2026-05-12) 探测 updates_buf 字段是否存在(老库未跑迁移时设为 True 后跳过)
    _buf_column_missing = False

    def __init__(self, db_row, pool):
        self.pool            = pool
        self.db_id           = db_row['id']
        # 该实例是微信发送实例。QQ 使用 QQBotInstanceAdapter，拥有独立的
        # access_token、openid 和被动消息 id，绝不能落入微信发送函数。
        self.tool_channel    = "wechat"
        self.channel         = "wechat"
        self.is_running      = True
        self.client          = self._make_client()
        # v11 (2026-05-12) 关键修复:get_updates_buf 必须从 DB 恢复,否则进程重启后
        # iLink 服务端会重放所有"未确认"消息 → 用户早上又收到昨晚的消息。
        # main() 在创建 BotInstance 时把 updates_buf 字段一并查出来传入。
        self.get_updates_buf = (db_row.get('updates_buf') or '') if isinstance(db_row, dict) else ''
        self.msg_task        = None
        # 防写库洪水:buf 推进每 30s 至多写一次(写库本身是 fire-and-forget,
        # 但每条消息进来都触发一次 UPDATE 也没必要),保留最新值定期 flush
        self._buf_dirty_at   = 0.0
        self._buf_last_save  = 0.0
        # v11:_save_buf_task 用于"健康路径下"的定期 flush(避免每条消息都 await DB)
        self._save_buf_task  = None

    async def _persist_updates_buf(self, force: bool = False) -> None:
        """
        v11 (2026-05-12) 把当前 get_updates_buf 写回 instances 表。
        - 默认 30s 节流;force=True 立即写(关停 / 异常退出时调用)
        - asyncio.create_task 发起,不 await,**不阻塞消息处理线程**
        - 老库无 updates_buf 字段 → 静默 ignore,不报错也不再尝试
        """
        try:
            async with self.pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "UPDATE instances SET updates_buf=%s WHERE id=%s",
                        (self.get_updates_buf or '', self.db_id),
                    )
                await conn.commit()
            self._buf_last_save = time.time()
            self._buf_dirty_at  = 0.0
        except Exception as e:
            # 老库未跑 v11 迁移 → Unknown column 'updates_buf'.
            # 不打 stdout(频繁触发会刷屏),改为标记后续不再尝试
            msg = str(e)
            if 'updates_buf' in msg and ('Unknown column' in msg or "doesn't exist" in msg):
                BotInstance._buf_column_missing = True
            else:
                # 真异常,打一行 stdout 让运维知道
                print(
                    f"[BufPersist] 实例 {self.db_id} 写库失败: "
                    f"{type(e).__name__}: {msg[:100]}",
                    flush=True,
                )

    def _make_client(self) -> httpx.AsyncClient:
        """新建一个 httpx 客户端 (供 __init__ + _message_loop 重连时用)。"""
        return httpx.AsyncClient(
            timeout=self.HTTPX_TIMEOUT,
            limits=self.HTTPX_LIMITS,
            trust_env=True,    # v8.2:尊重环境变量(如 HTTPS_PROXY),便于线上
                               # 在受限网络环境下手动配代理调试
            http2=False,       # 显式 HTTP/1.1,避免 HTTP/2 stream 限制踩坑
        )

    async def _reset_client(self, reason: str):
        """
        v8.2 (2026-05-09):连续多次异常时强制重建 httpx 客户端。
        症状:凌晨长轮询连续 N 次失败,可能是 keepalive 池里的 TCP 连接被中间盒
        切断,但 socket 还在 ESTABLISHED 状态;httpx 拿这种死连接发请求只会一直
        ReadTimeout。重建后强制走新建连接路径,绝大多数瞬时网络问题这一招就好。
        """
        print(f"[消息监听] 实例 {self.db_id} 重建 httpx 客户端,原因: {reason}", flush=True)
        try:
            await self.client.aclose()
        except Exception: pass
        self.client = self._make_client()
        try:
            await utils.add_temp_log(
                self.pool, self.db_id,
                f"[轮询消息] 检测到连接池可能损坏 ({reason}),已重建 HTTP 客户端"
            )
        except Exception: pass

    async def _login_flow(self):
        """
        二维码登录流程。
        v8.3 (2026-05-09) 瘦身:常规路径不打 print(原本 5 条 print 同步阻塞
        事件循环,影响二维码写入响应速度);只在异常 / 真正写库成功 这两个关
        键节点打一条简短 log。前端从 reset_token 到能拿到 qr_url 的时间因此
        明显缩短(原本几十 ms 的 print IO 全部省掉)。
        """
        # 日志:常规路径不打;只异常打
        async def _mark_error(reason: str):
            """统一把实例置为异常状态，前端能感知"""
            try:
                async with self.pool.acquire() as conn:
                    async with conn.cursor() as cur:
                        await cur.execute(
                            "UPDATE instances SET status='异常', qr_code_url=NULL WHERE id=%s",
                            (self.db_id,)
                        )
                    await conn.commit()
                print(f"[消息监听] 实例 {self.db_id} 状态置'异常',原因: {reason[:120]}", flush=True)
            except Exception as ee:
                print(f"[消息监听] 实例 {self.db_id} 写入异常状态失败: {ee}", flush=True)

        qr_key = None
        try:
            url = f"{BASE_URL}/get_bot_qrcode?bot_type=3"
            res = await self.client.get(url, timeout=20.0)
            res.raise_for_status()
            data   = res.json()
            qr_key = data.get("qrcode")

            qr_url = ""
            match  = re.search(r'(https?://[^\s"\'\\]+)', json.dumps(data))
            if match:
                qr_url = match.group(1)

            if qr_key and qr_url:
                # ── 关键修复（2026-05-09）─────────────────────────────
                # 旧: UPDATE instances SET qr_code_url=%s, status='启动' WHERE id=%s
                # 问题：admin 把 status 改成「停止」想关掉实例时，本协程
                # 仍会把 status 强写回「启动」，导致 main 下一轮再次激活，
                # _login_flow 一直被反复触发——表现为终端疯狂刷屏。
                # 修复：只更 qr_code_url，且 WHERE 限定 status='启动'，
                # 让 admin 的停止动作具有最终权威。
                async with self.pool.acquire() as conn:
                    async with conn.cursor() as cur:
                        await cur.execute(
                            "UPDATE instances SET qr_code_url=%s "
                            "WHERE id=%s AND status='启动'",
                            (qr_url, self.db_id)
                        )
                        affected = cur.rowcount
                    await conn.commit()
                if affected == 0:
                    # 已被 admin 停止 — 不打印噪音,直接返回
                    return
                # 二维码已写入 — 不打 stdout,前端轮询 status 接口即刻能拿到
            else:
                # qr_key 或 qr_url 缺失
                await _mark_error(f"接口返回缺少 qrcode 或 url 字段; 原始 data={str(data)[:300]}")
                return

        except httpx.TimeoutException as e:
            await _mark_error(f"网络超时: {e}")
            return
        except httpx.ConnectError as e:
            await _mark_error(f"无法连接微信服务器: {e}")
            return
        except httpx.HTTPStatusError as e:
            await _mark_error(f"微信接口返回 HTTP {e.response.status_code}")
            return
        except Exception as e:
            import traceback
            print(f"[消息监听] 实例 {self.db_id} 拉取二维码异常: {type(e).__name__}: {e}", flush=True)
            traceback.print_exc()
            await _mark_error(f"{type(e).__name__}: {e}")
            return

        # ── 进入 60 秒轮询确认登录 ────────────────────────────────────────
        headers    = {"iLink-App-ClientVersion": "1"}
        start_time = time.time()
        poll_count = 0
        while self.is_running:
            if time.time() - start_time > 60:
                # 60s 超时未扫:静默清 qr_code_url 即可,不打 stdout
                async with self.pool.acquire() as conn:
                    async with conn.cursor() as cur:
                        await cur.execute("UPDATE instances SET qr_code_url=NULL WHERE id=%s", (self.db_id,))
                    await conn.commit()
                return

            try:
                poll_count += 1
                res = await self.client.get(f"{BASE_URL}/get_qrcode_status?qrcode={qr_key}", headers=headers)
                ret = res.json()
                status = ret.get("status")

                # 不再打"轮询第 N 次"的进度日志(不刷屏)。只在真有事件时打:confirmed / expired。

                if status == "confirmed":
                    # ── 修复 (2026-05-09):重新扫码后 token 不写入 / 服务器没轮询到 ──
                    # 旧实现 3 个静默失败窗口:
                    #   ① ret.get("bot_token") 可能为 None/空,直接加密会污染 DB
                    #   ② UPDATE WHERE status='启动' 不匹配时静默丢弃,日志却打"登录确认成功"
                    #   ③ 旧 _message_loop 还没真退,可能在 401 分支把 wx_token 立刻写回 NULL
                    # 全部加日志 + 校验 + 写库后再读一次确认。
                    bot_token = ret.get("bot_token")
                    if not bot_token or not isinstance(bot_token, str) or not bot_token.strip():
                        print(
                            f"[消息监听] 实例 {self.db_id} confirmed 但 bot_token 缺失/为空,"
                            f"原始返回: {str(ret)[:300]}",
                            flush=True,
                        )
                        try:
                            await utils.add_temp_log(
                                self.pool, self.db_id,
                                f"[扫码登录] ✗ 微信返回 confirmed 但 bot_token 字段缺失,扫码失败,请重试"
                            )
                        except Exception: pass
                        return

                    enc_wx_token = utils.encrypt_data(bot_token.strip())

                    async with self.pool.acquire() as conn:
                        async with conn.cursor() as cur:
                            # 同样：admin 已停止则不强行回写 token / 状态
                            await cur.execute(
                                "UPDATE instances SET wx_token=%s, qr_code_url=NULL, last_heartbeat=%s "
                                "WHERE id=%s AND status='启动'",
                                (enc_wx_token, int(time.time()), self.db_id)
                            )
                            affected = cur.rowcount
                        await conn.commit()

                    if affected == 0:
                        # 罕见但严重:意味着 status 在扫码 60s 期间被改了(admin 停止 / 异常分支等)
                        print(
                            f"[消息监听] 实例 {self.db_id} confirmed 写 wx_token 时 affected=0,"
                            f"可能 status 已不是'启动',token 未入库",
                            flush=True,
                        )
                        try:
                            await utils.add_temp_log(
                                self.pool, self.db_id,
                                f"[扫码登录] ✗ 写入 wx_token 时 affected=0(实例状态已变),"
                                f"请检查实例是否被停止后重新启动一次"
                            )
                        except Exception: pass
                        return

                    # 立刻再读一次校验,排查 ③ 旧 _message_loop 抢着把 wx_token 写回 NULL 的竞态
                    await asyncio.sleep(0.1)
                    async with self.pool.acquire() as conn:
                        async with conn.cursor() as cur:
                            await cur.execute(
                                "SELECT wx_token FROM instances WHERE id=%s", (self.db_id,)
                            )
                            verify = await cur.fetchone()
                    if not verify or not verify.get("wx_token"):
                        print(
                            f"[消息监听] 实例 {self.db_id} 写完 wx_token 但 0.1s 后再读为空,"
                            f"说明被旧 _message_loop 的 401 分支抢回 NULL,二次写入...",
                            flush=True,
                        )
                        # 旧 _message_loop 的 401 路径里只 break,不再循环写 NULL,
                        # 这里二次写入足以稳住。再读一次确认。
                        async with self.pool.acquire() as conn:
                            async with conn.cursor() as cur:
                                await cur.execute(
                                    "UPDATE instances SET wx_token=%s, last_heartbeat=%s "
                                    "WHERE id=%s AND status='启动'",
                                    (enc_wx_token, int(time.time()), self.db_id)
                                )
                            await conn.commit()
                        try:
                            await utils.add_temp_log(
                                self.pool, self.db_id,
                                f"[扫码登录] ⚠ 检测到旧监听流回写 NULL,已二次写入 wx_token"
                            )
                        except Exception: pass

                    print(f"[消息监听] 实例 {self.db_id} 登录确认成功 (token 长度={len(bot_token)} 已入库)", flush=True)
                    try:
                        await utils.add_temp_log(
                            self.pool, self.db_id,
                            f"[扫码登录] ✓ 登录成功,token 已写入,等待消息监听接管"
                        )
                    except Exception: pass
                    return
                elif status == "expired":
                    # 二维码过期 — 不打 stdout(只是用户没扫,前端会反馈),
                    # 只在实例日志栏写一条让用户感知
                    async with self.pool.acquire() as conn:
                        async with conn.cursor() as cur:
                            await cur.execute("UPDATE instances SET qr_code_url=NULL WHERE id=%s", (self.db_id,))
                        await conn.commit()
                    try:
                        await utils.add_temp_log(
                            self.pool, self.db_id, "[扫码登录] 二维码已过期,请重新扫码"
                        )
                    except Exception: pass
                    return
            except Exception as e:
                # 轮询中的偶发异常不致命 — 只在前 10 次/最后 1 次时打,极少噪音
                if poll_count == 1:
                    print(f"[消息监听] 实例 {self.db_id} 轮询异常: {type(e).__name__}: {e}", flush=True)
            await asyncio.sleep(2)

    # ─── v12 (2026-05-12) 长轮询消息接收 ──────────────────────────────
    # 整段长轮询逻辑已经抽到 wechat_poller.py,严格对齐 openclaw-weixin@2.4.2
    # spec 实现:
    #   1. ReadTimeout = 正常长轮询超时,**不计入失败**(老代码致命 bug)
    #   2. 使用 longpolling_timeout_ms 动态调整 timeout
    #   3. 区分 HTTP 错误 / 业务错误 (resp.ret, resp.errcode)
    #   4. errcode == -14 (会话过期) 单独处理
    #   5. channel_version = "2.4.2" (与 npm 包同步)
    # 本方法只负责 callback 接线:消息分发 / buf 持久化 / 401 DB 校验 / 日志。
    # ─────────────────────────────────────────────────────────────────
    async def _message_loop(self, wx_token_plain):
        try:
            await utils.add_temp_log(
                self.pool, self.db_id,
                f"[轮询消息] 消息监听已就绪,token 前 6 字={wx_token_plain[:6]}***,等待新消息..."
            )
        except Exception: pass

        # ── callback 1:派发收到的消息 ──
        async def on_messages(msgs: list) -> None:
            # 注:之前 v12.1 在这里加过 message_type=2 过滤,但实际上服务端并不会
            # 把 bot 自己的消息推回来 — 自言自语的根因是 chat.py 构建 LLM messages
            # 时把当前 user_text 重复了两次,已在 v12.2 修复(见 chat.py L1962 注释)。
            try:
                await utils.add_temp_log(
                    self.pool, self.db_id,
                    f"[轮询消息] 收到 {len(msgs)} 条新消息,开始处理..."
                )
            except Exception: pass

            for msg in msgs:
                from_user = msg.get("from_user_id")
                ctx_token = msg.get("context_token") or ""
                content, img, voice, video = "", None, None, None
                for item in msg.get("item_list", []) or []:
                    t = item.get("type")
                    if   t == 1: content = (item.get("text_item")  or {}).get("text", "")
                    elif t == 2: img     =  item.get("image_item")
                    elif t == 3: voice   =  item.get("voice_item")
                    elif t == 5: video   =  item.get("video_item")
                if from_user:
                    # v12.8 (2026-05-12) 实例联系人表 UPSERT
                    # 每条入向消息都更新 (db_id, uid) 的最新 context_token + last_seen
                    # 这样 manual_push 总能拿到最新的 ctx,不再依赖 proactive_schedules
                    try:
                        async with self.pool.acquire() as conn:
                            async with conn.cursor() as cur:
                                await cur.execute(
                                    "INSERT INTO instance_contacts "
                                    "(db_id, uid, context_token, last_seen, msg_count) "
                                    "VALUES (%s, %s, %s, %s, 1) "
                                    "ON DUPLICATE KEY UPDATE "
                                    # 某些上行事件没有 context_token。它们仍然
                                    # 计入互动次数，但绝不能覆盖最近一条可回复
                                    # 的微信凭据，也不能伪造其刷新时间。
                                    "  context_token = CASE "
                                    "    WHEN VALUES(context_token) <> '' THEN VALUES(context_token) "
                                    "    ELSE context_token END, "
                                    "  last_seen = CASE "
                                    "    WHEN VALUES(context_token) <> '' THEN VALUES(last_seen) "
                                    "    ELSE last_seen END, "
                                    "  msg_count     = msg_count + 1",
                                    (self.db_id, from_user, ctx_token, int(time.time())),
                                )
                            await conn.commit()
                    except Exception as _e:
                        msg_e = str(_e)
                        if "instance_contacts" in msg_e and ("doesn't exist" in msg_e or "Table" in msg_e):
                            # 老库没跑迁移 — 静默,跑了就不会报
                            pass
                        else:
                            print(
                                f"[消息监听] instance_contacts upsert 异常 db_id={self.db_id} uid={from_user}: "
                                f"{type(_e).__name__}: {msg_e[:120]}",
                                flush=True,
                            )

                    try:
                        await utils.cancel_proactive_message(self.pool, self.db_id, from_user)
                    except Exception as _e:
                        print(f"[消息监听] cancel_proactive 异常: {_e}", flush=True)
                    await handle_incoming_message_debounced(
                        self, from_user, content, ctx_token, img, voice, video
                    )

            # 写一次 last_heartbeat — 让 console 上能看到"刚处理过消息"
            try:
                async with self.pool.acquire() as conn:
                    async with conn.cursor() as cur:
                        await cur.execute(
                            "UPDATE instances SET last_heartbeat=%s WHERE id=%s",
                            (int(time.time()), self.db_id),
                        )
                    await conn.commit()
            except Exception: pass

        # ── callback 2:游标推进 → 持久化到 DB(fire-and-forget,5s 节流) ──
        async def on_buf_advance(new_buf: str) -> None:
            self.get_updates_buf = new_buf
            now_ts = time.time()
            if (now_ts - self._buf_last_save) >= 5.0 and not BotInstance._buf_column_missing:
                self._buf_last_save = now_ts
                asyncio.create_task(self._persist_updates_buf())

        # ── callback 3:401 时校验 DB token,判断是真失效还是旧实例残留 ──
        async def on_token_invalid() -> bool:
            """返回 True = 真的当前 token 失效需清空;False = DB 已有新 token,
            本协程是旧实例残留,直接退出不要碰 DB。"""
            try:
                async with self.pool.acquire() as conn:
                    async with conn.cursor() as cur:
                        await cur.execute(
                            "SELECT wx_token FROM instances WHERE id=%s", (self.db_id,)
                        )
                        row = await cur.fetchone()
                if not row or not row.get("wx_token"):
                    return True  # DB 已经没 token 了,直接放行
                try:
                    cur_db_token = utils.decrypt_data(row["wx_token"])
                except Exception:
                    cur_db_token = None
                if cur_db_token and cur_db_token != wx_token_plain:
                    # DB 里 token 已经被 _login_flow 换成新的 → 本协程是旧的
                    print(
                        f"[消息监听] 实例 {self.db_id} 401 但 DB token 已更换,本协程为旧实例,直接退出",
                        flush=True,
                    )
                    return False
                # 真的是当前 token 失效 → 清空 wx_token 触发重新登录
                async with self.pool.acquire() as conn:
                    async with conn.cursor() as cur:
                        await cur.execute(
                            "UPDATE instances SET wx_token=NULL WHERE id=%s AND wx_token=%s",
                            (self.db_id, row["wx_token"]),
                        )
                    await conn.commit()
                print(
                    f"[消息监听] 实例 {self.db_id} token 已失效(401),清空触发重新登录",
                    flush=True,
                )
                return True
            except Exception as e:
                print(
                    f"[消息监听] on_token_invalid DB 异常: {type(e).__name__}: {e}",
                    flush=True,
                )
                return True  # 拿不准就放行,让上层走清 token 流程

        # ── callback 4:实例日志栏 ──
        async def on_log(text: str) -> None:
            try:
                await utils.add_temp_log(self.pool, self.db_id, text)
            except Exception: pass

        # ── callback 5:可选 — 网络协议层错误时重建 httpx client ──
        async def on_client_reset(reason: str) -> None:
            try: await self._reset_client(reason)
            except Exception as e:
                print(f"[消息监听] _reset_client 异常: {e}", flush=True)

        # ── 实例化 + 跑 ──
        poller = wechat_poller.WeChatPoller(
            client=self.client,
            base_url=BASE_URL,
            token=wx_token_plain,
            initial_buf=self.get_updates_buf,
            db_id=self.db_id,
            is_running=lambda: self.is_running,
            on_messages=on_messages,
            on_buf_advance=on_buf_advance,
            on_token_invalid=on_token_invalid,
            on_log=on_log,
            on_client_reset=on_client_reset,
        )

        try:
            stop_reason = await poller.run()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            import traceback as _tb
            _tb.print_exc()
            print(
                f"[消息监听] 实例 {self.db_id} poller.run 顶层异常: "
                f"{type(e).__name__}: {e}",
                flush=True,
            )
            return

        # poller 退出原因 → 不同后处理
        if stop_reason == wechat_poller.STOP_SESSION_EXPIRED:
            # 会话过期 → 清空 token 触发重新扫码
            try:
                async with self.pool.acquire() as conn:
                    async with conn.cursor() as cur:
                        await cur.execute(
                            "UPDATE instances SET wx_token=NULL WHERE id=%s",
                            (self.db_id,),
                        )
                    await conn.commit()
                await utils.add_temp_log(
                    self.pool, self.db_id,
                    "[轮询消息] 会话过期,已清空 wx_token 等待重新扫码"
                )
            except Exception: pass

    async def run_loop(self):
        import persona as persona_mod
        await persona_mod.refresh_persona_cache(self.pool, self.db_id)

        # v8.3: 删除"监控就绪"打印 (N 实例同时上线会刷 N 行)。
        # 启动期由 main 主循环统一打一行批量摘要 (上 / 下 / 总数)。

        # 上一轮状态,用于判定状态变化时打日志(默认健康路径完全静默)
        _last_state = None  # 'stopped' / 'no_token' / 'has_token'

        while self.is_running:
            try:
                async with self.pool.acquire() as conn:
                    async with conn.cursor() as cur:
                        await cur.execute("SELECT wx_token, status FROM instances WHERE id=%s", (self.db_id,))
                        row = await cur.fetchone()

                if not row or row['status'] != '启动':
                    # 状态切到 stopped: 不打 stdout,只更状态机
                    _last_state = 'stopped'
                    if self.msg_task and not self.msg_task.done():
                        self.msg_task.cancel()
                        try:
                            await asyncio.wait_for(self.msg_task, timeout=2.0)
                        except (asyncio.CancelledError, asyncio.TimeoutError):
                            pass
                        except Exception:
                            pass
                    self.msg_task = None
                    await asyncio.sleep(3)
                    continue

                if not row['wx_token']:
                    # 切到 no_token: 不打 stdout(扫码失败/过期由 _login_flow 在实例日志栏打)
                    _last_state = 'no_token'
                    if self.msg_task and not self.msg_task.done():
                        self.msg_task.cancel()
                        try:
                            await asyncio.wait_for(self.msg_task, timeout=2.0)
                        except (asyncio.CancelledError, asyncio.TimeoutError):
                            pass
                        except Exception:
                            pass
                    self.msg_task = None
                    await self._login_flow()
                else:
                    if self.msg_task is None or self.msg_task.done():
                        token = utils.decrypt_data(row['wx_token'])
                        if not token:
                            # decrypt 失败:这是真异常,要打 stdout
                            print(f"[消息监听] 实例 {self.db_id} wx_token 解密失败,清空触发重新登录", flush=True)
                            try:
                                async with self.pool.acquire() as conn:
                                    async with conn.cursor() as cur:
                                        await cur.execute("UPDATE instances SET wx_token=NULL WHERE id=%s", (self.db_id,))
                                    await conn.commit()
                            except Exception: pass
                            await asyncio.sleep(2)
                            continue
                        # 切到 has_token: 不打 stdout,只在实例日志栏写一条(用户看实例时能看到)
                        if _last_state != 'has_token':
                            try:
                                await utils.add_temp_log(
                                    self.pool, self.db_id,
                                    "[轮询消息] 已检测到有效 wx_token,消息监听接管中..."
                                )
                            except Exception: pass
                            _last_state = 'has_token'
                        self.msg_task = asyncio.create_task(self._message_loop(token))
            except asyncio.CancelledError:
                if self.msg_task and not self.msg_task.done():
                    self.msg_task.cancel()
                raise
            except Exception as e:
                # run_loop 自身异常仍要打 stdout(因为是 bug 信号)
                print(f"[消息监听] 实例 {self.db_id} run_loop 异常: {type(e).__name__}: {e}", flush=True)

            await asyncio.sleep(2)

async def system_monitor_task(pool):
    last_reported_state = (-1, -1)
    while True:
        try:
            import random as _random
            base_load     = int((active_workers / global_worker_count) * 100)
            queue_penalty = task_queue.qsize() * 5
            final_load    = min(100, base_load + queue_penalty)
            if final_load == 0:
                final_load = _random.randint(1, 3)

            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "INSERT INTO system_config (config_key, config_value) VALUES ('load_value', %s) "
                        "ON DUPLICATE KEY UPDATE config_value=%s",
                        (str(final_load), str(final_load))
                    )
                await conn.commit()

            # v8.3:系统监控默认静默(worker 激活/结束日志已让用户感知活跃度)。
            # 只在队列堆积超过阈值时报警一次(避免连续刷),阈值随 worker 数缩放。
            queue_alarm_threshold = max(20, global_worker_count * 3)
            qsz = task_queue.qsize()
            if qsz > queue_alarm_threshold and last_reported_state != ('alarm', qsz // 10):
                print(
                    f"[系统监控] ⚠ 任务队列堆积 {qsz} 条 (阈值 {queue_alarm_threshold}),"
                    f"负载 {final_load}% 活跃 Worker {active_workers}/{global_worker_count}",
                    flush=True,
                )
                last_reported_state = ('alarm', qsz // 10)
            elif qsz <= queue_alarm_threshold and last_reported_state and last_reported_state[0] == 'alarm':
                # 队列恢复正常 → 报一次"已恢复"
                print(f"[系统监控] ✓ 队列已恢复正常 ({qsz} 条)", flush=True)
                last_reported_state = None

        except Exception:
            pass
        await asyncio.sleep(10)


async def runtime_snapshot_writer(pool):
    """
    每 1 秒将运行时快照（活跃 worker、队列、stdout 日志）写入 system_config
    供 admin 实时监控页拉取。
    
    关键点：
      1) config_value 受 TEXT 限制（最大 65535 字节，UTF-8 中文 1 字 3 字节）。
         我们硬截断到 ~55KB，超出时按"先丢老日志、再截 worker 列表"的优先级保留。
      2) 单条快照独立 JSON，PHP 端 json_decode 即可，不需要 schema 迁移。
      3) DB 写失败时静默（终端仍能看见日志，不影响主流程）。
    """
    SAFE_BYTES = 55 * 1024
    while True:
        try:
            now_mono = time.monotonic()

            # ── 活跃 worker 列表（按已耗时降序，便于看出谁卡住） ─────────
            workers = []
            for wid, st in list(worker_states.items()):
                workers.append({
                    'wid':   wid,
                    'db_id': st.get('db_id', 0),
                    'uid':   st.get('uid', ''),
                    'stage': st.get('stage', ''),
                    'detail': st.get('detail', ''),
                    'pro':   1 if st.get('is_proactive') else 0,
                    'ms':    int((now_mono - st.get('started_at', now_mono)) * 1000),
                    'stage_ms': int((now_mono - st.get('stage_started_at', now_mono)) * 1000),
                    # 阶段轨迹只上报名称与耗时；历史 detail 不在弹窗展示，去掉后
                    # 可避免高并发时 runtime_snapshot TEXT 被诊断信息撑满。
                    'history': [
                        {
                            'stage': item.get('stage', ''),
                            'ms': item.get('ms', 0),
                        }
                        for item in list(st.get('stage_history', []))[-8:]
                    ],
                })
            workers.sort(key=lambda w: -w['ms'])

            # ── 数据库连接池状态（aiomysql 暴露 size/freesize/maxsize） ──
            pool_size = getattr(pool, 'size', 0)
            pool_free = getattr(pool, 'freesize', 0)
            pool_max  = getattr(pool, 'maxsize', 0)

            # ── stdout 日志快照 ──────────────────────────────────────────
            with _runtime_log_lock:
                logs = list(runtime_logs)

            snapshot = {
                'ts':              time.time(),
                'shard_index':     SHARD_INDEX,
                'shard_total':     SHARD_TOTAL,
                'queue_size':      task_queue.qsize(),
                'active_workers':  active_workers,
                'total_workers':   global_worker_count,
                'pool_used':       pool_size - pool_free,
                'pool_size':       pool_size,
                'pool_max':        pool_max,
                'workers':         workers,
                'logs':            logs,
            }

            # 序列化 + 体积保护
            payload = json.dumps(snapshot, ensure_ascii=False, separators=(',', ':'))
            if len(payload.encode('utf-8')) > SAFE_BYTES:
                # 优先丢最老的日志
                while snapshot['logs'] and len(payload.encode('utf-8')) > SAFE_BYTES:
                    drop = max(1, len(snapshot['logs']) // 10)
                    snapshot['logs'] = snapshot['logs'][drop:]
                    payload = json.dumps(snapshot, ensure_ascii=False, separators=(',', ':'))
                # 还超 → 截 worker 列表
                while len(snapshot['workers']) > 50 and len(payload.encode('utf-8')) > SAFE_BYTES:
                    snapshot['workers'] = snapshot['workers'][:max(50, len(snapshot['workers'])-20)]
                    payload = json.dumps(snapshot, ensure_ascii=False, separators=(',', ':'))

            # v8.3 (2026-05-09):MySQL 8.0.20+ 警告 'VALUES function is deprecated'。
            # 改成最简的"两个 %s 参数"写法,跨所有 MySQL 版本都没问题。
            # 多进程改造:每个分片进程写自己独立的一行 runtime_snapshot_{N},
            #   admin 端按 SHARD_TOTAL 读取并合并展示。互不覆盖。
            _snap_key = f"runtime_snapshot_{SHARD_INDEX}"
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "INSERT INTO system_config (config_key, config_value, remark) "
                        "VALUES (%s, %s, '运行时快照·main.py 每秒写入·勿手动改') "
                        "ON DUPLICATE KEY UPDATE config_value=%s",
                        (_snap_key, payload, payload)
                    )
                await conn.commit()

        except Exception as _e:
            # 不写日志通道，避免循环（写日志→print→deque→writer→…）
            pass
        await asyncio.sleep(1)


async def main():
    global global_worker_count
    # ── 连接池配置（多进程分片版）──────────────────────────────────────────
    # 每个后端分片的数据库连接池固定上限 150。两分片部署时合计最多
    # 300 条后端连接，给 PHP-FPM 与管理任务保留 MySQL 连接余量。
    # minsize 在多分片时压到 2，避免各进程长期囤积 Sleep 空连接。
    if SHARD_TOTAL > 1:
        _pool_max = 150
        _pool_min = 2
    else:
        _pool_max = 150
        _pool_min = 10
    print(f"[分片] 本进程连接池: minsize={_pool_min} maxsize={_pool_max}", flush=True)
    pool = await aiomysql.create_pool(
        minsize=_pool_min,
        maxsize=_pool_max,
        pool_recycle=1800,           # 30min 主动重连，防 MySQL 这边超时关闭
        cursorclass=aiomysql.DictCursor,
        **DB_CONFIG
    )

    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute("SELECT config_value FROM system_config WHERE config_key='worker_threads'")
            row = await cur.fetchone()
            if row:
                try: global_worker_count = int(row['config_value'])
                except: pass

    # 多进程改造:system_config.worker_threads 是【全局】worker 总数,
    #   按分片数均分到每个进程。13 进程、总数 500 → 每进程 ~38 个 worker。
    #   每进程只带 ~230 个实例,38 个并发 worker 足够;不够 admin 调大总数即可。
    if SHARD_TOTAL > 1:
        global_worker_count = max(8, global_worker_count // SHARD_TOTAL)

    print("=======================================")
    print(f" Webchat ReAct 服务引擎启动 (本进程 Workers: {global_worker_count}"
          f" · SHARD {SHARD_INDEX}/{SHARD_TOTAL}) ...")
    print("=======================================")

    # 「让 Ta 更懂你」经期关怀模块就绪提示
    period_care.startup_banner()

    await utils.init_rsa_keys(pool)

    # ── 语音通话 WebSocket 服务 ────────────────────────────────────────────
    # 与本进程共享 pool, 不另起进程. nginx 把 /ws 反代到本进程内的端口 5000.
    # 启动失败 (例如缺 VOICE_WS_SECRET / DASHSCOPE_API_KEY) 只打日志, 不影响
    # 主消息引擎 — 微信 bot 业务跟语音通话相互独立.
    # 多进程改造:端口全局唯一,只能由主进程(SHARD_INDEX==0)启动,
    #   否则其余 12 个进程会抢绑同一端口导致启动失败。
    voice_ws_task = None
    if IS_PRIMARY_SHARD:
        try:
            from websocker import server as voice_ws_server
            voice_ws_task = asyncio.create_task(voice_ws_server.run(pool))
            print("[就绪] 语音通话 WebSocket 已挂入主循环 (data/websocker/server.py)", flush=True)
        except Exception as _e:
            print(f"[警告] 语音通话 WebSocket 启动失败 (主引擎继续): {type(_e).__name__}: {_e}", flush=True)
    else:
        print(f"[分片] 非主进程(SHARD_INDEX={SHARD_INDEX}),跳过语音 WebSocket 服务", flush=True)

    # 网页端对话服务 —— 复用 chat.generate_reply，不新增实例
    # 多进程改造:同样端口全局唯一,只由主进程启动。
    webchat_task = None
    if IS_PRIMARY_SHARD:
        try:
            import webchat_server
            webchat_task = asyncio.create_task(webchat_server.run(pool))
        except Exception as _e:
            print(f"[警告] 网页端对话服务启动失败 (主引擎继续): {type(_e).__name__}: {_e}", flush=True)
    else:
        print(f"[分片] 非主进程(SHARD_INDEX={SHARD_INDEX}),跳过网页端对话服务", flush=True)


    running_tasks = {}

    # ── v13 (2026-05-13) 启动清理:消除上次进程残留的"卡死"状态 ────────────
    #
    # 上次 main.py 进程如果被 kill -9 或崩溃,system_config.runtime_snapshot
    # 里残留的 workers 列表会被 admin 监控页继续显示成"卡了 N 分钟",直到
    # 1 秒后 runtime_snapshot_writer 跑第一轮才覆盖。这里在 worker 启动之前
    # 抢先把它写成空快照,admin 进监控页立即看到"所有 worker 空闲"。
    #
    # typing(正在输入)状态:发到微信侧的 HTTP 推送,不存在 DB 里。微信端
    # keepalive 是 5 秒,5 秒不续就消失。无法精确取消(没有 typing_ticket),
    # 但 5-10 秒会自然恢复,所以不在这里特别处理。
    # 多进程改造:每个进程清空自己那行 runtime_snapshot_{N}(启动残留)。
    try:
        empty_snapshot = json.dumps({
            'ts':              time.time(),
            'shard_index':     SHARD_INDEX,
            'shard_total':     SHARD_TOTAL,
            'queue_size':      0,
            'active_workers':  0,
            'total_workers':   global_worker_count,
            'pool_used':       0, 'pool_size': 0, 'pool_max': 0,
            'workers':         [],
            'logs':            [f'[启动] 分片 {SHARD_INDEX} 上次残留状态已清空,等待 worker 上线...'],
        }, ensure_ascii=False, separators=(',', ':'))
        _snap_key = f"runtime_snapshot_{SHARD_INDEX}"
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "INSERT INTO system_config (config_key, config_value, remark) "
                    "VALUES (%s, %s, '运行时快照·main.py 每秒写入·勿手动改') "
                    "ON DUPLICATE KEY UPDATE config_value=%s",
                    (_snap_key, empty_snapshot, empty_snapshot)
                )
            await conn.commit()
        print(f"[启动] 已清空 {_snap_key},admin 监控页将立即看到干净状态", flush=True)
    except Exception as _e:
        print(f"[启动] 清空 runtime_snapshot 失败(已忽略,1 秒后会被覆盖): {_e}", flush=True)

    for i in range(1, global_worker_count + 1):
        asyncio.create_task(message_worker(i, pool))
    print(f"[系统] {global_worker_count} 个 worker 已就绪,等待消息任务", flush=True)

    # ── 后台 task ──────────────────────────────────────────────────────
    # 多进程改造:
#   · system_monitor_task —— 写全局 load_value,只主进程跑(避免多进程互覆盖)。
    #   · runtime_snapshot_writer —— 每个进程都跑,各写自己的 runtime_snapshot_{N},
    #     这样 admin 才能看到全部分片的 worker。互不覆盖。
    #   · dynamic_mind_proactive_scanner_task / manual_push_worker —— 每个进程都跑:
    #     靠本进程 running_tasks 找 BotInstance,
    #     扫到不属于自己分片的实例会自动 continue 跳过,天然分片安全。
    if IS_PRIMARY_SHARD:
        asyncio.create_task(system_monitor_task(pool))
        print("[分片] 主进程:已启动全局监控(system_monitor / load_value)", flush=True)
    asyncio.create_task(runtime_snapshot_writer(pool))
    asyncio.create_task(dynamic_mind_proactive_scanner_task(pool, running_tasks))
    # 旧 proactive_schedules 扫描器不再启动：它会绕过心智状态，直接发送预生成内容。
    # 保留函数仅供回滚/数据迁移；自主消息的唯一入口是 dynamic_mind。
    asyncio.create_task(manual_push_worker(pool, running_tasks))  # v12.7
    asyncio.create_task(broadcast_worker(pool, running_tasks))  # 节日推送
    # QQ 机器人由主分片统一从 qq_bot_accounts 表加载，避免多个分片重复
    # 建立 Gateway 连接。QQ 入站会复用 chat.generate_reply，但不进入心潮主动队列。
    if IS_PRIMARY_SHARD:
        asyncio.create_task(
            qqbot_worker.QQBotManager(pool).run(),
            name="qqbot-database-manager",
        )
        print("[QQBot] 主分片已启动数据库连接管理器（仅 C2C 被动对话）", flush=True)

    # v8.3 (2026-05-09):启动期日志精简
    # 旧:每激活一个实例打一行 "[系统] 激活实例 N",N 个实例就 N 行刷屏
    # 新:首轮把所有现存实例一次性批量打,后续只在有"上 / 下"变化时打一行摘要
    _is_first_loop = True
    while True:
        try:
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    # v11 (2026-05-12) 多 SELECT 一个 updates_buf;老库无字段时降级
                    # 多进程分片(2026):只认领 id %% SHARD_TOTAL == SHARD_INDEX 的实例。
                    # SHARD_TOTAL==1 时 `id %% 1 == 0` 对所有实例成立 → 等价单进程。
                    try:
                        await cur.execute(
                            "SELECT id, status, updates_buf FROM instances "
                            "WHERE id %% %s = %s",
                            (SHARD_TOTAL, SHARD_INDEX),
                        )
                        instances = await cur.fetchall()
                    except Exception as _e:
                        if 'updates_buf' in str(_e):
                            await cur.execute(
                                "SELECT id, status FROM instances "
                                "WHERE id %% %s = %s",
                                (SHARD_TOTAL, SHARD_INDEX),
                            )
                            instances = await cur.fetchall()
                            # 给每行补一个空 updates_buf,后续 BotInstance.__init__ 可用
                            for inst in instances:
                                inst['updates_buf'] = ''
                        else:
                            raise

            active_ids = {inst['id'] for inst in instances if inst['status'] == '启动'}
            # v11 关键:把 updates_buf 一并传给 BotInstance,这样实例重启时游标接续
            inst_by_id = {inst['id']: inst for inst in instances}

            # 收集本轮新增 / 移除的实例
            added_ids   = []
            removed_ids = []
            zombie_ids  = []   # v12.15: 任务已死但残留在 running_tasks 字典里的实例

            # ═════════════════════════════════════════════════════════════════
            # v12.15 (2026-05-15) 任务健康检查
            # ─────────────────────────────────────────────────────────────────
            # 修复"日志莫名其妙消失,需要重新扫码才显示监听"的死寂 bug.
            # 根因: BotInstance.run_loop() 因网络断/微信踢/未处理异常等原因
            #       结束时, asyncio.Task 进入 done 态, 但
            #       running_tasks[inst_id] 这个 dict 还在.
            #       下面 `if inst_id not in running_tasks` 一直命中 → 永不
            #       重建 task → 实例死寂. 用户只能去前端"重置 + 重新扫码".
            # 修复: 每轮先扫一遍, 把 done() 的 task 清理掉 + 写库标 '异常',
            #       前端就能看到状态变红, 用户能立刻点重启, 自然进入扫码流程.
            #       后续的 `inst_id not in running_tasks` 也会自然命中, 但
            #       因为 status='异常' 不在 active_ids 里, 不会自动重启,
            #       避免 token 失效造成的反复扫码死循环.
            # ═════════════════════════════════════════════════════════════════
            for inst_id, info in list(running_tasks.items()):
                t = info.get("task")
                if t is None or not t.done():
                    continue
                # task 已退出, 收集原因留个日志
                exc_msg = None
                try:
                    exc = t.exception()
                    if exc is not None:
                        exc_msg = f"{type(exc).__name__}: {exc}"
                except asyncio.CancelledError:
                    exc_msg = "已取消(cancel)"
                except asyncio.InvalidStateError:
                    exc_msg = None
                # 收尾该 BotInstance
                try:
                    old_bot = info.get("bot")
                    if old_bot:
                        old_bot.is_running = False
                        if getattr(old_bot, 'msg_task', None) is not None:
                            old_bot.msg_task.cancel()
                except Exception:
                    pass
                # 写库标'异常' (跟扫码失败一致, 让前端可见)
                try:
                    async with pool.acquire() as conn:
                        async with conn.cursor() as cur:
                            await cur.execute(
                                "UPDATE instances SET status='异常', qr_code_url=NULL WHERE id=%s",
                                (inst_id,)
                            )
                        await conn.commit()
                except Exception as e_db:
                    print(f"[系统][实例 {inst_id}] 写入异常状态失败: {e_db}", flush=True)
                # 控制台留痕
                if exc_msg:
                    print(
                        f"[系统][实例 {inst_id}] BotInstance.run_loop 异常退出: {exc_msg[:200]}",
                        flush=True,
                    )
                else:
                    print(
                        f"[系统][实例 {inst_id}] BotInstance.run_loop 自然结束, 已标 '异常'",
                        flush=True,
                    )
                # 也写一条到 temp_log 让用户在控制台日志面板看见
                try:
                    await utils.add_temp_log(
                        pool, inst_id,
                        f"[系统] 实例消息监听已停止: {exc_msg or '自然结束'}; 已置 '异常' 状态, 请到控制台点重启"
                    )
                except Exception:
                    pass
                del running_tasks[inst_id]
                zombie_ids.append(inst_id)

            for inst_id in active_ids:
                if inst_id not in running_tasks:
                    db_row = inst_by_id.get(inst_id) or {'id': inst_id, 'updates_buf': ''}
                    bot  = BotInstance(db_row, pool)
                    task = asyncio.create_task(bot.run_loop())
                    running_tasks[inst_id] = {"task": task, "bot": bot}
                    added_ids.append(inst_id)

            for db_id in list(running_tasks.keys()):
                if db_id not in active_ids:
                    bot_to_stop = running_tasks[db_id]["bot"]
                    # v11:强制持久化 buf,确保后续重启不会重放消息
                    try:
                        await bot_to_stop._persist_updates_buf(force=True)
                    except Exception:
                        pass
                    bot_to_stop.is_running = False
                    if bot_to_stop.msg_task: bot_to_stop.msg_task.cancel()
                    running_tasks[db_id]["task"].cancel()
                    del running_tasks[db_id]
                    removed_ids.append(db_id)
                    async with pool.acquire() as conn:
                        async with conn.cursor() as cur:
                            await cur.execute("UPDATE proactive_schedules SET status=2 WHERE db_id=%s AND status=0", (db_id,))
                        await conn.commit()

            # 日志:只在事件发生时打一行摘要
            if _is_first_loop:
                print(f"[系统] 启动完成: {len(running_tasks)} 个实例上线", flush=True)
                _is_first_loop = False
            elif added_ids or removed_ids or zombie_ids:
                # 后续轮次有增减时一行摘要 (用户在 admin 启停实例时能看到)
                parts = []
                if added_ids:   parts.append(f"+{len(added_ids)} {added_ids[:3]}{'…' if len(added_ids) > 3 else ''}")
                if removed_ids: parts.append(f"-{len(removed_ids)} {removed_ids[:3]}{'…' if len(removed_ids) > 3 else ''}")
                if zombie_ids:  parts.append(f"☠{len(zombie_ids)} {zombie_ids[:3]}{'…' if len(zombie_ids) > 3 else ''}")
                print(f"[系统] 实例变化: {', '.join(parts)},现共 {len(running_tasks)} 个", flush=True)

        except asyncio.CancelledError:
            # 进程级取消（Ctrl+C）—— 干净退出
            break
        except Exception as _e:
            # 主循环异常要打,这是 bug 信号
            print(f"[系统] 主循环异常: {type(_e).__name__}: {_e}", flush=True)
        await asyncio.sleep(3)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
