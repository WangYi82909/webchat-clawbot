# data/websocker — 实时语音通话服务 (嵌入式)

跑在 `data/main.py` 的同一个进程内,共享 aiomysql pool,**不需要独立 screen 挂起**。
nginx 把 `wss://webchat.asia/ws` 反代到本服务监听的端口。

## 业务链

```
浏览器 PCM 16kHz
    ↓ WSS /ws?token=...
nginx (终结 SSL)
    ↓ ws://127.0.0.1:5000
data/websocker/server.py (Session)
    ↓ feed_audio
asr.py (qwen3-asr-flash-realtime)
    ↓ on_final
chat_bridge.respond()
    ↓
chat.generate_reply()   ← 用户的 model / persona / 计费 / 记忆全部继承
    ↓
tts.py (cosyvoice-v3.5-plus, voice = users.voice_ids[0])
    ↓ mp3 base64
浏览器 <audio autoplay>
```

## 环境变量(在启动 main.py 之前 export)

| 名称 | 必填 | 默认 | 说明 |
|---|---|---|---|
| `VOICE_WS_SECRET` | **是** | — | 与 A 端 `api_voice_call.php` 的 `VOICE_WS_SECRET` 完全一致 |
| `DASHSCOPE_API_KEY` | **是** | — | DashScope API key,ASR 和 TTS 都用 |
| `VOICE_WS_HOST` | | `127.0.0.1` | nginx 反代到这里 |
| `VOICE_WS_PORT` | | `5000` | |
| `VOICE_MAX_CONNECTIONS` | | `100` | 软上限 |
| `VOICE_IDLE_TIMEOUT` | | `120` | 秒,没消息就踢 |
| `VOICE_SERVER_NAME` | | `voice-prod-01` | 给日志/前端展示 |
| `VOICE_ASR_MODEL` | | `qwen3-asr-flash-realtime` | |
| `VOICE_TTS_MODEL` | | `cosyvoice-v3.5-plus` | 必须 plus,因为用户音色用 plus 克隆 |

## 启动

```bash
export VOICE_WS_SECRET='64位hex,跟api_voice_call.php那个完全一样'
export DASHSCOPE_API_KEY='sk-xxx'
# DB 配置 main.py 自己有, 不用重复 export

cd /项目根目录/data
python3 main.py
```

启动成功的日志:
```
[就绪] 语音通话 WebSocket 已挂入主循环 (data/websocker/server.py)
voice_ws listening on 127.0.0.1:5000 (server_name=voice-prod-01)
```

启动失败(缺 VOICE_WS_SECRET / DASHSCOPE_API_KEY)只会打一行警告,**主消息引擎照常工作**:
```
[警告] 语音通话 WebSocket 启动失败 (主引擎继续): RuntimeError: 配置缺失:
  - VOICE_WS_SECRET (与 A 端 api_voice_call.php 一致)
```

## nginx (已配置过的话跳过)

```nginx
location /ws {
    proxy_pass http://127.0.0.1:5000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_read_timeout 600s;
    proxy_buffering off;
}
```

## 用户的音色 ID 是怎么来的

- 用户在 console.php → 实验性功能 → 语音克隆,上传一段 ≤ 20s 的语音
- `api_voice.php` 调 dashscope 克隆,把 `voice_id` 写入 `users.voice_ids`(JSON 数组)
- `MAX_VOICES_PER_USER=1`,所以一人一个音色
- 语音通话时,`auth.py` 从 `users.voice_ids` 取第一个作为 TTS 音色
- 用户**没克隆音色就建连**:`auth.authenticate` 抛 `AuthError("请先在「实验性功能」中克隆你的专属音色")`,WS close 1008

## chat.py 怎么被复用

- 每个用户在第一次进入语音通话页时,`chat_bridge.get_or_create_voice_instance` 会:
  - 检查 `instances` 表里有没有 `user_id=uid AND deploy_type='voice'` 的记录
  - 没有就建一条,复制该用户最近一个微信实例的 `model / persona_id / 三大采样参数`
- 该 instance 的 `status='voice'`,`main.py` 主循环只看 `deploy_type='custom'`,**不会误调长轮询逻辑**
- 调用 `chat.generate_reply(pool, voice_bot, uid, text)`,完整走计费、配额、节流、RAG、记忆
- 语音对话历史也会被 `_embed_and_save_turn` 写库,与微信对话历史在不同 instance 下隔离

## 协议(WS 消息格式)

**下行**(服务端 → 浏览器,全部 JSON):

| type | 字段 | 时机 |
|---|---|---|
| `ready` | `session_id`, `user`, `voice_id`, `server_name` | 鉴权通过,ASR 已就绪 |
| `auth_failed` | `message` | 鉴权失败,紧接 close 1008 |
| `speech_started` | — | ASR 检测到语音 |
| `speech_stopped` | — | ASR 检测到静音 |
| `partial` | `text` | 实时识别中间结果 |
| `final` | `text` | 一句话识别完成 |
| `thinking` | — | 已交给 chat 引擎 |
| `reply` | `text` | chat 返回了文本 |
| `synthesizing` | — | 开始合成 |
| `tts_audio` | `text`, `audio` (base64 mp3) | 合成完成,浏览器自动播放 |
| `tts_error` | `message` | TTS 失败 |
| `error` | `message` | 通用错误 |
| `log` | `level`, `message` | 实时日志,前端"事件日志"展示 |
| `pong` | `ts` | 响应 ping |

**上行**(浏览器 → 服务端):
- 二进制 = PCM 16kHz mono 16bit 帧
- 文本 = JSON 控制指令,目前支持 `{"type":"ping"}` / `{"type":"stop"}`

## 已知约束(待第二波前端改造完接上)

- 前端 voice_call.php 当前还是占位,**不录音**。第二波会改造前端真正采集 PCM
- 还没接 `console.php` 的"进入语音通话页"入口校验音色已克隆 — 现在 `auth.authenticate` 已经会拦,前端友好提示在第二波加
- 语音对话的事件日志在浏览器实时展示(`log` 消息),但 admin 后台暂未集成,如需可加查询
