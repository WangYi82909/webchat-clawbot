"""ASYNC GPT-compatible image generation followed by Weixin image delivery."""
from __future__ import annotations

import base64
import json
import urllib.parse

import httpx

import utils
import weixin_media


NAME = "generate_image"
DESCRIPTION = (
    "异步生成并自动发送图片。当用户明确要求画图，或当前语境确实适合分享照片时调用。"
    "prompt 应根据人设扩写出主体、动作、场景、光线和画风；同一轮必须输出非空文字。"
)
PARAMETERS = {
    "type": "object",
    "properties": {
        "prompt": {
            "type": "string",
            "description": "扩写后的生图提示词，建议约 100 字并包含具体画面细节。",
            "minLength": 1,
            "maxLength": 2000,
        }
    },
    "required": ["prompt"],
    "additionalProperties": False,
}
USAGE = '{"prompt": "扩写后的生图提示词，约100字，包含画面细节"}'
MODE = "ASYNC"


def _image_endpoint(raw_endpoint: str, *, edit: bool) -> str:
    endpoint = (raw_endpoint or "").strip()
    if not endpoint:
        endpoint = "https://api.openlux.ai/v1"
    parsed = urllib.parse.urlsplit(endpoint)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError("img_gen_endpoint 必须是有效的 HTTP(S) 地址")
    path = parsed.path.rstrip("/")
    for suffix in ("/images/generations", "/images/edits", "/images"):
        if path.endswith(suffix):
            path = path[: -len(suffix)]
            break
    if not path.endswith("/v1"):
        path += "/v1"
    path += "/images/edits" if edit else "/images/generations"
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, path, "", ""))


def _decode_figure_image(value: str) -> tuple[bytes, str, str]:
    if not isinstance(value, str) or "," not in value:
        raise ValueError("人物形象图不是有效的 data URL")
    header, encoded = value.split(",", 1)
    if not header.startswith("data:image/") or ";base64" not in header.lower():
        raise ValueError("人物形象图必须是 Base64 图片 data URL")
    mime = header[5:].split(";", 1)[0].lower()
    try:
        data = base64.b64decode(encoded, validate=True)
    except Exception as exc:
        raise ValueError("人物形象图 Base64 数据损坏") from exc
    ext = weixin_media.validate_image_bytes(data, label="人物形象图").lstrip(".")
    return data, mime, ext


async def _extract_generated_image(
    client: httpx.AsyncClient,
    response: httpx.Response,
) -> bytes:
    if not 200 <= response.status_code < 300:
        raise RuntimeError(
            f"生图接口 HTTP {response.status_code}: {(response.text or '')[:240]}"
        )
    try:
        payload = response.json()
    except Exception as exc:
        raise RuntimeError(f"生图接口返回非法 JSON: {(response.text or '')[:160]}") from exc
    items = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(items, list) or not items or not isinstance(items[0], dict):
        raise RuntimeError(
            "生图接口没有返回 data[0]: "
            + json.dumps(payload, ensure_ascii=False)[:240]
        )
    item = items[0]
    encoded = item.get("b64_json")
    if isinstance(encoded, str) and encoded:
        try:
            image_bytes = base64.b64decode(encoded, validate=True)
        except Exception as exc:
            raise RuntimeError("生图接口返回的 b64_json 已损坏") from exc
    else:
        image_url = item.get("url")
        if not isinstance(image_url, str) or not image_url:
            raise RuntimeError("生图接口既未返回 b64_json，也未返回图片 URL")
        if image_url.lower().startswith("data:image/"):
            try:
                meta, encoded_url = image_url.split(",", 1)
                if ";base64" not in meta.lower():
                    raise ValueError("不是 base64 data URL")
                image_bytes = base64.b64decode(encoded_url, validate=True)
            except Exception as exc:
                raise RuntimeError("生图接口返回的图片 data URL 已损坏") from exc
            weixin_media.validate_image_bytes(image_bytes, label="生成图片")
            return image_bytes
        parsed = urllib.parse.urlsplit(image_url)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            raise RuntimeError("生图接口返回了无效图片 URL")
        image_response = await client.get(image_url, follow_redirects=True)
        if not 200 <= image_response.status_code < 300:
            raise RuntimeError(f"下载生成图片失败，HTTP {image_response.status_code}")
        content_length = image_response.headers.get("content-length")
        if content_length and int(content_length) > weixin_media.MAX_IMAGE_BYTES:
            raise RuntimeError("生成图片超过 25MB 上限")
        image_bytes = image_response.content
    weixin_media.validate_image_bytes(image_bytes, label="生成图片")
    return image_bytes


async def _notify_failure(pool, db_id: int, uid: str, token: str, text: str, context: str) -> None:
    try:
        async with httpx.AsyncClient() as client:
            await weixin_media.send_text(
                client, token, uid, text, context_token=context
            )
    except Exception as exc:
        await utils.add_temp_log(
            pool, db_id, f"[生图] 失败提示也未能送达: {str(exc)[:100]}"
        )


async def _refund(pool, db_id: int, user_id: int, price: float) -> bool:
    if price <= 0:
        return True
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "UPDATE users SET balance=balance+%s WHERE id=%s",
                    (price, user_id),
                )
            await conn.commit()
        await utils.add_temp_log(pool, db_id, f"[生图] 失败，已退还 ¥{price:g}")
        return True
    except Exception as exc:
        await utils.add_temp_log(
            pool, db_id, f"[生图] 退款失败，请人工处理: {str(exc)[:100]}"
        )
        return False


async def run(params: dict, pool, db_id, uid, bot_instance) -> dict:
    prompt_value = params.get("prompt") if isinstance(params, dict) else None
    if not isinstance(prompt_value, str) or not prompt_value.strip():
        return {"success": False, "message": "未提供有效的 prompt 参数。"}
    prompt = prompt_value.strip()[:2000]
    context_token = str(params.get("_context_token") or "")
    if not context_token:
        context_token = await weixin_media.latest_context_token(pool, db_id, uid)

    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT config_key, config_value FROM system_config WHERE config_key IN "
                "('img_gen_price','img_gen_endpoint','img_gen_key','img_gen_model')"
            )
            config = {r["config_key"]: r["config_value"] for r in await cur.fetchall()}
            await cur.execute(
                "SELECT user_id, wx_token, persona_id FROM instances WHERE id=%s",
                (db_id,),
            )
            instance = await cur.fetchone()
    if not instance or not instance.get("wx_token"):
        return {"success": False, "message": "无法获取当前机器人的微信 Token。"}
    bot_token = utils.decrypt_data(instance["wx_token"])
    if not bot_token:
        return {"success": False, "message": "当前机器人的微信 Token 解密失败。"}
    user_id = int(instance["user_id"])

    try:
        price = max(0.0, float(config.get("img_gen_price") or 0.5))
    except (TypeError, ValueError):
        await _notify_failure(pool, db_id, uid, bot_token, "图片生成配置有误，请稍后再试", context_token)
        return {"success": False, "message": "img_gen_price 配置不是有效数字。"}
    api_key = str(config.get("img_gen_key") or "").strip()
    model = str(config.get("img_gen_model") or "gpt-image-2").strip()
    if not api_key or not model:
        await _notify_failure(pool, db_id, uid, bot_token, "图片生成功能暂未配置好，请稍后再试", context_token)
        return {"success": False, "message": "缺少 img_gen_key 或 img_gen_model。"}

    figure_image = None
    persona_id = instance.get("persona_id")
    if persona_id:
        try:
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT figure_image FROM user_personas WHERE id=%s AND user_id=%s",
                        (persona_id, user_id),
                    )
                    row = await cur.fetchone()
            figure_image = (row or {}).get("figure_image") or None
        except Exception as exc:
            await utils.add_temp_log(
                pool, db_id, f"[生图] 人物形象读取失败，改用文生图: {str(exc)[:80]}"
            )

    try:
        endpoint = _image_endpoint(
            str(config.get("img_gen_endpoint") or ""), edit=bool(figure_image)
        )
    except ValueError as exc:
        await _notify_failure(pool, db_id, uid, bot_token, "图片生成配置有误，请稍后再试", context_token)
        return {"success": False, "message": str(exc)}

    charged = False
    if price > 0:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                affected = await cur.execute(
                    "UPDATE users SET balance=balance-%s "
                    "WHERE id=%s AND balance >= %s",
                    (price, user_id, price),
                )
            await conn.commit()
        if not affected:
            await _notify_failure(
                pool, db_id, uid, bot_token,
                f"余额不足，生成图片需要 ¥{price:g}，请充值后再试",
                context_token,
            )
            return {"success": False, "message": f"余额不足，生图需要 ¥{price:g}。"}
        charged = True

    mode_label = "人物参考图" if figure_image else "文生图"
    await utils.add_temp_log(pool, db_id, f"[生图] 开始生成（{mode_label}）")
    try:
        actual_prompt = prompt
        async with httpx.AsyncClient(timeout=600.0) as client:
            headers = {"Authorization": f"Bearer {api_key}"}
            if figure_image:
                figure_bytes, mime, ext = _decode_figure_image(figure_image)
                actual_prompt = (
                    f"请让参考人物实现以下画面：{prompt}。必须保持人物主体、面部特征和"
                    "原画风一致，其余场景可自然发挥。"
                )
                response = await client.post(
                    endpoint,
                    files={"image": (f"figure.{ext}", figure_bytes, mime)},
                    data={"model": model, "prompt": actual_prompt, "n": "1", "size": "1024x1024"},
                    headers=headers,
                )
            else:
                response = await client.post(
                    endpoint,
                    json={"model": model, "prompt": actual_prompt, "n": 1, "size": "1024x1024"},
                    headers={**headers, "Content-Type": "application/json"},
                )
            image_bytes = await _extract_generated_image(client, response)
            await weixin_media.upload_and_send_image(
                client, bot_token, uid, image_bytes, context_token=context_token
            )
        await utils.add_temp_log(pool, db_id, "[生图] 图片已发送")
        return {"success": True, "message": "图片已生成并发送。"}
    except Exception as exc:
        error = str(exc)[:180]
        refunded = await _refund(pool, db_id, user_id, price) if charged else True
        suffix = "，费用已退回" if charged and refunded else ""
        await _notify_failure(
            pool, db_id, uid, bot_token, f"图片发送失败了{suffix}，请稍后再试", context_token
        )
        await utils.add_temp_log(pool, db_id, f"[生图] 失败: {error}")
        return {"success": False, "message": error}
