# -*- coding: utf-8 -*-
"""
眼科屈光状态评估程序
计算依据（权威来源）：
  · SE 公式 / 近视分级 / 近视前驱期：国家卫健委《近视防治指南（2024年版）》
  · 远视储备年龄下限：2022《近视管理白皮书》
  · 屈光参差（球镜≥1.50D 或 柱镜≥1.00D）：全国儿童弱视斜视防治学组(1985)、
    国家卫健委《弱视诊治指南》、《中国儿童弱视防治专家共识(2021)》
  · 远视分级为教科书惯例（国家指南未给远视分级）
"""

import unicodedata
from datetime import date
from typing import Any, Dict, Optional

ASTIGMATISM_THRESHOLD = 0.12
AXIS_MIN, AXIS_MAX = 1, 180

MYOPIA_HIGH_EDGE = -6.00
MYOPIA_MOD_EDGE = -3.00
MYOPIA_LOW_EDGE = -0.50
HYPEROPIA_LOW_EDGE = 3.00
HYPEROPIA_MOD_EDGE = 5.00

ANISO_RISK_EDGE = 1.50
ANISO_SEVERE_EDGE = 2.50
ANISO_CYL_EDGE = 1.00

# 远视储备年龄下限（D），来源 2022《近视管理白皮书》
RESERVE_LIMITS = ((6, 0.75, "≤6岁"), (8, 0.50, "7–8岁"), (10, 0.25, "9–10岁"))


class RefractionInputError(ValueError):
    pass


def _is_number(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _validate_eye(eye: Any) -> None:
    if not isinstance(eye, dict):
        raise RefractionInputError("无效输入")
    s, c = eye.get("sphere"), eye.get("cylinder")
    if not _is_number(s) or not _is_number(c):
        raise RefractionInputError("无效输入")
    if abs(c) > ASTIGMATISM_THRESHOLD:
        a = eye.get("axis")
        if not _is_number(a) or float(a) != int(a):
            raise RefractionInputError("无效输入")
        if not (AXIS_MIN <= a <= AXIS_MAX):
            raise RefractionInputError("轴位超出范围（1~180°）")


def spherical_equivalent(s: float, c: float) -> float:
    """等效球镜 SE = 球镜 + 1/2 柱镜（《近视防治指南2024》）。"""
    return s + c / 2.0


def classify_refraction(se: float) -> str:
    """按 SE 分级；近视侧边界归更严重一侧，与《近视防治指南2024》一致。"""
    if se <= MYOPIA_HIGH_EDGE:
        return "高度近视"
    if se <= MYOPIA_MOD_EDGE:
        return "中度近视"
    if se <= MYOPIA_LOW_EDGE:
        return "低度近视"
    if se < 0.50:
        return "正视眼"
    if se < HYPEROPIA_LOW_EDGE:
        return "低度远视"
    if se < HYPEROPIA_MOD_EDGE:
        return "中度远视"
    return "高度远视"


def evaluate_astigmatism(c: float, axis: Optional[float]) -> Dict[str, Any]:
    if abs(c) > ASTIGMATISM_THRESHOLD:
        return {"present": True, "cylinder": c, "axis": int(axis)}
    return {"present": False, "cylinder": 0.0, "axis": None}


def evaluate_anisometropia(se_r: float, se_l: float, c_r: float, c_l: float) -> Dict[str, Any]:
    """SE 差分档；并对柱镜差做 ≥1.00D 的并列判定（权威标准要求球镜、柱镜分别判）。"""
    se_diff = abs(se_r - se_l)
    cyl_diff = abs(c_r - c_l)
    if se_diff < ANISO_RISK_EDGE:
        level = "正常范围"
    elif se_diff < ANISO_SEVERE_EDGE:
        level = "较大差异，建议检查双眼视功能"
    else:
        level = "重度屈光参差，可能融像困难或弱视风险，建议专科就诊"
    return {"se_diff": se_diff, "cyl_diff": cyl_diff, "level": level,
            "cyl_significant": cyl_diff >= ANISO_CYL_EDGE}


def evaluate_reserve(age: Optional[float], se: float) -> Optional[Dict[str, str]]:
    """按年龄评估远视储备/近视前驱期；下限取 2022《近视管理白皮书》。"""
    if age is None:
        return None
    if age >= 18:
        txt = "成人，远视储备评估不适用"
        if age >= 40:
            txt += "；≥40岁注意老视"
        return {"text": txt}
    if se <= MYOPIA_LOW_EDGE:
        return {"text": "已发生近视，远视储备已耗尽"}
    for upper, limit, band in RESERVE_LIMITS:
        if age <= upper:
            if se < limit:
                return {"text": f"远视储备 {se:+.2f}D，低于{band}下限({limit:+.2f}D) → 不足，提示近视前驱期(高危)"}
            txt = f"远视储备 {se:+.2f}D，达{band}下限({limit:+.2f}D) → 在参考范围"
            if se > HYPEROPIA_LOW_EDGE:
                txt += "；远视偏高，警惕弱视/调节性内斜视"
            return {"text": txt}
    return {"text": f"远视储备 {se:+.2f}D（11岁以上趋于正视，无统一下限参考，建议结合眼轴/屈光发育档案）"}


def _dwidth(s: str) -> int:
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in s)


def _cell(text: str, width: int, align: str) -> str:
    pad = max(0, width - _dwidth(text))
    return (" " * pad + text) if align == "r" else (text + " " * pad)


def _row(cells) -> str:
    return "".join(_cell(t, w, a) for t, w, a in cells)


def _center(s: str, width: int) -> str:
    return " " * max(0, (width - _dwidth(s)) // 2) + s


def _ast_text(ast: Dict[str, Any], c: float) -> str:
    return f"有散光 ({c:+.2f}D @ {ast['axis']}°)" if ast["present"] else "无临床意义散光"


def _build_slip(name: str, age, right: Dict[str, Any], left: Dict[str, Any]) -> str:
    se_r = spherical_equivalent(right["sphere"], right["cylinder"])
    se_l = spherical_equivalent(left["sphere"], left["cylinder"])
    ast_r = evaluate_astigmatism(right["cylinder"], right.get("axis"))
    ast_l = evaluate_astigmatism(left["cylinder"], left.get("axis"))
    aniso = evaluate_anisometropia(se_r, se_l, right["cylinder"], left["cylinder"])
    res_r, res_l = evaluate_reserve(age, se_r), evaluate_reserve(age, se_l)

    eq, dash, W = "=" * 60, "-" * 60, (12, 10, 10, 9, 14)

    def crow(label, eye, se, ast):
        cyl = f"{eye['cylinder']:+.2f}" if ast["present"] else "0.00"
        ax = str(ast["axis"]) if ast["present"] else "—"
        return _row([(label, W[0], "l"), (f"{eye['sphere']:+.2f}", W[1], "r"),
                     (cyl, W[2], "r"), (ax, W[3], "r"), (f"{se:+.3f} D", W[4], "r")])

    lines = [eq, _center("屈光状态评估报告单", 60), eq,
             f"姓名：{name}    年龄：{age} 岁    检查日期：{date.today().isoformat()}", dash,
             _row([("项目", W[0], "l"), ("球镜(DS)", W[1], "r"), ("柱镜(DC)", W[2], "r"),
                   ("轴位(°)", W[3], "r"), ("等效球镜(SE)", W[4], "r")]),
             crow("右眼(OD)", right, se_r, ast_r),
             crow("左眼(OS)", left, se_l, ast_l), dash,
             "【屈光状态】",
             f"  右眼(OD)：{classify_refraction(se_r)}；{_ast_text(ast_r, right['cylinder'])}",
             f"  左眼(OS)：{classify_refraction(se_l)}；{_ast_text(ast_l, left['cylinder'])}", ""]

    if res_r is not None:
        lines += ["【远视储备评估】", f"  右眼(OD)：{res_r['text']}",
                  f"  左眼(OS)：{res_l['text']}", ""]

    lines += ["【屈光参差评估】",
              f"  双眼 SE 差值：{aniso['se_diff']:.3f} D —— {aniso['level']}"]
    if aniso["cyl_significant"]:
        lines.append(f"  双眼柱镜差值：{aniso['cyl_diff']:.2f} D（≥1.00D）—— 提示散光性屈光参差")

    lines += [dash, "说明：",
              "  · SE=球镜+1/2柱镜；近视分级及近视前驱期判定依据《近视防治指南(2024年版)》",
              "  · 远视储备下限参考2022《近视管理白皮书》，须以睫状肌麻痹(散瞳)验光结果为准",
              "  · 屈光参差依据全国儿童弱视斜视防治学组(1985)/《弱视诊治指南》",
              "  · 远视分级为教科书惯例；本报告为筛查辅助，不替代专业医师诊断", eq]
    return "\n".join(lines)


def assess(data: Dict[str, Any]) -> str:
    """主入口：输入含 name/age/right_eye/left_eye 的字典，返回报告单或错误提示。"""
    try:
        if not isinstance(data, dict):
            raise RefractionInputError("无效输入")
        name, age = data.get("name"), data.get("age")
        if not isinstance(name, str) or not name.strip():
            raise RefractionInputError("无效输入")
        if not _is_number(age) or age < 0:
            raise RefractionInputError("无效输入")
        if "right_eye" not in data or "left_eye" not in data:
            raise RefractionInputError("无效输入")
        _validate_eye(data["right_eye"])
        _validate_eye(data["left_eye"])
    except RefractionInputError as exc:
        return str(exc)
    age_disp = int(age) if float(age).is_integer() else age
    return _build_slip(name.strip(), age_disp, data["right_eye"], data["left_eye"])


def _ask_number(prompt, valid=lambda v: True, err="输入无效"):
    while True:
        try:
            v = float(input(prompt).strip())
        except ValueError:
            print(f"  {err}，请重新输入。")
            continue
        if not valid(v):
            print(f"  {err}，请重新输入。")
            continue
        return v


def _ask_eye():
    s = _ask_number("  球镜(D)，如 -3.00：")
    c = _ask_number("  柱镜(D)，如 -0.75，无散光填 0：")
    axis = None
    if abs(c) > ASTIGMATISM_THRESHOLD:
        axis = int(_ask_number("  轴位(°，1~180整数)：",
                               lambda v: AXIS_MIN <= v <= AXIS_MAX and float(v).is_integer(),
                               "轴位需为1~180的整数"))
    return {"sphere": s, "cylinder": c, "axis": axis}


def run_interactive():
    print("=== 屈光状态评估 · 数据录入 ===")
    name = ""
    while not name:
        name = input("请输入患者姓名：").strip()
        if not name:
            print("  姓名不能为空，请重新输入。")
    age = _ask_number("请输入患者年龄(岁)：", lambda v: v >= 0, "年龄需为非负数")
    print("-- 右眼(OD) --")
    right = _ask_eye()
    print("-- 左眼(OS) --")
    left = _ask_eye()
    print()
    print(assess({"name": name, "age": age, "right_eye": right, "left_eye": left}))


if __name__ == "__main__":
    run_interactive()