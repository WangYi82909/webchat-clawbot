import inspect
import json
import asyncio
import unittest

import chat


class _Response:
    def __init__(self, status_code, body):
        self.status_code = status_code
        self._body = body
        self.text = body if isinstance(body, str) else json.dumps(body)
        self.headers = {}

    def json(self):
        if isinstance(self._body, str):
            raise ValueError("invalid json")
        return self._body


class _Client:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = 0

    async def post(self, *_args, **_kwargs):
        self.calls += 1
        return self.responses.pop(0)


class _UtilsLogPatch:
    def __enter__(self):
        self.original = chat.utils.add_temp_log

        async def _noop(*_args, **_kwargs):
            return None

        chat.utils.add_temp_log = _noop
        return self

    def __exit__(self, *_args):
        chat.utils.add_temp_log = self.original


class LlmRetryPolicyTests(unittest.IsolatedAsyncioTestCase):
    async def test_http_error_is_never_retried(self):
        client = _Client([
            _Response(429, {"error": {"message": "busy"}}),
            _Response(200, {"choices": [{"message": {"content": "{}"}}]}),
        ])
        with _UtilsLogPatch():
            result = await chat._call_llm_with_format_retry(
                client, "https://example.invalid/v1", {}, {}, None, 1, "测试"
            )
        self.assertIsNone(result)
        self.assertEqual(client.calls, 1)

    async def test_invalid_json_retries_exactly_once(self):
        client = _Client([
            _Response(200, "not-json"),
            _Response(200, {"choices": [{"message": {"content": "{}"}}]}),
        ])
        with _UtilsLogPatch():
            result = await chat._call_llm_with_format_retry(
                client, "https://example.invalid/v1", {}, {}, None, 1, "测试"
            )
        self.assertIsNotNone(result)
        self.assertEqual(client.calls, 2)
        self.assertTrue(result["_format_retry_used"])

    async def test_http_200_error_envelope_is_not_retried(self):
        client = _Client([
            _Response(200, {"error": {"message": "invalid request"}}),
            _Response(200, {"choices": [{"message": {"content": "{}"}}]}),
        ])
        with _UtilsLogPatch():
            result = await chat._call_llm_with_format_retry(
                client, "https://example.invalid/v1", {}, {}, None, 1, "测试"
            )
        self.assertIsNone(result)
        self.assertEqual(client.calls, 1)

    async def test_response_deadline_retries_at_most_three_requests(self):
        class _SlowClient:
            def __init__(self):
                self.calls = 0

            async def post(self, *_args, **_kwargs):
                self.calls += 1
                await asyncio.sleep(0.05)
                return _Response(
                    200, {"choices": [{"message": {"content": "{}"}}]}
                )

        client = _SlowClient()
        old_deadline = chat.LLM_RESPONSE_TIMEOUT_SECONDS
        chat.LLM_RESPONSE_TIMEOUT_SECONDS = 0.005
        try:
            with _UtilsLogPatch():
                result = await chat._call_llm_with_format_retry(
                    client, "https://example.invalid/v1", {}, {},
                    None, 1, "测试", protocol="openai",
                )
        finally:
            chat.LLM_RESPONSE_TIMEOUT_SECONDS = old_deadline
        self.assertIsNone(result)
        self.assertEqual(client.calls, 3)

    def test_no_legacy_retry_or_pending_arguments(self):
        signature = inspect.signature(chat.generate_reply)
        self.assertNotIn("_retry_meta", signature.parameters)
        source = inspect.getsource(chat._call_llm_with_format_retry)
        self.assertNotIn("asyncio.sleep", source)

    def test_shared_client_has_long_read_timeout(self):
        client = chat.get_http_client()
        self.assertEqual(client.timeout.connect, 120.0)
        self.assertEqual(client.timeout.read, 600.0)
        self.assertEqual(client.timeout.write, 600.0)
        self.assertEqual(client.timeout.pool, 120.0)

    def test_gemini_has_cross_process_concurrency_cap(self):
        self.assertGreaterEqual(chat.GEMINI_GLOBAL_CONCURRENCY, 16)
        self.assertEqual(
            chat._DEFAULT_GEMINI_GLOBAL_CONCURRENCY,
            max(16, (chat.os.cpu_count() or 8) * 2),
        )
        source = inspect.getsource(chat._call_llm_with_format_retry)
        self.assertIn("_gemini_request_slot", source)

    async def test_gemini_gate_limits_parallel_requests(self):
        class _ConcurrentClient:
            timeout = type(
                "Timeout", (), {
                    "connect": 120.0, "read": 600.0,
                    "write": 600.0, "pool": 120.0,
                }
            )()

            def __init__(self):
                self.active = 0
                self.maximum = 0

            async def post(self, *_args, **_kwargs):
                self.active += 1
                self.maximum = max(self.maximum, self.active)
                await asyncio.sleep(0.03)
                self.active -= 1
                return _Response(
                    200, {"candidates": [{
                        "content": {"role": "model", "parts": [{"text": "{}"}]}
                    }]}
                )

        client = _ConcurrentClient()
        old_fcntl = chat._fcntl
        old_semaphore = chat._GEMINI_LOCAL_SEMAPHORE
        chat._fcntl = None
        chat._GEMINI_LOCAL_SEMAPHORE = asyncio.Semaphore(1)
        try:
            with _UtilsLogPatch():
                await asyncio.gather(*(
                    chat._call_llm_with_format_retry(
                        client, "https://example.invalid/v1beta", {}, {},
                        None, index, "测试", protocol="gemini",
                    )
                    for index in (1, 2)
                ))
        finally:
            chat._fcntl = old_fcntl
            chat._GEMINI_LOCAL_SEMAPHORE = old_semaphore
        self.assertEqual(client.maximum, 1)

    async def test_runtime_stage_callback_receives_llm_phases(self):
        events = []
        token = chat._RUNTIME_STAGE_CALLBACK.set(
            lambda stage, detail="": events.append((stage, detail))
        )
        client = _Client([
            _Response(200, {"choices": [{"message": {"content": "{}"}}]}),
        ])
        try:
            with _UtilsLogPatch():
                result = await chat._call_llm_with_format_retry(
                    client, "https://example.invalid/v1", {}, {},
                    None, 1, "第1轮", protocol="openai",
                )
        finally:
            chat._RUNTIME_STAGE_CALLBACK.reset(token)
        self.assertIsNotNone(result)
        self.assertIn("llm_request", [stage for stage, _ in events])
        self.assertIn("llm_response_parse", [stage for stage, _ in events])
