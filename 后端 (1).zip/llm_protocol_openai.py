"""
================================================================================
data/llm_protocol_openai.py · OpenAI 通用协议适配器
================================================================================
2026-07-23  v22 通用 Chat Completions 协议保持 reasoning_effort="high"
2026-05-27  v18 思维链字段按模型 ID 前缀分发(被 v19 替代)
2026-05-08  v17

【职责】
把"如何构造发往 LLM 的请求 + 如何解析响应 + 如何在多轮工具循环中正确回放
assistant 消息"的全部协议细节,从 chat.py 抽离到本文件。chat.py 只负责
业务流程编排(rag、计费、节流、工具调度、长记忆),不再关心协议层细节。

【为什么独立成文件】
  1. chat.py 已经接近 2200 行,继续堆协议细节读不下去。
  2. 后续要支持 Gemini / Anthropic 协议(payload 字段名、思维链字段、
     tool 调用格式都不一样),按 model_pricing.protocol 字段动态分发。
  3. 协议的"幂等纯函数"性质很强,独立文件后单测、灰度都更容易。

【后续规划(本文件目前不实现)】
  - data/llm_protocol_gemini.py     ← Google 原生 generateContent 协议
  - data/llm_protocol_anthropic.py  ← Anthropic Messages API 协议
  三个文件提供同名公开接口(resolve_endpoint / build_payload /
  extract_reasoning / assistant_message_for_replay),chat.py 通过
  protocol 字段选用其中之一。

【性能】
  本文件全是同步纯函数,无 IO、无锁、无外部依赖,执行成本可忽略。
  resolve_endpoint 在每个请求都会调一次,经测算 < 1μs。

【公开接口】(chat.py 通过这些函数与协议层交互)
  resolve_endpoint(model_endpoint, platform_endpoint)
      返回最终 chat 端点 URL(自动补全 /v1 → /v1/chat/completions)。

  supports_thinking_by_prefix(model)
      DB 字段缺失时的前缀白名单兜底,返回 bool。

  build_payload(model, messages, ..., supports_thinking=None)
      构造请求体 dict。supports_thinking=None 时自动回退前缀白名单。

  extract_reasoning(resp_json)
      从模型响应中提取思维链文本(支持 4 种字段名 + 嵌套结构)。

  assistant_message_for_replay(message)
      ⭐ 关键:把响应里的 assistant message 转成 messages 列表里的回放格式。
      保留思维链字段,避免下一轮请求时被丢。
      修复 bug: "The `reasoning_content` in the thinking mode must be
      passed back to the API." (Anthropic / DeepSeek 思考模式强制要求)
================================================================================
"""
from __future__ import annotations
from typing import Any


def is_explicit_native_vision_model(model: str) -> bool:
    """OpenAI 兼容协议下，模型 ID 任意位置含 gemini 即支持 image_url。"""
    return "gemini" in (model or "").strip().lower()


# ── 思维链兜底前缀白名单(model_pricing.supports_thinking 为 NULL 时使用) ──
# 与 migrate_v7_model_endpoint.py:THINKING_PREFIXES 严格一致。
_THINKING_PREFIXES: tuple[str, ...] = (
    "gemini-3.1-flash-lite-preview",
    "gemini-3.1-flash",
    "gemini-3-flash-preview",
    "gemini-3.1-flash-lite",
    "gemini-2.5-pro",
    "deepseek-v4-flash",
)


# ── assistant message 回放时需要保留的思考字段(顺序按响应中出现的优先级) ──
# 不同模型 / 聚合层把思维链放在不同字段,保留所有可能的字段最稳。
# 模型若不识别会忽略;模型若强制要求(如 DeepSeek 思考模式)会通过校验。
_REASONING_FIELDS: tuple[str, ...] = (
    "reasoning_content",  # OpenAI o1/o3、DeepSeek 标准
    "reasoning",          # 部分聚合层
    "thinking",           # Anthropic 风格透传
    "thought",            # 兜底
)


# ─────────────────────────────────────────────────────────────────────────────
# 端点选择 + 自动补全
# ─────────────────────────────────────────────────────────────────────────────
def resolve_endpoint(model_endpoint: str | None, platform_endpoint: str | None) -> str:
    """
    端点选择 + 自动补全(v7 · 2026-05-08)。

    输入:
      model_endpoint    — model_pricing.endpoint(可空)
      platform_endpoint — system_config.platform_endpoint(全局兜底,可空)

    规则:
      1. 选择基础 URL:模型自有端点优先,否则用全局
      2. 自动补全:
         - 已经以 /chat/completions 结尾 → 不动(老配置兼容)
         - 剥掉尾部 / 后以 /v1 结尾       → 补 /chat/completions(标准 OpenAI)
         - 其他形式                       → 视为特殊端点,原样返回(不补全)

    例:
      "https://yunwu.ai/v1"                        → "https://yunwu.ai/v1/chat/completions"
      "https://yunwu.ai/v1/"                       → "https://yunwu.ai/v1/chat/completions"
      "https://yunwu.ai/v1/chat/completions"       → 原样
      "https://api.openai.com/v1/responses"        → 原样(特殊端点)
      "https://x.azure.com/openai/deployments/..." → 原样(Azure 特殊路径)
    """
    raw = (model_endpoint or "").strip() or (platform_endpoint or "").strip()
    if not raw:
        return ""
    # 老配置:已经填到 /chat/completions 了,直接用
    if raw.endswith("/chat/completions"):
        return raw
    # 标准:填到 /v1 → 自动补全
    stripped = raw.rstrip("/")
    if stripped.endswith("/v1"):
        return stripped + "/chat/completions"
    # 其他:特殊端点,不动
    return raw


# ─────────────────────────────────────────────────────────────────────────────
# 思维链兜底前缀匹配
# ─────────────────────────────────────────────────────────────────────────────
def supports_thinking_by_prefix(model: str) -> bool:
    """
    判断模型是否走思维链 ── 兜底前缀匹配(v7 起仅作 DB 字段缺失时的回退)。

    v7 起,优先读取 model_pricing.supports_thinking 字段。本函数仅在 DB
    字段为 NULL 时由 build_payload 内部回退调用,不应被业务代码直接使用。
    """
    model_lower = (model or "").lower().strip()
    return any(
        model_lower == p or model_lower.startswith(p + "-")
        for p in _THINKING_PREFIXES
    )


# ─────────────────────────────────────────────────────────────────────────────
# 请求体构造
# ─────────────────────────────────────────────────────────────────────────────
def build_payload(
    model: str,
    messages: list,
    temperature: float = 1.1,
    presence_penalty: float = 0.2,
    tools: list | None = None,
    enable_thinking: bool = True,
    supports_thinking: bool | None = None,
    tool_choice: str | dict | None = None,
    prompt_cache_key: str | None = None,
) -> dict:
    """
    构造发往大模型的请求体(OpenAI国际协议通用)。

    参数:
      model              当前请求模型名
      messages           对话消息数组(已经 flatten 好,可直接发给 LLM)
      temperature        采样温度(实例可调)
      presence_penalty   出现惩罚(实例可调)
      tools              OpenAI function calling tools 数组,None 表示不带
      enable_thinking    实例层面是否启用思维链(instances.thinking_enabled)
      supports_thinking  模型层面是否支持思维链(model_pricing.supports_thinking)
                          - True / False  → 直接用此值
                          - None          → 兜底前缀白名单(supports_thinking_by_prefix)
      prompt_cache_key   2026-07-12 新增, 缓存命中优化。官方文档建议:共享长公共
                         前缀的请求复用同一个 key, 帮助路由到同一台已有缓存的
                         机器, 减少因请求量分散到多台机器导致的缓存未命中。
                         建议按会话粒度传(如 f"instance-{{db_id}}"), 单一 key
                         每分钟请求量建议控制在 ~15 次以内(官方 cookbook 给出
                         的经验值), 超过会被分流到额外机器、丧失效果。
                         None 时不下发该字段。
                         ⚠ 若本次请求实际打的是 Gemini(通过其 OpenAI 兼容层),
                         Gemini 官方文档并未提及这个字段, 是否真的影响 Gemini
                         的隐式缓存路由未经证实——这里加它是"零风险的顺手优化"
                         (不支持就是被兼容层静默忽略), 不是"确认对 Gemini 有效
                         的修复"。Gemini 自己的隐式缓存靠的是"前缀不变"本身
                         (即本文件其它改动 + chat.py 的滞后截断), 不依赖这个字段。
      tool_choice        OpenAI function calling 的 tool_choice 字段, 控制 AI 调工具行为:
                          - None        → 默认 "auto" 行为(传 tools 时), 当前向后兼容
                          - "auto"      → AI 自由决定调不调工具(OpenAI 默认)
                          - "none"      → ★ 强制 AI 必须生成 message 文本, 不能调工具 ★
                                          关键用法: 异步空 content 重试 / 防空回兜底时下发,
                                          按 OpenAI 协议规定模型此时必须出文字
                          - "required"  → 必须调至少一个工具(本项目用不到, 留接口)
                          - {"type":"function","function":{"name":"X"}}
                                        → 强制调指定工具(本项目用不到, 留接口)

    思维链下发逻辑(v22, 统一 Chat Completions 字段, 不按模型 ID 分支):
      - 支持思考的模型统一下发: reasoning_effort="high"
        * OpenAI 官方协议字段, 全主流上游(OpenAI o系/GPT-5、Gemini 2.5/3.x、
          Claude 兼容层、DeepSeek、Qwen、OpenRouter、yunwu、LiteLLM)统一支持
        * Google 官方明确: 该字段与 thinking_level / thinking_budget 互斥,
          只能且仅能下发它一个, 同时下发其它任何字段都会冲突
        * "high" 是本项目明确要求的思考深度；协议适配器不再按具体模型名
          改写深度，也不注入某个模型专属的请求体结构
      - max_tokens 统一 16384, 与 Gemini maxOutputTokens 上限齐平,
        其它模型也够用

    ⚠️ 实例 thinking_enabled 强制忽略(按 chat.py 之外的需求):
       本函数不再读 enable_thinking 参数, 所有用户全员开思维链。
       入参保留只是为了不破坏 chat.py 的调用签名。
       如需恢复"按实例开关",删除 _FORCE_THINKING_ON 即可。

    工具协议:OpenAI 标准 function calling
      - tools 数组直接塞 payload["tools"],设 tool_choice="auto"
      - 模型用 message.tool_calls 描述要调用的工具及参数
      - 模型回复在 message.content,不需要 JSON 包装

    不下发 response_format(yunwu 文档未列,容易报错)。
    """
    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": 16384,
        "presence_penalty": presence_penalty,
        # v?? (2026-05-27) 不下发 response_format ★ 重要 ★
        # 实测: yunwu/gemini-3.x 兼容层下发 response_format={"type":"json_object"}
        # 后, reasoning_effort 字段被抑制, 思维链完全消失(reasoning_tokens=0)。
        # 老代码注释里早就警告过"yunwu 文档未列, 容易报错", 这次实锤验证。
        # 改为完全靠 system prompt 引导 JSON 格式, 清洗器 clean_json_response
        # 三段式兜底(直接 parse / 剥围栏 / 找 {...} 块 / 裸提取)足以处理非纯
        # JSON 响应, 无需协议层强制。
    }
    # v?? (2026-05-27) 不再下发 OpenAI 原生 tools / tool_choice 字段。
    # 工具规格已经通过 utils.build_tools_system_block 注入 system prompt,
    # 模型在 message.content 的 JSON 里返回 tools 数组。
    # 入参 tools / tool_choice 仍保留, 仅为兼容老调用方签名, 不实际下发。
    _ = tools          # 显式忽略, 防 linter 报"参数未使用"
    _ = tool_choice    # 同上

    # 2026-07-12 缓存命中优化:传了就下发, 帮同一会话的请求路由到同一台
    # 已有缓存前缀的机器上。None(未传)时不下发, 不影响老调用方。
    if prompt_cache_key:
        payload["prompt_cache_key"] = prompt_cache_key

    # 模型是否支持思维链:DB 字段优先,缺失回退前缀白名单
    if supports_thinking is None:
        model_supports_thinking = supports_thinking_by_prefix(model)
    else:
        model_supports_thinking = bool(supports_thinking)

    # ── v19 (2026-05-27) 强制全员开思维链 ─────────────────────────────────────
    # 业务需求: 忽略 chat.py 传入的 enable_thinking(它来自实例 thinking_enabled
    # 字段), 所有用户都打开。如需恢复"按实例开关", 把这一行删掉、改回
    # enable_thinking 参数即可。
    _FORCE_THINKING_ON = True

    if model_supports_thinking and (_FORCE_THINKING_ON or enable_thinking):
        # ── v19 (2026-05-27) 统一单字段策略 ──────────────────────────────────
        # 不再按 gemini- / claude- / 其他 做模型 ID 硬编码分支。
        # 理由:
        #   1) 模型名从 DB 读, 千变万化, 无法穷举前缀
        #   2) Google 官方文档明确: reasoning_effort 与 thinking_level/budget
        #      "不能同时使用" — 一个字段就是最稳的下发方式
        #   3) reasoning_effort 是 OpenAI 标准字段, 全主流上游统一支持,
        #      兼容层会自动翻译到各自原生字段(thinking_budget / thinkingLevel /
        #      Anthropic thinking / OpenAI reasoning)
        #
        # 业务要求固定 high。这里保持国际通用 OpenAI Chat Completions
        # 请求形状，只使用 reasoning_effort 单字段，不做具体模型分流。
        payload["reasoning_effort"] = "high"
        # max_tokens 取 16384: Gemini 2.5/3.x maxOutputTokens 实际上限,
        # 其它模型也够用; 32768 在 Gemini 端会触发参数校验拒绝。
        payload["max_tokens"] = 16384
    # 模型不支持思维链 → 不写任何字段
    return payload


# ─────────────────────────────────────────────────────────────────────────────
# 响应解析
# ─────────────────────────────────────────────────────────────────────────────
def extract_reasoning(resp_json: dict) -> str | None:
    """
    从 LLM 响应中提取思维链文本。

    不同聚合层放在不同字段:
      - reasoning_content   ← OpenAI o1/o3 / DeepSeek 标准
      - reasoning           ← 部分聚合层
      - thinking            ← Anthropic 风格透传
      - thought             ← 兜底
    任一字段非空就返回;字段是嵌套字典(如 {"content":"..."})也能解析。
    都没有则返回 None。
    """
    try:
        msg = resp_json["choices"][0]["message"]
    except (KeyError, IndexError, TypeError):
        return None
    if not isinstance(msg, dict):
        return None
    for key in _REASONING_FIELDS:
        v = msg.get(key)
        if isinstance(v, str) and v.strip():
            return v
        # 部分实现把 thinking 放在嵌套结构里
        if isinstance(v, dict):
            inner = v.get("content") or v.get("text") or ""
            if isinstance(inner, str) and inner.strip():
                return inner
    return None


# ─────────────────────────────────────────────────────────────────────────────
# ⭐ 修 bug 关键函数:回放 assistant 消息时保留思维链
# ─────────────────────────────────────────────────────────────────────────────
def assistant_message_for_replay(message: dict) -> dict:
    """
    把 LLM 响应里的 assistant message,转成 messages 列表中可"回放"的格式。

    【为什么需要这个函数】
    OpenAI function calling 多轮循环:
      第 1 轮 →  user prompt
              ←  assistant: tool_calls=[get_emoji]   (可能带 reasoning_content)
      工具执行 →  tool: 结果
      第 2 轮 →  把 [user, assistant_replay, tool_result] 回传给 LLM
              ←  最终回复

    【v?? 修复:第二轮思维链永远为空】
    旧实现把响应里的 reasoning_content / reasoning / thinking / thought
    一并搬进回放消息。问题:OpenAI 协议下,历史 assistant 轮里如果带着
    reasoning_content,绝大多数 OpenAI 兼容网关会判定"思考已经给过了",
    于是第 2 轮(工具结果回来后的那一轮)不再产生新的思维链 ——
    表现就是"第一轮有思维链,第二轮永远空"。

    OpenAI 官方语义:o1/o3 的 reasoning 是服务端的,不应该、也不需要在
    后续请求里回放。所以 OpenAI 协议这里**不再回放 reasoning 字段**,
    只回放 role / content / tool_calls。

    (Anthropic / DeepSeek 思考模式确实要求把 thinking 块带回 ——
     那是 llm_protocol_anthropic.py 的职责,它会处理;本文件只管
     标准 OpenAI 协议。)

    content 可以是 None(只有 tool_calls 时),OpenAI 协议允许。

    【调用方】
    chat.py 工具循环中,messages.append(assistant_message_for_replay(message))
    """
    if not isinstance(message, dict):
        # 防御:理论不会到这里,但万一上游解析异常,返回最小有效格式
        return {"role": "assistant", "content": ""}

    content = message.get("content")
    tool_calls = message.get("tool_calls") or []

    # content 可以是 None(只有 tool_calls 时),OpenAI 协议允许;
    # 不存在的话强制设 None 而非空串,避免某些聚合层校验报错。
    replay = {
        "role": "assistant",
        "content": content if (content is None or isinstance(content, str)) else None,
    }
    if tool_calls:
        replay["tool_calls"] = tool_calls

    # ⭐ 不回放任何 reasoning 字段。
    # 历史轮带 reasoning_content 会让网关在下一轮跳过思考,
    # 导致"第二轮思维链永远为空"。OpenAI 协议下 reasoning 是服务端的,
    # 不需要也不应该回放。

    return replay
