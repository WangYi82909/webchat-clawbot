"""
group_chat.py — 拼小圈（群聊）引擎 · v1（2026-06-05）

定位
  与 chat.py 平级的独立后端模块：chat.py 负责「一对一怎么回」，
  本文件负责「群里谁来回、怎么回」。**不改 chat.py 的任何既有逻辑**，
  只 import 复用它的底层设施：
    chat.resolve_model_runtime   模型端点 / 协议 / 单价解析
    chat._call_llm_with_format_retry    统一模型请求状态机
    chat.get_http_client         全局共享 httpx 客户端
    billing.check_quota / calc_cost_from_usage / commit_usage   计费（与私聊同一套）
    tool_leak_cleaner.clean_json_response                       JSON 协议解析
    persona.get_persona_prompt                                  人格 system 文本
    llm_protocol_openai / llm_protocol_anthropic
                                                              payload / headers

main.py 集成（仅主分片，与 webchat_server 完全同一手法）：
    if IS_PRIMARY_SHARD:
        try:
            import group_chat
            asyncio.create_task(group_chat.run(pool))
        except Exception as _e:
            print(f"[警告] 拼小圈群聊引擎启动失败 (主引擎继续): {_e}", flush=True)

工作方式（轮询，对 PHP 零侵入）
  1. 每 POLL_INTERVAL 秒扫一次 chat_group_messages（WHERE id > 游标，
     一条 SQL 覆盖所有群），游标持久化在 chat_group_state 表，崩溃不丢。
  2. 新消息进各群的「合并缓冲」：静默 MERGE_WINDOW 秒（或缓冲存在超过
     MAX_BUFFER_WAIT 秒）才触发一次处理 —— 用户连发五条只触发一次。
  3. 仲裁（零 token 成本的规则层）从群内 AI 实例里选出 0~MAX_RESPONDERS
     个候选：@必回 > 点名高概率 > 疑问句挑 1 个 > 闲聊低概率挑 1 个。
     冷却 / 群级限速 / 禁言 / AI 连锁深度都在这里拦。
  4. 被选中的实例走群聊专用提示词生成回复（独立于 chat.py 的 1v1 模板，
     JSON 协议形状保持一致：{"reply": "...", "tools": []}，群聊 v1 不开工具），
     模型仍可输出空 reply = 看完上下文后选择沉默（最后一道自决层）。
  5. 回复 INSERT 回 chat_group_messages（sender_type='instance'），
     前端现有 2.5s 轮询自动显示；计费按实例主人现有桶位扣。
  6. 全程动作 / 错误写 chat_group_ai_logs，前端「日志」面板可见。

记忆互通（群 ↔ 私聊）
  · 群 → 私聊：本文件提供 get_group_context_for_private(pool, db_id)，
    chat.py 在 extra_user_block 注入点加 6 行调用（见交付说明里的补丁），
    把「最近群里发生了什么」作为独立 user 背景块带给 1v1 —— 微信上问
    "刚刚群里聊了什么" AI 能答上来。带 30s 进程内缓存，不拖慢私聊。
  · 私聊 → 群：生成群回复时，把 instances.context（私聊共享历史）的
    最后几条压缩成「你和主人的私下近况」注入，并明确标注保密红线，
    让 AI 在群里"心里有数"但不外泄隐私。

多进程分片
  引擎是全局单例（全库一个游标），只允许主分片(SHARD_INDEX==0)启动 ——
  与 webchat_server / 语音 WS 的约束一致。进程内的冷却表 / 锁因此有效。
"""

import asyncio
import json
import random
import re
import time
import traceback
import uuid
from datetime import datetime, timezone, timedelta

# ════════════════════════════════════════════════════════════════════════
# 可调参数（全部集中在这里）
# ════════════════════════════════════════════════════════════════════════
POLL_INTERVAL        = 1.5     # 秒 · 扫库间隔
MERGE_WINDOW         = 5.0     # 秒 · 静默多久才处理一批（用户连发合并）
MAX_BUFFER_WAIT      = 12.0    # 秒 · 缓冲最长等待，避免对方一直打字永不触发
MAX_RESPONDERS       = 2       # 一批消息最多放行几个 AI（多个被@时取前 2）
REPLY_PROB_NAMED     = 0.85    # 被点名（没@）时回复概率
REPLY_PROB_QUESTION  = 0.85    # 疑问句时"挑 1 个 AI 回"的概率
REPLY_PROB_CHAT      = 0.30    # 普通闲聊时"挑 1 个 AI 回"的概率
INST_COOLDOWN_WINDOW = 60      # 秒 · 单实例频控窗口
INST_COOLDOWN_MAX    = 2       # 窗口内最多发言条数（被@不受限）
GROUP_RATE_WINDOW    = 60      # 秒 · 群级 AI 消息限速窗口
GROUP_RATE_MAX       = 4       # 窗口内全群 AI 消息上限
AI_CHAIN_MAX_DEPTH   = 2       # 人类最后一条消息之后，AI 连锁最多几跳
GROUP_CTX_MSGS       = 40      # 群历史带给模型的条数
PRIVATE_TAIL_ENTRIES = 6       # 注入群 prompt 的私聊历史条数
PRIVATE_TAIL_CHARS   = 400     # 私聊近况注入的字符上限
DIGEST_CACHE_TTL     = 30      # 秒 · 群动态摘要（注入私聊用）进程内缓存
DIGEST_MSGS          = 12      # 摘要取最近几条群消息
DIGEST_MAX_AGE       = 48 * 3600   # 只摘要 48h 内的群消息
GEN_TIMEOUT          = 180     # 秒 · 单次群回复生成超时
LOG_KEEP_PER_GROUP   = 300     # 每群日志保留条数（超出自动清理）

# 分段发送（与微信端同一套 utils.split_text 口径，按实例配置切，最多 10 段）
SEGMENT_GAP_BASE     = 0.8     # 段间基础间隔(秒)，模拟真人逐条发
SEGMENT_GAP_PER_CH   = 0.04    # 下一段每个字追加的间隔
SEGMENT_GAP_MAX      = 2.5     # 单个间隔封顶
SEGMENT_TOTAL_MAX    = 6.0     # 一次回复全部间隔总封顶（不拖慢下一批调度）

_CURSOR_KEY = 'ai_cursor'      # chat_group_state 里的全局游标键

# ── 进程内运行时状态（仅主分片单进程，无需跨进程同步） ─────────────────
_POOL          = None
_buffers       = {}    # group_id -> {'msgs': [...], 'last_at': ts, 'first_at': ts, 'task': Task|None}
_inst_locks    = {}    # instance_id -> asyncio.Lock（同一实例群回复串行）
_inst_spoke    = {}    # instance_id -> [ts, ...]   实例冷却
_group_spoke   = {}    # group_id    -> [ts, ...]   群级限速
_ai_chain      = {}    # group_id    -> int          人类消息后的 AI 连锁深度
_ai_chain_last = {}    # group_id    -> instance_id  最近计入链深的实例（分段连发只算1跳）
_digest_cache  = {}    # db_id       -> (expire_ts, text|None)  群动态摘要缓存


# ════════════════════════════════════════════════════════════════════════
# 小工具
# ════════════════════════════════════════════════════════════════════════
def _now() -> int:
    return int(time.time())


def _beijing_now_str() -> str:
    """北京时间字符串（与 utils.get_beijing_time 同格式意图，独立实现避免依赖）。"""
    bj = datetime.now(timezone(timedelta(hours=8)))
    week = '一二三四五六日'[bj.weekday()]
    return bj.strftime(f'%Y-%m-%d %H:%M 星期{week}')


def _fmt_ts(ts: int) -> str:
    bj = datetime.fromtimestamp(int(ts), timezone(timedelta(hours=8)))
    return bj.strftime('%m-%d %H:%M')


def _strip(s, n: int) -> str:
    s = (s or '').strip()
    return s if len(s) <= n else s[:n] + '…'


_QUESTION_RE = re.compile(r'[?？]|[吗呢嘛吧]\s*$|^(谁|啥|什么|怎么|为什么|为啥|哪|几|多少|要不要|有没有|是不是|能不能|可不可以)')


def _is_question(text: str) -> bool:
    return bool(_QUESTION_RE.search((text or '').strip()))


def _detect_mention(text: str, name: str) -> str:
    """
    返回 'at'（@人格名，必回）/ 'named'（点到名字）/ ''（无关）。
    @ 匹配同时认半角 @ 和全角 ＠。
    """
    if not name:
        return ''
    t = text or ''
    if ('@' + name) in t or ('＠' + name) in t:
        return 'at'
    if name in t:
        return 'named'
    return ''


def _prune_window(lst: list, window: int) -> list:
    cut = _now() - window
    return [t for t in lst if t > cut]


# ════════════════════════════════════════════════════════════════════════
# 版本兼容层（2026-06-05 hotfix）
#   线上实测：生产 chat.py 比开发包旧，缺 resolve_model_runtime（6/3 才从
#   generate_reply 抽出的函数），导致 AttributeError。
#   原则：chat.py / tool_leak_cleaner / persona / 协议模块里**有现成函数就用**
#   （与私聊行为保持一致）；缺什么就走下面的内置同逻辑兜底 ——
#   群聊引擎不再因 chat.py 版本差异而崩。
# ════════════════════════════════════════════════════════════════════════
_local_http_client = None     # 本地兜底 httpx 客户端（chat.get_http_client 缺失时用）


def _http_client():
    """优先复用 chat 的全局共享客户端；没有就自建一个（惰性、进程内单例）。"""
    try:
        import chat
        fn = getattr(chat, 'get_http_client', None)
        if callable(fn):
            return fn()
    except Exception:
        pass
    global _local_http_client
    if _local_http_client is None or getattr(_local_http_client, 'is_closed', False):
        import httpx
        _local_http_client = httpx.AsyncClient(
            timeout=120.0,
            limits=httpx.Limits(max_connections=200,
                                max_keepalive_connections=50,
                                keepalive_expiry=60))
    return _local_http_client


def _resolve_endpoint_compat(proto, protocol: str, model_ep, plat_ep) -> str:
    """端点选择 + 自动补全。协议模块有 resolve_endpoint 就用，否则同逻辑内置。"""
    fn = getattr(proto, 'resolve_endpoint', None)
    if callable(fn):
        try:
            return fn(model_ep, plat_ep)
        except Exception:
            pass
    raw = (model_ep or '').strip() or (plat_ep or '').strip()
    if not raw:
        return ''
    if raw.endswith('/chat/completions'):
        return raw
    if protocol == 'anthropic' and raw.endswith('/messages'):
        return raw[: -len('/messages')] + '/chat/completions'
    stripped = raw.rstrip('/')
    if stripped.endswith('/v1'):
        return stripped + '/chat/completions'
    return raw


async def _resolve_model_runtime(pool, model: str):
    """
    模型运行时解析（端点/协议/单价/Key/思维链）。
    chat.resolve_model_runtime 存在 → 直接用（单一可信来源）；
    不存在（老版 chat.py）→ 用下面与新版逐字同逻辑的内置实现。
    返回 dict 或 None（模型未配置定价）。
    """
    try:
        import chat
        fn = getattr(chat, 'resolve_model_runtime', None)
        if callable(fn):
            return await fn(pool, model)
    except AttributeError:
        pass
    except Exception as e:
        print(f"[群聊][resolve兼容] chat.resolve_model_runtime 调用异常,走内置兜底: {e}", flush=True)

    import llm_protocol_openai as proto_openai
    import llm_protocol_anthropic as proto_anthropic

    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT config_key, config_value FROM system_config "
                "WHERE config_key IN ('platform_endpoint', 'platform_api_key')")
            sys_rows = await cur.fetchall()
            sys_cfg  = {r['config_key']: r['config_value'] for r in sys_rows}
            p_endpoint = (sys_cfg.get('platform_endpoint') or '').strip()
            p_api_key  = (sys_cfg.get('platform_api_key') or '').strip()

            # 与新版 chat.resolve_model_runtime 相同的三级列降级（老库兼容）
            price_row = None
            try:
                await cur.execute(
                    "SELECT input_price, output_price, "
                    "endpoint AS model_endpoint, api_key AS model_api_key, "
                    "protocol AS model_protocol, supports_thinking, tags "
                    "FROM model_pricing WHERE model_name=%s", (model,))
                price_row = await cur.fetchone()
            except Exception:
                try:
                    await cur.execute(
                        "SELECT input_price, output_price, "
                        "endpoint AS model_endpoint, api_key AS model_api_key, "
                        "protocol AS model_protocol, supports_thinking "
                        "FROM model_pricing WHERE model_name=%s", (model,))
                    price_row = await cur.fetchone()
                    if price_row is not None:
                        price_row = dict(price_row)
                        price_row['tags'] = ''
                except Exception:
                    await cur.execute(
                        "SELECT input_price, output_price FROM model_pricing "
                        "WHERE model_name=%s", (model,))
                    price_row = await cur.fetchone()
                    if price_row is not None:
                        price_row = dict(price_row)
                        price_row.update({
                            'model_endpoint':    None,
                            'model_api_key':     None,
                            'model_protocol':    'openai',
                            'supports_thinking': None,
                            'tags':              '',
                        })

    if not price_row:
        return None

    in_price  = float(price_row['input_price'])
    out_price = float(price_row['output_price'])
    m_endpoint = (price_row.get('model_endpoint') or '').strip() or None
    m_api_key  = (price_row.get('model_api_key')  or '').strip() or None
    m_protocol = (price_row.get('model_protocol') or 'openai').strip().lower()
    if m_protocol == 'anthropic':
        proto = proto_anthropic
    else:
        proto = proto_openai
        m_protocol = 'openai'
    api_key = m_api_key or p_api_key
    endpoint = _resolve_endpoint_compat(proto, m_protocol, m_endpoint, p_endpoint)
    st = price_row.get('supports_thinking')
    if st is not None:
        st = bool(int(st))
    return {
        'platform_endpoint': p_endpoint,
        'platform_api_key':  p_api_key,
        'price_row':         dict(price_row),
        'in_price':          in_price,
        'out_price':         out_price,
        'protocol':          m_protocol,
        'endpoint':          endpoint,
        'api_key':           api_key,
        'supports_thinking': st,
    }


async def _call_llm(client, endpoint, payload, headers, pool, db_id, protocol):
    """复用私聊请求状态机，不设置旁路重试器。"""
    import chat
    return await chat._call_llm_with_format_retry(
        client, endpoint, payload, headers, pool, db_id, "群聊",
        protocol=protocol,
    )
_THINK_TAG_RE = re.compile(r'<think(?:ing)?>[\s\S]*?</think(?:ing)?>\s*', re.I)


def _strip_thinking_compat(text: str) -> str:
    try:
        import tool_leak_cleaner as tlc
        fn = getattr(tlc, 'strip_thinking_tags', None)
        if callable(fn):
            return fn(text)
    except Exception:
        pass
    return _THINK_TAG_RE.sub('', text or '')


async def _parse_reply_compat(raw: str, reasoning: str) -> dict:
    """JSON 协议解析：优先 tlc.clean_json_response（多级兜底齐全），
    缺失时用内置三段式（直接 parse → 剥围栏 → 找首个 {...} → 裸文本）。"""
    try:
        import tool_leak_cleaner as tlc
        fn = getattr(tlc, 'clean_json_response', None)
        if callable(fn):
            try:
                return await fn(raw, None, reasoning or None)
            except TypeError:
                return await fn(raw)
    except Exception:
        pass
    text = (raw or '').strip()
    candidates = [text,
                  re.sub(r'^```(?:json)?\s*|\s*```\s*$', '', text, flags=re.I).strip()]
    m = re.search(r'\{[\s\S]*\}', text)
    if m:
        candidates.append(m.group(0))
    for c in candidates:
        if not c:
            continue
        try:
            d = json.loads(c)
            if isinstance(d, dict) and 'reply' in d:
                return {'reply': str(d.get('reply') or ''),
                        'tools': d.get('tools') or []}
        except Exception:
            continue
    # 全失败：非 JSON 形态就当裸文本回复，JSON 残片则放弃
    if text and not text.lstrip().startswith('{'):
        return {'reply': text, 'tools': []}
    return {'reply': '', 'tools': []}


async def _get_persona_compat(pool, db_id: int) -> tuple:
    """人格 + 情绪。persona 模块在则用（含缓存热路径），否则直查 DB 同逻辑。"""
    try:
        import persona as persona_mod
        fn = getattr(persona_mod, 'get_persona_prompt', None)
        if callable(fn):
            return await fn(pool, db_id)
    except Exception as e:
        print(f"[群聊][persona兼容] 模块不可用,直查DB: {type(e).__name__}: {e}", flush=True)
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT persona_id, persona FROM instances WHERE id=%s", (db_id,))
                inst = await cur.fetchone()
                if not inst or not inst.get('persona_id'):
                    return '', ''
                sp, emotion = '', ''
                try:
                    await cur.execute(
                        "SELECT system_prompt, emotion_state FROM user_personas "
                        "WHERE id=%s", (inst['persona_id'],))
                    row = await cur.fetchone()
                    if row:
                        sp = row.get('system_prompt') or ''
                        emotion = row.get('emotion_state') or ''
                except Exception:
                    await cur.execute(
                        "SELECT system_prompt FROM user_personas WHERE id=%s",
                        (inst['persona_id'],))
                    row = await cur.fetchone()
                    if row:
                        sp = row.get('system_prompt') or ''
        return (inst.get('persona') or sp or ''), emotion
    except Exception:
        return '', ''


def _build_payload_compat(proto, model, messages, temperature,
                          presence_penalty, frequency_penalty,
                          enable_thinking, supports_thinking) -> dict:
    """协议层 build_payload 新老签名自适应；全失败回退最小请求体。"""
    fn = getattr(proto, 'build_payload', None)
    if callable(fn):
        try:
            return fn(model, messages,
                      temperature=temperature,
                      presence_penalty=presence_penalty,
                      frequency_penalty=frequency_penalty,
                      tools=None,
                      enable_thinking=enable_thinking,
                      supports_thinking=supports_thinking,
                      tool_choice=None)
        except TypeError:
            try:
                return fn(model, messages,
                          temperature=temperature,
                          presence_penalty=presence_penalty,
                          frequency_penalty=frequency_penalty)
            except TypeError:
                try:
                    return fn(model, messages)
                except Exception:
                    pass
        except Exception:
            pass
    return {'model': model, 'messages': messages,
            'temperature': temperature,
            'presence_penalty': presence_penalty,
            'frequency_penalty': frequency_penalty}


def _build_headers_compat(protocol: str, api_key: str) -> dict:
    if protocol == 'anthropic':
        try:
            import llm_protocol_anthropic as pa
            fn = getattr(pa, 'build_headers', None)
            if callable(fn):
                return fn(api_key)
        except Exception:
            pass
    return {'Authorization': f'Bearer {api_key}',
            'Content-Type':  'application/json'}


def _extract_reasoning_compat(proto, resp_json) -> str:
    try:
        fn = getattr(proto, 'extract_reasoning', None)
        if callable(fn):
            return fn(resp_json) or ''
    except Exception:
        pass
    try:
        msg = (resp_json.get('choices') or [{}])[0].get('message') or {}
        return msg.get('reasoning_content') or msg.get('reasoning') or ''
    except Exception:
        return ''


def _calc_cost_compat(usage: dict, in_price: float, out_price: float):
    """计费换算：billing.calc_cost_from_usage 在则用，否则同公式内置。"""
    try:
        import billing
        fn = getattr(billing, 'calc_cost_from_usage', None)
        if callable(fn):
            return fn(usage, in_price, out_price)
    except Exception:
        pass
    p = int((usage or {}).get('prompt_tokens') or 0)
    c = int((usage or {}).get('completion_tokens') or 0)
    cost = p * in_price / 1e6 + c * out_price / 1e6
    return cost, p, c, ''


async def _fetch_split_config(pool, db_id: int) -> tuple:
    """读实例的分段配置（split_rule / ignore_punctuation）。
    不走 utils._fetch_send_config —— 那个函数对没绑微信 token 的实例
    会丢弃用户配置返回默认值；群聊/纯网页实例也应该按用户配置切。
    老库缺列 → 降级 ('\\n', False)。"""
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT split_rule, ignore_punctuation FROM instances WHERE id=%s",
                    (db_id,))
                row = await cur.fetchone()
        if not row:
            return '\n', False
        rule = (row.get('split_rule') or '\\n').replace('\\n', '\n')
        ignore_punc = int(row.get('ignore_punctuation') or 0) == 1
        return rule, ignore_punc
    except Exception:
        return '\n', False


def _split_reply_compat(reply: str, rule: str, ignore_punc: bool) -> list:
    """按用户配置分段：utils.split_text 在则用（与微信端逐字同口径），
    缺失/异常 → 整段单条。"""
    try:
        import utils
        fn = getattr(utils, 'split_text', None)
        if callable(fn):
            parts = fn(reply, rule, ignore_punc)
            if parts:
                return parts
    except Exception as e:
        print(f"[群聊][分段失败,整段发送] {type(e).__name__}: {e}", flush=True)
    return [reply]


# ════════════════════════════════════════════════════════════════════════
# AI 动作日志（前端「日志」面板的数据源）
# ════════════════════════════════════════════════════════════════════════
async def _ai_log(pool, group_id: int, instance_id, instance_name: str,
                  level: str, event: str, detail: str, task_id: str = ''):
    """
    level: info(调度信息) / action(实例动作) / error(报错)
    event: dispatch / skip / gen_start / gen_reply / gen_silent / gen_error
    永不抛异常 —— 日志失败不允许影响主流程。
    """
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "INSERT INTO chat_group_ai_logs "
                    "(group_id, instance_id, instance_name, level, event, detail, task_id, ts) "
                    "VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
                    (group_id, instance_id, _strip(instance_name, 60),
                     level, event, _strip(detail, 1800), task_id, _now())
                )
                # 顺手裁剪：只保留每群最近 LOG_KEEP_PER_GROUP 条
                await cur.execute(
                    "DELETE FROM chat_group_ai_logs WHERE group_id=%s AND id < ("
                    "  SELECT min_id FROM (SELECT MIN(id) AS min_id FROM ("
                    "    SELECT id FROM chat_group_ai_logs WHERE group_id=%s "
                    "    ORDER BY id DESC LIMIT %s) t1) t2)",
                    (group_id, group_id, LOG_KEEP_PER_GROUP)
                )
            await conn.commit()
    except Exception as e:
        print(f"[群聊][日志写入失败] gid={group_id} {event}: {e}", flush=True)


# ════════════════════════════════════════════════════════════════════════
# 游标（chat_group_state）
# ════════════════════════════════════════════════════════════════════════
async def _load_cursor(pool) -> int:
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute("SELECT v FROM chat_group_state WHERE k=%s", (_CURSOR_KEY,))
            row = await cur.fetchone()
            if row:
                return int(row['v'])
            # 首次启动：从当前最大消息 id 开始（不补发历史，避免重启风暴）
            await cur.execute("SELECT COALESCE(MAX(id),0) AS m FROM chat_group_messages")
            m = int((await cur.fetchone())['m'])
            await cur.execute(
                "INSERT INTO chat_group_state (k, v) VALUES (%s,%s) "
                "ON DUPLICATE KEY UPDATE v=v", (_CURSOR_KEY, m))
        await conn.commit()
    return m


async def _save_cursor(pool, v: int):
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "UPDATE chat_group_state SET v=%s WHERE k=%s AND v<%s",
                (v, _CURSOR_KEY, v))
        await conn.commit()


# ════════════════════════════════════════════════════════════════════════
# 轮询主循环
# ════════════════════════════════════════════════════════════════════════
def _env_report():
    """启动时打印运行环境实情：进程实际加载的 chat 模块路径 + 关键能力位。
    专治"本地源码是新版、服务器跑的是旧版"这类文件不同步问题 ——
    shard_0.log 里这几行一眼定位。"""
    try:
        import os as _os
        lines = []
        try:
            import chat as _c
            cf = getattr(_c, '__file__', '?')
            caps = []
            caps.append('resolve_model_runtime ' + ('✓' if hasattr(_c, 'resolve_model_runtime') else '✗旧版,群聊走内置兜底'))
            caps.append('_call_llm_with_format_retry ' + ('✓' if hasattr(_c, '_call_llm_with_format_retry') else '✗不可用'))
            caps.append('get_http_client ' + ('✓' if hasattr(_c, 'get_http_client') else '✗走内置'))
            try:
                import inspect as _i
                _ps = _i.signature(_c.generate_reply).parameters
                caps.append('generate_reply(force_rag) ' + ('✓' if 'force_rag' in _ps else '✗旧签名'))
            except Exception:
                pass
            mt = ''
            try:
                mt = ' · mtime ' + datetime.fromtimestamp(_os.path.getmtime(cf)).strftime('%m-%d %H:%M')
            except Exception:
                pass
            lines.append(f"[拼小圈][环境] chat = {cf}{mt}")
            lines.append(f"[拼小圈][环境] chat 能力: " + ' | '.join(caps))
        except Exception as e:
            lines.append(f"[拼小圈][环境] chat 模块导入失败: {type(e).__name__}: {e}")
        for mod, attr in (('tool_leak_cleaner', 'clean_json_response'),
                          ('persona', 'get_persona_prompt'),
                          ('billing', 'check_quota')):
            try:
                m = __import__(mod)
                ok = '✓' if hasattr(m, attr) else f'✗缺{attr}(走兼容)'
                lines.append(f"[拼小圈][环境] {mod} {ok}")
            except Exception as e:
                lines.append(f"[拼小圈][环境] {mod} 导入失败: {type(e).__name__}")
        for ln in lines:
            print(ln, flush=True)
    except Exception:
        pass


async def run(pool):
    """main.py 入口：asyncio.create_task(group_chat.run(pool))，仅主分片。"""
    global _POOL
    _POOL = pool
    _env_report()
    try:
        cursor = await _load_cursor(pool)
    except Exception as e:
        print(f"[群聊] 启动失败：读取游标异常（请确认已建表 chat_group_state）：{e}", flush=True)
        return
    print(f"[就绪] 拼小圈群聊引擎已挂入主循环（轮询 {POLL_INTERVAL}s · 游标={cursor}）", flush=True)

    while True:
        try:
            await asyncio.sleep(POLL_INTERVAL)
            cursor = await _poll_once(pool, cursor)
            _flush_due_buffers()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[群聊][轮询异常·已忽略] {e}", flush=True)
            traceback.print_exc()


async def _poll_once(pool, cursor: int) -> int:
    """扫一轮新消息，路由进各群缓冲；返回新游标。"""
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT id, group_id, sender_type, sender_uid, instance_id, "
                "       sender_name, content, ts "
                "FROM chat_group_messages WHERE id > %s ORDER BY id ASC LIMIT 200",
                (cursor,))
            rows = await cur.fetchall()
    if not rows:
        return cursor

    new_cursor = cursor
    for r in rows:
        new_cursor = max(new_cursor, int(r['id']))
        gid   = int(r['group_id'])
        stype = r['sender_type']

        # AI 连锁深度：人类消息归零；AI 消息 +1。
        # 同一实例的连续消息（分段发送）只算 1 跳 —— 链深语义是"发言次数"。
        if stype == 'user':
            _ai_chain[gid] = 0
            _ai_chain_last.pop(gid, None)
        elif stype == 'instance':
            iid = int(r.get('instance_id') or 0)
            if _ai_chain_last.get(gid) != iid:
                _ai_chain[gid] = _ai_chain.get(gid, 0) + 1
                _ai_chain_last[gid] = iid

        if stype == 'system':
            continue                      # 入群/禁言等系统动态不触发 AI

        buf = _buffers.setdefault(gid, {'msgs': [], 'last_at': 0.0, 'first_at': 0.0, 'task': None})
        if not buf['msgs']:
            buf['first_at'] = time.monotonic()
        buf['msgs'].append(dict(r))
        buf['last_at'] = time.monotonic()

    await _save_cursor(pool, new_cursor)
    return new_cursor


def _flush_due_buffers():
    """检查各群缓冲：静默够久 / 等待超限 → 起 dispatch 任务。"""
    now = time.monotonic()
    for gid, buf in list(_buffers.items()):
        if not buf['msgs']:
            continue
        if buf['task'] is not None and not buf['task'].done():
            continue                      # 上一批还在处理，处理完会再 flush
        quiet_ok = (now - buf['last_at']) >= MERGE_WINDOW
        wait_ok  = (now - buf['first_at']) >= MAX_BUFFER_WAIT
        if quiet_ok or wait_ok:
            batch = buf['msgs']
            buf['msgs'] = []
            buf['task'] = asyncio.get_running_loop().create_task(
                _dispatch_batch(_POOL, gid, batch))


# ════════════════════════════════════════════════════════════════════════
# 仲裁：这批消息，群里哪些 AI 来回？
# ════════════════════════════════════════════════════════════════════════
async def _load_group_and_members(pool, gid: int):
    """群行 + 成员（实例成员带实时人格名 / 主人名 / 禁言位 / 采样参数等）。"""
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute("SELECT * FROM chat_groups WHERE id=%s", (gid,))
            group = await cur.fetchone()
            if not group:
                return None, [], []
            await cur.execute(
                "SELECT m.id AS member_id, m.member_type, m.user_id, m.instance_id, "
                "       m.owner_uid, m.nickname, m.is_muted, "
                "       u.username AS owner_name, "
                "       i.model, i.persona_id, "
                "       p.name AS persona_name "
                "FROM chat_group_members m "
                "LEFT JOIN users u ON u.id = m.owner_uid "
                "LEFT JOIN instances i ON m.member_type='instance' AND i.id = m.instance_id "
                "LEFT JOIN user_personas p ON p.id = i.persona_id "
                "WHERE m.group_id = %s", (gid,))
            members = await cur.fetchall()

    humans, ais = [], []
    for m in members:
        if m['member_type'] == 'instance' and m['instance_id']:
            name = (m.get('persona_name') or m.get('nickname') or
                    f"{m.get('owner_name') or '成员'}的AI").strip()
            ais.append({
                'instance_id': int(m['instance_id']),
                'name':        name,
                'owner_uid':   int(m['owner_uid']),
                'owner_name':  (m.get('owner_name') or '').strip() or f"用户{m['owner_uid']}",
                'is_muted':    int(m.get('is_muted') or 0) == 1,
            })
        elif m['member_type'] == 'user':
            humans.append({
                'user_id':    int(m['user_id'] or 0),
                'name':       (m.get('nickname') or m.get('owner_name') or '').strip()
                              or f"用户{m['user_id']}",
                'is_owner':   int(m['user_id'] or 0) == int(group['owner_uid']),
            })
    return group, humans, ais


def _arbitrate(gid: int, batch: list, ais: list) -> tuple[list, list]:
    """
    规则仲裁（零 token）。返回 (chosen, skip_notes)
      chosen: [{'ai':…, 'reason':'at'|'named'|'question'|'chat'}, …] 最多 MAX_RESPONDERS
      skip_notes: 写日志用的人类可读筛除原因
    """
    notes = []
    batch_text = '\n'.join((m.get('content') or '') for m in batch)
    has_human  = any(m['sender_type'] == 'user' for m in batch)
    only_ai    = (not has_human)

    # AI→AI 连锁闸：这批全是 AI 发言时，仅被@才允许接话，且深度受限
    chain_depth = _ai_chain.get(gid, 0)
    if only_ai and chain_depth > AI_CHAIN_MAX_DEPTH:
        return [], [f'AI连锁已达 {chain_depth} 跳(上限{AI_CHAIN_MAX_DEPTH})，全员沉默']

    # 候选池逐个打标
    must, named, pool_ = [], [], []
    for ai in ais:
        if ai['is_muted']:
            notes.append(f"{ai['name']}：被禁言，跳过")
            continue
        # 自己这批刚说过话的实例不再接（防自我对话）
        if any(m['sender_type'] == 'instance' and int(m.get('instance_id') or 0) == ai['instance_id']
               for m in batch):
            notes.append(f"{ai['name']}：本批消息含自己发言，跳过")
            continue
        mention = _detect_mention(batch_text, ai['name'])
        if mention == 'at':
            must.append(ai)
            continue
        if only_ai:
            notes.append(f"{ai['name']}：AI 间对话未被@，不接话")
            continue
        # 实例冷却（@不受限，普通触发受限）
        spoke = _inst_spoke.get(ai['instance_id']) or []
        spoke = _prune_window(spoke, INST_COOLDOWN_WINDOW)
        _inst_spoke[ai['instance_id']] = spoke
        if len(spoke) >= INST_COOLDOWN_MAX:
            notes.append(f"{ai['name']}：{INST_COOLDOWN_WINDOW}s 内已发 {len(spoke)} 条，冷却中")
            continue
        if mention == 'named':
            named.append(ai)
        else:
            pool_.append(ai)

    chosen = [{'ai': a, 'reason': 'at'} for a in must[:MAX_RESPONDERS]]

    # @ 是指向性发言：只要这批消息里出现了对任意 AI 的 @（包括被禁言/冷却中的），
    # 其他 AI 一律不再自发插话 —— 抢别人被点名的话头很失礼。
    batch_has_at = bool(must) or any(
        _detect_mention(batch_text, a['name']) == 'at' for a in ais)

    # 群级限速只约束"非@"的自发回复；@必回不受限
    g_spoke = _prune_window(_group_spoke.get(gid) or [], GROUP_RATE_WINDOW)
    _group_spoke[gid] = g_spoke
    rate_full = len(g_spoke) >= GROUP_RATE_MAX

    if (not chosen) and (not batch_has_at) and not rate_full and not only_ai:
        if named and random.random() < REPLY_PROB_NAMED:
            pick = random.choice(named)
            chosen.append({'ai': pick, 'reason': 'named'})
        elif pool_:
            prob = REPLY_PROB_QUESTION if _is_question(batch_text) else REPLY_PROB_CHAT
            if random.random() < prob:
                pick = random.choice(pool_)
                chosen.append({'ai': pick,
                               'reason': 'question' if _is_question(batch_text) else 'chat'})
            else:
                notes.append(f"概率抽签未命中(p={prob:.0%})，自发回复本批沉默")
    elif rate_full and not must:
        notes.append(f"群 {GROUP_RATE_WINDOW}s 内 AI 消息已达 {len(g_spoke)} 条，限速中")

    return chosen, notes


_REASON_CN = {'at': '被@点名', 'named': '消息提到了名字', 'question': '群里在提问', 'chat': '闲聊随机参与'}


async def _dispatch_batch(pool, gid: int, batch: list):
    """一批合并后的群消息 → 仲裁 → 给选中的实例起生成任务。"""
    try:
        group, humans, ais = await _load_group_and_members(pool, gid)
        if not group or not ais:
            return
        chosen, notes = _arbitrate(gid, batch, ais)

        preview = _strip('；'.join(f"[{m['sender_name']}] {m['content']}" for m in batch), 160)
        await _ai_log(pool, gid, None, '',
                      'info', 'dispatch',
                      f"新消息 {len(batch)} 条（{preview}）→ "
                      + (('选中：' + '、'.join(f"{c['ai']['name']}({_REASON_CN[c['reason']]})" for c in chosen))
                         if chosen else '本批无 AI 回复')
                      + (('；' + '；'.join(notes)) if notes else ''))

        tasks = [
            _generate_group_reply(pool, group, humans, ais, c['ai'], batch, c['reason'])
            for c in chosen
        ]
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
    except Exception as e:
        print(f"[群聊][dispatch异常] gid={gid}: {e}", flush=True)
        traceback.print_exc()
        try:
            await _ai_log(pool, gid, None, '', 'error', 'gen_error',
                          f"调度异常：{type(e).__name__}: {e}")
        except Exception:
            pass
    finally:
        # 处理期间若又攒了新消息，立即让 flush 逻辑能再次触发
        buf = _buffers.get(gid)
        if buf is not None:
            buf['task'] = None
        _flush_due_buffers()


# ════════════════════════════════════════════════════════════════════════
# 群聊提示词（基于 chat.py 现行 1v1 模板改写的群聊版）
# ════════════════════════════════════════════════════════════════════════
def _build_group_system_prompt(persona_text: str, group_name: str,
                               humans: list, ais: list, me: dict) -> str:
    """
    群聊版 system_prompt。
    与 chat.py 的 1v1 模板同骨架（角色/风格/JSON 协议），差异点：
      · 场景从"微信私聊"改为"多人群聊"，给出成员名单 + 谁是你主人
      · 风格强调"群聊礼仪"：短、口语、可@、不必每条都回
      · 协议保留 reply/tools 双字段（清洗器/解析复用），但群聊 v1 工具关闭
        → tools 永远 []，沉默 = reply 空串
    """
    member_lines = []
    for h in humans:
        tag = '（群主）' if h['is_owner'] else ''
        tag += '（你的主人）' if me['owner_uid'] == h['user_id'] else ''
        member_lines.append(f"- {h['name']}{tag}")
    for a in ais:
        if a['instance_id'] == me['instance_id']:
            member_lines.append(f"- {a['name']}（就是你自己）")
        else:
            member_lines.append(f"- {a['name']}（{a['owner_name']} 的 AI）")
    members_block = '\n'.join(member_lines)

    return f"""\
【角色】
{persona_text}

【场景 · 多人群聊】
你正在一个叫「{group_name}」的微信群（拼小圈）里。群里既有真人，也有别人家的 AI。
成员名单：
{members_block}
- 历史消息里 [名字] 前缀表示是谁说的；你自己的发言没有前缀。
- 你主人也在群里。对主人保持你们私下的相处方式，但注意这是群，大家都看得到。

【群聊说话风格】
- 你是真人，不是 AI 客服。像在朋友群里插话一样说话。
- 一次回复 1-3 句短句，群里没人长篇大论。
- 自然口语化；可以用 @某人 来指名说话（直接写 @名字）。
- 不是每条消息都需要你回。没你的事、没新东西可说，就保持沉默。
- 别加旁白、动作描写；别写时间戳；别复述系统信息。
- 别在群里泄露你和主人的私聊隐私细节；可以提到近况，但点到为止。

═══════════════════════════════════════════════════════
【响应格式 · 必须严格遵守】
═══════════════════════════════════════════════════════
每次响应必须是【纯 JSON】，直接以 {{ 开头，}} 结尾。
不要 markdown 代码块，不要前后多余文字。

固定两个字段（都必填）：
  {{
    "reply": "你要在群里说的话（允许空字符串）",
    "tools": []
  }}

【群聊里只有 2 种合法走法】
  ① 在群里说话：  {{"reply":"哈哈我也想吃", "tools":[]}}
  ② 保持沉默：    {{"reply":"", "tools":[]}}

⚠ 群聊模式下不开放任何工具，tools 必须是空数组 []。
⚠ 拿不准要不要说话时，优先选 ② 沉默 —— 群里抢话比沉默更尴尬。

【冲突】人设语气优先，本模板的格式 / 群聊礼仪规则优先。
"""


def _build_group_user_prompt(batch: list, reason: str, me: dict,
                             emotion: str, private_tail: str) -> str:
    """群聊版 user_prompt（对应 chat.py 的被动消息预设，场景换成群）。"""
    new_lines = '\n'.join(
        f"[{m['sender_name']}] {m['content']}" for m in batch
    )
    reason_line = {
        'at':       '有人在群里 @ 了你，需要你接话。',
        'named':    '群里有人提到了你的名字。',
        'question': '群里有人抛出了问题，你被氛围点到，可以参与。',
        'chat':     '群里在闲聊，你可以自然插一句，也可以不说。',
    }.get(reason, '群里有新消息。')

    private_block = ''
    if private_tail:
        private_block = f"""
【你和主人的私下近况 · 仅你自己知道 · 保密】
{private_tail}
（这是你和主人一对一聊天的背景，群里其他人看不到。让你心里有数即可：
可以自然带到近况，但绝对不要把私聊的具体内容、隐私细节复述到群里。）
"""

    return f"""\
【触发场景 · 群聊】
{reason_line}

【现在几点】{_beijing_now_str()}
先看一眼群里的消息流，想清楚此刻的话题走到哪了，别接错茬。

【你现在的情绪】{emotion}
按这个情绪状态决定语气和要不要说话。
{private_block}
【群里刚刚的新消息】
{new_lines}

【先在心里想一想】（只是心里想，不发出去）
- 这几句话跟你有关系吗？{'被@了就必须回应。' if reason == 'at' else '没你的事可以不说话。'}
- 群里现在什么氛围？你插这句话自然吗？
- 想说的话和你刚说过的重复吗？
- 会不会暴露你和主人的私聊隐私？

═══════════════════════════════════════════════════════
【这一轮你必须输出 JSON，两种走法】
═══════════════════════════════════════════════════════
  ① 说话：  {{"reply":"你要在群里说的话", "tools":[]}}
  ② 沉默：  {{"reply":"", "tools":[]}}
{'被@的场合一般要回应（哪怕简短一句），冷场会让@你的人尴尬。' if reason == 'at' else '拿不准就选 ②，群聊里少说不会错。'}

【最终回复前 · 自查】
1. 输出必须是合法 JSON，直接 {{ 开头 }} 结尾，含 reply 和 tools 两个字段。
2. tools 必须是 []。
3. reply 里不能出现：旁白括号、时间戳、[名字] 前缀（系统会自动署名）、
   任何像数据/配置的方括号花括号、工具调用文本。
4. 1-3 句以内，像真人在群里说话。

确认完毕，输出 JSON。
"""


# ════════════════════════════════════════════════════════════════════════
# 历史与背景块
# ════════════════════════════════════════════════════════════════════════
async def _load_group_history_msgs(pool, gid: int, before_id: int, limit: int) -> list:
    """取该群 before_id（含）之前的最近 limit 条，升序返回。"""
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(
                "SELECT id, sender_type, instance_id, sender_name, content, ts "
                "FROM chat_group_messages "
                "WHERE group_id=%s AND id<=%s ORDER BY id DESC LIMIT %s",
                (gid, before_id, limit))
            rows = await cur.fetchall()
    return list(reversed(rows))


def _history_to_llm_messages(rows: list, my_instance_id: int, batch_first_id: int) -> list:
    """
    群历史 → LLM messages：
      · 自己（本实例）发的 → assistant，content 原文（不带前缀）
      · 其他人 / 其他 AI   → user，content 加 [名字] 前缀
      · system 动态        → user，[群系统] 前缀（入群/禁言等社交信号有用）
      · 本批新消息（id >= batch_first_id）跳过 —— 它们由 user_prompt 呈现
      · 连续同 role 合并为一条（分段发送会产生连续 assistant 行，
        合并后对各家 OpenAI 兼容层最稳）
    """
    out = []
    for r in rows:
        if int(r['id']) >= batch_first_id:
            continue
        stype = r['sender_type']
        body  = (r['content'] or '').strip()
        if not body:
            continue
        if stype == 'instance' and int(r.get('instance_id') or 0) == my_instance_id:
            role, line = 'assistant', body
        elif stype == 'system':
            role, line = 'user', f"[群系统] {body}"
        else:
            role, line = 'user', f"[{r['sender_name']}] {body}"
        if out and out[-1]['role'] == role:
            out[-1]['content'] += '\n' + line
        else:
            out.append({'role': role, 'content': line})
    return out


async def _load_private_tail(pool, db_id: int) -> str:
    """instances.context（私聊共享历史）末尾几条 → 压缩文本，注入群 prompt。"""
    try:
        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute("SELECT context FROM instances WHERE id=%s", (db_id,))
                row = await cur.fetchone()
        history = json.loads(row['context']) if row and row.get('context') else []
    except Exception:
        return ''
    lines, total = [], 0
    for msg in reversed(history):
        role = msg.get('role')
        if role not in ('user', 'assistant'):
            continue
        content = msg.get('content')
        if isinstance(content, list):       # 多模态条目 → 只取文本片段
            content = ' '.join(p.get('text', '') for p in content
                               if isinstance(p, dict) and p.get('type') == 'text')
        content = _strip(str(content or ''), 80)
        if not content:
            continue
        line = ('主人：' if role == 'user' else '你：') + content
        total += len(line)
        if total > PRIVATE_TAIL_CHARS or len(lines) >= PRIVATE_TAIL_ENTRIES:
            break
        lines.append(line)
    return '\n'.join(reversed(lines))


# ════════════════════════════════════════════════════════════════════════
# 生成一条群回复（被选中的实例执行）
# ════════════════════════════════════════════════════════════════════════
async def _generate_group_reply(pool, group, humans, ais, me, batch, reason):
    """单实例群回复全流程：配额 → 拼 prompt → LLM → 解析 → 入库 → 扣费。
    所有对 chat / tlc / persona / 协议模块的依赖都走顶部的版本兼容层，
    生产环境这些模块缺函数 / 签名不同也能正常生成。"""
    import billing                 # 惰性导入，避免模块加载顺序问题
    import llm_protocol_openai as proto_openai
    import llm_protocol_anthropic as proto_anthropic

    gid     = int(group['id'])
    db_id   = me['instance_id']
    task_id = uuid.uuid4().hex[:12]
    lock    = _inst_locks.setdefault(db_id, asyncio.Lock())

    async with lock:               # 同一实例的群回复串行（不与自己抢话）
        try:
            # ── 实例配置 + 配额 ───────────────────────────────────────
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute("SELECT * FROM instances WHERE id=%s", (db_id,))
                    inst = await cur.fetchone()
            if not inst:
                await _ai_log(pool, gid, db_id, me['name'], 'error', 'gen_error',
                              '实例配置读取失败（实例可能已删除）', task_id)
                return

            user_id = int(inst['user_id'])
            model   = (inst.get('model') or '').strip()
            quota   = await billing.check_quota(pool, user_id, db_id, model)
            if not quota['ok']:
                await _ai_log(pool, gid, db_id, me['name'], 'error', 'gen_error',
                              f"主人配额不足，本次不回复：{quota.get('deny_reason') or '配额/权限不通过'}",
                              task_id)
                return
            bucket        = quota['bucket']
            count_pack_id = quota.get('count_pack_id')

            runtime = await _resolve_model_runtime(pool, model)
            if not runtime:
                await _ai_log(pool, gid, db_id, me['name'], 'error', 'gen_error',
                              f"模型 {model} 未在 model_pricing 配置定价，无法生成", task_id)
                return

            # ── 人格 + 情绪（实时） ──────────────────────────────────
            persona_text, emotion = await _get_persona_compat(pool, db_id)
            if not persona_text:
                persona_text = '你是一个友好的 AI。'
            emotion = (emotion or '').strip() or '（暂无记录）'

            await _ai_log(pool, gid, db_id, me['name'], 'action', 'gen_start',
                          f"开始生成（{_REASON_CN.get(reason, reason)} · 模型 {model}）", task_id)

            # ── messages 组装 ─────────────────────────────────────────
            batch_first_id = min(int(m['id']) for m in batch)
            hist_rows = await _load_group_history_msgs(
                pool, gid, before_id=max(int(m['id']) for m in batch), limit=GROUP_CTX_MSGS)
            history_msgs = _history_to_llm_messages(hist_rows, db_id, batch_first_id)
            private_tail = await _load_private_tail(pool, db_id)

            system_prompt = _build_group_system_prompt(
                persona_text, group['name'], humans, ais, me)
            user_prompt = _build_group_user_prompt(
                batch, reason, me, emotion, private_tail)

            messages = [{'role': 'system', 'content': system_prompt}]
            messages.extend(history_msgs)
            messages.append({'role': 'user', 'content': user_prompt})

            # ── 采样参数（与私聊同字段，老库缺失回退默认） ─────────────
            def _f(key, default):
                v = inst.get(key)
                try:
                    return float(v) if v is not None else default
                except (TypeError, ValueError):
                    return default
            temperature       = _f('temperature', 1.0)
            presence_penalty  = _f('presence_penalty', 0.1)
            frequency_penalty = _f('frequency_penalty', 0.1)
            thinking_enabled  = bool(int(inst.get('thinking_enabled') or 1))

            m_protocol = runtime['protocol']
            if m_protocol == 'anthropic':
                proto = proto_anthropic
            else:
                proto = proto_openai
            payload = _build_payload_compat(
                proto, model, messages,
                temperature=temperature,
                presence_penalty=presence_penalty,
                frequency_penalty=frequency_penalty,
                enable_thinking=thinking_enabled,
                supports_thinking=runtime['supports_thinking'],
            )
            req_headers = _build_headers_compat(m_protocol, runtime['api_key'])

            # ── LLM 请求 ───────────────────────────────────────────
            t0 = time.monotonic()
            resp_json = await asyncio.wait_for(
                _call_llm(_http_client(), runtime['endpoint'], payload, req_headers,
                          pool, db_id, m_protocol),
                timeout=GEN_TIMEOUT)
            elapsed = time.monotonic() - t0

            if resp_json is None:
                await _ai_log(pool, gid, db_id, me['name'], 'error', 'gen_error',
                              "LLM 请求失败（详见实例日志），已发送失败提示", task_id)
                resp_json = {
                    "choices": [{
                        "message": {
                            "content": '{"reply":"消息未发出，请查看日志"}'
                        }
                    }],
                    "usage": {},
                }

            message     = (resp_json.get('choices') or [{}])[0].get('message') or {}
            raw_content = (message.get('content') or '').strip()
            raw_content = _strip_thinking_compat(raw_content)
            reasoning   = _extract_reasoning_compat(proto, resp_json)
            parsed = await _parse_reply_compat(raw_content, reasoning)
            reply  = (parsed.get('reply') or '').strip()

            # ── 计费（与私聊完全同一套 commit_usage） ─────────────────
            # commit 失败不丢回复：上游 token 已实际消耗，回复照发，
            # 但要把扣费异常打到日志面板（error）让你看得到。
            usage = resp_json.get('usage') or {}
            cost, p_tok, c_tok, _br = _calc_cost_compat(
                usage, runtime['in_price'], runtime['out_price'])
            if p_tok > 0 or c_tok > 0:
                try:
                    await billing.commit_usage(
                        pool=pool, user_id=user_id, db_id=db_id, bucket=bucket,
                        total_cost=cost, total_prompt_tokens=p_tok,
                        total_completion_tokens=c_tok, model=model,
                        count_pack_id=count_pack_id)
                except Exception as _be:
                    print(f"[群聊][扣费异常] db_id={db_id}: {_be}", flush=True)
                    traceback.print_exc()
                    await _ai_log(pool, gid, db_id, me['name'], 'error', 'gen_error',
                                  f"扣费提交异常（回复仍发出）：{type(_be).__name__}: {_strip(str(_be), 200)}",
                                  task_id)

            if not reply:
                await _ai_log(pool, gid, db_id, me['name'], 'action', 'gen_silent',
                              f"看完上下文选择沉默（{elapsed:.1f}s · In:{p_tok} Out:{c_tok}）",
                              task_id)
                return

            # ── 按用户配置分段入库（与微信端 split_text 同口径） ───────
            # 一段一条消息，段间小间隔模拟真人逐条发；前端轮询逐步显示。
            reply = _strip(reply, 2000)
            split_rule, ignore_punc = await _fetch_split_config(pool, db_id)
            segments = _split_reply_compat(reply, split_rule, ignore_punc)
            segments = [_strip(seg, 2000) for seg in segments if seg and seg.strip()]
            if not segments:
                segments = [reply]

            name_snap = _strip(me['name'], 60)
            total_gap = 0.0
            for idx, seg in enumerate(segments):
                now = _now()
                async with pool.acquire() as conn:
                    async with conn.cursor() as cur:
                        await cur.execute(
                            "INSERT INTO chat_group_messages "
                            "(group_id, sender_type, sender_uid, instance_id, sender_name, content, ts) "
                            "VALUES (%s,'instance',NULL,%s,%s,%s,%s)",
                            (gid, db_id, name_snap, seg, now))
                    await conn.commit()
                if idx < len(segments) - 1 and total_gap < SEGMENT_TOTAL_MAX:
                    gap = min(SEGMENT_GAP_MAX,
                              SEGMENT_GAP_BASE + len(segments[idx + 1]) * SEGMENT_GAP_PER_CH,
                              SEGMENT_TOTAL_MAX - total_gap)
                    if gap > 0:
                        total_gap += gap
                        await asyncio.sleep(gap)

            # 冷却 / 限速记账（一次发言只记 1 次，分段是呈现形式不是刷屏）
            # + 私聊摘要缓存失效（群里有新动态了）
            now = _now()
            _inst_spoke.setdefault(db_id, []).append(now)
            _group_spoke.setdefault(gid, []).append(now)
            _digest_cache.pop(db_id, None)

            seg_note = f"（共{len(segments)}段）" if len(segments) > 1 else ""
            await _ai_log(pool, gid, db_id, me['name'], 'action', 'gen_reply',
                          f"已回复{seg_note}：{_strip(reply, 120)}"
                          f"（{elapsed:.1f}s · In:{p_tok} Out:{c_tok} · ¥{cost:.4f}）",
                          task_id)

        except asyncio.TimeoutError:
            await _ai_log(pool, gid, db_id, me['name'], 'error', 'gen_error',
                          f"生成超时（>{GEN_TIMEOUT}s），本次放弃", task_id)
        except Exception as e:
            print(f"[群聊][生成异常] gid={gid} db_id={db_id}: {e}", flush=True)
            traceback.print_exc()
            await _ai_log(pool, gid, db_id, me['name'], 'error', 'gen_error',
                          f"{type(e).__name__}: {_strip(str(e), 300)}", task_id)


# ════════════════════════════════════════════════════════════════════════
# 群 → 私聊：最近群动态摘要（chat.py 的 extra_user_block 钩子调用）
# ════════════════════════════════════════════════════════════════════════
async def get_group_context_for_private(pool, db_id: int) -> str | None:
    """
    给 1v1 私聊注入的「拼小圈近况」背景块。
    · 该实例不在任何群 / 群里近 48h 没消息 → 返回 None（私聊零开销）
    · 30s 进程内缓存，避免每条私聊消息都查库
    · 永不抛异常 —— 任何失败都返回 None，绝不影响私聊主流程
    """
    try:
        db_id = int(db_id)
        hit = _digest_cache.get(db_id)
        if hit and hit[0] > time.monotonic():
            return hit[1]

        async with pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    "SELECT m.group_id, g.name AS group_name "
                    "FROM chat_group_members m JOIN chat_groups g ON g.id=m.group_id "
                    "WHERE m.member_type='instance' AND m.instance_id=%s", (db_id,))
                groups = await cur.fetchall()
                digest = None
                if groups:
                    blocks = []
                    cutoff = _now() - DIGEST_MAX_AGE
                    for g in groups[:3]:                       # 最多摘 3 个群
                        await cur.execute(
                            "SELECT sender_type, sender_name, content, ts "
                            "FROM chat_group_messages "
                            "WHERE group_id=%s AND ts>%s AND sender_type IN ('user','instance') "
                            "ORDER BY id DESC LIMIT %s",
                            (int(g['group_id']), cutoff, DIGEST_MSGS))
                        rows = await cur.fetchall()
                        if not rows:
                            continue
                        lines = []
                        for r in reversed(rows):
                            # 摘要统一用署名（你自己的发言也带人格名，AI 看记录更直观）
                            lines.append(f"[{_fmt_ts(r['ts'])}] [{r['sender_name']}] "
                                         f"{_strip(r['content'], 60)}")
                        blocks.append(f"群「{g['group_name']}」最近的消息：\n" + '\n'.join(lines))
                    if blocks:
                        digest = (
                            "【拼小圈群聊近况 · 系统背景 · 不是用户说的话】\n"
                            "你也在下面这些群里（你在群里的发言也会出现在记录中）：\n\n"
                            + '\n\n'.join(blocks) +
                            "\n\n（主人在私聊里问起群里的事时，你可以基于以上记录自然聊起；"
                            "主人没问就别主动复述这些内容。）"
                        )
        _digest_cache[db_id] = (time.monotonic() + DIGEST_CACHE_TTL, digest)
        return digest
    except Exception as e:
        print(f"[群聊][私聊摘要失败·已忽略] db_id={db_id}: {e}", flush=True)
        return None
